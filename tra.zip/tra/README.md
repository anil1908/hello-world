for project run use the : 'ng serve' command => localhost:4200
for project build use the ' ng build --base-href /new/ -w' command