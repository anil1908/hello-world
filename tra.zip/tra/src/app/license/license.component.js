var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientService } from '../common/http-client.service';
import { CommonService } from '../common/common.service';
import { Router } from '@angular/router';
var LicenseComponent = (function () {
    function LicenseComponent(activeModal, router, httpclient, commonService) {
        this.activeModal = activeModal;
        this.router = router;
        this.httpclient = httpclient;
        this.commonService = commonService;
        this.showInstruction = false;
        this.showIssue = false;
        this.showSuccess = false;
        this.currentCredit = 0;
        this.creditsRemaining = 0;
    }
    /* This method is call when page is load
       */
    LicenseComponent.prototype.ngOnInit = function () {
        this.issueLicense();
    };
    /*
    Get customer license detail for selected work
     */
    LicenseComponent.prototype.issueLicense = function () {
        var _this = this;
        if (this.workDetail.id != null && this.workDetail.id != undefined) {
            this.httpclient.get('user/credit_balance')
                .subscribe(function (data) {
                if (data['code'] == 200) {
                    var avail_licenses = data['data']["by_license"];
                    if (Object.keys(avail_licenses).length > 0) {
                        for (var key in avail_licenses) {
                            if (key == _this.workDetail.extra_properties.license_type) {
                                _this.currentCredit = avail_licenses[key].count;
                                _this.licenceType = key;
                            }
                        }
                    }
                    if (_this.licenceType == "" || _this.licenceType == undefined) {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], _this.commonService.globalVar['something_went_wrong']);
                    }
                    else {
                        if (_this.currentCredit >= _this.workDetail.count_for_licence) {
                            _this.showInstruction = true;
                            _this.showIssue = false;
                            _this.showSuccess = false;
                        }
                        else {
                            _this.showInstruction = false;
                            _this.showIssue = true;
                            _this.showSuccess = false;
                        }
                    }
                }
                else {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], _this.commonService.globalVar['something_went_wrong']);
                }
            }, function (error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], _this.commonService.globalVar['something_went_wrong']);
            });
        }
        else {
            this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
        }
    };
    /*
    Generate license for selected work
     */
    LicenseComponent.prototype.generateLicense = function () {
        var _this = this;
        if (this.workDetail.id != null && this.workDetail.id != undefined && this.licenceType != "" && this.licenceType != undefined) {
            // this.commonService.confirmMessagePopup(this.commonService.globalVar['confirmation'], this.commonService.globalVar['purchase_license_confirm'] + this.workDetail.name + " ?", true, true).then((result) => {
            //   if (result) {
            this.httpclient.post('project/' + this.workDetail.id + '/generate_license', { "license_type": this.licenceType })
                .subscribe(function (data) {
                if (data['code'] == 200) {
                    _this.showInstruction = false;
                    _this.showIssue = false;
                    _this.showSuccess = true;
                }
                else if (data['code'] == 500) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                }
            }, function (error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], _this.commonService.globalVar['something_went_wrong']);
            });
            //   }
            // }, (reason) => {
            // });
        }
        else {
            this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
        }
    };
    /**
     * Redirect To Another Page
     */
    LicenseComponent.prototype.moveTo = function (url) {
        this.activeModal.dismiss();
        this.router.navigate([url]);
    };
    return LicenseComponent;
}());
__decorate([
    Input(),
    __metadata("design:type", Object)
], LicenseComponent.prototype, "workDetail", void 0);
LicenseComponent = __decorate([
    Component({
        selector: 'app-license',
        templateUrl: './license.component.html',
        styleUrls: ['./license.component.css']
    }),
    __metadata("design:paramtypes", [NgbActiveModal,
        Router,
        HttpClientService,
        CommonService])
], LicenseComponent);
export { LicenseComponent };
//# sourceMappingURL=license.component.js.map