import { Component, OnInit, Input } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientService } from '../common/http-client.service';
import { CommonService } from '../common/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-license',
  templateUrl: './license.component.html',
  styleUrls: ['./license.component.css']
})
export class LicenseComponent implements OnInit {
  /* initialize variables */
  @Input() workDetail:any;
  showInstruction: boolean = false;
  showIssue: boolean = false;
  showSuccess: boolean = false;
  licenceType: String;
  currentCredit: Number = 0;
  creditsRemaining: Number = 0;
  constructor(
    public activeModal: NgbActiveModal,
    private router: Router,
    private httpclient: HttpClientService,
    private commonService: CommonService,
  ) {

  }

  /* This method is call when page is load
     */
  ngOnInit() {
    this.issueLicense();
  }

  /*
  Get customer license detail for selected work
   */
  issueLicense() {
    if (this.workDetail.id != null && this.workDetail.id != undefined) {
      this.httpclient.get('user/credit_balance')
        .subscribe(
        data => {
          if (data['code'] == 200) {
            let avail_licenses = data['data']["by_license"];
            if (Object.keys(avail_licenses).length > 0) {
              for (var key in avail_licenses) {
                if (key == this.workDetail.extra_properties.license_type) {
                  this.currentCredit = avail_licenses[key].count;
                  this.licenceType = key;
                }
              }
            }
            if (this.licenceType == "" || this.licenceType == undefined) {
              this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
            } else {
              if (this.currentCredit >= this.workDetail.count_for_licence) {
                this.showInstruction = true;
                this.showIssue = false;
                this.showSuccess = false;
              } else {
                this.showInstruction = false;
                this.showIssue = true;
                this.showSuccess = false;
              }
            }
          } else {
            this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
        });
    } else {
      this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
    }
  }

  /*
  Generate license for selected work
   */
  generateLicense() {
    if (this.workDetail.id != null && this.workDetail.id != undefined && this.licenceType != "" && this.licenceType != undefined) {
      // this.commonService.confirmMessagePopup(this.commonService.globalVar['confirmation'], this.commonService.globalVar['purchase_license_confirm'] + this.workDetail.name + " ?", true, true).then((result) => {
      //   if (result) {
      this.httpclient.post('project/' + this.workDetail.id + '/generate_license', { "license_type": this.licenceType })
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.showInstruction = false;
            this.showIssue = false;
            this.showSuccess = true;
          } else if (data['code'] == 500) {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
        });
      //   }
      // }, (reason) => {

      // });
    } else {
      this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
    }
  }
  /**
   * Redirect To Another Page
   */
  moveTo(url:any) {
    this.activeModal.dismiss();
    this.router.navigate([url]);
  }
}