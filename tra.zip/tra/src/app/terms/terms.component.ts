import { Component, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal, NgbModalOptions,ModalDismissReasons, NgbDateParserFormatter, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from '../common/common.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-terms',
  templateUrl: './terms.component.html',
  styleUrls: ['./terms.component.css']
})
export class TermsComponent implements OnInit {

  constructor(
    private modalService: NgbModal,
    private router: Router,
    public commonService: CommonService,
    public activeModal: NgbActiveModal) { }

  ngOnInit() {
  }

  acceptTerms(){
    this.activeModal.close();
    this.commonService.setLocalStorage('tos',true);
    this.router.navigate(['/user/signup']);
  }

}
