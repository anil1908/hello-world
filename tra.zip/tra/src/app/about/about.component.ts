import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common/common.service';

@Component({
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  constructor(
    public commonService: CommonService
  ) { }

  /* This method is call when page is load
     */
  ngOnInit() {
  }

}
