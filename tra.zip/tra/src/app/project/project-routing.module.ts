import { NgModule } from '@angular/core';
import { RouterModule, Routes, ROUTER_CONFIGURATION } from '@angular/router';
import 'rxjs/Rx';

import { ProjectComponent } from './project.component';
import { ProjectGuard } from './project.guard';
import { AuthGuard } from '../common/auth.guard';
import { UnauthGuard } from '../common/auth.guard';
import { VideosComponent } from '../videos/videos.component';
import { SignupComponent } from '../signup/signup.component';

const projectRoutes: Routes = [
  {
    path: '',
    component: ProjectComponent,
    canActivate: [ProjectGuard],
    children: [
      {
        path: 'videos',
        component: VideosComponent,
        canActivate: [AuthGuard],
        data: {
          title: 'Videos'
        }
      },
    ]
  }
];

export const projectrouting = RouterModule.forRoot(projectRoutes);
@NgModule({
  imports: [
    RouterModule.forChild(projectRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    ProjectGuard
  ]
})
export class ProjectRoutingModule { }

