import { NgModule, ElementRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateService } from 'ng2-translate';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {MomentModule} from 'angular2-moment';
import {ShareButtonsModule} from "ng2-sharebuttons";

import { ProjectRoutingModule } from './project-routing.module';
import { ProjectComponent } from './project.component';

import { VideosComponent } from '../videos/videos.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ProjectRoutingModule,
    NgbModule.forRoot(),
    MomentModule,
    TranslateModule.forRoot(),
    ShareButtonsModule.forRoot()
  ],
  declarations: [
    ProjectComponent,
    VideosComponent
  ],
  providers: [
    TranslateService
  ]
})
export class ProjectModule {

}