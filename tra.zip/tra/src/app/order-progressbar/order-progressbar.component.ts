import { Component, Input, OnInit } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'app-order-progressbar',
  templateUrl: './order-progressbar.component.html',
  styleUrls: ['./order-progressbar.component.css']
})
export class OrderProgressbarComponent implements OnInit {
  timesec: number = 10;
  constructor(public activeModal: NgbActiveModal) { }

  ngOnInit() {
    const source = Observable
      .timer(1000, 1000)
      .subscribe(tick => {
        this.timesec+=10;
        document.getElementById("processvideobar").style.width = this.timesec+"%";
      });

    setTimeout(() => {
      source.unsubscribe();
      this.activeModal.close(true);
    }, 10000);
  }

  confirmOk() {
    this.activeModal.close(true);
  }

}
