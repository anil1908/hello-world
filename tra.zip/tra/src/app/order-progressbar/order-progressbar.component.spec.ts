import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderProgressbarComponent } from './order-progressbar.component';

describe('OrderProgressbarComponent', () => {
  let component: OrderProgressbarComponent;
  let fixture: ComponentFixture<OrderProgressbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderProgressbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderProgressbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
