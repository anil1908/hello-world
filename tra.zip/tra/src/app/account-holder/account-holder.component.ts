import { Component, Input, OnInit } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { LoginComponent } from '../login/login.component';

@Component({
  selector: 'app-account-holder',
  templateUrl: './account-holder.component.html',
  styleUrls: ['./account-holder.component.css']
})
export class AccountHolderComponent implements OnInit {
  @Input() title: any;
  @Input() message: any;

  constructor(
    private router: Router,
    private modalService: NgbModal,
    public activeModal: NgbActiveModal
    ) { }

  ngOnInit() {
  }

  moveTo(url) {
    this.activeModal.close();
    this.router.navigate([url]);
  }

  /**
   * Show Login Popup
   */
  showLoginPopup() {
    this.activeModal.close();
    this.modalService.open(LoginComponent).result.then((result) => {
      
    }, (reason) => {
      
    });
  };

}
