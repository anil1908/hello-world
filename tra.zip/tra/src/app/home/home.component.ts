import { Component,NgZone, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal,NgbModalOptions, ModalDismissReasons, NgbDateParserFormatter, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
import { LoginComponent } from '../login/login.component';
import {PageScrollConfig} from 'ng2-page-scroll';

@Component({
  templateUrl: './home.component.html',
  host: {
    '(document:click)': 'handleClick($event)',
  },
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  /* initialize variables */
  tracks : string = '';
  filteredList: Object = { albums: [], artists: [], tracks: [] };
  selectedIdx: number;
  collectionList: any = [];
  collectionInfo: any;

  constructor(
    private modalService: NgbModal,
    public commonService: CommonService,
    private httpclient: HttpClientService,
    private router: Router
  ) {
    PageScrollConfig.defaultDuration = 700;
    this.selectedIdx = -1;
  }
  /* This method is call when page is load
   */
  ngOnInit() {
    this.commonService.updateLogin();
    this.getCollectionList();
    let ispopup = this.commonService.getLocalStorage('isloginpopup');
    if(ispopup!==null && ispopup!==undefined && ispopup!==''){
      this.showLoginPopup();
      this.commonService.removeLocalStorage('isloginpopup')
    }
  }

  /**
   * Filter Result
   */
  filterTracks(event: any) {
    if (this.tracks !== "" && this.tracks.length > 2) {
      this.httpclient.post('search/autocomplete', { txt: this.tracks })
        .subscribe(
        data => {
          this.filteredList = {
            albums: data['data']['albums'],
            artists: data['data']['artists'],
            tracks: data['data']['tracks']
          };
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    } else {
      this.filteredList = { albums: [], artists: [], tracks: [] };
    }
  }

  /*
  Redirect to search page based on selection
   */
  searchResult(data: any = null, type: any) {
    let queryParams: Object = {};
    if (type == "tracks") {
      queryParams = {
        track_name: data.track_name,
        id: data.artist_id,
        type: "tracks",
      }
    } else if (type == "artist_tracks") {
      queryParams = {
        id: data.artist_id,
        type: "artists",
      }
    } else if (type == "album_tracks") {
      queryParams = {
        id: data.album_id,
        type: "albums",
      }
    } else if (type == "collection") {
      queryParams = {
        id: data.id,
        type: "collection",
      }
    } else if (type == "full" && this.tracks != "") {
      queryParams = {
        type: "full",
        track_name: this.tracks,
      }
    } else {
      queryParams = null;
    }

   
    if (queryParams != null) {
      this.router.navigate(['/search'], { queryParams: queryParams });
    }
  }

  select(item:any) {
    this.tracks = item;
    this.filteredList = { albums: [], artists: [], tracks: [] };
    this.selectedIdx = -1;
  }

  handleClick(event:any) {
    this.filteredList = { albums: [], artists: [], tracks: [] };
    this.selectedIdx = -1;
  }
  /*
   Get system defined collection/playlist
    */
  getCollectionList() {
    let data: Object;
    this.httpclient.post('admin/public_playlists/read', data)
      .subscribe(
      data => {
        if (data['code'] == 200) {
          this.collectionList = data['data'];
        }
      },
      error => {
        this.commonService.messagePopup(this.commonService.globalVar['error'], error);
      });
  }
  /**
   * Show Login Popup
   */
  showLoginPopup() {
    this.modalService.open(LoginComponent).result.then((result) => {
      
    }, (reason) => {
      
    });
  };

}