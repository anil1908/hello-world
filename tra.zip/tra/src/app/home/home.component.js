var __decorate = (this && this.__decorate) || function(decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
        d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else
        for (var i = decorators.length - 1; i >= 0; i--)
            if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
import { LoginComponent } from '../login/login.component';
import { PageScrollConfig } from 'ng2-page-scroll';
var HomeComponent = (function() {
    function HomeComponent(modalService, commonService, httpclient, router) {
        this.modalService = modalService;
        this.commonService = commonService;
        this.httpclient = httpclient;
        this.router = router;
        /* initialize variables */
        this.tracks = '';
        this.filteredList = { albums: [], artists: [], tracks: [] };
        this.collectionList = [];
        PageScrollConfig.defaultDuration = 700;
        this.selectedIdx = -1;
    }
    /* This method is call when page is load
     */
    HomeComponent.prototype.ngOnInit = function() {
        this.commonService.updateLogin();
        this.getCollectionList();
        var ispopup = this.commonService.getLocalStorage('isloginpopup');
        if (ispopup !== null && ispopup !== undefined && ispopup !== '') {
            this.showLoginPopup();
            this.commonService.removeLocalStorage('isloginpopup');
        }
    };
    /**
     * Filter Result
     */
    HomeComponent.prototype.filterTracks = function(event) {
        var _this = this;
        if (this.tracks !== "" && this.tracks.length > 2) {
            this.httpclient.post('search/autocomplete', { txt: this.tracks })
                .subscribe(function(data) {
                    _this.filteredList = {
                        albums: data['data']['albums'],
                        artists: data['data']['artists'],
                        tracks: data['data']['tracks']
                    };
                }, function(error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
        } else {
            this.filteredList = { albums: [], artists: [], tracks: [] };
        }
    };
    /*
    Redirect to search page based on selection
     */
    HomeComponent.prototype.searchResult = function(data, type) {
        if (data === void 0) { data = null; }
        var queryParams = {};
        if (type == "tracks") {
            queryParams = {
                track_name: data.track_name,
                id: data.artist_id,
                type: "tracks",
            };
        } else if (type == "artist_tracks") {
            queryParams = {
                id: data.artist_id,
                type: "artists",
            };
        } else if (type == "album_tracks") {
            queryParams = {
                id: data.album_id,
                type: "albums",
            };
        } else if (type == "collection") {
            queryParams = {
                id: data.id,
                type: "collection",
            };
        } else if (type == "full" && this.tracks != "") {
            queryParams = {
                type: "full",
                track_name: this.tracks,
            };
        } else {
            queryParams = null;
        }
        if (queryParams != null) {
            this.router.navigate(['/search'], { queryParams: queryParams });
        }
    };
    HomeComponent.prototype.select = function(item) {
        this.tracks = item;
        this.filteredList = { albums: [], artists: [], tracks: [] };
        this.selectedIdx = -1;
    };
    HomeComponent.prototype.handleClick = function(event) {
        this.filteredList = { albums: [], artists: [], tracks: [] };
        this.selectedIdx = -1;
    };
    /*
     Get system defined collection/playlist
      */
    HomeComponent.prototype.getCollectionList = function() {
        var _this = this;
        var data;
        this.httpclient.post('admin/public_playlists/read', data)
            .subscribe(function(data) {
                if (data['code'] == 200) {
                    _this.collectionList = data['data'];
                }
            }, function(error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
            });
    };
    /**
     * Show Login Popup
     */
    HomeComponent.prototype.showLoginPopup = function() {
        this.modalService.open(LoginComponent).result.then(function(result) {

        }, function(reason) {

        });
    };;
    return HomeComponent;
}());
HomeComponent = __decorate([
    Component({
        templateUrl: './home.component.html',
        host: {
            '(document:click)': 'handleClick($event)',
        },
        styleUrls: ['./home.component.css']
    }),
    __metadata("design:paramtypes", [NgbModal,
        CommonService,
        HttpClientService,
        Router
    ])
], HomeComponent);
export { HomeComponent };
//# sourceMappingURL=home.component.js.map