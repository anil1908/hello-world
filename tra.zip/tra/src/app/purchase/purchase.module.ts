import { NgModule, ElementRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateService } from 'ng2-translate';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ObjarrPipe } from './objarr.pipe';

import { PurchaseRoutingModule } from './purchase-routing.module';
import { PurchaseComponent } from './purchase.component';
import { PaypalResponseComponent } from '../paypal-response/paypal-response.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    PurchaseRoutingModule,
    NgbModule.forRoot(),
    TranslateModule.forRoot()
  ],
  declarations: [
    PurchaseComponent,
    ObjarrPipe,
    PaypalResponseComponent
  ],
  providers: [
    TranslateService
  ]
})
export class PurchaseModule {

}