import { Injectable } from '@angular/core';
import {Router, CanActivate, Resolve, RouterStateSnapshot,ActivatedRouteSnapshot } from '@angular/router';

@Injectable()
export class PurchaseGuard implements CanActivate {

  constructor(
    private router: Router,
  ) {

  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return true;
  }


}