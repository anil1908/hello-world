import { Pipe, PipeTransform, Injectable } from '@angular/core';
import { CommonService } from '../common/common.service';

@Pipe({
  name: 'objarr',
  pure: false
})

export class ObjarrPipe implements PipeTransform {
  transform(value: any, args: string = ''): any {
    var a = [];
    for (var key in value) {
      if (value.hasOwnProperty(key)) {
        if (args === 'key') {
          //return key
          a.push(key);
        } else if (args === 'value') {
          //return value
          a.push(value[key]);
        }
        else {
          //return key and value
          a.push({ objKey: key, objValue: value[key] });
        }
      }
    }
    return a;
  }
}
