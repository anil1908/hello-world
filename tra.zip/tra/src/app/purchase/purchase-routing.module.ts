import { NgModule } from '@angular/core';
import { RouterModule, Routes, ROUTER_CONFIGURATION } from '@angular/router';
import 'rxjs/Rx';

import { PurchaseComponent } from './purchase.component';
import { PurchaseGuard } from './purchase.guard';
import { AuthGuard } from '../common/auth.guard';
import { UnauthGuard } from '../common/auth.guard';
import { PaypalResponseComponent } from '../paypal-response/paypal-response.component';

const userRoutes: Routes = [
  {
    path: '',
    component: PurchaseComponent,
    canActivate: [PurchaseGuard],
    children: [
      {
        path: 'close_verified_order/:id',
        component: PaypalResponseComponent,
        canActivate: [AuthGuard],
        data: {
          title: 'Credit'
        }
      },
      {
        path: 'close_invalid_order/:id',
        component: PaypalResponseComponent,
        canActivate: [AuthGuard],
        data: {
          title: 'Credit'
        }
      },
      {
        path: 'cancel/:id',
        component: PaypalResponseComponent,
        canActivate: [AuthGuard],
        data: {
          title: 'Credit'
        }
      }
    ],
    data: {
      title: 'Credit'
    }
  }
];

export const userrouting = RouterModule.forRoot(userRoutes);
@NgModule({
  imports: [
    RouterModule.forChild(userRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    PurchaseGuard
  ]
})
export class PurchaseRoutingModule { }

