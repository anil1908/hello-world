import { Component, Input } from '@angular/core';
import { TranslateService } from 'ng2-translate';
import { NgbActiveModal, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';

@Component({
  templateUrl: './purchase.component.html',
})
export class PurchaseComponent {
  /* initialize variables */
  purchaseData: Object = {};
  purchaseOffer: Object = {};
  offerQuantity: Array<number> = [1, 2, 3, 4, 5];
  selectedQuantity: number = 1;
  cartData: Object = {};
  totalObj: Object = { total: 0, code: '' };
  useageType: Object = {};
  order_id: any;
  isgetCredit: boolean = false;

  constructor(
    private translate: TranslateService,
    private commonService: CommonService,
    private modalService: NgbModal,
    private httpclient: HttpClientService
  ) {
  }

  /* This method is call when page is load
     */
  ngOnInit() {
    this.translate.addLangs(['en', 'fr']);
    this.translate.setDefaultLang('en');
    let browserLang = this.translate.getBrowserLang();
    this.translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
    this.getPlans();
  }
  /**
   * get Purchse Plans list
   */
  getPlans() {
    this.httpclient.get('purchase/credit_plans')
      .subscribe(
      data => {
        this.isgetCredit = true;
        if (data['code'] == 200) {
          data['data'].forEach(purchasevalue => {
            //create daynamic object
            if (this.purchaseData[purchasevalue.license_type] === undefined && purchasevalue.purchase_group !== 'special_offer' && purchasevalue.license_type !== '') {
              this.purchaseData[purchasevalue.license_type] = {
                bundle: [],
                single: []
              };
            }
            //special offer object
            if (purchasevalue.purchase_group === 'special_offer') {
              this.purchaseOffer = purchasevalue;
              this.purchaseOffer['maincost'] = this.purchaseOffer['cost'];
            }
            //usage type object
            if (purchasevalue.purchase_group !== 'special_offer' && purchasevalue.purchase_group !== '') {
              this.purchaseData[purchasevalue.license_type][purchasevalue.purchase_group].push(purchasevalue);
            }
          });
          let cartdata = this.commonService.getLocalStorage('purdata');
          if (cartdata !== null && cartdata !== '' && cartdata !== undefined) {
            this.useageType = cartdata;
            this.manageCart(cartdata);
          }
        }
        else {
          this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
        }
      },
      error => {
        this.isgetCredit = true;
      });
  }
  /**
   * add special offer in cart
   */
  addSpecialOffer() {
    let cartdata = (this.commonService.getLocalStorage('purdata') !== null && this.commonService.getLocalStorage('purdata') !== undefined && this.commonService.getLocalStorage('purdata') !== '') ? this.commonService.getLocalStorage('purdata') : {};
    cartdata['special'] = this.selectedQuantity;
    this.cartData['special'] = this.purchaseOffer;
    this.cartData['special']['cost'] = this.cartData['special']['maincost'] * this.selectedQuantity;
    this.commonService.setLocalStorage('purdata', cartdata);
    this.totalAmount();
  }
  /**
   * Change Special Offer Quantity
   */
  changeOfferQuantity() {
    this.purchaseOffer['cost'] = this.purchaseOffer['maincost'] * this.selectedQuantity;
  }
  /**
   * add credit to cart
   */
  addCredit(type, group, index) {
    let cartdata = this.commonService.getLocalStorage('purdata');
    if (cartdata !== null && cartdata[type] !== undefined) {
      delete cartdata[type];
    }
    let obj = {};
    obj[type] = type + group + index;
    this.manageCart(obj);
  }
  /**
   * Manage Cart
   */
  manageCart(cart) {
    for (let key in cart) {
      if (key != 'special') {
        let dataArr = cart[key].split('/');
        this.cartData[key] = this.purchaseData[dataArr[0]][dataArr[1]][dataArr[2]];
      }
      else {
        this.selectedQuantity = cart[key];
        this.purchaseOffer['cost'] = this.purchaseOffer['maincost'] * this.selectedQuantity;
        this.cartData[key] = this.purchaseOffer;
      }
      let addobj = (this.commonService.getLocalStorage('purdata') !== null && this.commonService.getLocalStorage('purdata') !== undefined && this.commonService.getLocalStorage('purdata') !== '') ? this.commonService.getLocalStorage('purdata') : {};
      addobj[key] = cart[key];
      this.commonService.setLocalStorage("purdata", addobj);
    }
    this.totalAmount();
  }
  /**
   * Calculate Total Amount
   */
  totalAmount() {
    var total = 0;
    var currencyCode = '';
    for (let key in this.cartData) {
      currencyCode = this.cartData[key]['currency'];
      total += this.cartData[key]['cost'];
    }
    this.totalObj = { total: total, code: currencyCode };
  }
  /**
   * Delete Cart Item
   */
  deleteItem(key) {
    if (key !== null && key !== undefined && key !== '') {
      let cartdata = this.commonService.getLocalStorage('purdata');
      delete cartdata[key];
      delete this.cartData[key];
      delete this.useageType[key];
      this.commonService.setLocalStorage("purdata", cartdata);
      this.totalAmount();
    }
  }
  /**
   * place Order
   */
  placeOrder() {
    var cartArr = [];
    this.order_id = [];
    for (var key in this.cartData) {
      let purchaseObj = {
        "plan_id": this.cartData[key]['id'],
        "name": this.cartData[key]['name'],
        "count": this.cartData[key]['count'],
        "type": this.cartData[key]['license_type'],
        "duration_days": this.cartData[key]['duration_days'],
        "cost": this.cartData[key]['cost'],
        "totalcost": (key === 'special') ? this.cartData[key]['maincost'] : this.cartData[key]['cost'],
        "quantity": (key === 'special') ? this.selectedQuantity : '1'
      };
      cartArr.push(purchaseObj);
      this.httpclient.post('purchase/place_open_order', { purchase_item: purchaseObj })
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.order_id.push(data['data']['order_id']);
            if (cartArr.length == this.order_id.length) {
              this.order_id = this.order_id.join(",");
              this.paypalPayment(cartArr);
            }
          }
          else {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
          }
        },
        error => {

        });
    }
  }
  /**
   * Paypal Submit
   */
  paypalPayment(cartArr) {
    var form = document.createElement("form");
    form.method = "POST";
    form.action = this.commonService.paypalObj['paypalUrl'];
    this.createElement(form, 'email', this.commonService.userDetail['email']);
    this.createElement(form, 'first_name', this.commonService.userDetail['first_name']);
    this.createElement(form, 'last_name', this.commonService.userDetail['last_name']);
    this.createElement(form, 'cmd', '_cart');
    this.createElement(form, 'test_ipn', '1');
    this.createElement(form, 'upload', '1');
    this.createElement(form, 'charset', 'utf-8');
    this.createElement(form, 'business', "buyer@catchmedia.com");
    this.createElement(form, 'currency_code', 'USD');
    this.createElement(form, 'custom', '{ "order_id": "' + this.order_id + '" }');
    for (var key in cartArr) {
      this.createElement(form, 'item_name_' + (parseInt(key) + 1), cartArr[key]['name']);
      this.createElement(form, 'amount_' + (parseInt(key) + 1), cartArr[key]['totalcost']);
      this.createElement(form, 'quantity_' + (parseInt(key) + 1), cartArr[key]['quantity']);
    }
    this.createElement(form, 'return', this.httpclient.domainUrl + 'events?st=success&order=' + this.order_id);
    this.createElement(form, 'cancel_return', this.httpclient.domainUrl + 'events?st=fail&order=' + this.order_id);
    this.createElement(form, 'notify_url', "http://tracks-qa.catchmedia.com/payment/paypal/ipn");
    document.body.appendChild(form);
    this.commonService.setCookie('isPurchase', "true");
    setTimeout(function () {
      form.submit();
    }, 1000);
  }
  /**
   * create input element
   */
  createElement(form, name, value) {
    var element = document.createElement("input");
    element.name = name;
    element.value = value;
    element.type = 'hidden'
    form.appendChild(element);
  }

}
