import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpModule, URLSearchParams, ConnectionBackend, RequestOptionsArgs, Headers, RequestOptions, Http, Request, Response } from '@angular/http';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientService } from '../common/http-client.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import { CommonService } from '../common/common.service';
import { ValidationService } from '../common/validation.service';
import { HeaderComponent } from '../header/header.component';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';

@Component({
  templateUrl: './login.component.html',
  //styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  /* initialize variables */
  public myValue: number = 3;
  loginForm: FormGroup;
  ForgotPasswordForm: FormGroup;
  returnUrl: string;
  submitted: boolean = false;
  forgotSubmitted: boolean = false;
  showLoginForm: boolean = true;
  showForgotForm: boolean = false;
  showForgotSuccess: boolean = false;
  mailSentTo: string = "";
  //set server side error message Object
  msg: Object = { issuccess: false, isError: false, msg: '' };
  msgForget: Object = { issuccess: false, isError: false, msg: '' };

  constructor(
    private http: Http,
    public fb: FormBuilder,
    public activeModal: NgbActiveModal,
    private router: Router,
    private httpclient: HttpClientService,
    private commonService: CommonService,
    private validationService: ValidationService,
  ) {

  }

  /* This method is call when page is load
   */
  ngOnInit() {
    /* Create login form and set validation rules */
    this.loginForm = this.fb.group({
      'username': ['', Validators.compose([Validators.required, this.validationService.emailValidator])],
      'password': ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(50)])],
      'remember_me': [true]
    });

    //Create forgot password form and set validation rules
    this.ForgotPasswordForm = this.fb.group({
      'email': ['', Validators.compose([Validators.required, this.validationService.emailValidator])],
    });
  }

  /**
  * Show Hide forms based on clicks.
  */
  showHideForms(formName:any) {
    switch (formName) {
      case "login":
        this.forgotSubmitted = false;
        this.showLoginForm = true;
        this.showForgotForm = false;
        this.showForgotSuccess = false;
        this.ForgotPasswordForm.controls['email'].setValue('');
        break;
      case "forgot":
        this.submitted = false;
        this.showLoginForm = false;
        this.showForgotForm = true;
        this.showForgotSuccess = false;
        this.loginForm.controls['username'].setValue('');
        this.loginForm.controls['password'].setValue('');
        break;
      case "success":
        this.showLoginForm = false;
        this.showForgotForm = false;
        this.showForgotSuccess = true;
        break;
    }
  }

  /**
   * Login Request
   */
  submitLogin(usernamefocus,userpasswordfocus): void {
    if (this.loginForm.valid) {
      this.loginForm.controls['username'].setValue(this.loginForm.controls['username'].value.trim());
      var isremember = this.loginForm.value.remember_me;
      let ispopup = this.commonService.getLocalStorage('iscredential');
      let withcredential = true;
      if (ispopup !== null && ispopup !== undefined && ispopup !== '') {
        withcredential = false;
        this.commonService.removeLocalStorage('iscredential');
      }
      this.httpclient.post('user/signin_submit', this.loginForm.value, {}, withcredential)
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.msg['isError'] = this.msg['isSuccess'] = false;
            this.commonService.setCookie("isLogin", "true");
            this.commonService.setLocalStorage('remember_me', isremember);
            this.commonService.setLocalStorage('userDetail', data['data']);
            this.commonService.updateLogin();
            //check user is collaborator or videographer
            this.commonService.is_regular_account = (this.commonService.userDetail["extra_data"].tracks_is_regular_account != null && this.commonService.userDetail["extra_data"].tracks_is_regular_account != undefined) ? this.commonService.userDetail["extra_data"].tracks_is_regular_account : "1";
            if (this.commonService.is_regular_account == '1') {
              this.commonService.getUserCredit();
              this.commonService.getUserFavorite();
            }
            this.activeModal.close();
            this.router.navigate(['/events']);
          } else if (data['code'] == 500) {
            this.msg = { issuccess: false, isError: true, msg: data['message'][0] }
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['warning'], error);
        });
    }
    else {
      if(!this.loginForm.controls['username'].valid){
        usernamefocus.focus();
      }
      else{
        userpasswordfocus.focus();
      }
      this.msg['isError'] = this.msg['isSuccess'] = false;
      this.submitted = true;
    }
  }
  /**
    * Forgot Password Request
    */
  submitForgotPasswordForm(forgetemail): void {
    if (this.ForgotPasswordForm.valid) {
      this.httpclient.post('user/forgot_password_submit', this.ForgotPasswordForm.value)
        .subscribe(
        data => {
          this.showLoginForm = false;
          this.showForgotForm = false;
          this.showForgotSuccess = true;
          /*if (data['code'] == 200) {
            this.msgForget['isError'] = this.msgForget['isSuccess'] = false;
            this.showLoginForm = false;
            this.showForgotForm = false;
            this.showForgotSuccess = true;
            this.mailSentTo = this.ForgotPasswordForm.value.email;
          } else if (data['code'] == 500) {
            this.forgotSubmitted = true;
            this.msgForget = { issuccess: false, isError: true, msg: data['message'][0] }
          }*/
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      forgetemail.focus();
      this.msgForget['isError'] = this.msgForget['isSuccess'] = false;
      this.forgotSubmitted = true;
    }
  }


}