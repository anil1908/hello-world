var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Http } from '@angular/http';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientService } from '../common/http-client.service';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../common/common.service';
import { ValidationService } from '../common/validation.service';
var LoginComponent = (function () {
    function LoginComponent(http, fb, activeModal, router, httpclient, commonService, validationService) {
        this.http = http;
        this.fb = fb;
        this.activeModal = activeModal;
        this.router = router;
        this.httpclient = httpclient;
        this.commonService = commonService;
        this.validationService = validationService;
        /* initialize variables */
        this.myValue = 3;
        this.submitted = false;
        this.forgotSubmitted = false;
        this.showLoginForm = true;
        this.showForgotForm = false;
        this.showForgotSuccess = false;
        this.mailSentTo = "";
        //set server side error message Object
        this.msg = { issuccess: false, isError: false, msg: '' };
        this.msgForget = { issuccess: false, isError: false, msg: '' };
    }
    /* This method is call when page is load
     */
    LoginComponent.prototype.ngOnInit = function () {
        /* Create login form and set validation rules */
        this.loginForm = this.fb.group({
            'username': ['', Validators.compose([Validators.required, this.validationService.emailValidator])],
            'password': ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(50)])],
            'remember_me': [true]
        });
        //Create forgot password form and set validation rules
        this.ForgotPasswordForm = this.fb.group({
            'email': ['', Validators.compose([Validators.required, this.validationService.emailValidator])],
        });
    };
    /**
    * Show Hide forms based on clicks.
    */
    LoginComponent.prototype.showHideForms = function (formName) {
        switch (formName) {
            case "login":
                this.forgotSubmitted = false;
                this.showLoginForm = true;
                this.showForgotForm = false;
                this.showForgotSuccess = false;
                this.ForgotPasswordForm.controls['email'].setValue('');
                break;
            case "forgot":
                this.submitted = false;
                this.showLoginForm = false;
                this.showForgotForm = true;
                this.showForgotSuccess = false;
                this.loginForm.controls['username'].setValue('');
                this.loginForm.controls['password'].setValue('');
                break;
            case "success":
                this.showLoginForm = false;
                this.showForgotForm = false;
                this.showForgotSuccess = true;
                break;
        }
    };
    /**
     * Login Request
     */
    LoginComponent.prototype.submitLogin = function () {
        var _this = this;
        if (this.loginForm.valid) {
            this.loginForm.controls['username'].setValue(this.loginForm.controls['username'].value.trim());
            var isremember = this.loginForm.value.remember_me;
            var ispopup = this.commonService.getLocalStorage('iscredential');
            var withcredential = true;
            if (ispopup !== null && ispopup !== undefined && ispopup !== '') {
                withcredential = false;
                this.commonService.removeLocalStorage('iscredential');
            }
            this.httpclient.post('user/signin_submit', this.loginForm.value, {}, withcredential)
                .subscribe(function (data) {
                if (data['code'] == 200) {
                    _this.msg['isError'] = _this.msg['isSuccess'] = false;
                    _this.commonService.setCookie("isLogin", "true");
                    _this.commonService.setLocalStorage('remember_me', isremember);
                    _this.commonService.setLocalStorage('userDetail', data['data']);
                    _this.commonService.updateLogin();
                    //check user is collaborator or videographer
                    _this.commonService.is_regular_account = (_this.commonService.userDetail["extra_data"].tracks_is_regular_account != null && _this.commonService.userDetail["extra_data"].tracks_is_regular_account != undefined) ? _this.commonService.userDetail["extra_data"].tracks_is_regular_account : "1";
                    if (_this.commonService.is_regular_account == '1') {
                        _this.commonService.getUserCredit();
                        _this.commonService.getUserFavorite();
                    }
                    _this.activeModal.close();
                    _this.router.navigate(['/events']);
                }
                else if (data['code'] == 500) {
                    _this.msg = { issuccess: false, isError: true, msg: data['message'][0] };
                }
            }, function (error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['warning'], error);
            });
        }
        else {
            this.msg['isError'] = this.msg['isSuccess'] = false;
            this.submitted = true;
        }
    };
    /**
      * Forgot Password Request
      */
    LoginComponent.prototype.submitForgotPasswordForm = function () {
        var _this = this;
        if (this.ForgotPasswordForm.valid) {
            this.httpclient.post('user/forgot_password_submit', this.ForgotPasswordForm.value)
                .subscribe(function (data) {
                _this.showLoginForm = false;
                _this.showForgotForm = false;
                _this.showForgotSuccess = true;
                /*if (data['code'] == 200) {
                  this.msgForget['isError'] = this.msgForget['isSuccess'] = false;
                  this.showLoginForm = false;
                  this.showForgotForm = false;
                  this.showForgotSuccess = true;
                  this.mailSentTo = this.ForgotPasswordForm.value.email;
                } else if (data['code'] == 500) {
                  this.forgotSubmitted = true;
                  this.msgForget = { issuccess: false, isError: true, msg: data['message'][0] }
                }*/
            }, function (error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
            });
        }
        else {
            this.msgForget['isError'] = this.msgForget['isSuccess'] = false;
            this.forgotSubmitted = true;
        }
    };
    return LoginComponent;
}());
LoginComponent = __decorate([
    Component({
        templateUrl: './login.component.html',
    }),
    __metadata("design:paramtypes", [Http,
        FormBuilder,
        NgbActiveModal,
        Router,
        HttpClientService,
        CommonService,
        ValidationService])
], LoginComponent);
export { LoginComponent };
//# sourceMappingURL=login.component.js.map