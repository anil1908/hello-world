var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClientService } from '../common/http-client.service';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../common/common.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
var GalleryComponent = (function () {
    function GalleryComponent(modalService, fb, router, route, httpclient, commonService) {
        this.modalService = modalService;
        this.fb = fb;
        this.router = router;
        this.route = route;
        this.httpclient = httpclient;
        this.commonService = commonService;
        /* initialize variables */
        this.galleryData = [];
        this.showGalleryForm = false;
        this.galleryFormSubmitted = false;
        this.galleryMsg = { issuccess: false, isError: false, msg: '' };
        this.is_show_empty_msg = false;
        this.creator = '';
    }
    /* This method is call when page is load
       */
    GalleryComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.userData = this.commonService.userDetail;
        this.route.params.subscribe(function (params) {
            _this.galleryPage = params['id'];
        });
        if (this.userData.extra_data.tracks_is_regular_account == '0' || !this.commonService.isLogin) {
            this.commonService.galleryPage['isGuest'] = true;
        }
        else {
            this.commonService.galleryPage['isGuest'] = false;
        }
        this.galleryForm = this.fb.group({
            'gallery_page': [this.galleryPage, Validators.compose([Validators.required, Validators.maxLength(100)])]
        });
        this.getAllGalleryVideos();
    };
    /**
     * Get All Gallery Videos
     */
    GalleryComponent.prototype.getAllGalleryVideos = function () {
        var _this = this;
        this.httpclient.get('gallery/videos/' + this.galleryPage)
            .subscribe(function (data) {
            _this.is_show_empty_msg = true;
            if (data['code'] == 200) {
                _this.creator = data['data']['creator'];
                _this.galleryData = data['data']['videos'];
            }
            else if (data['code'] == 500) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
            }
        }, function (error) {
            _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
        });
    };
    /**
     * save Gallery Name
     */
    GalleryComponent.prototype.saveGalleryName = function () {
        var _this = this;
        if (this.galleryForm.valid) {
            this.httpclient.post('user/account/update', this.galleryForm.value)
                .subscribe(function (data) {
                if (data['code'] == 200) {
                    _this.galleryMsg = { issuccess: false, isError: false, msg: '' };
                    /*If name saved successfully then update related variables */
                    _this.commonService.userDetail["gallery_page"] = _this.galleryForm.value.gallery_page;
                    _this.commonService.setLocalStorage('userDetail', _this.commonService.userDetail);
                    _this.userData.gallery_page = _this.galleryForm.value.gallery_page;
                    _this.showGalleryForm = false;
                    //set success message
                    _this.commonService.successMsg = { "show": true, "msg": "<strong>" + _this.commonService.globalVar['gallery_success_message'] + "</strong>" };
                    _this.router.navigate(['/gallery', _this.galleryForm.value["gallery_page"]]);
                }
                else if (data['code'] == 500) {
                    _this.galleryMsg = { issuccess: false, isError: true, msg: data['message'][0] };
                }
            }, function (error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
            });
        }
        else {
            this.galleryFormSubmitted = true;
        }
    };
    /**
     * check Pattern
     */
    GalleryComponent.prototype.keyPress = function (event) {
        var pattern = /[a-z0-9_-]/;
        var inputChar = String.fromCharCode(event.charCode);
        if (!pattern.test(inputChar)) {
            // invalid character, prevent input
            event.preventDefault();
        }
    };
    /**
     * guest view enable
     */
    GalleryComponent.prototype.viewGuest = function () {
        this.commonService.galleryPage['isGuest'] = true;
    };
    /**
     * Learn more tracks
     */
    GalleryComponent.prototype.moreTracks = function () {
    };
    /**
     * delete video
     */
    GalleryComponent.prototype.deleteVideo = function (gallery) {
    };
    return GalleryComponent;
}());
GalleryComponent = __decorate([
    Component({
        templateUrl: './gallery.component.html',
        styleUrls: ['./gallery.component.css']
    }),
    __metadata("design:paramtypes", [NgbModal,
        FormBuilder,
        Router,
        ActivatedRoute,
        HttpClientService,
        CommonService])
], GalleryComponent);
export { GalleryComponent };
//# sourceMappingURL=gallery.component.js.map