import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClientService } from '../common/http-client.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../common/common.service';
import { NgbActiveModal, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {
  /* initialize variables */
  galleryData: Array<any> = [];
  galleryForm: FormGroup;
  userData: any;
  galleryPage : any;
  showGalleryForm: boolean = false;
  galleryFormSubmitted: boolean = false;
  galleryMsg: Object = { issuccess: false, isError: false, msg: '' };
  is_show_empty_msg = false;
  creator: any = '';

  constructor(
    private modalService: NgbModal,
    public fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private httpclient: HttpClientService,
    public commonService: CommonService
  ) { 
    
  }

  /* This method is call when page is load
     */
  ngOnInit() {
    this.userData = this.commonService.userDetail;
    this.route.params.subscribe(params => {
       this.galleryPage = params['id'];
    });
    if(this.userData.extra_data.tracks_is_regular_account=='0' || !this.commonService.isLogin){
      this.commonService.galleryPage['isGuest'] = true;
    }else{
      this.commonService.galleryPage['isGuest'] = false;
    }
    this.galleryForm = this.fb.group({
      'gallery_page': [this.galleryPage, Validators.compose([Validators.required, Validators.maxLength(100)])]
    });
    this.getAllGalleryVideos();
  }

  /**
   * Get All Gallery Videos
   */
  getAllGalleryVideos() {
    this.httpclient.get('gallery/videos/' + this.galleryPage)
      .subscribe(
      data => {
        this.is_show_empty_msg = true;
        if (data['code'] == 200) {
          this.creator = data['data']['creator'];
          this.galleryData = data['data']['videos'];
        }
        else if (data['code'] == 500) {
          this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
        }
      },
      error => {
        this.commonService.messagePopup(this.commonService.globalVar['error'], error);
      });
  }
  /**
   * save Gallery Name
   */
  saveGalleryName(gallerypagefocus): void {
    if (this.galleryForm.valid) {
      this.httpclient.post('user/account/update', this.galleryForm.value)
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.galleryMsg = { issuccess: false, isError: false, msg: '' }
            /*If name saved successfully then update related variables */
            this.commonService.userDetail["gallery_page"] = this.galleryForm.value.gallery_page;
            this.commonService.setLocalStorage('userDetail', this.commonService.userDetail);
            this.userData.gallery_page  = this.galleryForm.value.gallery_page;
            this.showGalleryForm = false;
            //set success message
            this.commonService.successMsg = { "show": true, "msg": "<strong>" + this.commonService.globalVar['gallery_success_message'] + "</strong>" };
            this.router.navigate(['/gallery', this.galleryForm.value["gallery_page"]]);
          }
          else if (data['code'] == 500) {
            this.galleryMsg = { issuccess: false, isError: true, msg: data['message'][0] }
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      if (this.galleryForm.controls['gallery_page'].value == '') {
        gallerypagefocus.focus();
      }
      this.galleryFormSubmitted = true;
    }
  }
  /**
   * check Pattern
   */
  keyPress(event: any) {
    const pattern = /[a-z0-9_-]/;
    let inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }
  }
  /**
   * guest view enable
   */
  viewGuest() {
    this.commonService.galleryPage['isGuest'] = true;
  }
  /**
   * Learn more tracks
   */
  moreTracks() {

  }
  /**
   * delete video
   */
  deleteVideo(gallery:any) {

  }

}
