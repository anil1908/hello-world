import { NgModule, ElementRef } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { TranslateModule, TranslateService } from 'ng2-translate';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MyDatePickerModule } from 'mydatepicker';
import {MomentModule} from 'angular2-moment';

import { UserRoutingModule } from './user-routing.module';
import { UserComponent } from './user.component';

import { SignupComponent } from '../signup/signup.component';
import { AccountSettingsComponent } from '../account-settings/account-settings.component';
import { ResetPasswordComponent } from '../reset-password/reset-password.component';
import { LicenseHistoryComponent } from '../license-history/license-history.component';
import { PurchaseHistoryComponent } from '../purchase-history/purchase-history.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    UserRoutingModule,
    NgbModule.forRoot(),
    TranslateModule.forRoot(),
    MomentModule,
    MyDatePickerModule
  ],
  declarations: [
    UserComponent,
    AccountSettingsComponent,
    ResetPasswordComponent,
    SignupComponent,
    LicenseHistoryComponent,
    PurchaseHistoryComponent
  ],
  providers: [
    TranslateService
  ]
})
export class UserModule {

}

