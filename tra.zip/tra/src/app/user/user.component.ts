import { Component, Input, trigger, state, style, transition, animate } from '@angular/core';
import { NgSwitch, NgSwitchCase, NgSwitchDefault } from '@angular/common';
import { TranslateService } from 'ng2-translate';
import {NgbModule,NgbInputDatepicker,NgbDatepicker} from '@ng-bootstrap/ng-bootstrap';

@Component({
  template: `
    <router-outlet></router-outlet>
  `
})
export class UserComponent {
  constructor(
    private translate: TranslateService
  ) {

  }
/* This method is call when page is load
     */
  ngOnInit() {
    this.translate.addLangs(['en', 'fr']);
    this.translate.setDefaultLang('en');
    let browserLang = this.translate.getBrowserLang();
    this.translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
  }

}
