import { Injectable } from '@angular/core';
import {
  Router, CanActivate, Resolve, RouterStateSnapshot,
  ActivatedRouteSnapshot
} from '@angular/router';

@Injectable()
export class UserGuard implements CanActivate {

  constructor(
    private router: Router,
  ) {

  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    if(state.url=="/user"){
      this.router.navigate(['/']);
    }
    return true;
  }


}