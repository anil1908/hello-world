import { NgModule } from '@angular/core';
import { RouterModule, Routes, ROUTER_CONFIGURATION } from '@angular/router';
import 'rxjs/Rx';

import { UserComponent } from './user.component';
import { SignupComponent } from '../signup/signup.component';
import { ResetPasswordComponent } from '../reset-password/reset-password.component';
import { AccountSettingsComponent } from '../account-settings/account-settings.component';
import { UserGuard } from './user.guard';
import { AuthGuard } from '../common/auth.guard';
import { UnauthGuard } from '../common/auth.guard';
import { LicenseHistoryComponent } from '../license-history/license-history.component';
import { PurchaseHistoryComponent } from '../purchase-history/purchase-history.component';

const userRoutes: Routes = [
  {
    path: '',
    component: UserComponent,
    canActivate: [UserGuard],
    children: [
      {
        path: 'account',
        component: AccountSettingsComponent,
        canActivate: [AuthGuard],
        data: {
            title: 'Account'
        }
      },
      {
        path: 'license',
        component: LicenseHistoryComponent,
        canActivate: [AuthGuard],
        data: {
            title: 'License History'
        }
      },
      {
        path: 'purchases',
        component: PurchaseHistoryComponent,
        canActivate: [AuthGuard],
        data: {
            title: 'Purchase History'
        }
      },
      {
        path: 'reset_password/:id',
        component: ResetPasswordComponent,
        canActivate: [UnauthGuard],
        data: {
            title: 'Resetpassword'
        }
      },
      {
        path: 'activation/:id',
        component: ResetPasswordComponent,
        canActivate: [UnauthGuard],
        data: {
            title: 'User activation'
        }
      },
      {
        path: 'signup',
        component: SignupComponent,
        canActivate: [UnauthGuard],
        data: {
            title: 'Signup'
        }
      },
    ]
  }
];

export const userrouting = RouterModule.forRoot(userRoutes);
@NgModule({
  imports: [
    RouterModule.forChild(userRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    UserGuard
  ]
})
export class UserRoutingModule { }

