import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';

@Component({
  selector: 'app-license-history',
  templateUrl: './license-history.component.html',
  styleUrls: ['./license-history.component.css']
})
export class LicenseHistoryComponent implements OnInit {
  /* initialize variables */
  licenseHistory: Array<any>;
  isgethistory : Boolean = false;
  pagination: Object = {
    start: -100,
    limit: 100
  }

  constructor(
    private commonService: CommonService,
    private httpclient: HttpClientService) {

  }

/* This method is call when page is load
   */
  ngOnInit() {
    this.getLicenseHistory();
  }
  /**
   *get License History
   */
  getLicenseHistory(isnext = true) {
    if (isnext) {
      this.pagination['start'] = this.pagination['start']+this.pagination['limit'];
    }
    else {
      this.pagination['start'] = this.pagination['start']-this.pagination['limit'];
    }
    this.httpclient.get('license/history?offset=' + this.pagination['start'] + '&limit=' + this.pagination['limit'])
      .subscribe(
      data => {
        this.isgethistory = true;
        if (data['code'] == 200) {
          this.licenseHistory = data['data'];
        }
      },
      error => {
        this.isgethistory = true;

      });
  }

}
