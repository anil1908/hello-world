var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientService } from '../common/http-client.service';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../common/common.service';
import { ValidationService } from '../common/validation.service';
var CollaboratorComponent = (function () {
    function CollaboratorComponent(fb, activeModal, httpclient, commonService, validationService) {
        this.fb = fb;
        this.activeModal = activeModal;
        this.httpclient = httpclient;
        this.commonService = commonService;
        this.validationService = validationService;
        this.submitted = false;
        //set server side error message Object
        this.msg = { issuccess: false, isError: false, msg: '' };
    }
    /* This method is call when page is load
       */
    CollaboratorComponent.prototype.ngOnInit = function () {
        //Create Add Collaborator form and set validation rules
        this.collaboratorForm = this.fb.group({
            'email': ['', Validators.compose([Validators.required, this.validationService.multipleemailValidator])],
        });
    };
    /**
       * Add Collaborator Request
       */
    CollaboratorComponent.prototype.submitCollaboratorForm = function () {
        var _this = this;
        if (this.collaboratorForm.valid) {
            var emailarr = this.collaboratorForm.controls['email'].value.split(',');
            for (var _i = 0, emailarr_1 = emailarr; _i < emailarr_1.length; _i++) {
                var emailvalue = emailarr_1[_i];
                this.httpclient.post('project/' + this.event_id + '/add_member', { "email": emailvalue })
                    .subscribe(function (data) {
                    if (data["code"] == 500) {
                        _this.msg = { issuccess: false, isError: true, msg: data['message'] };
                    }
                    else {
                        _this.activeModal.close(true);
                    }
                }, function (error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
            }
        }
        else {
            this.msg = { issuccess: false, isError: false, msg: "" };
            this.submitted = true;
        }
    };
    return CollaboratorComponent;
}());
__decorate([
    Input(),
    __metadata("design:type", Object)
], CollaboratorComponent.prototype, "event_id", void 0);
CollaboratorComponent = __decorate([
    Component({
        selector: 'app-collaborator',
        templateUrl: './collaborator.component.html',
        styleUrls: ['./collaborator.component.css']
    }),
    __metadata("design:paramtypes", [FormBuilder,
        NgbActiveModal,
        HttpClientService,
        CommonService,
        ValidationService])
], CollaboratorComponent);
export { CollaboratorComponent };
//# sourceMappingURL=collaborator.component.js.map