import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientService } from '../common/http-client.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../common/common.service';
import { ValidationService } from '../common/validation.service';

@Component({
  selector: 'app-collaborator',
  templateUrl: './collaborator.component.html',
  styleUrls: ['./collaborator.component.css']
})
export class CollaboratorComponent implements OnInit {
  /* initialize variables */
  @Input() event_id: any;
  collaboratorForm: FormGroup;
  submitted: boolean = false;
  //set server side error message Object
  msg: Object = { issuccess: false, isError: false, msg: '' };

  constructor(public fb: FormBuilder,
    public activeModal: NgbActiveModal,
    private httpclient: HttpClientService,
    private commonService: CommonService,
    private validationService: ValidationService, ) { }

  /* This method is call when page is load
     */
  ngOnInit() {
    //Create Add Collaborator form and set validation rules
    this.collaboratorForm = this.fb.group({
      'email': ['', Validators.compose([Validators.required, this.validationService.multipleemailValidator])],
    });
  }

  /**
     * Add Collaborator Request
     */
  submitCollaboratorForm(): void {
    if (this.collaboratorForm.valid) {
      let emailarr = this.collaboratorForm.controls['email'].value.split(',');
      for (let emailvalue of emailarr) {
        this.httpclient.post('project/' + this.event_id + '/add_member', { "email": emailvalue })
          .subscribe(
          data => {
            if (data["code"] == 500) {
              this.msg = { issuccess: false, isError: true, msg: data['message'] }
            } else {
              this.activeModal.close(true);
            }
          },
          error => {
            this.commonService.messagePopup(this.commonService.globalVar['error'], error);
          });
      }
    }
    else {
      this.msg = { issuccess: false, isError: false, msg: "" }
      this.submitted = true;
    }
  }
}
