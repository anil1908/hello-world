import { Component, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal, NgbModalOptions,ModalDismissReasons, NgbDateParserFormatter, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { TermsComponent } from '../terms/terms.component';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  currentYear: number;
  constructor(
    private modalService: NgbModal) { }

  /* This method is call when page is load
     */
  ngOnInit() {
    this.currentYear = new Date().getFullYear();
  }

  openTermsPopup() {
    const modalRef = this.modalService.open(TermsComponent,{size:'lg'});
    modalRef.result.then((result) => {
      
    }, (reason) => {
      
    });
  }

}
