import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClientService } from '../common/http-client.service';
import { CommonService } from '../common/common.service';
import { ValidationService } from '../common/validation.service';

@Component({
  selector: 'app-account-settings',
  templateUrl: './account-settings.component.html',
  styleUrls: ['./account-settings.component.css']
})
export class AccountSettingsComponent implements OnInit {
  /* initialize variables */
  nameForm: FormGroup;
  passwordForm: FormGroup;
  galleryForm: FormGroup;
  nameFormSubmitted: boolean = false;
  passwordFormSubmitted: boolean = false;
  galleryFormSubmitted: boolean = false;
  showNameForm: boolean = false;
  showPasswordForm: boolean = false;
  showGalleryForm: boolean = false;
  serverError: Array<any> = [];
  userData: Object;
  is_regular_account = "1";
  //set server side error message Object
  nameMsg: Object = { issuccess: false, isError: false, msg: '' };
  pwdMsg: Object = { issuccess: false, isError: false, msg: '' };
  galleryMsg: Object = { issuccess: false, isError: false, msg: '' };
  constructor(
    public fb: FormBuilder,
    private httpclient: HttpClientService,
    private validationService: ValidationService,
    public commonService: CommonService
  ) {
  }

  /* This method is call when page is load
   */
  ngOnInit() {

    /*check user is collaborator or videographer*/
    this.is_regular_account = (this.commonService.userDetail["extra_data"].tracks_is_regular_account != null && this.commonService.userDetail["extra_data"].tracks_is_regular_account != undefined) ? this.commonService.userDetail["extra_data"].tracks_is_regular_account : "1";

    /*set user data from common*/
    this.userData = this.commonService.userDetail;

    /*Create user name detail form*/
    this.nameForm = this.fb.group({
      'first_name': [this.userData['first_name'], Validators.compose([Validators.required, Validators.maxLength(50)])],
      'last_name': [this.userData['last_name'], Validators.compose([Validators.required, Validators.maxLength(50)])],
    });

    /*Create password form*/
    this.passwordForm = this.fb.group({
      'password': ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(50)])],
      'confirm_password': ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(50)])],
      'passwords': this.fb.group({
        password: [''],
        confirm_password: ['']
      })
    }, { validator: this.validationService.compareField('password', 'confirm_password') });

    /*Create gallery form*/
    this.galleryForm = this.fb.group({
      'gallery_page': [this.userData['gallery_page'], Validators.compose([Validators.required, Validators.maxLength(100)])]
    });
  }

  /* Submit user name form request */
  saveName(firstnamefocus,lastnamefocus): void {
    if (this.nameForm.valid) {
      this.httpclient.post('user/account/update', this.nameForm.value)
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.nameMsg = { issuccess: false, isError: false, msg: '' }
            /* If name update successfully then update user name related variables */
            this.commonService.userDetail["first_name"] = this.nameForm.value.first_name;
            this.commonService.userDetail["last_name"] = this.nameForm.value.last_name;
            this.commonService.setLocalStorage('userDetail', this.commonService.userDetail);
            this.showNameForm = false;
            this.userData = this.commonService.userDetail;
            //set success message
            this.commonService.successMsg = { "show": true, "msg": "<strong>" + this.commonService.globalVar['name_success_message'] + "</strong>" };
          }
          else if (data['code'] == 500) {
            this.nameMsg = { issuccess: false, isError: true, msg: data['message'][0] }
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      if (this.nameForm.controls['first_name'].value == '') {
        firstnamefocus.focus();
      }
      else if (this.nameForm.controls['last_name'].value == '') {
        lastnamefocus.focus();
      }
      this.nameFormSubmitted = true;
    }
  }

  /* Submit password form request */
  savePassword(passwordfocus,confirmpasswordfocus): void {
    if (this.passwordForm.valid) {
      this.httpclient.post('user/account/update', this.passwordForm.value)
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.pwdMsg = { issuccess: false, isError: false, msg: '' }
            this.showPasswordForm = false;
            //set success message
            this.commonService.successMsg = { "show": true, "msg": "<strong>" + this.commonService.globalVar['password_success_message'] + "</strong>" };
          }
          else if (data['code'] == 500) {
            this.pwdMsg = { issuccess: false, isError: true, msg: data['message'][0] }
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      if (!this.passwordForm.controls['password'].valid) {
        passwordfocus.focus();
      }
      else if (!this.passwordForm.controls['confirm_password'].valid) {
        confirmpasswordfocus.focus();
      }
      this.passwordFormSubmitted = true;
    }
  }

  /* Submit gallery form request */
  saveGalleryName(gallerypagefocus): void {
    if (this.galleryForm.valid) {
      this.httpclient.post('user/account/update', this.galleryForm.value)
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.galleryMsg = { issuccess: false, isError: false, msg: '' }
            /*If name saved successfully then update related variables */
            this.commonService.userDetail["gallery_page"] = this.galleryForm.value.gallery_page;
            this.commonService.setLocalStorage('userDetail', this.commonService.userDetail);
            this.showGalleryForm = false;
            this.userData = this.commonService.userDetail;
            //set success message
            this.commonService.successMsg = { "show": true, "msg": "<strong>" + this.commonService.globalVar['gallery_success_message'] + "</strong>" };
          }
          else if (data['code'] == 500) {
            this.galleryMsg = { issuccess: false, isError: true, msg: data['message'][0] }
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      if (this.galleryForm.controls['gallery_page'].value == '') {
        gallerypagefocus.focus();
      }
      this.galleryFormSubmitted = true;
    }
  }

  /* Check gallery name format  */
  keyPress(event: any) {
    const pattern = /[a-z0-9_-]/;
    let inputChar = String.fromCharCode(event.charCode);

    if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }
  }
}