import { NgModule, ElementRef } from '@angular/core';
import { FormsModule,ReactiveFormsModule  }    from '@angular/forms';
import { CommonModule }   from '@angular/common';
import {TranslateModule,TranslateService} from 'ng2-translate';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { PageRoutingModule } from './page-routing.module';
import { PageComponent }     from './page.component';

import { AboutComponent } from '../about/about.component';
import { WhyLicenseComponent } from '../why-license/why-license.component';
import { HowItWorksComponent } from '../how-it-works/how-it-works.component';
import { FaqsComponent } from '../faqs/faqs.component';
import { ContactUsComponent } from '../contact-us/contact-us.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    PageRoutingModule,
    NgbModule.forRoot(),
    TranslateModule.forRoot()
  ],
  declarations: [
    PageComponent,
    AboutComponent,
    WhyLicenseComponent,
    HowItWorksComponent,
    FaqsComponent,
    ContactUsComponent,
  ],
  providers: [
    TranslateService
  ]
})
export class PageModule {

}

