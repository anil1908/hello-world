import { NgModule } from '@angular/core';
import { RouterModule, Routes, ROUTER_CONFIGURATION } from '@angular/router';
import 'rxjs/Rx';

import { PageComponent } from './page.component';
import { PageGuard } from './page.guard';
import { AuthGuard } from '../common/auth.guard';
import { UnauthGuard } from '../common/auth.guard';
import { AboutComponent } from '../about/about.component';
import { WhyLicenseComponent } from '../why-license/why-license.component';
import { HowItWorksComponent } from '../how-it-works/how-it-works.component';
import { FaqsComponent } from '../faqs/faqs.component';
import { ContactUsComponent } from '../contact-us/contact-us.component';

const pageRoutes: Routes = [
  {
    path: '',
    component: PageComponent,
    canActivate: [PageGuard],
    children: [
      {
        path: 'about',
        component: AboutComponent,
        data: {
          title: 'About us'
        }
      },
      {
        path: 'why_license',
        component: WhyLicenseComponent,
        data: {
          title: 'Why license'
        }
      },
      {
        path: 'how_it_works',
        component: HowItWorksComponent,
        data: {
          title: 'How it works'
        }
      },
      {
        path: 'contactus',
        component: ContactUsComponent,
        data: {
          title: 'Contact us'
        }
      },
      {
        path: 'faqs',
        component: FaqsComponent,
        data: {
          title: 'FAQ'
        }
      },
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(pageRoutes)
  ],
  exports: [
    RouterModule
  ],
  providers: [
    PageGuard
  ]
})
export class PageRoutingModule { }

