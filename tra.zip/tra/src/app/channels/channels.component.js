var __decorate = (this && this.__decorate) || function(decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
        d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else
        for (var i = decorators.length - 1; i >= 0; i--)
            if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function(paramIndex, decorator) {
    return function(target, key) { decorator(target, key, paramIndex); }
};
import { Component, NgZone, Inject, EventEmitter, Input, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { DomSanitizer } from "@angular/platform-browser";
import { NgUploaderOptions } from 'ngx-uploader';
var ChannelsComponent = (function() {
    function ChannelsComponent(commonService, httpclient, activeModal, fb, sanitizer, zone) {
        this.commonService = commonService;
        this.httpclient = httpclient;
        this.activeModal = activeModal;
        this.fb = fb;
        this.sanitizer = sanitizer;
        this.zone = zone;
        this.submitted = false;
        this.sizeLimit = 1000000000; // video size
        this.isProcess = false;
        this.videostatus = true;
        this.in_gallery = true;
        this.inputUploadEvents = new EventEmitter();
    }
    /* This method is call when page is load
     */
    ChannelsComponent.prototype.ngOnInit = function() {
        /* Create upload video form */
        this.youtubeForm = this.fb.group({
            'event_id': [this.projectId, Validators.compose([Validators.required])],
            'work_id': [this.workId, Validators.compose([Validators.required])],
            'title': ['', Validators.compose([Validators.required, Validators.maxLength(100)])],
            'description': ['', Validators.compose([Validators.required])],
            'visibility': [true],
        });
        /*Set file uploader library options */
        this.options = new NgUploaderOptions({
            url: this.httpclient.apiUrl + 'project/' + this.youtubeForm.controls['work_id'].value + '/upload_video?comet_request=true',
            filterExtensions: true,
            allowedExtensions: ['mp4', 'avi', 'mov', 'MOV', 'flv', '3gp'],
            // maxSize: 2097152,
            data: { 'chunk': '0', 'chunks': '1', },
            autoUpload: false,
            fieldName: 'file',
            fieldReset: true,
            maxUploads: 2,
            method: 'POST',
            previewUrl: true,
            withCredentials: true
        });
        /**
         * handle process file
         * */
        window['upload_video_progress_handler'] = function(progress) {
            document.getElementById('processPer').innerHTML = progress['data']['complete_prcn'];
            document.getElementById("uploadVideo").style.display = 'none';
            document.getElementById("processVideo").style.display = 'block';
            document.getElementById("processvideobar").style.width = progress['data']['complete_prcn'] + "%";
        };
        window['upload_video_completed_handler'] = function(complete) {
            document.getElementById('processPer').innerHTML = '100';
            document.getElementById("processvideobar").style.width = "100%";
        };
        window['upload_video_error_handler'] = function(errors) {
            document.getElementById("processVideo").style.display = 'none';
            document.getElementById("processError").style.display = 'block';
            document.getElementById('processError').innerHTML = errors;
        };
    };
    /*
     *After view init
     */
    ChannelsComponent.prototype.ngAfterViewInit = function() {
        this.videoFile.nativeElement.addEventListener('dragover', function(e) {
            e.preventDefault();
            e.stopPropagation();
            e.currentTarget.parentElement.style.backgroundColor = '#ccc';
        });
        this.videoFile.nativeElement.addEventListener('dragleave', function(e) {
            e.preventDefault();
            e.stopPropagation();
            e.currentTarget.parentElement.style.backgroundColor = '';
        });
    };
    /**
     * Upload Video
     */
    ChannelsComponent.prototype.youtubeUpload = function() {
        if (this.youtubeForm.valid) {
            this.inputUploadEvents.emit('startUpload');
        } else {
            this.submitted = true;
        }
    };
    /**
     * before Video
     */
    ChannelsComponent.prototype.beforeUpload = function(uploadingFile) {
        this.options.data['name'] = uploadingFile['originalName'];
        this.filename = uploadingFile['originalName'];
        if (uploadingFile.size > this.sizeLimit) {
            uploadingFile.setAbort();
            this.errorMessage = 'File is too large!';
        }
    };
    /**
     * Progress Video
     */
    ChannelsComponent.prototype.handleUpload = function(data) {
        var _this = this;
        this.zone.run(function() {
            _this.uploadProgress = data.progress.percent;
            _this.response = data;
            if (data && data.response) {
                _this.response = JSON.parse(data.response);
                if (_this.response['code'] == 200 && !_this.isProcess) {
                    _this.isProcess = true;
                    if (_this.in_gallery) {
                        _this.commonService.setCookie('uploadvideoevent', _this.youtubeForm.controls['work_id'].value);
                    }
                    /**
                     *  process video form
                     * */
                    var form = document.createElement("form");
                    form.method = 'POST';
                    form.target = 'iframe';
                    form.className = 'iframeform';
                    form.action = _this.httpclient.apiUrl + 'project/' + _this.youtubeForm.controls['work_id'].value + '/process_video?comet_request=true';
                    var e1 = document.createElement("input");
                    e1.name = 'video_name';
                    e1.value = encodeURIComponent(_this.filename);
                    form.appendChild(e1);
                    var e2 = document.createElement("input");
                    e2.name = 'video_title';
                    e2.value = encodeURIComponent(_this.youtubeForm.controls['title'].value);
                    form.appendChild(e2);
                    var e3 = document.createElement("input");
                    e3.name = 'video_desc';
                    e3.value = encodeURIComponent(_this.youtubeForm.controls['description'].value);
                    form.appendChild(e3);
                    var e4 = document.createElement("input");
                    e4.name = 'video_tags';
                    e4.value = encodeURIComponent('');
                    form.appendChild(e4);
                    var e5 = document.createElement("input");
                    e5.name = 'video_status';
                    e5.value = (_this.videostatus) ? 'public' : 'unlisted';
                    form.appendChild(e5);
                    document.body.appendChild(form);
                    form.submit();
                }
                if (_this.response['code'] != 200) {
                    document.getElementById("uploadVideo").style.display = 'none';
                    document.getElementById("uploadError").style.display = 'block';
                    document.getElementById('uploadError').innerHTML = _this.response['message'].toString(',');
                }
            }
        });
    };
    /**
     *change Project
     */
    ChannelsComponent.prototype.changeProject = function() {
        var _this = this;
        if (this.youtubeForm.value.event_id !== '' && this.youtubeForm.value.event_id !== null && this.youtubeForm.value.event_id !== undefined) {
            this.httpclient.get('project/' + this.youtubeForm.value.event_id + '/details')
                .subscribe(function(data) {
                    if (data['code'] == 200) {
                        _this.workList = [];
                        _this.youtubeForm.controls['work_id'].setValue('');
                        if (data['data'].child_list !== undefined && data['data'].child_list != null) {
                            for (var workObj in data['data'].child_list) {
                                if (data['data'].child_list[workObj].license_code !== null) {
                                    var workObjData = {
                                        "id": data['data'].child_list[workObj].id,
                                        "name": data['data'].child_list[workObj].name
                                    };
                                    _this.workList.push(workObjData);
                                }
                            }
                            _this.youtubeForm.controls["work_id"].setValue("");
                        }
                    } else if (data['code'] == 500) {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                    }
                }, function(error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
        } else {
            this.workList = [];
            this.youtubeForm.controls['work_id'].setValue('');
        }
    };
    /**
     * change Work
     */
    ChannelsComponent.prototype.changeWork = function() {
        this.options = new NgUploaderOptions({
            url: this.httpclient.apiUrl + 'project/' + this.youtubeForm.controls['work_id'].value + '/upload_video?comet_request=true',
            filterExtensions: true,
            allowedExtensions: ['mp4', 'avi', 'mov', 'MOV', 'flv', '3gp'],
            data: { 'chunk': '0', 'chunks': '1', },
            autoUpload: false,
            fieldName: 'file',
            fieldReset: true,
            maxUploads: 2,
            method: 'POST',
            previewUrl: true,
            withCredentials: true
        });
    };
    ChannelsComponent.prototype.fileOverBase = function(e) {
        this.hasBaseDropZoneOver = e;
    };
    ChannelsComponent.prototype.filePreviewData = function(filename) {
        this.filename = filename;
        this.options.data['name'] = filename;
    };
    /**
     * file Change Event
     */
    ChannelsComponent.prototype.fileChangeEvent = function(event) {
        this.videoFile.nativeElement.parentElement.style.backgroundColor = '';
        this.filename = this.videoFile.nativeElement.files[0].name;
        this.options.data['name'] = this.filename;
    };
    ChannelsComponent.prototype.removeFrameForm = function() {
        this.isProcess = false;
        this.removeElementsByClass('iframeform');
    };
    ChannelsComponent.prototype.removeElementsByClass = function(className) {
        var elements = document.getElementsByClassName(className);
        while (elements.length > 0) {
            elements[0].parentNode.removeChild(elements[0]);
        }
    };
    return ChannelsComponent;
}());
__decorate([
    Input(),
    __metadata("design:type", Object)
], ChannelsComponent.prototype, "projectList", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], ChannelsComponent.prototype, "workList", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], ChannelsComponent.prototype, "projectId", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], ChannelsComponent.prototype, "workId", void 0);
__decorate([
    ViewChild('videoFile'),
    __metadata("design:type", ElementRef)
], ChannelsComponent.prototype, "videoFile", void 0);
ChannelsComponent = __decorate([
    Component({
        selector: 'app-channels',
        templateUrl: './channels.component.html',
        styleUrls: ['./channels.component.css']
    }),
    __param(5, Inject(NgZone)),
    __metadata("design:paramtypes", [CommonService,
        HttpClientService,
        NgbActiveModal,
        FormBuilder,
        DomSanitizer,
        NgZone
    ])
], ChannelsComponent);
export { ChannelsComponent };
//# sourceMappingURL=channels.component.js.map