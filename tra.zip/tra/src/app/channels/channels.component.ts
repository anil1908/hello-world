import { Component, NgZone, Inject, EventEmitter, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import { NgUploaderOptions, UploadedFile, UploadRejected } from 'ngx-uploader';

@Component({
  selector: 'app-channels',
  templateUrl: './channels.component.html',
  styleUrls: ['./channels.component.css']
})

export class ChannelsComponent implements OnInit {
  /* Input from parent */
  @Input() projectList: any;
  @Input() workList: any;
  @Input() projectId: any;
  @Input() workId: any;

  /* initialize variables */
  filename: any;
  filesource: string;
  submitted: boolean = false;
  youtubeForm: FormGroup;
  privacyStatusData: Array<any>;
  @ViewChild('videoFile') videoFile: ElementRef;

  options: NgUploaderOptions;
  response: any;
  sizeLimit: number = 4000000000; // video size
  previewData: any;
  errorMessage: string;
  inputUploadEvents: EventEmitter<string>;
  uploadProgress: number;
  processContent: any;
  hasBaseDropZoneOver: boolean;
  htmlcont: any;
  isProcess: boolean = false;
  iframediv: any;
  videostatus: boolean = true;
  in_gallery: boolean = true;

  constructor(
    private commonService: CommonService,
    private httpclient: HttpClientService,
    public activeModal: NgbActiveModal,
    public fb: FormBuilder,
    private sanitizer: DomSanitizer,
    @Inject(NgZone) private zone: NgZone
  ) {
    this.inputUploadEvents = new EventEmitter<string>();
  }

  /* This method is call when page is load
   */

  ngOnInit() {
    /* Create upload video form */
    this.youtubeForm = this.fb.group({
      'event_id': [this.projectId, Validators.compose([Validators.required])],
      'work_id': [this.workId, Validators.compose([Validators.required])],
      'title': ['', Validators.compose([Validators.required, Validators.maxLength(100)])],
      'description': ['', Validators.compose([Validators.required])],
      'visibility': [true],
    });
    /*Set file uploader library options */
    this.options = new NgUploaderOptions({
      url: this.httpclient.apiUrl + 'project/' + this.youtubeForm.controls['work_id'].value + '/upload_video?comet_request=true',
      filterExtensions: true,
      allowedExtensions: ['mp4', 'avi', 'mov', 'MOV', 'flv', '3gp'],
      // maxSize: 2097152,
      data: { 'chunk': '0', 'chunks': '1', },
      autoUpload: false,
      fieldName: 'file',
      fieldReset: true,
      maxUploads: 2,
      method: 'POST',
      previewUrl: true,
      withCredentials: true
    });
    /**
     * handle process file
     * */
    window['upload_video_progress_handler'] = function (progress: any) {
      document.getElementById('processPer').innerHTML = progress['data']['complete_prcn'];
      document.getElementById("uploadVideo").style.display = 'none';
      document.getElementById("processVideo").style.display = 'block';
      document.getElementById("processvideobar").style.width = progress['data']['complete_prcn'] + "%";
    };
    window['upload_video_completed_handler'] = function (complete: any) {
      document.getElementById('processPer').innerHTML = '100';
      document.getElementById("processvideobar").style.width = "100%";
    };
    window['upload_video_error_handler'] = function (errors: any) {
      document.getElementById("processVideo").style.display = 'none';
      document.getElementById("processError").style.display = 'block';
      document.getElementById('processError').innerHTML = errors;
    };
  }
  /*
  *After view init
  */
  ngAfterViewInit() {

  }

  /**
  * Upload Video
  */
  youtubeUpload(eventidfocus,workidfocus,titlefocus,descriptionfocus) {
    if (this.youtubeForm.valid) {
      this.inputUploadEvents.emit('startUpload');
    }
    else {
      if (this.youtubeForm.controls['event_id'].value == '') {
        eventidfocus.focus();
      }
      else if (this.youtubeForm.controls['work_id'].value == '') {
        workidfocus.focus();
      }
      else if (this.youtubeForm.controls['title'].value == '') {
        titlefocus.focus();
      }
      else if (this.youtubeForm.controls['description'].value == '') {
        descriptionfocus.focus();
      }
      this.submitted = true;
    }
  }
  /**
  * before Video
  */
  beforeUpload(uploadingFile: UploadedFile): void {
    this.filename = uploadingFile['originalName'];
    if (uploadingFile.size > this.sizeLimit) {
      uploadingFile.setAbort();
      this.errorMessage = 'File is too large!';
    }
  }
  /**
   * Progress Video
   */
  handleUpload(data: any) {
    this.zone.run(() => {
      this.uploadProgress = data.progress.percent;
      this.response = data;
      if (data && data.response) {
        this.response = JSON.parse(data.response);
        if (this.response['code'] == 200 && !this.isProcess) {
          this.isProcess = true;
          if (this.youtubeForm.controls['visibility']) {
            this.commonService.setCookie('uploadvideoevent', this.youtubeForm.controls['work_id'].value);
          }
          /**
           *  process video form
           * */
          var form = document.createElement("form");
          form.method = 'POST';
          form.target = 'iframe';
          form.className = 'iframeform';
          form.action = this.httpclient.apiUrl + 'project/' + this.youtubeForm.controls['work_id'].value + '/process_video?comet_request=true';
          var e1 = document.createElement("input");
          e1.name = 'video_name';
          e1.value = encodeURIComponent(this.filename);
          form.appendChild(e1);

          var e2 = document.createElement("input");
          e2.name = 'video_title';
          e2.value = encodeURIComponent(this.youtubeForm.controls['title'].value);
          form.appendChild(e2);

          var e3 = document.createElement("input");
          e3.name = 'video_desc';
          e3.value = encodeURIComponent(this.youtubeForm.controls['description'].value);
          form.appendChild(e3);

          var e4 = document.createElement("input");
          e4.name = 'video_tags';
          e4.value = encodeURIComponent('');
          form.appendChild(e4);

          var e5 = document.createElement("input");
          e5.name = 'video_status';
          e5.value = (this.videostatus) ? 'public' : 'unlisted';
          form.appendChild(e5);

          document.body.appendChild(form);
          form.submit();
        }

        if (this.response['code'] != 200) {
          document.getElementById("uploadVideo").style.display = 'none';
          document.getElementById("uploadError").style.display = 'block';
          document.getElementById('uploadError').innerHTML = this.response['message'].toString(',');
        }
      }
    });
  }
  /**
   *change Project
   */
  changeProject() {
    if (this.youtubeForm.value.event_id !== '' && this.youtubeForm.value.event_id !== null && this.youtubeForm.value.event_id !== undefined) {
      this.httpclient.get('project/' + this.youtubeForm.value.event_id + '/details')
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.workList = [];
            this.youtubeForm.controls['work_id'].setValue('');
            if (data['data'].child_list !== undefined && data['data'].child_list != null) {
              for (var workObj in data['data'].child_list) {
                if (data['data'].child_list[workObj].license_code !== null) {
                  let workObjData = {
                    "id": data['data'].child_list[workObj].id,
                    "name": data['data'].child_list[workObj].name
                  };
                  this.workList.push(workObjData);
                }
              }
              this.youtubeForm.controls["work_id"].setValue("");
            }
          }
          else if (data['code'] == 500) {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      this.workList = [];
      this.youtubeForm.controls['work_id'].setValue('');
    }
  }
  /**
   * change Work
   */
  changeWork() {
    this.options = new NgUploaderOptions({
      url: this.httpclient.apiUrl + 'project/' + this.youtubeForm.controls['work_id'].value + '/upload_video?comet_request=true',
      filterExtensions: true,
      allowedExtensions: ['mp4', 'avi', 'mov', 'MOV', 'flv', '3gp'],
      data: { 'chunk': '0', 'chunks': '1', },
      autoUpload: false,
      fieldName: 'file',
      fieldReset: true,
      maxUploads: 2,
      method: 'POST',
      previewUrl: true,
      withCredentials: true
    });

  }

  fileOverBase(e: boolean) {
    this.hasBaseDropZoneOver = e;
  }

  filePreviewData(filename: any) {
    this.filename = filename;
    this.options.data['name'] = filename;
  }
  /**
   * file Change Event
   */
  fileChangeEvent(event: any) {
    this.videoFile.nativeElement.parentElement.style.backgroundColor = '';
    this.filename = this.videoFile.nativeElement.files[0].name;
    this.options.data['name'] = this.filename;
  }

  removeFrameForm() {
    this.isProcess = false;
    this.removeElementsByClass('iframeform');
  }

  removeElementsByClass(className: any) {
    var elements = document.getElementsByClassName(className);
    while (elements.length > 0) {
      elements[0].parentNode.removeChild(elements[0]);
    }
  }

}