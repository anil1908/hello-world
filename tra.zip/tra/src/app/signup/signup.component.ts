import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClientService } from '../common/http-client.service';
import { CommonService } from '../common/common.service';
import { ValidationService } from '../common/validation.service';
import { Cookie } from 'angular2-cookies';
import { NgbActiveModal, NgbInputDatepicker, NgbDatepickerConfig, NgbDateStruct, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { IMyOptions, IMyDate, IMyDateModel } from 'mydatepicker';

@Component({
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
  host: {
    '(document:click)': 'documentclick($event)',
  },
})
export class SignupComponent implements OnInit {
  /* initialize variables */
  registerdata: any = {};
  usertypes: Array<Object>;
  signupForm: FormGroup;
  submitted: boolean = false;
  stateList: Array<Object>;
  serverError: Array<any> = [];
  myDatePickerOptions: IMyOptions;
  show_date_tooltip = false;
  isRegisterState: boolean = false;

  constructor(
    public fb: FormBuilder,
    private router: Router,
    private modalService: NgbModal,
    private httpclient: HttpClientService,
    private validationService: ValidationService,
    private commonService: CommonService
  ) {

    this.myDatePickerOptions = {
      firstDayOfWeek: 'su',
      dateFormat: 'mmm. dd, yyyy',
      showClearDateBtn: false,
      editableDateField: false,
      openSelectorOnInputClick: true,
      minYear: 1950,
      showTodayBtn: false,
      disableSince: {
        year: new Date().getFullYear(),
        month: new Date().getMonth() + 1,
        day: new Date().getDate() + 1
      }
    };
    
  }

  /* This method is call when page is load
       */
  ngOnInit() {
    this.commonService.getLocalStorage('tos');
    let tos = this.commonService.getLocalStorage('tos');
    this.stateList = this.commonService.getState();
    this.signupForm = this.fb.group({
      'email': ['', Validators.compose([Validators.required, Validators.maxLength(100), this.validationService.emailValidator])],
      'password': ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(50)])],
      'confirm_password': ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(50)])],
      'first_name': ['', Validators.compose([Validators.required, Validators.maxLength(50)])],
      'last_name': ['', Validators.compose([Validators.required, Validators.maxLength(50)])],
      'company_name': ['', Validators.compose([Validators.maxLength(100)])],
      'birthdate': [''],
      'state': [''],
      'phone_no': ['', Validators.compose([Validators.minLength(10), Validators.maxLength(15), this.validationService.mobileValidator])],
      'terms_and_conditions': [(tos!==null && tos!==undefined && tos!=='')?tos:false, Validators.pattern('true')],
      'weva_id': [false],
      'remember_me': [true],
    }, { validator: this.validationService.compareField('password', 'confirm_password') });
    this.commonService.removeLocalStorage('tos')
    this.httpclient.getgeolocation('http://ipinfo.io')
      .subscribe(
      data => {
        if (data['region'] !== undefined && data['region'] !== null && data['region'] !== '') {
          for (let state of this.commonService.getState()) {
            if(state['key'].toLowerCase()==data['region'].toLowerCase()){
              this.isRegisterState = true;
            }
          }
        }
      },
      error => {
        
      });
  }

  ngAfterViewInit(){
    if(document.getElementsByClassName('selbtngroup')[0]!==undefined && document.getElementsByClassName('selbtngroup')[0]!==null){
      document.getElementsByClassName('selbtngroup')[0].remove();
    }
    if(document.getElementsByClassName('selection')[0]!==undefined && document.getElementsByClassName('selection')[0]!==null){
      document.getElementsByClassName('selection')[0]['style'] = '';
    }
    if(document.getElementsByClassName('selectiongroup')[0]!==undefined && document.getElementsByClassName('selectiongroup')[0]!==null){
      document.getElementsByClassName('selectiongroup')[0]['className'] = 'fieldvalue';
    }
  }
  /**
   * document click
   */
  documentclick(event) {
    this.show_date_tooltip = false;
  }

  /**
   * User Register Request
   */
  register(form: any,firstnamefocus,lastnamefocus,emailfocus,passwordfocus,confirmpasswordfocus): void {
    if (this.signupForm.valid && this.isRegisterState) {
      this.signupForm.controls['email'].setValue(this.signupForm.controls['email'].value.trim());
      this.signupForm.controls['first_name'].setValue(this.signupForm.controls['first_name'].value.trim());
      this.signupForm.controls['last_name'].setValue(this.signupForm.controls['last_name'].value.trim());
      this.signupForm.controls['company_name'].setValue(this.signupForm.controls['company_name'].value.trim());
      this.signupForm.controls['phone_no'].setValue(this.signupForm.controls['phone_no'].value.trim());
      if (this.signupForm.controls['birthdate'].value !== '') {
        let birthdate = this.signupForm.controls['birthdate'].value.jsdate;
        this.signupForm.controls["birthdate"].setValue(birthdate);
      }
      var isremember = this.signupForm.value.remember_me;
      this.httpclient.post('user/signup_submit', this.signupForm.value)
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.commonService.setCookie("isLogin", "true");
            this.commonService.setLocalStorage('remember_me', isremember);
            this.commonService.setLocalStorage('userDetail', data['data']);
            this.commonService.updateLogin();

            //check user is collaborator or videographer
            this.commonService.is_regular_account = (this.commonService.userDetail["extra_data"].tracks_is_regular_account != null && this.commonService.userDetail["extra_data"].tracks_is_regular_account != undefined) ? this.commonService.userDetail["extra_data"].tracks_is_regular_account : "1";

            if (this.commonService.is_regular_account == '1') {
              this.commonService.getUserCredit();
              this.commonService.getUserFavorite();
            }
            this.router.navigate(['/events']);
          }
          else if (data['code'] == 500) {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      if(!this.signupForm.controls['first_name'].valid){
        firstnamefocus.focus();
      }
      else if(!this.signupForm.controls['last_name'].valid){
        lastnamefocus.focus();
      }
      else if(!this.signupForm.controls['email'].valid){
        emailfocus.focus();
      }
      else if(!this.signupForm.controls['password'].valid){
        passwordfocus.focus();
      }
      else if(!this.signupForm.controls['confirm_password'].valid){
        confirmpasswordfocus.focus();
      }

      this.submitted = true;
    }
  }

  /* Check valid phone number enter or not */
  _keyPress(event: any) {
    const pattern = /[0-9 ()-]/;
    let inputChar = String.fromCharCode(event.charCode);

    if (!pattern.test(inputChar)) {
      // invalid character, prevent input
      event.preventDefault();
    }
  }

}