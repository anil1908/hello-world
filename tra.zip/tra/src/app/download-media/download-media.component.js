var __decorate = (this && this.__decorate) || function(decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
        d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else
        for (var i = decorators.length - 1; i >= 0; i--)
            if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input } from '@angular/core';
import { CommonService } from '../common/common.service';
import { DomSanitizer } from "@angular/platform-browser";
import { HttpClientService } from '../common/http-client.service';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
var DownloadMediaComponent = (function() {
    function DownloadMediaComponent(httpclient, modalService, commonService, activeModal, sanitizer) {
        this.httpclient = httpclient;
        this.modalService = modalService;
        this.commonService = commonService;
        this.activeModal = activeModal;
        this.sanitizer = sanitizer;
        this.mediaurl = this.sanitizer.bypassSecurityTrustResourceUrl('');
    }
    DownloadMediaComponent.prototype.ngOnInit = function() {
        /**
         * handle download process file
         * */
        window['download_media_progress_handler'] = function(progress) {
            document.getElementById('processPer').innerHTML = progress['data']['complete_prcn'];
            document.getElementById("processVideo").style.display = 'block';
            document.getElementById("processvideobar").style.width = progress['data']['complete_prcn'] + "%";
        };
        window['download_media_completed_handler'] = function(complete) {
            document.getElementById('processPer').innerHTML = '100';
            document.getElementById("processvideobar").style.width = "100%";
            window.location.href = complete.url;
        };
        window['download_media_error_handler'] = function(errors) {
            document.getElementById("processVideo").style.display = 'none';
            document.getElementById("processError").style.display = 'block';
            document.getElementById('processError').innerHTML = errors;
        };
        this.downloadMedia();
    };
    /**
     * Download Media form
     */
    DownloadMediaComponent.prototype.downloadMedia = function() {
        var url = this.httpclient.apiUrl + 'project/' + this.projectId + '/download_media?comet_request=true';
        this.mediaurl = (this.sanitizer.bypassSecurityTrustResourceUrl(url));
        //window.parent.postMessage('', this.mediaurl);
    };
    DownloadMediaComponent.prototype.removeFrameForm = function() {
        this.removeElementsByClass('downloadframeform');
    };
    DownloadMediaComponent.prototype.removeElementsByClass = function(className) {
        var elements = document.getElementsByClassName(className);
        while (elements.length > 0) {
            elements[0].parentNode.removeChild(elements[0]);
        }
    };
    return DownloadMediaComponent;
}());
__decorate([
    Input(),
    __metadata("design:type", Object)
], DownloadMediaComponent.prototype, "projectId", void 0);
DownloadMediaComponent = __decorate([
    Component({
        selector: 'app-download-media',
        templateUrl: './download-media.component.html',
        styleUrls: ['./download-media.component.css']
    }),
    __metadata("design:paramtypes", [HttpClientService,
        NgbModal,
        CommonService,
        NgbActiveModal,
        DomSanitizer
    ])
], DownloadMediaComponent);
export { DownloadMediaComponent };
//# sourceMappingURL=download-media.component.js.map