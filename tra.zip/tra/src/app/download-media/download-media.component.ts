import { Component, OnInit, Input } from '@angular/core';
import { CommonService } from '../common/common.service';
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import { HttpClientService } from '../common/http-client.service';
import { NgbActiveModal, NgbModal, ModalDismissReasons, NgbDateParserFormatter, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-download-media',
  templateUrl: './download-media.component.html',
  styleUrls: ['./download-media.component.css']
})
export class DownloadMediaComponent implements OnInit {
  @Input() projectId : any;
  @Input() extraproperties : any;
  
  mediaurl : any;
  constructor(
    private httpclient: HttpClientService,
    private modalService: NgbModal,
    public commonService: CommonService,
    public activeModal: NgbActiveModal,
    private sanitizer: DomSanitizer
  ) {
    this.mediaurl = this.sanitizer.bypassSecurityTrustResourceUrl('');
  }

  ngOnInit() {
    /**
    * handle download process file
    * */
    window['download_media_progress_handler'] = function (progress:any) {
      document.getElementById('processPer').innerHTML = progress['data']['complete_prcn'];
      document.getElementById("processVideo").style.display = 'block';
      document.getElementById("processvideobar").style.width = progress['data']['complete_prcn'] + "%";
    };
    window['download_media_completed_handler'] = function (complete:any) {
      document.getElementById('processPer').innerHTML = '100';
      document.getElementById("processvideobar").style.width = "100%";
      window.location.href = complete.url;
    };
    window['download_media_error_handler'] = function (errors:any) {
      document.getElementById("processVideo").style.display = 'none';
      document.getElementById("processError").style.display = 'block';
      document.getElementById('processError').innerHTML = errors;
    };
    this.downloadMedia();
  }
  /**
   * Download Media form
   */
  downloadMedia() {
    let url = this.httpclient.apiUrl+ 'project/'+ this.projectId+ '/download_media?comet_request=true';
    this.mediaurl = (this.sanitizer.bypassSecurityTrustResourceUrl(url));
    //window.parent.postMessage('', this.mediaurl);
  }

  removeFrameForm() {
    this.removeElementsByClass('downloadframeform');
  }

  removeElementsByClass(className : any) {
    var elements = document.getElementsByClassName(className);
    while (elements.length > 0) {
      elements[0].parentNode.removeChild(elements[0]);
    }
  }

}
