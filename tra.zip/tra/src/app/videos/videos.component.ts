import { Component, OnInit } from '@angular/core';
import { HttpClientService } from '../common/http-client.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '../common/common.service';
import { NgbActiveModal, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { ChannelsComponent } from '../channels/channels.component';

@Component({
  templateUrl: './videos.component.html',
  styleUrls: ['./videos.component.css']
})
export class VideosComponent implements OnInit {
  /**
   * initialize variables
   */
  videosData: Array<any> = [];
  ProjectList: Array<any> = [];
  workList: Array<any> = [];
  is_show_empty_msg = false;

  constructor(
    private modalService: NgbModal,
    private httpclient: HttpClientService,
    private router: Router,
    private commonService: CommonService
  ) { }
  /* This method is call when page is load
       */
  ngOnInit() {
    this.getAllVideos();
  }

  /**
   * get All Video
   */
  getAllVideos() {
    this.httpclient.get('videos/all')
      .subscribe(
      data => {
        this.is_show_empty_msg = true;
        if (data['code'] == 200) {
          this.videosData = data['data'];
        }
        else if (data['code'] == 500) {
          this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
        }
      },
      error => {
        this.commonService.messagePopup(this.commonService.globalVar['error'], error);
      });
  }

  /**
   * upload Video
   */
  uploadVideo() {
    this.httpclient.get('projects/get_all_projects')
      .subscribe(
      data => {
        if (data['code'] == 200) {
          this.ProjectList = data['data']['projects'];
          let projectArr = [];
          this.ProjectList.forEach(project => {
            if (project["child_list"].length > 0) {
              projectArr.push({
                id: project['id'],
                name: project['name']
              })
            }
          });
          const modalRef = this.modalService.open(ChannelsComponent);
          modalRef.componentInstance.projectList = projectArr;
          modalRef.componentInstance.workList = [];
          modalRef.componentInstance.projectId = '';
          modalRef.componentInstance.workId = '';
          modalRef.result.then((result) => {
            let projectId = this.commonService.getCookie('uploadvideoevent');
            if (projectId !== null && projectId !== undefined && projectId !== '') {
              let videodata = {
                id: projectId,
                type: "gallery",
                status: 'visible'
              };
              this.changeStatus(projectId, videodata);
              this.commonService.removeCookie('uploadvideoevent');
            }
            else {
              this.getAllVideos();
            }
          }, (reason) => {
            let projectId = this.commonService.getCookie('uploadvideoevent');
            if (projectId !== null && projectId !== undefined && projectId !== '') {
              let videodata = {
                id: projectId,
                type: "gallery",
                status: 'visible'
              };
              this.changeStatus(projectId, videodata);
              this.commonService.removeCookie('uploadvideoevent');
            }
            else {
              this.getAllVideos();
            }
          })
        }
        else if (data['code'] == 500) {
          /**
           * If no event found then clear previous data
           */
          this.workList = [];
          this.ProjectList = [];
          this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
        }
      },
      error => {
      });
  }
  /**
   * Change Status
   */
  changevisiableStatus(projectId, statusval) {
    let data = {
      id: projectId,
      type: "youtube",
      status: (statusval == 'public') ? 'unlisted' : 'public'
    };
    this.changeStatus(projectId, data);
  }
  /**
   * Change gallery Status
   */
  changegalleryStatus(projectId, statusval) {
    let data = {
      id: projectId,
      type: "gallery",
      status: (statusval == 'visible') ? 'invisible' : 'visible'
    };
    this.changeStatus(projectId, data);
  }
  /**
   * Change Status
   */
  changeStatus(projectId, data) {
    this.httpclient.post('project/' + projectId + '/video_change_status', data)
      .subscribe(
      data => {

        if (data['code'] == 200 || data['data']) {
          this.getAllVideos();
        }
        else if (data['code'] == 500) {
          this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
        }
      },
      error => {

      });
  }
  /**
   * mov to event page
   */
  movetoEvent(projectId) {
    this.commonService.setLocalStorage('projectId', projectId);
    this.router.navigate(['/events']);
  }

}
