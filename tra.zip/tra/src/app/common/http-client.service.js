var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from '@angular/core';
import { Headers, RequestOptions, Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { LocalStorageService } from 'angular-2-local-storage';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { TranslateService } from 'ng2-translate';
import 'rxjs/add/operator/map';
var HttpClientService = (function () {
    function HttpClientService(http, translate, router, modalService, localStorageService) {
        this.http = http;
        this.translate = translate;
        this.router = router;
        this.modalService = modalService;
        this.localStorageService = localStorageService;
        this.apiUrl = 'http://tracks-qa.catchmedia.com/';
        this.domainUrl = 'http://' + window.location.hostname + window.location.pathname.substr(0, window.location.pathname.lastIndexOf("/")) + '/';
        this.headers = this.publicheader();
        this.loader = [];
    }
    /**
      *  Request
      */
    HttpClientService.prototype.request = function (url, options) {
        var _this = this;
        this.loader.push(true);
        return this.http.request(this.apiUrl + url, this.headers)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(function () { _this.finalResponse(); });
    };
    /**
     * Get Request
     */
    HttpClientService.prototype.get = function (url, options) {
        var _this = this;
        this.loader.push(true);
        return this.http.get(this.apiUrl + url, this.headers)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(function () { _this.finalResponse(); });
        ;
    };
    /**
     * Post Request
     */
    HttpClientService.prototype.post = function (url, data, options, withCredentials) {
        var _this = this;
        this.loader.push(true);
        return this.http.post(this.apiUrl + url, data, this.publicheader(withCredentials))
            .map(this.extractData)
            .catch(this.handleError)
            .finally(function () { _this.finalResponse(); });
    };
    /**
     * delete Request
     */
    HttpClientService.prototype.delete = function (url, options) {
        var _this = this;
        this.loader.push(true);
        return this.http.delete(this.apiUrl + url, this.headers)
            .map(this.extractData)
            .catch(this.handleError)
            .finally(function () { _this.finalResponse(); });
    };
    /**
       * Success Handler
       */
    HttpClientService.prototype.extractData = function (res) {
        var body = (res['_body'] !== '' && res['_body'] !== undefined && res['_body'] !== null) ? res.json() : {};
        return body || {};
    };
    /**
     * Error Handler
     */
    HttpClientService.prototype.handleError = function (error) {
        var errMsg;
        if (error instanceof Response) {
            var body = error.json() || '';
            var err = body.message || JSON.stringify(body);
            errMsg = error.status + " - " + (error.statusText || '') + " " + err;
            this.errormessage = errMsg;
        }
        else {
            errMsg = error.message ? error.message : error.toString();
            this.errormessage = errMsg;
        }
        return Observable.throw(errMsg);
    };
    /**
     * Final Response
     */
    HttpClientService.prototype.finalResponse = function () {
        this.loader.pop();
    };
    /**
     * Set Logout user Http Header
     */
    HttpClientService.prototype.publicheader = function (withCredentials) {
        if (withCredentials === void 0) { withCredentials = true; }
        var headers = new Headers({
            'X-Requested-With': 'XMLHttpRequest'
        });
        return new RequestOptions({ headers: headers, withCredentials: withCredentials });
    };
    return HttpClientService;
}());
HttpClientService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [Http,
        TranslateService,
        Router,
        NgbModal,
        LocalStorageService])
], HttpClientService);
export { HttpClientService };
//# sourceMappingURL=http-client.service.js.map