import { Injectable } from '@angular/core';
import { HttpModule, URLSearchParams, ConnectionBackend, RequestOptionsArgs, Headers, RequestOptions, Http, Request, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { Cookie } from 'angular2-cookies';
import { LocalStorageService } from 'angular-2-local-storage';
import { NgbActiveModal, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Router, ActivatedRoute } from '@angular/router';
import { MessageComponent } from '../message/message.component';
import { TranslateService } from 'ng2-translate';
import 'rxjs/add/operator/map';

@Injectable()

export class HttpClientService {
  apiUrl: string = 'http://tracks-qa.catchmedia.com/';
  domainUrl: string = 'http://'+window.location.host+window.location.pathname.substr(0, window.location.pathname.lastIndexOf("/"))+'/';
  headers: Object = this.publicheader();
  loader: Array<any> = [];
  errormessage: string;
  apiArr :Array<any> = [];

  constructor(
    private http: Http,
    private translate: TranslateService,
    private router: Router,
    private modalService: NgbModal,
    private localStorageService: LocalStorageService,
  ) {

  }
  /**
    *  Request
    */
  request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
    this.loader.push(true);
    return this.http.request(
      this.apiUrl + url,
      this.headers
    )
      .map(this.extractData)
      .catch(this.handleError)
      .finally(() => { this.finalResponse(this.apiUrl + url); });
  }
  /**
   * Get Request
   */
  get(url: string, options?: RequestOptionsArgs): Observable<Response> {
    this.apiArr[this.apiUrl + url] = new Date();
    this.loader.push(true);
    return this.http.get(
      this.apiUrl + url,
      this.headers
    )
      .map(this.extractData)
      .catch(this.handleError)
      .finally(() => { this.finalResponse(this.apiUrl + url); });
    ;
  }
  /**
   * Post Request
   */
  post(url: string, data:any, options?: RequestOptionsArgs, withCredentials?:any): Observable<Response> {
    this.apiArr[this.apiUrl + url] = new Date();
    this.loader.push(true);
    return this.http.post(
      this.apiUrl + url,
      data,
      this.publicheader(withCredentials)
    )
      .map(this.extractData)
      .catch(this.handleError)
      .finally(() => { this.finalResponse(this.apiUrl + url); });
  }
  /**
   * delete Request
   */
  delete(url: string, options?: RequestOptionsArgs): Observable<Response> {
    this.loader.push(true);
    return this.http.delete(
      this.apiUrl + url,
      this.headers
    )
      .map(this.extractData)
      .catch(this.handleError)
      .finally(() => { this.finalResponse(this.apiUrl + url); });
  }
  /**
   * Get Request
   */
  getgeolocation(url: string): Observable<Response> {
    return this.http.get(
      url
    )
      .map(this.extractData)
      .catch(this.handleError)
      .finally(() => { this.finalResponse(this.apiUrl + url); });
    ;
  }
  /**
     * Success Handler
     */
  private extractData(res: Response) {
    let body = (res['_body'] !== '' && res['_body'] !== undefined && res['_body'] !== null) ? res.json() : {};
    return body || {};
  }
  /**
   * Error Handler
   */
  private handleError(error: Response | any) {
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.message || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
      this.errormessage = errMsg;
    } else {
      errMsg = error.message ? error.message : error.toString();
      this.errormessage = errMsg;
    }
    return Observable.throw(errMsg);
  }
  /**
   * Final Response
   */
  finalResponse(url) {
    let seconds = (new Date().getTime() - this.apiArr[url].getTime()) / 1000;
    console.log(url +' = '+seconds+' second');
    this.loader.pop();
  }
  /**
   * Set Logout user Http Header
   */
  publicheader(withCredentials = true) {
    let headers = new Headers({
      'X-Requested-With': 'XMLHttpRequest'
    });
    return new RequestOptions({ headers: headers, withCredentials: withCredentials });
  }

}