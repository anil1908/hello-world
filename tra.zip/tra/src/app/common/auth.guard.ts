import { Injectable } from '@angular/core';
import { CommonService } from '../common/common.service';
import { Router,NavigationStart, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

/**
 * check login page
 */
@Injectable()
export class AuthGuard implements CanActivate {
    constructor(private router: Router,
        private commonService: CommonService) {
    }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (this.commonService.isLogin) {
            return true;
        }
        this.router.navigate(['/'], { queryParams: { returnUrl: state.url } });
        return false;
    }
}
/**
 * check without login page
 */
@Injectable()
export class UnauthGuard implements CanActivate {
    constructor(
        private router: Router,
        private commonService: CommonService) {

    }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        if (!this.commonService.isLogin) {
            return true;
        }
        this.router.navigate(['/events'], {  });
        return false;
    }
}