var __decorate = (this && this.__decorate) || function(decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
        d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else
        for (var i = decorators.length - 1; i >= 0; i--)
            if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Injectable } from '@angular/core';
import { Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { TranslateService } from 'ng2-translate';
import { Cookie } from 'angular2-cookies';
import { LocalStorageService } from 'angular-2-local-storage';
import { HttpClientService } from './http-client.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MessageComponent } from '../message/message.component';
var CommonService = (function() {
    function CommonService(translate, httpclient, modalService, localStorageService) {
        var _this = this;
        this.translate = translate;
        this.httpclient = httpclient;
        this.modalService = modalService;
        this.localStorageService = localStorageService;
        this.defaultLanguage = "en_US";
        this.globalVar = {};
        this.youtubeToken = '';
        this.imagePath = {
            logoImg: 'assets/images/logo.png',
            eventlogoImg: 'assets/images/logo-gray.png',
            arrowdown: 'assets/images/arrowdown-36.png',
            macbook: 'assets/images/home-macbook.png',
            homerowfirst: 'assets/images/homerow3-img1.png',
            homerow32: 'assets/images/homerow3-img2.png',
            homerow33: 'assets/images/homerow3-img3.png',
            collectionDefault: 'assets/images/homerow3-img3.png',
            favoriteActive: 'assets/images/favouriteactive-ico.png',
            favoriteInactive: 'assets/images/favourite-ico.png',
            noImage: 'assets/images/no-images.jpg',
            waveImg: 'assets/images/wevaimg.png',
            fbTemp: '<img src="assets/images/facebook.png">',
            twttTemp: '<img src="assets/images/twitter.png">',
            googleTemp: '<img src="assets/images/googleplus.png">',
        };
        this.is_regular_account = '1';
        this.userDetail = {
            consumer_id: '',
            country: '',
            date_created: '',
            email: '',
            first_name: '',
            last_name: '',
            partner_activated: '',
            phone_number: '',
            username: '',
            extra_data: {
                company_name: '',
                signup_type: '',
                tracks_is_regular_account: '',
                weva_id: ''
            },
            gallery_page: '',
        };
        this.galleryPage = {
            isGuest: false
        };
        this.paypalObj = {
            //  paypalUrl: 'https://www.sandbox.paypal.com/cgi-bin/webscr',
            paypalUrl: 'https://www.paypal.com/cgi-bin/webscr',
            business_email: 'buyer@catchmedia.com'
        };
        this.eventPageLink = [
            '/purchase',
            '/user/purchases',
            '/user/license',
            '/user/account',
            '/gallery/:id',
            '/project/videos',
            '/page/faqs',
            '/page/contactus',
            '/',
        ];
        this.dateConfig = {
            firstDayOfWeek: 'su',
            dateFormat: 'dd/mm/yyyy',
            showClearDateBtn: false,
            editableDateField: false,
            openSelectorOnInputClick: true,
            minYear: 1950,
            showTodayBtn: false,
            disableSince: {
                year: new Date().getFullYear(),
                month: new Date().getMonth() + 1,
                day: new Date().getDate() + 1
            }
        };
        this.isLogin = false;
        this.hasAnyFavorite = true;
        this.licenseTypes = {
            video: "microlicense_video_social",
            photo: "microlicense_photomontage_social",
            shortphoto: "microlicense_photomontage_short_social"
        };
        this.contactAddress = {
            line1: "Tracks Inc.",
            line2: "1450 Broadway,",
            line3: "39th floor New York, NY 10018",
        };
        this.pressEnq = 'press@tracksmusic.com';
        this.salesEnq = 'sales@tracksmusic.com';
        this.successMsg = { "show": false, "image": null, "msg": "", "callback": null, callbackObj: {} };
        this.isLoginUpdate = Observable.create(function(observer) {
            _this.isLoginObserver = observer;
        });
        //check user is collaborator or videographer
        this.is_regular_account = (this.userDetail["extra_data"].tracks_is_regular_account != null && this.userDetail["extra_data"].tracks_is_regular_account != undefined && this.userDetail["extra_data"].tracks_is_regular_account != '') ? this.userDetail["extra_data"].tracks_is_regular_account : "1";
    }
    /**
     * Set Language Variable
     */
    CommonService.prototype.setLanguageVar = function() {
        var _this = this;
        this.translate.get('COMMON.CONFIRMATION').subscribe(function(res) {
            _this.globalVar['confirmation'] = res;
        });
        this.translate.get('COMMON.WARNING').subscribe(function(res) {
            _this.globalVar['warning'] = res;
        });
        this.translate.get('COMMON.ERROR').subscribe(function(res) {
            _this.globalVar['error'] = res;
        });
        this.translate.get('COMMON.SUCCESS').subscribe(function(res) {
            _this.globalVar['success'] = res;
        });
        this.translate.get('EVENTS.ARCHIVE_CREATED_SUCCESSFULLY').subscribe(function(res) {
            _this.globalVar['archive_success'] = res;
        });
        this.translate.get('COMMON.SOMETHING_WENT_WRONG').subscribe(function(res) {
            _this.globalVar['something_went_wrong'] = res;
        });
        this.translate.get('EVENTS.ADDED_TO').subscribe(function(res) {
            _this.globalVar['added_to'] = res;
        });
        this.translate.get('EVENTS.DETAIL_UPDATE_SUCCESS').subscribe(function(res) {
            _this.globalVar['detail_updated_success'] = res;
        });
        this.translate.get('EVENTS.REMOVED_FROM').subscribe(function(res) {
            _this.globalVar['removed_from'] = res;
        });
        this.translate.get('EVENTS.FAVORITES').subscribe(function(res) {
            _this.globalVar['favorite'] = res;
        });
        this.translate.get('COMMON.THIS').subscribe(function(res) {
            _this.globalVar['this'] = res;
        });
        this.translate.get('EVENTS.SUGGESTED_WARNING').subscribe(function(res) {
            _this.globalVar['suggested_warning'] = res;
        });
        this.translate.get('COLLABORATOR.REMOVE_COLLABORATOR_CONFIRM').subscribe(function(res) {
            _this.globalVar['remove_collaborator_confirm'] = res;
        });
        this.translate.get('EVENTS.REMOVE_TRACK_CONFIRM').subscribe(function(res) {
            _this.globalVar['remove_track_confirm'] = res;
        });
        this.translate.get('LICENSE.SUGGESTED_TRACKS').subscribe(function(res) {
            _this.globalVar['suggested_tracks'] = res;
        });
        this.translate.get('EVENTS.EVENT_ARCHIVE_CONFIRM').subscribe(function(res) {
            _this.globalVar['event_archive_confirm'] = res;
        });
        this.translate.get('EVENTS.EVENT_ARCHIVE_CONFIRM2').subscribe(function(res) {
            _this.globalVar['event_archive_confirm2'] = res;
        });
        this.translate.get('ACCOUNT.NAME_SUCCESS_MESSAGE').subscribe(function(res) {
            _this.globalVar['name_success_message'] = res;
        });
        this.translate.get('ACCOUNT.PASSWORD_SUCCESS_MESSAGE').subscribe(function(res) {
            _this.globalVar['password_success_message'] = res;
        });
        this.translate.get('ACCOUNT.GALLARY_SUCCESS_MESSAGE').subscribe(function(res) {
            _this.globalVar['gallery_success_message'] = res;
        });
        this.translate.get('EVENTS.EVENT_DELETE_SUCCESS').subscribe(function(res) {
            _this.globalVar['event_delete_success'] = res;
        });
        this.translate.get('EVENTS.WORK_DELETE_SUCCESS').subscribe(function(res) {
            _this.globalVar['work_delete_success'] = res;
        });
        this.translate.get('COLLABORATOR.REMOVE_COLLABORATOR_SUCCESS').subscribe(function(res) {
            _this.globalVar['remove_collaborator_success'] = res;
        });
        this.translate.get('COLLABORATOR.REINVITE_COLLABORATOR_SUCCESS').subscribe(function(res) {
            _this.globalVar['reinvite_collaborator_success'] = res;
        });
        this.translate.get('LICENSE.PURCHASE_LICENSE_CONFIRM').subscribe(function(res) {
            _this.globalVar['purchase_license_confirm'] = res;
        });
        this.translate.get('LICENSE.LICENSE_VIDEO_NOT_CAPITALIZED').subscribe(function(res) {
            _this.globalVar['license_video'] = res;
        });
        this.translate.get('LICENSE.LICENSE_SHORT_PHOTO_NOT_CAPITALIZED').subscribe(function(res) {
            _this.globalVar['license_short_photo'] = res;
        });
        this.translate.get('LICENSE.LICENSE_PHOTO_NOT_CAPITALIZED').subscribe(function(res) {
            _this.globalVar['license_photo'] = res;
        });
        this.translate.get('LICENSE.LICENSE_WORK_TEXT').subscribe(function(res) {
            _this.globalVar['license_work'] = res;
        });
        this.translate.get('EVENTS.PAYMENT_SUCCESS').subscribe(function(res) {
            _this.globalVar['payment_success'] = res;
        });
        this.translate.get('EVENTS.PAYMENT_FAIL').subscribe(function(res) {
            _this.globalVar['payment_fail'] = res;
        });
        this.translate.get('CREATE_WORK.WORK_NAME_REQUIRED').subscribe(function(res) {
            _this.globalVar['work_name_required'] = res;
        });
        this.translate.get('VALIDATION.WORK_NAME_THIRTY_CHARACTERS_EXCEED').subscribe(function(res) {
            _this.globalVar['work_name_maxlength_error'] = res;
        });
        this.translate.get('COMMON.NOT_ADD_TRACKS_ON_ISSUE_LICENSE_WORK1').subscribe(function(res) {
            _this.globalVar['issue_license_work_restrict1'] = res;
        });
        this.translate.get('COMMON.NOT_ADD_TRACKS_ON_ISSUE_LICENSE_WORK2').subscribe(function(res) {
            _this.globalVar['issue_license_work_restrict2'] = res;
        });
    };
    /**
     * Set localStorage
     */
    CommonService.prototype.setLocalStorage = function(key, value) {
        this.localStorageService.set(key, value);
    };
    /**
     * get localStorage value
     */
    CommonService.prototype.getLocalStorage = function(key) {
        return this.localStorageService.get(key);
    };
    /**
     * remove localStorage
     * key : string or array
     */
    CommonService.prototype.removeLocalStorage = function(key) {
        if (typeof(key) == 'object') {
            for (var _i = 0, key_1 = key; _i < key_1.length; _i++) {
                var value = key_1[_i];
                this.localStorageService.remove(value);
            }
        } else {
            this.localStorageService.remove(key);
        }
    };
    /**
     * Set Cookie
     */
    CommonService.prototype.setCookie = function(name, value, expires, path, domain) {
        Cookie.save(name, value, expires, path, domain);
    };
    /**
     * get Cookie
     */
    CommonService.prototype.getCookie = function(name) {
        return Cookie.load(name);
    };
    /**
     * Remove Cookie
     * name : string or array
     */
    CommonService.prototype.removeCookie = function(name, path, domain) {
        if (typeof(name) == 'object') {
            for (var _i = 0, name_1 = name; _i < name_1.length; _i++) {
                var value = name_1[_i];
                Cookie.remove(value, path, domain);
            }
        } else {
            Cookie.remove(name, path, domain);
        }
    };
    /**
     * Check Is Login User
     */
    CommonService.prototype.updateLogin = function(call) {
        /**
         * Check Keep Login
         */
        var isremember = this.getLocalStorage('remember_me');
        if (isremember !== undefined && isremember !== null && isremember !== '' && isremember) {
            this.setCookie("isLogin", "true");
        }
        var userdetail = this.getLocalStorage('userDetail');
        this.isLogin = (userdetail !== null && userdetail !== undefined && userdetail !== '') ? true : false;
        /**
         * User Detail
         */
        if (this.getLocalStorage('userDetail') !== undefined && this.getLocalStorage('userDetail') !== null && this.getLocalStorage('userDetail') !== '') {
            this.userDetail = this.getLocalStorage('userDetail');
        }
    };
    /**
     * Update Language
     */
    CommonService.prototype.updatedefaultLanguage = function(language) {
        this.defaultLanguage = language;
    };;
    /**
     * Stringify Object (object to string)
     */
    CommonService.prototype.stringifyObject = function(data) {
        return (typeof data == "object") ? JSON.stringify(data) : data;
    };
    /**
     * string to object
     */
    CommonService.prototype.json = function(str) {
        return JSON.parse(str);
    };
    /**
     * Set Logout user Http Header
     */
    CommonService.prototype.publicjwt = function() {
        var headers = new Headers({
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/json'
        });
        return new RequestOptions({ headers: headers });
    };
    /**
     * State List
     */
    CommonService.prototype.getState = function() {
        return [
            { key: 'Alabama', value: 'Alabama' },
            { key: 'Alaska', value: 'Alaska' },
            { key: 'Arizona', value: 'Arizona' },
            { key: 'Arkansas', value: 'Arkansas' },
            { key: 'California', value: 'California' },
            { key: 'Colorado', value: 'Colorado' },
            { key: 'Connecticut', value: 'Connecticut' },
            { key: 'Delaware', value: 'Delaware' },
            { key: 'District of Columbia', value: 'District of Columbia' },
            { key: 'Florida', value: 'Florida' },
            { key: 'Georgia', value: 'Georgia' },
            { key: 'Hawaii', value: 'Hawaii' },
            { key: 'Idaho', value: 'Idaho' },
            { key: 'Illinois', value: 'Illinois' },
            { key: 'Indiana', value: 'Indiana' },
            { key: 'Iowa', value: 'Iowa' },
            { key: 'Kansas', value: 'Kansas' },
            { key: 'Kentucky', value: 'Kentucky' },
            { key: 'Louisiana', value: 'Louisiana' },
            { key: 'Maine', value: 'Maine' },
            { key: 'Maryland', value: 'Maryland' },
            { key: 'Massachusetts', value: 'Massachusetts' },
            { key: 'Michigan', value: 'Michigan' },
            { key: 'Minnesota', value: 'Minnesota' },
            { key: 'Mississippi', value: 'Mississippi' },
            { key: 'Missouri', value: 'Missouri' },
            { key: 'Montana', value: 'Montana' },
            { key: 'Nebraska', value: 'Nebraska' },
            { key: 'Nevada', value: 'Nevada' },
            { key: 'New Hampshire', value: 'New Hampshire' },
            { key: 'New Jersey', value: 'New Jersey' },
            { key: 'New Mexico', value: 'New Mexico' },
            { key: 'New York', value: 'New York' },
            { key: 'North Carolina', value: 'North Carolina' },
            { key: 'North Dakota', value: 'North Dakota' },
            { key: 'Ohio', value: 'Ohio' },
            { key: 'Oklahoma', value: 'Oklahoma' },
            { key: 'Pennsylvania', value: 'Pennsylvania' },
            { key: 'Rhode Island', value: 'Rhode Island' },
            { key: 'South Carolina', value: 'South Carolina' },
            { key: 'South Dakota', value: 'South Dakota' },
            { key: 'Tennessee', value: 'Tennessee' },
            { key: 'Texas', value: 'Texas' },
            { key: 'Utah', value: 'Utah' },
            { key: 'Vermont', value: 'Vermont' },
            { key: 'Virginia', value: 'Virginia' },
            { key: 'Washington', value: 'Washington' },
            { key: 'West Virginia', value: 'West Virginia' },
            { key: 'Wisconsin', value: 'Wisconsin' },
            { key: 'Wyoming', value: 'Wyoming' }
        ];
    };
    /**
     * Get login user all favorite tracks ids and store into cookie for furhter usage
     */
    CommonService.prototype.getUserFavorite = function() {
        var _this = this;
        this.httpclient.get('favorites/get_all')
            .subscribe(function(data) {
                if (data['code'] == 200) {
                    _this.setLocalStorage('favoriteIds', _this.stringifyObject(data['data']));
                    var favoriteIds = _this.json(_this.getLocalStorage("favoriteIds"));
                    if (favoriteIds != null && favoriteIds.length > 0) {
                        _this.hasAnyFavorite = true;
                    } else {
                        _this.hasAnyFavorite = false;
                    }
                }
            }, function(error) {});
    };
    /**
     *Message Popup
     */
    CommonService.prototype.messagePopup = function(title, message, showOk, showCancel) {
        if (showOk === void 0) { showOk = true; }
        if (showCancel === void 0) { showCancel = false; }
        var modalRef = this.modalService.open(MessageComponent);
        modalRef.componentInstance.message = message;
        modalRef.componentInstance.title = title;
        modalRef.componentInstance.showOk = showOk;
        modalRef.componentInstance.showCancel = showCancel;
        modalRef.result.then(function(result) {

        }, function(reason) {

        });
    };
    /**
     *Confirm Message Popup
     */
    CommonService.prototype.confirmMessagePopup = function(title, message, showOk, showCancel) {
        if (showOk === void 0) { showOk = true; }
        if (showCancel === void 0) { showCancel = false; }
        var modalRef = this.modalService.open(MessageComponent);
        modalRef.componentInstance.message = message;
        modalRef.componentInstance.title = title;
        modalRef.componentInstance.showOk = showOk;
        modalRef.componentInstance.showCancel = showCancel;
        return modalRef.result;
    };
    /**
     *Hide success message after 5 second
     */
    CommonService.prototype.hideSuccessMsg = function() {
        setTimeout(function() {
            this.successMsg['show'] = false;
        }.bind(this), 5000);
    };
    CommonService.prototype.getDateObject = function(datestr) {
        if (datestr !== '') {
            var dateFormat = new Date(datestr);
            return {
                year: (dateFormat !== undefined) ? dateFormat.getFullYear() : '',
                month: (dateFormat !== undefined) ? ("0" + (dateFormat.getMonth() + 1)).slice(-2) : '',
                day: (dateFormat !== undefined) ? ("0" + dateFormat.getDate()).slice(-2) : ''
            };
        } else {
            return {
                year: '',
                month: '',
                day: ''
            };
        }
    };
    /**
     * get User Credit
     */
    CommonService.prototype.getUserCredit = function() {
        var _this = this;
        this.httpclient.get('user/credit_balance')
            .subscribe(function(data) {
                if (data['code'] == 200) {
                    _this.creditData = data['data']['total'];
                }
            }, function(error) {});
    };
    return CommonService;
}());
CommonService = __decorate([
    Injectable(),
    __metadata("design:paramtypes", [TranslateService,
        HttpClientService,
        NgbModal,
        LocalStorageService
    ])
], CommonService);
export { CommonService };
//# sourceMappingURL=common.service.js.map