import { RouterModule } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { SearchResultComponent } from '../search-result/search-result.component';
import { EventsComponent } from '../events/events.component';
import { GalleryComponent } from '../gallery/gallery.component';
import { AuthGuard } from './auth.guard';
import { UnauthGuard } from './auth.guard';
// Route Configuration
var appRoutes = [
    {
        path: 'user',
        loadChildren: 'app/user/user.module#UserModule',
    },
    {
        path: 'page',
        loadChildren: 'app/page/page.module#PageModule'
    },
    {
        path: 'project',
        loadChildren: 'app/project/project.module#ProjectModule'
    },
    {
        path: 'purchase',
        loadChildren: 'app/purchase/purchase.module#PurchaseModule',
        canActivate: [AuthGuard]
    },
    {
        path: '',
        component: HomeComponent,
        canActivate: [UnauthGuard],
        data: {
            title: 'Home'
        }
    },
    {
        path: 'search',
        component: SearchResultComponent,
        canActivate: [UnauthGuard],
        data: {
            title: 'Search'
        }
    },
    {
        path: 'events',
        component: EventsComponent,
        canActivate: [AuthGuard],
        data: {
            title: 'Events'
        }
    },
    {
        path: 'gallery/:id',
        component: GalleryComponent,
        data: {
            title: 'Gallery'
        }
    },
    { path: '**', redirectTo: '' }
];
export var routing = RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routes.js.map