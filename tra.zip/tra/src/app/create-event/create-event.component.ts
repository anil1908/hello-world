import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { NgbActiveModal, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClientService } from '../common/http-client.service';
import { CommonService } from '../common/common.service';
import { ValidationService } from '../common/validation.service';

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css']
})
export class CreateEventComponent implements OnInit {
  /* initialize variables */
  @ViewChild('focusable') inputfocus: any;
  @Input() copy_of_project: any;
  createEventForm: FormGroup;
  liveDate: Object = { "day": "", "month": "", "year": "" };
  eventTypes: Object;
  showOther = false;
  collaboratorMails: any = [];
  submitted: boolean = false;
  //set server side error message Object
  msg: Object = { issuccess: false, isError: false, msg: '' };

  constructor(
    public fb: FormBuilder,
    public activeModal: NgbActiveModal,
    private httpclient: HttpClientService,
    private commonService: CommonService,
    private validationService: ValidationService) { }

  /* This method is call when page is load
     */
  ngOnInit() {
    //Create form to add new event
    this.createEventForm = this.fb.group({
      'project_name': ['', Validators.compose([Validators.required, Validators.maxLength(100)])],
      'copy_of_project': [null],
      'event_type': [''],
      'live_date': [''],
      'sub_type': [''],
      'parent_project_id': [''],
      'collaborators': [null]
    });

    /*
    Get list of event type
     */
    this.httpclient.get('projects/get_event_types')
      .subscribe(
      data => {
        if (data['code'] == 200) {
          this.eventTypes = data['data'];
        }
      },
      error => {
        this.commonService.messagePopup(this.commonService.globalVar['error'], error);
      });
  }

  /*
  On chnage of event type
  If other event then visible textbox to add value
   */
  onChange(event: string, el: any) {
    if (event == "Other") {
      this.showOther = true;
      el.value = event;
      setTimeout(function () {
        el.focus();
      }, 0);
    } else {
      this.showOther = false;
    }
  }

  /*
  Add vollaborator into array
   */
  addCollaborator(email: HTMLInputElement) {
    if (email.value != "" && (this.validationService.emailValidator(email) == null)) {
      let collArr: Array<any> = [];
      if (this.collaboratorMails.length > 0) {
        for (var emails in this.collaboratorMails) {
          collArr.push(this.collaboratorMails[emails]["email"]);
        }
      }
      if (collArr.length > 0 && collArr.indexOf(email.value) == -1) {
        this.collaboratorMails.push({ "email": email.value });
      } else if (collArr.length == 0) {
        this.collaboratorMails.push({ "email": email.value });
      }
      email.value = "";
    }
  }

  /*
  Remove collaborator from list
  */
  removeCollaboratorMail(email: any) {
    this.collaboratorMails.splice(this.collaboratorMails.indexOf(email), 1);
  }

  /**
   * Create Event Request
   */
  submitCreateEvent(projectnamefocus): void {
    if (this.liveDate['year'] != "" && this.liveDate['year'] != null && this.liveDate['year'] != undefined && this.liveDate['month'] != "" && this.liveDate['month'] != null && this.liveDate['month'] != undefined && this.liveDate['day'] != "" && this.liveDate['day'] != null && this.liveDate['day'] != undefined) {

    } else {
      this.createEventForm.controls["live_date"].setValue("");
    }
    if (this.createEventForm.valid) {
      /*
      Check event name is unique or not
      */
      this.httpclient.post('project/is_name_unique', { "project_name": this.createEventForm.value.project_name })
        .subscribe(
        data => {
          if (data['code'] == 500) {
            this.msg['isError'] = true;
            this.msg['isSuccess'] = false;
            this.msg['msg'] = data['message'];
          } else {
            /* If name is not unique then create event */
            this.createEvent();
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      if (this.createEventForm.controls['project_name'].value == '') {
        projectnamefocus.focus();
      }
      this.submitted = true;
    }
  }

  /* Create event request */
  private createEvent() {
    if (this.liveDate['year'] != "" && this.liveDate['year'] != null && this.liveDate['year'] != undefined && this.liveDate['month'] != "" && this.liveDate['month'] != null && this.liveDate['month'] != undefined && this.liveDate['day'] != "" && this.liveDate['day'] != null && this.liveDate['day'] != undefined) {
      let dateobj = this.liveDate;
      this.createEventForm.controls["live_date"].setValue(new Date(this.liveDate['year'], (this.liveDate['month'] - 1), this.liveDate['day']));
      this.liveDate = dateobj;
    } else {
      this.createEventForm.controls["live_date"].setValue("");
    }
    if (this.createEventForm.controls['collaborators'].value != "" && this.createEventForm.controls['collaborators'].value != null && this.createEventForm.controls['collaborators'].value != undefined && this.createEventForm.controls['collaborators'].value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
      this.collaboratorMails.push({ "email": this.createEventForm.controls['collaborators'].value });
    }
    let formData: Object = {
      "project_name": this.createEventForm.value.project_name,
      "event_type": this.createEventForm.value.event_type,
      "live_date": this.createEventForm.value.live_date
    };
    (this.copy_of_project != null && this.copy_of_project != '' && this.copy_of_project != undefined) ? formData["copy_of_project"] = this.copy_of_project : "";
    (this.collaboratorMails.length > 0) ? formData["collaborators"] = (this.collaboratorMails) : "";
    (this.createEventForm.value.sub_type != null) ? formData["sub_type"] = this.createEventForm.value.sub_type : "";
    (this.createEventForm.value.parent_project_id != null) ? formData["parent_project_id"] = this.createEventForm.value.parent_project_id : "";
    this.createEventForm.controls['collaborators'].setValue('');
    this.httpclient.post('project/create', formData)
      .subscribe(
      data => {
        if (data['code'] == 500) {
          this.commonService.messagePopup(this.commonService.globalVar['error'], data['message']);
        } else {
          this.activeModal.close({ project_id: data['data']['project']['id'] });
        }
      },
      error => {
        this.commonService.messagePopup(this.commonService.globalVar['error'], error);
      });
  }
}
