var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input, ViewChild } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClientService } from '../common/http-client.service';
import { CommonService } from '../common/common.service';
import { ValidationService } from '../common/validation.service';
var CreateEventComponent = (function () {
    function CreateEventComponent(fb, activeModal, httpclient, commonService, validationService) {
        this.fb = fb;
        this.activeModal = activeModal;
        this.httpclient = httpclient;
        this.commonService = commonService;
        this.validationService = validationService;
        this.liveDate = { "day": "", "month": "", "year": "" };
        this.showOther = false;
        this.collaboratorMails = [];
        this.submitted = false;
        //set server side error message Object
        this.msg = { issuccess: false, isError: false, msg: '' };
    }
    /* This method is call when page is load
       */
    CreateEventComponent.prototype.ngOnInit = function () {
        var _this = this;
        //Create form to add new event
        this.createEventForm = this.fb.group({
            'project_name': ['', Validators.compose([Validators.required, Validators.maxLength(100)])],
            'copy_of_project': [null],
            'event_type': [''],
            'live_date': [''],
            'sub_type': [''],
            'parent_project_id': [''],
            'collaborators': [null]
        });
        /*
        Get list of event type
         */
        this.httpclient.get('projects/get_event_types')
            .subscribe(function (data) {
            if (data['code'] == 200) {
                _this.eventTypes = data['data'];
            }
        }, function (error) {
            _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
        });
    };
    /*
    On chnage of event type
    If other event then visible textbox to add value
     */
    CreateEventComponent.prototype.onChange = function (event, el) {
        if (event == "Other") {
            this.showOther = true;
            el.value = event;
            setTimeout(function () {
                el.focus();
            }, 0);
        }
        else {
            this.showOther = false;
        }
    };
    /*
    Add vollaborator into array
     */
    CreateEventComponent.prototype.addCollaborator = function (email) {
        if (email.value != "" && (this.validationService.emailValidator(email) == null)) {
            var collArr = [];
            if (this.collaboratorMails.length > 0) {
                for (var emails in this.collaboratorMails) {
                    collArr.push(this.collaboratorMails[emails]["email"]);
                }
            }
            if (collArr.length > 0 && collArr.indexOf(email.value) == -1) {
                this.collaboratorMails.push({ "email": email.value });
            }
            else if (collArr.length == 0) {
                this.collaboratorMails.push({ "email": email.value });
            }
            email.value = "";
        }
    };
    /*
    Remove collaborator from list
    */
    CreateEventComponent.prototype.removeCollaboratorMail = function (email) {
        this.collaboratorMails.splice(this.collaboratorMails.indexOf(email), 1);
    };
    /**
     * Create Event Request
     */
    CreateEventComponent.prototype.submitCreateEvent = function () {
        var _this = this;
        if (this.liveDate['year'] != "" && this.liveDate['year'] != null && this.liveDate['year'] != undefined && this.liveDate['month'] != "" && this.liveDate['month'] != null && this.liveDate['month'] != undefined && this.liveDate['day'] != "" && this.liveDate['day'] != null && this.liveDate['day'] != undefined) {
        }
        else {
            this.createEventForm.controls["live_date"].setValue("");
        }
        if (this.createEventForm.valid) {
            /*
        Check event name is unique or not
         */
            this.httpclient.post('project/is_name_unique', { "project_name": this.createEventForm.value.project_name })
                .subscribe(function (data) {
                if (data['code'] == 500) {
                    _this.msg['isError'] = true;
                    _this.msg['isSuccess'] = false;
                    _this.msg['msg'] = data['message'];
                }
                else {
                    /* If name is not unique then create event */
                    _this.createEvent();
                }
            }, function (error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
            });
        }
        else {
            this.submitted = true;
        }
    };
    /* Create event request */
    CreateEventComponent.prototype.createEvent = function () {
        var _this = this;
        if (this.liveDate['year'] != "" && this.liveDate['year'] != null && this.liveDate['year'] != undefined && this.liveDate['month'] != "" && this.liveDate['month'] != null && this.liveDate['month'] != undefined && this.liveDate['day'] != "" && this.liveDate['day'] != null && this.liveDate['day'] != undefined) {
            var dateobj = this.liveDate;
            this.createEventForm.controls["live_date"].setValue(new Date(this.liveDate['year'], (this.liveDate['month'] - 1), this.liveDate['day']));
            this.liveDate = dateobj;
        }
        else {
            this.createEventForm.controls["live_date"].setValue("");
        }
        var formData = {
            "project_name": this.createEventForm.value.project_name,
            "event_type": this.createEventForm.value.event_type,
            "live_date": this.createEventForm.value.live_date
        };
        (this.copy_of_project != null && this.copy_of_project != '' && this.copy_of_project != undefined) ? formData["copy_of_project"] = this.copy_of_project : "";
        (this.collaboratorMails.length > 0) ? formData["collaborators"] = (this.collaboratorMails) : "";
        (this.createEventForm.value.sub_type != null) ? formData["sub_type"] = this.createEventForm.value.sub_type : "";
        (this.createEventForm.value.parent_project_id != null) ? formData["parent_project_id"] = this.createEventForm.value.parent_project_id : "";
        this.httpclient.post('project/create', formData)
            .subscribe(function (data) {
            if (data['code'] == 500) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message']);
            }
            else {
                _this.activeModal.close({ project_id: data['data']['project']['id'] });
            }
        }, function (error) {
            _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
        });
    };
    return CreateEventComponent;
}());
__decorate([
    ViewChild('focusable'),
    __metadata("design:type", Object)
], CreateEventComponent.prototype, "inputfocus", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], CreateEventComponent.prototype, "copy_of_project", void 0);
CreateEventComponent = __decorate([
    Component({
        selector: 'app-create-event',
        templateUrl: './create-event.component.html',
        styleUrls: ['./create-event.component.css']
    }),
    __metadata("design:paramtypes", [FormBuilder,
        NgbActiveModal,
        HttpClientService,
        CommonService,
        ValidationService])
], CreateEventComponent);
export { CreateEventComponent };
//# sourceMappingURL=create-event.component.js.map