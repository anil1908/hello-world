import { Component, Input, OnInit } from '@angular/core';
import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-message',
  templateUrl: './message.component.html',
  styleUrls: ['./message.component.css']
})
export class MessageComponent implements OnInit {
  @Input() title :any;
  @Input() message : any;
  @Input() showCancel = false;
  @Input() showOk = true;

  constructor(public activeModal: NgbActiveModal) { }

/* This method is call when page is load
   */
  ngOnInit() {

  }

  confirmOk() {
    this.activeModal.close(true);
  }
}
