import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common/common.service';

@Component({
  selector: 'app-why-license',
  templateUrl: './why-license.component.html',
  styleUrls: ['./why-license.component.css']
})
export class WhyLicenseComponent implements OnInit {

  constructor(
    private commonService: CommonService) { }

  ngOnInit() {
  }

}
