import { Pipe, PipeTransform, Injectable } from '@angular/core';
import { CommonService } from '../common/common.service';

@Pipe({
  name: 'values',
  pure: false
})

export class ValuesPipe implements PipeTransform {
  transform(value: any, args: string = ''): any {
    var a = [];
    for (var key in value) {
      if (value.hasOwnProperty(key)) {
        if (args === 'key') {
          //return key
          a.push(key);
        } else if (args === 'value') {
          //return value
          a.push(value[key]);
        }
        else {
          //return key and value
          a.push({ objKey: key, objValue: value[key] });
        }
      }
    }
    return a;
  }
}

/*
  Check tracks id in user favorite or not
  return: boolean
 */
@Pipe({
  name: 'trackIsFavorite',
  pure: false
})
@Injectable()
export class trackIsFavoritePipe implements PipeTransform {
  private favoriteIds: any = this.commonService.getLocalStorage("favoriteIds");
  constructor(
    private commonService: CommonService) {
  }
  transform(args: any[]): boolean {
    if (this.favoriteIds != null && this.commonService.isLogin) {
      this.favoriteIds = this.commonService.json(this.commonService.getLocalStorage("favoriteIds"));
      return (this.favoriteIds.indexOf(args) !== -1);
    }
    return false;
  }
}

/*
 Get month short name
  return: string
 */
@Pipe({
  name: 'getMonthShortName',
  pure: true
})
@Injectable()
export class getMonthShortNamePipe implements PipeTransform {
  transform(args: number): string {
    var months = { "1": "Jan", "2": "Feb", "3": "Mar", "4": "Apr", "5": "May", "6": "Jun", "7": "Jul", "8": "Aug", "9": "Sep", "10": "Oct", "11": "Nov", "12": "Dec" };
    return months[args];
  }
}

/*
 Get month short name
  return: string
 */
@Pipe({
  name: 'workIdString',
  pure: true
})
@Injectable()
export class workIdStringPipe implements PipeTransform {
  transform(args: any): boolean {
    if (args == "like" || args == "dislike" || args == "suggested") {
      return true;
    } return false;
  }
}
/*
 truncate charecter
  return: string
 */
@Pipe({
  name: 'truncate'
})
export class TruncatePipe {
  transform(value: any, args: number): any {
    if (value != null && value != undefined && value != "") {
      let strlength = value.toString().length;
      let start = strlength - args;
      return (typeof (value) == 'number') ? value.toString().substring(start, strlength) : value.substring(start, strlength);
    }
    return null;
  }
}