var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Pipe, Injectable } from '@angular/core';
import { CommonService } from '../common/common.service';
var ValuesPipe = (function () {
    function ValuesPipe() {
    }
    ValuesPipe.prototype.transform = function (value, args) {
        if (args === void 0) { args = ''; }
        var a = [];
        for (var key in value) {
            if (value.hasOwnProperty(key)) {
                if (args === 'key') {
                    //return key
                    a.push(key);
                }
                else if (args === 'value') {
                    //return value
                    a.push(value[key]);
                }
                else {
                    //return key and value
                    a.push({ objKey: key, objValue: value[key] });
                }
            }
        }
        return a;
    };
    return ValuesPipe;
}());
ValuesPipe = __decorate([
    Pipe({
        name: 'values',
        pure: false
    })
], ValuesPipe);
export { ValuesPipe };
/*
  Check tracks id in user favorite or not
  return: boolean
 */
var trackIsFavoritePipe = (function () {
    function trackIsFavoritePipe(commonService) {
        this.commonService = commonService;
        this.favoriteIds = this.commonService.getLocalStorage("favoriteIds");
    }
    trackIsFavoritePipe.prototype.transform = function (args) {
        if (this.favoriteIds != null && this.commonService.isLogin) {
            this.favoriteIds = this.commonService.json(this.commonService.getLocalStorage("favoriteIds"));
            return (this.favoriteIds.indexOf(args) !== -1);
        }
        return false;
    };
    return trackIsFavoritePipe;
}());
trackIsFavoritePipe = __decorate([
    Pipe({
        name: 'trackIsFavorite',
        pure: false
    }),
    Injectable(),
    __metadata("design:paramtypes", [CommonService])
], trackIsFavoritePipe);
export { trackIsFavoritePipe };
/*
 Get month short name
  return: string
 */
var getMonthShortNamePipe = (function () {
    function getMonthShortNamePipe() {
    }
    getMonthShortNamePipe.prototype.transform = function (args) {
        var months = { "1": "Jan", "2": "Feb", "3": "Mar", "4": "Apr", "5": "May", "6": "Jun", "7": "Jul", "8": "Aug", "9": "Sep", "10": "Oct", "11": "Nov", "12": "Dec" };
        return months[args];
    };
    return getMonthShortNamePipe;
}());
getMonthShortNamePipe = __decorate([
    Pipe({
        name: 'getMonthShortName',
        pure: true
    }),
    Injectable()
], getMonthShortNamePipe);
export { getMonthShortNamePipe };
/*
 Get month short name
  return: string
 */
var workIdStringPipe = (function () {
    function workIdStringPipe() {
    }
    workIdStringPipe.prototype.transform = function (args) {
        if (args == "like" || args == "dislike" || args == "suggested") {
            return true;
        }
        return false;
    };
    return workIdStringPipe;
}());
workIdStringPipe = __decorate([
    Pipe({
        name: 'workIdString',
        pure: true
    }),
    Injectable()
], workIdStringPipe);
export { workIdStringPipe };
/*
 truncate charecter
  return: string
 */
var TruncatePipe = (function () {
    function TruncatePipe() {
    }
    TruncatePipe.prototype.transform = function (value, args) {
        if (value != null && value != undefined && value != "") {
            var strlength = value.toString().length;
            var start = strlength - args;
            return (typeof (value) == 'number') ? value.toString().substring(start, strlength) : value.substring(start, strlength);
        }
        return null;
    };
    return TruncatePipe;
}());
TruncatePipe = __decorate([
    Pipe({
        name: 'truncate'
    })
], TruncatePipe);
export { TruncatePipe };
//# sourceMappingURL=values.pipe.js.map