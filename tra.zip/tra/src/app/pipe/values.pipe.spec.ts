/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ValuesPipe } from './values.pipe';

describe('ValuesPipe', () => {
  it('create an instance', () => {
    let pipe = new ValuesPipe();
    expect(pipe).toBeTruthy();
  });
});
