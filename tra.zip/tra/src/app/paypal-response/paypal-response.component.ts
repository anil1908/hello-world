import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';

@Component({
  templateUrl: './paypal-response.component.html',
  styleUrls: ['./paypal-response.component.css']
})
export class PaypalResponseComponent implements OnInit {
  /* initialize variables */
  order_id: string;
  orderArr: Array<any> = [];
  constructor(
    private router: Router,
    private commonService: CommonService,
    private httpclient: HttpClientService,
    private route: ActivatedRoute) { }

  /* This method is call when page is load
     */
  ngOnInit() {
    this.order_id = this.route.snapshot.params['id'];
    this.orderArr = this.order_id.split(',');
    if (this.commonService.getLocalStorage('purdata') === null || this.commonService.getLocalStorage('purdata') === undefined || this.commonService.getLocalStorage('purdata') === '') {
      this.router.navigate(['/purchase']);
      return false;
    } else {
      this.commonService.removeLocalStorage('purdata');
      this.router.events.subscribe(url => {
        if (url['url'].indexOf('/purchase/close_verified_order/') >= 0) {
          this.closeVerifyOrder();
        }
        else if (url['url'].indexOf('/purchase/cancel/') >= 0) {
          this.cancleOrder();
        }
      });
    }
  }
  /**
   * Close Verify Order
   */
  closeVerifyOrder() {
    this.commonService.getUserCredit();
    // let retData = this.route.snapshot.queryParams;
    // let data = {
    //   "payment_status": retData["st"],
    //   "txn_id": retData["tx"],
    //   "mc_currency": retData["cc"],
    //   "payment_gross": retData["amt"],
    // }
    // let purchaseUrl = 'purchase/close_verified_order/';
    // if (this.orderArr.length > 0) {
    //   for (let k = 0; k < this.orderArr.length; k++) {
    //     this.httpclient.post(purchaseUrl+this.orderArr[k], data)
    //       .subscribe(
    //       data => {
    //         if (data['code'] == 200) {
    //           this.commonService.getUserCredit();
    //         }
    //         else {
    //           this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'].join());
    //         }
    //       },
    //       error => {
    //         this.commonService.messagePopup(this.commonService.globalVar['error'], error);
    //       });
    //   }
    // }
  }
  /**
   * cancle Order
   */
  cancleOrder() {
    // if (this.orderArr.length > 0) {
    //   for (let k = 0; k < this.orderArr.length; k++) {
    //     this.httpclient.get('purchase/cancel/' + this.orderArr[k])
    //       .subscribe(
    //       data => {
    //         if (data['code'] == 200) {

    //         }
    //         else {
    //           this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'].join());
    //         }
    //       },
    //       error => {
    //         this.commonService.messagePopup(this.commonService.globalVar['error'], error);
    //       });
    //   }
    // }
  }

}
