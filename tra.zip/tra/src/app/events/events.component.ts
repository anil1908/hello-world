import { Component, ViewChildren, ViewChild, OnInit, Renderer, ElementRef } from '@angular/core';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
import { NgbActiveModal, NgbModal,NgbModalOptions, ModalDismissReasons, NgbDateParserFormatter, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MessageComponent } from '../message/message.component';
import { LicenseComponent } from '../license/license.component';
import { ChannelsComponent } from '../channels/channels.component';
import { DownloadMediaComponent } from '../download-media/download-media.component';
import { CreateEventComponent } from '../create-event/create-event.component';
import { DeleteEventComponent } from '../delete-event/delete-event.component';
import { CollaboratorComponent } from '../collaborator/collaborator.component';
import { CreateWorkComponent } from '../create-Work/create-work.component';
import { OrderProgressbarComponent } from '../order-progressbar/order-progressbar.component';
import { trackIsFavoritePipe } from '../pipe/values.pipe';
import { workIdStringPipe } from '../pipe/values.pipe';
import { IMyOptions, IMyDate, IMyDateModel } from 'mydatepicker';
import { Router, ActivatedRoute } from '@angular/router';
import { TranslateService } from 'ng2-translate';

@Component({
  selector: 'app-events',
  templateUrl: './events.component.html',
  styleUrls: ['./events.component.css'],
  host: {
    '(document:click)': 'documentclick($event)',
  },
})
export class EventsComponent implements OnInit {
  @ViewChildren('workPlayer') workPlayer : any;
  @ViewChildren('searchPlayer') searchPlayer : any;
  @ViewChildren('collectionPlayer') collectionPlayer : any;
  @ViewChildren('favouritePlayer') favouritePlayer : any;
  @ViewChild('actvieProjectList') private actvieProjectList: ElementRef;

  /* initialize variables */
  myDatePickerOptions: IMyOptions;
  enableRightPanel: boolean = false;
  isenableRightPanel: boolean = true;
  eventOption: boolean = false;
  tracks : string = '';
  filteredList: Object = { albums: [], artists: [], tracks: [] };
  likeData: any;
  activityData: Array<any> = [];
  searchDetail = { id: '', track_name: '' };
  collaboratorActivity: Object = { start: 0, limit: 5 }
  resultList: Array<any> = [];
  show_no_result_list: Boolean = false;
  searchHistoryList: Array<any> = (this.commonService.json(this.commonService.getLocalStorage('searchData')) !== null && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== undefined && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== '') ? this.commonService.json(this.commonService.getLocalStorage('searchData')) : [];
  pc: any;
  currentaudio: any;
  lastplayid: any;
  workList: Array<any> = [];
  projectId: any = '';
  workIdStringData: String = '';
  ProjectList: Array<any> = [];
  isArchiveProject: boolean = false;
  eventData: any;
  collectionObj: Object = {
    collectionList: [],
    collectionTracksList: [],
    selectedCollection: '',
  };
  iscollectionfetch: boolean = false;
  updateEventForm: FormGroup;
  eventTypes: any;
  dispalyLiveDate: String = "";
  //set server side error message Object
  msg: Object = { issuccess: false, isError: false, msg: '' };
  submitted: boolean = false;
  enableEdit: Boolean = false;
  showOther: Boolean = false;
  favoriteList: Array<any>;
  is_regular_account = "1";
  hideNewEvent: Boolean = false;
  allsetEvent : Boolean = false;
  hideNewWork: Boolean = false;
  hideFavorite: Boolean = false;
  hideTrackAdd: Boolean = false;
  allsettooltip : Boolean = false;
  collaboratorInstruction : Boolean = false;
  collaboratorTabActive :number =1;
  showdatePicker: boolean = false;
  hideLicense: Boolean = false;
  workaudio = 0;
  show_new_event_tooltip: Boolean = false;
  show_new_work_tooltip: Boolean = false;
  isEventWorkLicense : Boolean = false;
  orderpendingstatuscount : number = 1;

  constructor(
    private translate: TranslateService,
    public fb: FormBuilder,
    private modalService: NgbModal,
    public commonService: CommonService,
    private httpclient: HttpClientService,
    private renderer: Renderer,
    private parserFormatter: NgbDateParserFormatter,
    private route: ActivatedRoute,
    private elm: ElementRef,
  ) {
    this.myDatePickerOptions = {
      firstDayOfWeek : 'su',
      dateFormat: 'MMM. DD, YYYY',
      showClearDateBtn: false,
      editableDateField: false,
      openSelectorOnInputClick: true,
      showTodayBtn: false,
      inline: true
    };
  }

  /* This method is call when page is load
     */
  ngOnInit() {
    this.pc = 298.1371428256714; // 2 pi r
    //Create form to add new event
    this.updateEventForm = this.fb.group({
      'project_id': [''],
      'project_name': ['', Validators.compose([Validators.required, Validators.maxLength(100)])],
      'event_type': [''],
      'live_date': [''],
    });
    //check user is collaborator or videographer
    this.is_regular_account = (this.commonService.userDetail["extra_data"].tracks_is_regular_account != null && this.commonService.userDetail["extra_data"].tracks_is_regular_account != undefined) ? this.commonService.userDetail["extra_data"].tracks_is_regular_account : "1";
    //check tooltip variable are set or not
    this.hideFavorite = Boolean(this.commonService.getCookie('hideFavorite'));
    this.hideTrackAdd = Boolean(this.commonService.getCookie('hideTrackAdd'));
    this.hideLicense = Boolean(this.commonService.getCookie('hideLicense'));
    this.hideNewEvent = Boolean(this.commonService.getCookie('hideNewEvent'));
    this.allsetEvent = Boolean(this.commonService.getCookie('allsetEvent'));
    this.hideNewWork = Boolean(this.commonService.getCookie('hideNewWork'));
    this.collaboratorInstruction = Boolean(this.commonService.getLocalStorage('collaboratorInstruction'));
    
    /* Get all project when page load */
    ``
    this.getAllProject();
    /* check come from payment page or not */
    let paymentResponse = this.route.snapshot.queryParams;
    let isPurchase = Boolean(this.commonService.getCookie('isPurchase'));
    if (paymentResponse != null && paymentResponse != undefined && (Object.keys(paymentResponse).length) > 0 && isPurchase) {
      if (paymentResponse["st"] == "fail") {
        this.translate.get('EVENTS.PAYMENT_FAIL').subscribe((res: any) => {
          this.commonService.successMsg = { "show": true, "msg": "<strong>" + res + "</strong>" };
        });
        this.cancelOrder(paymentResponse["order"]);
      }
      else{
        this.checkPaymentStatus(paymentResponse["order"]); 
      }
      this.commonService.removeLocalStorage('purdata');
      this.commonService.removeCookie('isPurchase');
    }

  }

  /**
   * Check Payment Status
   */
  checkPaymentStatus(order_id){
      this.httpclient.get('/purchase/status/'+order_id)
        .subscribe(
        data => {
          if(data['code']==200){
            if(data['data']['status']=='completed'){
              this.commonService.getUserCredit();   
            }
            if(data['data']['status']=='failed'){
              this.translate.get('EVENTS.PAYMENT_FAIL').subscribe((res: any) => {
                this.commonService.successMsg = { "show": true, "msg": "<strong>" + res + "</strong>" };
              });
              this.cancelOrder(order_id);
            }
            if(data['data']['status']=='pending'){
              if(this.orderpendingstatuscount>3){
                this.commonService.messagePopup(this.commonService.globalVar['information'], this.commonService.globalVar['order_pending']);
              }
              else{
                this.orderpendingstatuscount++;
                const modalRef = this.modalService.open(OrderProgressbarComponent);
                modalRef.result.then((result) => {
                  this.checkPaymentStatus(order_id);
                }, (reason) => {
                  this.checkPaymentStatus(order_id);
                });
              }
            }
          }
          else{
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message']);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
  }
  /**
   * accordian click event
   */
  accordianClick(event:any) {
    let classname = event.currentTarget.parentElement.parentElement.getAttribute('class');
    if (classname.indexOf('active') >= 0) {
      event.currentTarget.title = this.commonService.globalVar['expand'];
      event.currentTarget.children[0].children[1].style.display = 'inline-block';
      // event.currentTarget.children[1].children[0].style.display = 'inline-block';
    }
    else {
      event.currentTarget.title = this.commonService.globalVar['collapse'];
      event.currentTarget.children[0].children[1].style.display = 'none';
      // event.currentTarget.children[1].children[0].style.display = 'none';
    }
  }

  disableRightPanel(){
    this.enableRightPanel=false;
  }
  /**
   * prevent event
   */
  preventEvent($event:any) {
    $event.stopPropagation();
    return false;
  }

  eventcoverdefault(){
    
  }
  /**
   * Avtive Event Scroll top
   */
  scrolltopEvent() {
    this.actvieProjectList.nativeElement.scrollTop = 0;
  }
  /**
   * close right panel
   */
  closeRightPanel() {
    this.enableRightPanel = false;
  }
  /**
   * change right panel
   */
  changeRightPanel() {
    if (this.isArchiveProject) {
      this.isArchiveProject = false;
      this.getAllProject();
    }
    this.enableRightPanel = !this.enableRightPanel;
  }
  /**
   * document click
   */
  documentclick(event:any) {
    this.commonService.successMsg['show'] = false;
    this.showdatePicker = false;
  }

  ngAfterViewInit() {
    document.getElementById('searchTab').removeAttribute("href");
  }

  onDateChanged(event:any) {
    setTimeout(() => {
      this.updateEventForm.controls['live_date'].setValue(event.jsdate);
      this.showdatePicker = false;
    }, 0);
  }

  /* Undo Option */
  undoOption(option:any, dataObj:any) {
    if (option == 'addProjectWork') {
      this.addProjectWork(dataObj.trackDetail, dataObj.mediaId, dataObj.trackName, '', '', dataObj.trackImage, dataObj.projectId, '', dataObj.workName);
    } if (option == 'removeMedia') {
      this.removeMedia(dataObj.trackDetail, dataObj.projectId, dataObj.mediaId, this.projectId, dataObj.workName, dataObj.trackName, dataObj.trackImage);
    }
  };
  /**
   * Drop Target
   */
  onDrop(data: any, workDetail: any, childIndex: number) {
    data.nativeEvent.currentTarget.parentElement.parentElement.parentElement.style.border = '';
    if (workDetail.license_code !== null && workDetail.license_code !== undefined && workDetail.license_code !== '') {
      const modalRef = this.modalService.open(MessageComponent);
      let work_type_msg = "";
      if (workDetail.extra_properties.license_type == this.commonService.licenseTypes['video']) {
        work_type_msg = this.commonService.globalVar['license_video'];
      } else if (workDetail.extra_properties.license_type == this.commonService.licenseTypes['photo']) {
        work_type_msg = this.commonService.globalVar['license_photo'];
      } else if (workDetail.extra_properties.license_type == this.commonService.licenseTypes['shortphoto']) {
        work_type_msg = this.commonService.globalVar['license_short_photo'];
      }
      modalRef.componentInstance.message = this.commonService.globalVar['issue_license_work_restrict1'] + work_type_msg + this.commonService.globalVar['issue_license_work_restrict2'];
      modalRef.componentInstance.title = this.commonService.globalVar['warning'];
      modalRef.result.then((result) => {
        
      }, (reason) => {
        
      });
    }
    else {
      let dataObject = data.dragData;
      this.addProjectWork(dataObject.result, dataObject.media_id, dataObject.track_name, dataObject.artist_name, dataObject.track_url, dataObject.album_pic, workDetail.id, childIndex, workDetail.name);
    }
  }
  /**
   * on drag over
   */
  dragover(event:any) {
    event.currentTarget.parentElement.parentElement.parentElement.style.border = '#00bfff dashed 2px';
  }
  /**
   * on drag leave
   */
  dragleave(event:any) {
    event.currentTarget.parentElement.parentElement.parentElement.style.border = '';
  }
  /**
   * Filter Result
   */
  filterTracks(event: any) {
    if (this.tracks !== "" && this.tracks.length > 2) {
      //document.getElementById('tracks').blur();
      this.httpclient.post('search/autocomplete', { txt: this.tracks })
        .subscribe(
        data => {
          if (data["code"] == 500) {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
          } else {
            this.filteredList = {
              albums: data['data']['albums'],
              artists: data['data']['artists'],
              tracks: data['data']['tracks']
            };
          }
        },
        error => {

        });
    }
    else {
      this.filteredList = { albums: [], artists: [], tracks: [] };
      this.resultList = [];

    }
  }
  /**
   * Search Data
   */
  getSearchData(searchdata: any = null, type: any) {
    this.filteredList = { albums: [], artists: [], tracks: [] };
    if (type == "tracks") {
      this.searchDetail = {
        id: (searchdata.artist_id!==undefined && searchdata.artist_id!==null && searchdata.artist_id!=='')?searchdata.artist_id:searchdata.id,
        track_name: searchdata.track_name
      }
      this.tracks = (searchdata['track_name']!==undefined && searchdata['track_name']!==null && searchdata['track_name']!=='')?searchdata['track_name']:'';
    } else if (type == "artists") {
      this.searchDetail = {
        id: searchdata.artist_id,
        track_name: ''
      }
      this.tracks = (searchdata['artist_name']!==undefined && searchdata['artist_name']!==null && searchdata['artist_name']!=='')?searchdata['artist_name']:'';
    } else if (type == "albums") {
      this.searchDetail = {
        id: searchdata.album_id,
        track_name: ''
      }
      this.tracks = (searchdata['album_name']!==undefined && searchdata['album_name']!==null && searchdata['album_name']!=='')?searchdata['album_name']:'';
    } else if (type == "full") {
      this.searchDetail = {
        id: '',
        track_name: this.tracks
      }
    }
    /**
     * Search History save Client Side
     */
    if (type !== "full") {
      this.searchHistoryList = (this.commonService.json(this.commonService.getLocalStorage('searchData')) !== null && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== undefined && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== '') ? this.commonService.json(this.commonService.getLocalStorage('searchData')) : [];
      var isAvailable = false;
      for (let k = 0; k < this.searchHistoryList.length; k++) {
        if (this.searchHistoryList[k].type == type && this.searchHistoryList[k].id == this.searchDetail.id) {
          isAvailable = true;
        }
      }
      if (!isAvailable) {
        this.searchHistoryList.push({ searchdata: searchdata, type: type, id: this.searchDetail.id });
      }
      this.searchHistoryList = (this.searchHistoryList.length > 5) ? this.searchHistoryList.slice(Math.max(this.searchHistoryList.length - 5, 1)) : this.searchHistoryList;
      this.commonService.setLocalStorage('searchData', this.commonService.stringifyObject(this.searchHistoryList));
      this.searchHistoryList = this.commonService.json(this.commonService.getLocalStorage('searchData'));
    }
    /**
     * End Search History save Client Side
     */
    let api = "";
    let data;
    switch (type) {
      case "albums":
        api = "search/album_tracks/" + this.searchDetail.id;
        break;
      case "artists":
        api = "search/artist_tracks/" + this.searchDetail.id;
        break;
      case "tracks":
        api = "search/similar_tracks/" + this.searchDetail.id + '/' + this.searchDetail.track_name;
        break;
      case "full":
        api = "search/full/" + this.searchDetail.track_name;
        break;
    }

    /*Get search result*/
    if (api != "") {
     // this.tracks = "";
      this.filteredList = { albums: [], artists: [], tracks: [] };
      this.httpclient.get(api)
        .subscribe(
        data => {
          this.filteredList = { albums: [], artists: [], tracks: [] };
          if (data['code'] == 200) {
            this.resultList = data['data'];
          }
          else {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message']);
          }
        },
        error => {

        });
    }
  }
  /**
   * Add/Delete track to/from user favorite list
   */
  updateFavorite(trackId:any, api:any, trackName:any, trackImage = "", event:any) {
    if (trackId !== "") {
      this.renderer.setElementClass(event.target, "active", (api == 'delete') ? false : true);
      this.httpclient.post('favorites/' + api, { media_id: trackId, media_kind: "track" })
        .subscribe(
        data => {
          if (data['code'] == 200) {
            //get updated user favorite Ids
            this.commonService.getUserFavorite();
            //update favorite list
            this.getFavoritesList();
            //update Collection List
            this.collectionObj["collectionTracksList"] = this.collectionObj["collectionTracksList"];
            //update search result
            this.resultList = this.resultList;
            //update event details
            this.eventData = this.eventData;
            //set success message
            this.commonService.successMsg = { "show": true, "image": trackImage, "msg": "<strong><i>" + trackName + "</i>&nbsp;&nbsp;" + this.commonService.globalVar[(api == 'add') ? 'added_to' : 'removed_from'] + " " + this.commonService.globalVar['favorite'] + " </strong>" };
          } else {
            this.renderer.setElementClass(event.target, "active", (api == 'delete') ? true : false);
          }
        },
        error => {

        });
    }
  }
  /**
   * Audio Timer
   */
  reportPosition(index:any, player:any) {
    let currentaudio = this[player]._results[index];
    let dur = ((currentaudio.nativeElement.currentTime / currentaudio.nativeElement.duration) * this.pc);
    let value = this.pc - dur;
    currentaudio.nativeElement.nextElementSibling.childNodes[1].childNodes[3].style.strokeDashoffset = value;
    if (value === 0) {
      currentaudio.nativeElement.nextElementSibling.setAttribute("class", "not-started");
      currentaudio.nativeElement.removeEventListener('timeupdate', this.reportPosition);
    }
  }
  /**
   * Audio Control
   */
  controlBtn(event:any, index: number, player: string) {
    this.currentaudio = this[player]._results[index];
    switch (this.currentaudio.nativeElement.nextElementSibling.getAttribute('class')) {
      case "not-started":
        if (this.lastplayid !== undefined && this.lastplayid !== null && this.lastplayid !== '') {
          this.lastplayid.nativeElement.pause();
          if (!isNaN(this.lastplayid.nativeElement.duration)) {
            this.lastplayid.nativeElement.currentTime = 0;
          }
          this.lastplayid.nativeElement.nextElementSibling.setAttribute("class", "not-started");
          this.lastplayid.nativeElement.removeEventListener('timeupdate', this.reportPosition);
        }
        this.renderer.listen(this.currentaudio.nativeElement, 'timeupdate', (event:any) => {
          this.reportPosition(index, player);
        })
        this.currentaudio.nativeElement.play();
        this.lastplayid = this.currentaudio;
        this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
        break;
      case "playing":
        this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "paused");
        this.currentaudio.nativeElement.pause();
        break;
      case "paused":
        this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
        this.currentaudio.nativeElement.play();
        break;
    }
  }

  workcontrolBtn(event:any, workindex: number, mediaindex: number, player: string) {
    let index = 0;
    for (var key in this.eventData.child_list) {
      if (parseInt(key) < workindex) {
        index += (this.eventData.child_list[key].media !== null && this.eventData.child_list[key].media !== undefined && this.eventData.child_list[key].media !== '') ? this.eventData.child_list[key].media.length : 0;
      }
    }
    index += mediaindex;
    this.currentaudio = this[player]._results[index];
    switch (this.currentaudio.nativeElement.nextElementSibling.getAttribute('class')) {
      case "not-started":
        if (this.lastplayid !== undefined && this.lastplayid !== null && this.lastplayid !== '') {
          this.lastplayid.nativeElement.pause();
          if (!isNaN(this.lastplayid.nativeElement.duration)) {
            this.lastplayid.nativeElement.currentTime = 0;
          }
          this.lastplayid.nativeElement.nextElementSibling.setAttribute("class", "not-started");
          this.lastplayid.nativeElement.removeEventListener('timeupdate', this.reportPosition);
        }
        this.renderer.listen(this.currentaudio.nativeElement, 'timeupdate', (event:any) => {
          this.reportPosition(index, player);
        })
        this.currentaudio.nativeElement.play();
        this.lastplayid = this.currentaudio;
        this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
        break;
      case "playing":
        this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "paused");
        this.currentaudio.nativeElement.pause();
        break;
      case "paused":
        this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
        this.currentaudio.nativeElement.play();
        break;
    }
  }
  /** Get event type request */
  getEventType() {
    this.httpclient.get('projects/get_event_types')
      .subscribe(
      data => {
        if (data['code'] == 200) {
          this.eventTypes = data['data'];
        }
      },
      error => {

      });
  }

  /**
   * add track into selected Work
   */
  addProjectWork(trackDetail:any, media_id:any, track_name:any, artist_name:any, track_url:any, album_thumb:any, workId:any, childIndex:any, workName:any, licenseType = "") {
    if (workId !== "" && workId !== undefined && workId !== null && this.projectId != '') {
      if (this.workList[childIndex] !== undefined && this.workList[childIndex] !== null && this.workList[childIndex] !== '' && this.workList[childIndex]['license_code'] !== null && this.workList[childIndex]['license_code'] !== undefined && this.workList[childIndex]['license_code'] !== '') {
        const modalRef = this.modalService.open(MessageComponent);
        let work_type_msg = "";
        if (licenseType == this.commonService.licenseTypes['video']) {
          work_type_msg = this.commonService.globalVar['license_video'];
        } else if (licenseType == this.commonService.licenseTypes['photo']) {
          work_type_msg = this.commonService.globalVar['license_photo'];
        } else if (licenseType == this.commonService.licenseTypes['shortphoto']) {
          work_type_msg = this.commonService.globalVar['license_short_photo'];
        }
        modalRef.componentInstance.message = this.commonService.globalVar['issue_license_work_restrict1'] + work_type_msg + this.commonService.globalVar['issue_license_work_restrict2'];

        modalRef.componentInstance.title = this.commonService.globalVar['warning'];
        modalRef.result.then((result) => {
          
        }, (reason) => {
          
        });
      }
      else {
        let data = { "media": [{ "media_id": media_id, "kind": "track" }] };
        this.httpclient.post('project/' + workId + '/append_media', data)
          .subscribe(
          data => {
            if (data['code'] == 200) {
              /* If track added then append object to work*/
              let trackObj = {
                album_image_thumb: album_thumb,
                name: track_name,
                artist_name: artist_name,
                media_id: media_id,
                showLike: true,
                likeCount: 0,
                dislikeCount: 0,
                extra_properties: {
                  "track_url": track_url
                },
              }
              /* Display success message */
              this.commonService.successMsg = {
                "show": true,
                "image": album_thumb,
                "msg": "<i>" + track_name + "</i>&nbsp;&nbsp;<strong>" + this.commonService.globalVar['added_to'] + " " + workName + "</strong>",
                "callback": "removeMedia",
                "callbackObj": { trackDetail: trackDetail, "projectId": workId, "mediaId": media_id, "eventId": this.projectId, workName: workName, "trackName": track_name, "trackImage": album_thumb }
              };
              this.getAllProject();
            }
            else if (data['code'] == 500) {
              this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
            }
          },
          error => {

          });
      }
    }
    else {
      return false;
    }
  }
  /**
   * Clear Search
   */
  clearSearch() {
    this.tracks = '';
    this.filteredList = { albums: [], artists: [], tracks: [] };
    this.resultList = [];
    document.getElementById('tracks').focus();
  }

  /**
   * get All Project List
   */
  getAllProject() {
    this.httpclient.get((!this.isArchiveProject) ? 'projects/get_all_projects' : 'projects/get_all_projects?archived=true')
      .subscribe(
      data => {
        if (data['code'] == 200) {
          this.ProjectList = data['data']['projects'];
          /* If event list found then get 3 unique album cover from its work */
          if (this.ProjectList.length > 0) {
            for (var project in this.ProjectList) {
              this.ProjectList[project]["cover_images"] = [];
              if (this.ProjectList[project].child_list != undefined && this.ProjectList[project].child_list.length > 0 && this.ProjectList[project]["cover_images"].length < 3) {
                let childList = this.ProjectList[project].child_list;
                for (var work_list in childList) {
                  if (childList[work_list].extra_properties != undefined && childList[work_list].extra_properties.images != undefined && childList[work_list].extra_properties.images.length > 0 && this.ProjectList[project]["cover_images"].length < 3) {
                    let imageList = childList[work_list].extra_properties.images;
                    for (var image in imageList) {
                      if (this.ProjectList[project]["cover_images"].length < 3) {
                        this.ProjectList[project]["cover_images"].push(imageList[image]['image_thumb']);
                      }
                    }
                  }
                }
              }
              if (this.ProjectList[project]["cover_images"].length == 0) {
                this.ProjectList[project]["cover_images"].push(this.commonService.imagePath['noImage']);
                this.ProjectList[project]["cover_images"].push(this.commonService.imagePath['noImage']);
                this.ProjectList[project]["cover_images"].push(this.commonService.imagePath['noImage']);
              }
              if (this.ProjectList[project]["cover_images"].length == 1) {
                this.ProjectList[project]["cover_images"].push(this.commonService.imagePath['noImage']);
                this.ProjectList[project]["cover_images"].push(this.commonService.imagePath['noImage']);
              }
              if (this.ProjectList[project]["cover_images"].length == 2) {
                this.ProjectList[project]["cover_images"].push(this.commonService.imagePath['noImage']);
              }
            }
          } else {
            this.show_new_event_tooltip = true;
          }

          /*Select first event from event list */
          if (this.ProjectList[0] != null && this.ProjectList[0] != undefined && !this.isArchiveProject) {
            let projectId :any = '';
            if (this.projectId !== '' && this.projectId !== undefined && this.projectId !== null) {
              projectId = this.projectId;
            }
            else {
              if (this.commonService.getLocalStorage('projectId') !== undefined && this.commonService.getLocalStorage('projectId') !== null && this.commonService.getLocalStorage('projectId') !== '') {
                projectId = this.commonService.getLocalStorage('projectId');
                this.commonService.removeLocalStorage('projectId');
              }
              else {
                projectId = data['data']['projects'][0]['id'];
              }
            }
            this.selectProject(projectId);
          } else {
            this.workList = [];
            this.eventData = {};
            this.updateEventForm.controls["project_id"].setValue(this.projectId);
            this.updateEventForm.controls["live_date"].setValue('');
            this.updateEventForm.controls["project_name"].setValue('');
          }
        }
        else if (data['code'] == 500) {
          /* If no event found then clear previous data */
          this.workList = [];
          this.eventData = {};
          this.updateEventForm.controls["project_id"].setValue(this.projectId);
          this.updateEventForm.controls["live_date"].setValue('');
          this.updateEventForm.controls["project_name"].setValue('');
          this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
        }
      },
      error => {

      });
  }
  /**
   * Archive event request
   */
  createArchive(projectId:any, eventName:any, isselectproject = false) {
    this.commonService.confirmMessagePopup(this.commonService.globalVar['confirmation'], this.commonService.globalVar['event_archive_confirm'] + "<b>" + eventName + "</b>" + " ?", true, true).then((result) => {
      if (result) {
        this.httpclient.get('project/' + projectId + '/archive')
          .subscribe(
          data => {
            if (data['code'] == 200) {
              (isselectproject) ? this.commonService.removeCookie("projectId") : '';
              const modalRef = this.modalService.open(MessageComponent);
              modalRef.componentInstance.message = this.commonService.globalVar['archive_success'];
              modalRef.componentInstance.title = this.commonService.globalVar['confirmation'];
              modalRef.result.then((result) => {
                this.projectId = (isselectproject) ? '' : this.projectId;
                this.getAllProject();
                this.eventData = {};
              }, (reason) => {
                this.projectId = (isselectproject) ? '' : this.projectId;
                this.getAllProject();
                this.eventData = {};
              })
            }
            else if (data['code'] == 500) {
              this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
            }
          },
          error => {
            this.commonService.messagePopup(this.commonService.globalVar['error'], error);
          });
      }
    }, (reason) => {

    });
  }
  /**
   * Copy event
   */
  copyProject(projectId:any) {
    /*if (this.is_regular_account == '1') {
      const modalRef = this.modalService.open(CreateEventComponent);
      modalRef.componentInstance.copy_of_project = projectId;
      modalRef.result.then((result) => {
        this.projectId = result['project_id'];
        this.getAllProject();
      }, (reason) => {

      })
    }*/
  }
  /**
   * View archive events
   */
  viewArchiveProject() {
    this.isenableRightPanel = false;
    this.isArchiveProject = !this.isArchiveProject;
    this.getAllProject();
  }
  /**
   * Open create event modal
   */
  createNewEvent() {
    if (this.is_regular_account == '1') {
      const modalRef = this.modalService.open(CreateEventComponent);
      modalRef.componentInstance.copy_of_project = '';
      modalRef.result.then((result) => {
        this.projectId = result['project_id'];
        this.getAllProject();
      }, (reason) => {

      })
    }
  }
  /**
   * Select event and get detail
   */
  selectProject(projectId:any) {
    if (projectId != "" && projectId != null && projectId != undefined && !isNaN(projectId)) {
      this.isEventWorkLicense = false;
      this.httpclient.get('project/' + projectId + '/details')
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.commonService.setLocalStorage('projectId', projectId);
            if (this.isenableRightPanel) {
              this.enableRightPanel = false;
            }
            this.isenableRightPanel = true;
            this.workList = [];
            this.enableEdit = false;
            this.eventData = data['data'];
            this.getActivity(this.eventData['id']);
            this.projectId = projectId;
            this.updateEventForm.controls["project_id"].setValue(this.projectId);
            this.updateEventForm.controls["project_name"].setValue(this.eventData.name);
            if (this.eventData.is_owner != undefined && this.eventData.is_owner) {
              /* If owner then get event type for edit detail */
              this.getEventType();
            }
            if (this.eventData.extra_data != 'undefined') {
              if (this.eventData.extra_data.event_type != undefined) {
                this.updateEventForm.controls["event_type"].setValue(this.eventData.extra_data.event_type);
              }
              else{
                this.updateEventForm.controls["event_type"].setValue('');
              }
              if (this.eventData.extra_data.live_date != undefined) {
                // this.dispalyLiveDate = this.eventData.extra_data.live_date;
                this.updateEventForm.controls["live_date"].setValue(this.eventData.extra_data.live_date);
              }
              else{
                this.updateEventForm.controls["live_date"].setValue('');
              }
            }
            /* Create work list object */
            if (this.eventData.child_list !== undefined && this.eventData.child_list !== null && this.eventData.child_list.length > 0) {
              this.workIdStringData = "";
              for (var workObj in this.eventData.child_list) {
                if(this.eventData.child_list[workObj].license_code!==null && this.eventData.child_list[workObj].license_code!=='' && this.eventData.child_list[workObj].license_code!==undefined){
                  this.isEventWorkLicense = true;                  
                }
                this.workIdStringData = this.workIdStringData + workObj.toString() + ",";
                let workObjData = {
                  "id": this.eventData.child_list[workObj].id,
                  "name": this.eventData.child_list[workObj].name,
                  "license_code": this.eventData.child_list[workObj].license_code,
                  "license_type": this.eventData.child_list[workObj].extra_properties.license_type,
                };
                this.workList.push(workObjData);

                if (this.eventData.child_list[workObj].media !== undefined && this.eventData.child_list[workObj].media !== null && this.eventData.child_list[workObj].media.length > 0) {
                  let mediaData = this.eventData.child_list[workObj].media;
                  this.eventData.child_list[workObj].media = [];
                  this.eventData.child_list[workObj]['count_for_licence'] = this.eventData.child_list[workObj].media_count;
                  for (var mediaObj in mediaData) {
                    this.eventData.child_list[workObj].media[mediaObj] = mediaData[mediaObj];
                    this.eventData.child_list[workObj].media[mediaObj]['likeCount'] = 0;
                    this.eventData.child_list[workObj].media[mediaObj]['dislikeCount'] = 0;
                    this.eventData.child_list[workObj].media[mediaObj]['userLike'] = false;
                    this.eventData.child_list[workObj].media[mediaObj]['userDislike'] = false;
                    this.eventData.child_list[workObj].media[mediaObj]['showLike'] = true;
                    this.eventData.child_list[workObj].media[mediaObj]['email'] = "";
                    this.eventData.child_list[workObj].media[mediaObj]['consumer_id'] = "";
                    if (mediaData[mediaObj].annotations !== undefined && mediaData[mediaObj].annotations !== null && mediaData[mediaObj].annotations.length > 0) {
                      var annotationsValue = mediaData[mediaObj].annotations;
                      let inSuggested = false;
                      for (var annotationsObj in annotationsValue) {

                        this.eventData.child_list[workObj].media[mediaObj]['likeCount'] = (annotationsValue[annotationsObj].annotation == 'like') ? (this.eventData.child_list[workObj].media[mediaObj]['likeCount'] + 1) : this.eventData.child_list[workObj].media[mediaObj]['likeCount'];

                        this.eventData.child_list[workObj].media[mediaObj]['dislikeCount'] = (annotationsValue[annotationsObj].annotation == 'dislike') ? (this.eventData.child_list[workObj].media[mediaObj]['dislikeCount'] + 1) : this.eventData.child_list[workObj].media[mediaObj]['dislikeCount'];

                        if (!(this.eventData.child_list[workObj].media[mediaObj]['userLike'])) {
                          this.eventData.child_list[workObj].media[mediaObj]['userLike'] = ((annotationsValue[annotationsObj].consumer_id == this.commonService.userDetail['consumer_id']) && (annotationsValue[annotationsObj].annotation == 'like')) ? true : false;
                        }

                        if (!(this.eventData.child_list[workObj].media[mediaObj]['userDislike'])) {
                          this.eventData.child_list[workObj].media[mediaObj]['userDislike'] = ((annotationsValue[annotationsObj].consumer_id == this.commonService.userDetail['consumer_id']) && (annotationsValue[annotationsObj].annotation == 'dislike')) ? true : false;
                        }

                        if (annotationsValue[annotationsObj].annotation == 'suggested') {
                          this.eventData.child_list[workObj].media[mediaObj]['showLike'] = false;
                          if (!inSuggested) {
                            this.eventData.child_list[workObj]['count_for_licence'] = this.eventData.child_list[workObj]['count_for_licence'] - 1;
                            inSuggested = true;
                          }
                        }

                        this.eventData.child_list[workObj].media[mediaObj]['email'] = annotationsValue[annotationsObj].email;

                        this.eventData.child_list[workObj].media[mediaObj]['consumer_id'] = annotationsValue[annotationsObj].consumer_id;
                      }
                    }
                  }
                }
              }
            } else {
              this.show_new_work_tooltip = true;
            }
            /* End create work list object */
          }
          else if (data['code'] == 500) {
            this.isenableRightPanel = true;
            /* If not getting event detail then reset all old data */
            this.workList = [];
            this.eventData = {};
            this.updateEventForm.controls["project_id"].setValue(this.projectId);
            this.updateEventForm.controls["project_name"].setValue('');
            this.updateEventForm.controls["live_date"].setValue('');
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
          }
        },
        error => {
          this.isenableRightPanel = true;
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
  }
  /**
   * get Collection List
   */
  getCollectionList() {
   
    this.show_no_result_list = false;
    // if (this.is_regular_account === "1") {
      this.httpclient.post('admin/public_playlists/read', {})
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.collectionObj['collectionList'] = data['data'];
            if (this.collectionObj['collectionList'][0] !== undefined && this.collectionObj['collectionList'][0] != null) {
              this.getCollectionTracks(this.collectionObj['collectionList'][0]['id']);
            } else {
              this.show_no_result_list = true;
            }
          }
          else if (data['code'] == 500) {
            this.show_no_result_list = true;
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    // } else {
    //   this.collectionObj['collectionList'] = {
    //     collectionList: [],
    //     collectionTracksList: [],
    //     selectedCollection: '',
    //   }
    // }

  }
  /**
   * Get collection tracks by id
   */
  getCollectionTracks(collectionId:any) {
    this.show_no_result_list = false;
    this.collectionObj['selectedCollection'] = collectionId;
    if (this.collectionObj['selectedCollection'] !== '') {
      this.httpclient.post('admin/public_playlists/read/' + this.collectionObj['selectedCollection'], {}).subscribe(
        data => {
          this.iscollectionfetch = true;
          if (data['code'] == 200) {
            this.collectionObj['collectionTracksList'] = [];
            if (data["data"]["media_list"] !== undefined && data["data"]["media_list"].length > 0) {
              data["data"]["media_list"].forEach((trackObj:any) => {
                if ((trackObj["media_list"]) && (trackObj["media_list"].length > 0)) {
                  trackObj["media_list"].forEach((trackChildObj:any) => {
                    this.collectionObj['collectionTracksList'].push(trackChildObj);
                  });
                } else {
                  this.collectionObj['collectionTracksList'].push(trackObj);
                }
              });
            } else {
              this.show_no_result_list = true;
            }
          }
          else if (data['code'] == 500) {
            this.show_no_result_list = true;
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
          }
        },
        error => {
          this.iscollectionfetch = true;
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
  }
  /**
   * get Favourite Tracks List
   */
  getFavoritesList() {
    if (this.is_regular_account === "1") {
      this.httpclient.get('favorites/all')
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.favoriteList = data['data'];
          }
          else if (data['code'] == 500) {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    } else {
      this.favoriteList = [];
    }
  }
  /**
    * Vote media
    */
  voteMedia(projectId: Number, mediaId: Number, annotation: String, eventId: Number, hasVoted = false, isOwner:any): void {
    if (projectId != null && mediaId != null && eventId != null && annotation != null && annotation != 'undefined' && !isOwner) {
      if (!hasVoted) {
        let mediaData: Object = [{
          "media_id": mediaId,
          "kind": "track",
          "annotation": annotation
        }];
        this.httpclient.post('project/' + projectId + '/vote_media', { "media_data": mediaData })
          .subscribe(
          data => {
            if (data["code"] == 200) {
              //update work list of this project
              this.selectProject(eventId);
            }
            else if (data['code'] == 500) {
              this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
            }
          },
          error => {
            this.commonService.messagePopup(this.commonService.globalVar['error'], error);
          });
      }
    }
    else {
      this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
    }
  }
  /**
  * Remove media from work
  */
  removeMedia(trackDetail:any, projectId: Number, mediaId: Number, eventId: Number, workName:any, trackName:any, trackImage = ""): void {
    if (projectId != null && mediaId != null) {
      let mediaData: Object = {
        "project_id": projectId,
        "media_data": [
          {
            "media_id": mediaId,
            "kind": "track"
          }
        ]
      };
      this.httpclient.post('project/' + projectId + '/remove_media', mediaData)
        .subscribe(
        data => {
          if (data["code"] == 200) {
            //update work list of this project
            this.selectProject(eventId);
            this.commonService.successMsg = {
              "show": true,
              "image": trackImage,
              "msg": "<i>" + trackName + "</i>&nbsp;&nbsp;<strong>" + this.commonService.globalVar['removed_from'] + " " + workName + "</strong>",
              "callback": "addProjectWork",
              "callbackObj": { trackDetail: trackDetail, "projectId": projectId, "mediaId": mediaId, "eventId": eventId, workName: workName, "trackName": trackName, "trackImage": trackImage }
            };
          }
          else {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data["message"]);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });

    }
  }
  /**
   * Open issue license modal
   */
  issueLicense(event:any, workDetail:any, eventId:any) {
    if (workDetail.count_for_licence != workDetail.media_count) {
      let showType = (workDetail.extra_properties.license_type == this.commonService.licenseTypes['video']) ? this.commonService.globalVar["license_video"] : (workDetail.extra_properties.license_type == this.commonService.licenseTypes['photo']) ? this.commonService.globalVar["license_photo"] : (workDetail.extra_properties.license_type == this.commonService.licenseTypes['shortphoto']) ? this.commonService.globalVar["license_short_photo"] : "work";
      this.commonService.messagePopup(this.commonService.globalVar["suggested_tracks"], this.commonService.globalVar["this"] + " " + showType + this.commonService.globalVar["suggested_warning"]);
    }
    else {
      const modalRef = this.modalService.open(LicenseComponent);
      workDetail['project_name'] = this.eventData.name;
      modalRef.componentInstance.workDetail = workDetail;
      modalRef.result.then((result) => {
        this.selectProject(eventId);
        this.commonService.getUserCredit();
        if(result!=='cancle'){
          this.downloadMedia(workDetail.id,workDetail.extra_properties);
        }
      }, (reason) => {

      })
    }
  }

  /**
     * Set event type to check is other or not
     */
  setEventType(event: string, el:any) {
    this.updateEventForm.controls["event_type"].setValue(event);
    el.value = event;
    if (event == "Other") {
      this.showOther = true;
      el.value = event;
      setTimeout(function () {
        el.focus();
      }, 0);
    } else {
      this.showOther = false;
    }
  }
  /**
   * Update Event Request
   */
  submitUpdateEvent(editprojectnamefocus): void {
    if (this.updateEventForm.valid) {
      let formData: Object = {
        id: this.updateEventForm.value.project_id,
        project_name: this.updateEventForm.value.project_name,
        event_type: this.updateEventForm.value.event_type,
        live_date : this.updateEventForm.controls['live_date'].value
      };
     
      this.httpclient.post('project/' + formData['id'] + '/update', formData)
        .subscribe(
        data => {
          if (data["code"] == 500) {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data["message"][0]);
          } else {
            document.getElementById("editprojectname").blur();
            this.commonService.successMsg = { "show": true, "msg": "<strong><i>" + this.updateEventForm.value.project_name + "</i>&nbsp;&nbsp;" + this.commonService.globalVar['detail_updated_success'] + "</strong>" };
            this.enableEdit = false;
            this.projectId = data['data']['id'];
            this.getAllProject();
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      if (this.updateEventForm.controls['project_name'].value == '') {
        editprojectnamefocus.focus();
      }
      this.submitted = true;
    }
  }
  /**
   * Delete Event confirmation
   */
  deleteEventModel(eventId: Number, eventName: String, isWork = false) {
    if (eventId != null) {
      const modalRef = this.modalService.open(DeleteEventComponent);
      modalRef.componentInstance.event_id = eventId;
      modalRef.componentInstance.event_name = eventName;
      modalRef.componentInstance.is_work = isWork;
      modalRef.result.then((result) => {
        if (result) {
          this.commonService.successMsg = {
            "show": true,
            "image": null,
            "msg": result
          };
          if (!isWork) {
            this.commonService.removeLocalStorage('projectId');
            this.eventData = {};
            this.projectId = '';
          }
          this.getAllProject();
          //this.commonService.successMsg = { "show": true, "image": trackImage, "msg": "<i>" + trackName + "</i>&nbsp;&nbsp;<strong>" + this.commonService.globalVar['added_to'] + " " + workName + "</strong>" };
        }
      }, (reason) => {
        //do nothing
      })
    }
  }
  /**
     * close tooltip
     */
  closeTooltip(event:any, type = "") {
    if(type=='hideTrackAdd'){
      this.allsettooltip = true;
      this.commonService.setCookie('allsetEvent', "true");
      this.allsetEvent = Boolean(this.commonService.getCookie('allsetEvent'));
    }
    this.commonService.setCookie(type, "true");
    event.target.parentElement.remove();
    //check tooltip variable are set or not
    this.hideFavorite = Boolean(this.commonService.getCookie('hideFavorite'));
    this.hideTrackAdd = Boolean(this.commonService.getCookie('hideTrackAdd'));
    this.hideLicense = Boolean(this.commonService.getCookie('hideLicense'));
    this.hideNewEvent = Boolean(this.commonService.getCookie('hideNewEvent'));
    this.hideNewWork = Boolean(this.commonService.getCookie('hideNewWork'));
  }
  allTooltipEvent(event:any){
    this.commonService.removeCookie('allsetEvent');
    this.allsetEvent = Boolean(this.commonService.getCookie('allsetEvent'));
    event.target.parentElement.remove();
  }
  movetoNextCollaboratortab(){
    if(this.collaboratorTabActive==4){
      this.commonService.removeLocalStorage('collaboratorInstruction');
      this.collaboratorInstruction = Boolean(this.commonService.getLocalStorage('collaboratorInstruction'));
    }
    else{
      this.collaboratorTabActive++;  
    }
  }
  /**
     * End close tooltip
     */
  /**
   * Delete Event confirmation
   */
  addCollaborator(eventId: Number) {
    if (eventId != null) {
      const modalRef = this.modalService.open(CollaboratorComponent);
      modalRef.componentInstance.event_id = eventId;
      modalRef.result.then((result) => {
        if (result) {
          this.selectProject(eventId);
        }
      }, (reason) => {
        //do nothing
      })
    }
  }

  /**
  Remove collaborator from event
  */
  removeCollaborator(collaborator:any, eventId:any, eventName:any) {
    this.commonService.confirmMessagePopup(this.commonService.globalVar['confirmation'], this.commonService.globalVar['remove_collaborator_confirm'] + eventName + " ?", true, true).then((result) => {
      if (result) {
        this.httpclient.delete('project/' + eventId + '/remove_member/' + collaborator.consumer_id)
          .subscribe(
          data => {
            if (data['code'] == 200) {
              this.selectProject(eventId);
              this.commonService.messagePopup(this.commonService.globalVar['success'], this.commonService.globalVar['remove_collaborator_success']);
            }
            else if (data['code'] == 500) {
              this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
            }
          },
          error => {
            this.commonService.messagePopup(this.commonService.globalVar['error'], error);
          });
      }
    }, (reason) => {

    });
  }
  /**
   * Accept collaborator media request
   */
  acceptMedia(trackDetail:any, workId: Number, mediaId: Number, eventId: Number, workName:any, trackName:any, trackImage = "") {
    if (workId !== undefined && workId !== null && mediaId !== undefined && mediaId !== null && eventId !== undefined && eventId !== null) {
      let data = { "accept_suggestion": 1, "media": [{ "media_id": mediaId, "kind": "track" }] };
      this.httpclient.post('project/' + workId + '/append_media', data)
        .subscribe(
        data => {
          if (data['code'] == 200) {

            /* Display success message */
            this.commonService.successMsg = {
              "show": true,
              "image": trackImage,
              "msg": "<i>" + trackName + "</i>&nbsp;&nbsp;<strong>" + this.commonService.globalVar['added_to'] + " " + workName + "</strong>",
              "callback": "removeMedia",
              "callbackObj": { trackDetail: trackDetail, "projectId": workId, "mediaId": mediaId, "eventId": this.projectId, workName: workName, "trackName": trackName, "trackImage": trackImage }
            };
            this.selectProject(eventId);
          }
          else if (data['code'] != 401) {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data["message"][0]);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      return false;
    }
  }
  /**
     * Open create new work modal
     */
  createNewWork() {
    if (this.is_regular_account == '1') {
      const modalRef = this.modalService.open(CreateWorkComponent);
      modalRef.componentInstance.projectId = this.projectId;
      modalRef.result.then((result) => {
        this.getAllProject();
      }, (reason) => {
        //do nothing
      });
    }
  }

  /**
      Get collaborator latest activities
      */
  getActivity(eventId: any) {
    if (this.is_regular_account == '1') {
      this.httpclient.get('activity/feed/' + eventId + '?limit=' + this.collaboratorActivity['limit'] + '&offset=' + this.collaboratorActivity['start'])
        .subscribe(
        data => {
          if (data['code'] == 200) {
            // this.collaboratorActivity['start'] = this.collaboratorActivity['start'] + this.collaboratorActivity['limit'];
            data['data'].forEach((element:any) => {
              //this.activityData.length < 5 &&
              if ((element.activity == "like" || element.activity == "dislike" || element.activity == "suggested")) {
                this.activityData.push(element);
              }
            });
          }
          else if (data['code'] == 500) {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
  }

  /**
 Reinvite collaborator
 */
  reinviteCollaborator(collaborator: any, eventId: any, eventName: any) {
    this.httpclient.get('project/' + eventId + '/reinvite/' + collaborator.consumer_id)
      .subscribe(
      data => {
        if (data['code'] == 200) {
          this.commonService.messagePopup(this.commonService.globalVar['success'], this.commonService.globalVar['reinvite_collaborator_success']);
        }
        else if (data['code'] == 500) {
          this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
        }
      },
      error => {
        this.commonService.messagePopup(this.commonService.globalVar['error'], error);
      });
  }

  /**
   * Upload video request
   */
  uploadVideo(workId : any) {
    /* Create event array to select in form */
    let projectArr : Array<any> = [];
    this.ProjectList.forEach(project => {
      if (project["child_list"].length > 0) {
        projectArr.push({
          id: project['id'],
          name: project['name']
        })
      }
    });
    /* Create work array to select in form */
    let workArr = [];
    for (var workObj in this.workList) {
      if (this.workList[workObj].license_code !== null) {
        let workObjData = {
          "id": this.workList[workObj].id,
          "name": this.workList[workObj].name
        };
        workArr.push(workObjData);
      }
    }
    /* Open modal of video form */
    const modalRef = this.modalService.open(ChannelsComponent);
    modalRef.componentInstance.projectList = projectArr;
    modalRef.componentInstance.workList = workArr;
    modalRef.componentInstance.projectId = parseInt(this.projectId);
    modalRef.componentInstance.workId = workId;
    modalRef.result.then((result) => {
      let projectId = this.commonService.getCookie('uploadvideoevent');
      if (projectId !== null && projectId !== undefined && projectId !== '') {
        let videodata = {
          id: projectId,
          type: "gallery",
          status: 'visible'
        };
        this.changeStatus(projectId, videodata);
        this.commonService.removeCookie('uploadvideoevent');
      }
    }, (reason) => {
      let projectId = this.commonService.getCookie('uploadvideoevent');
      if (projectId !== null && projectId !== undefined && projectId !== '') {
        let videodata = {
          id: projectId,
          type: "gallery",
          status: 'visible'
        };
        this.changeStatus(projectId, videodata);
        this.commonService.removeCookie('uploadvideoevent');
      }
    })
  }
   /**
   * Change Status
   */
  changeStatus(projectId : any, data : any) {
    this.httpclient.post('project/' + projectId + '/video_change_status', data)
      .subscribe(
      data => {
        if (data['data']) {
          
        }
      },
      error => {

      });
  }
  /**
   * Download media
   */
  downloadMedia(workId : any,extraproperties:any) {
    /* Open modal of video form */
    const modalRef = this.modalService.open(DownloadMediaComponent);
    modalRef.componentInstance.projectId = parseInt(workId);
    modalRef.componentInstance.extraproperties = extraproperties;
    modalRef.result.then((result) => {

    }, (reason) => {

    })
  }

  /* cancel payment order if order is cancel */
  cancelOrder(orderId : any) {
    if (orderId != "" && orderId != undefined) {
      this.httpclient.get('purchase/cancel/' + orderId)
        .subscribe(
        data => {

        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
  }

  /**
   * Update work detail
   */
  updateWork(workId : any, isSubmit : any, index : any, event : any, checkParent : any = true) {
    if (isSubmit) {
      let updatedProjectName : any;
      if (!checkParent) {
        updatedProjectName = event.target.value;
      } else {
        updatedProjectName = event.currentTarget.previousElementSibling.value;
      }

      let isError = false;
      if (updatedProjectName == null || updatedProjectName == undefined || updatedProjectName == "") {
        isError = true;
        this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['work_name_required']);
      } else if (updatedProjectName != null && updatedProjectName != undefined && updatedProjectName != "" && updatedProjectName.length > 30) {
        isError = true;
        this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['work_name_maxlength_error']);
      } else if (workId == null || workId == undefined || workId == "") {
        isError = true;
        this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
      }
      if (!isError) {
        let formData: Object = {
          "id": workId,
          "project_name": updatedProjectName
        };
        var render = this.renderer;
        this.httpclient.post('project/' + workId + '/update', formData)
          .subscribe(
          data => {
            if (data["code"] == 500) {
              this.commonService.messagePopup(this.commonService.globalVar['error'], data["message"][0]);
            } else {
              document.getElementById("edit_work_name_" + workId).blur();
              this.eventData.child_list[index]['name'] = updatedProjectName;
              render.setElementClass(document.getElementById("edit_work_form_id_" + workId), "hidetag", true);
              render.setElementClass(document.getElementById("edit_work_id_" + workId), "hidetag", false);
              this.commonService.successMsg = { "show": true, "msg": "<strong><i>" + updatedProjectName + "</i>&nbsp;&nbsp;" + this.commonService.globalVar['detail_updated_success'] + "</strong>" };
            }
          },
          error => {
            this.commonService.messagePopup(this.commonService.globalVar['error'], error);
          });
      }
    }
    else {
      this.renderer.setElementClass(document.getElementById("edit_work_form_id_" + workId), "hidetag", false);
      this.renderer.setElementClass(document.getElementById("edit_work_id_" + workId), "hidetag", true);
      setTimeout(function () {
        document.getElementById("edit_work_name_" + workId).focus();
      }, 0);
    }
  }
}
