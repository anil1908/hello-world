var __decorate = (this && this.__decorate) || function(decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
        d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else
        for (var i = decorators.length - 1; i >= 0; i--)
            if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, ViewChildren, ViewChild, Renderer, ElementRef } from '@angular/core';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
import { NgbModal, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, Validators } from '@angular/forms';
import { MessageComponent } from '../message/message.component';
import { LicenseComponent } from '../license/license.component';
import { ChannelsComponent } from '../channels/channels.component';
import { DownloadMediaComponent } from '../download-media/download-media.component';
import { CreateEventComponent } from '../create-event/create-event.component';
import { DeleteEventComponent } from '../delete-event/delete-event.component';
import { CollaboratorComponent } from '../collaborator/collaborator.component';
import { CreateWorkComponent } from '../create-Work/create-work.component';
import { ActivatedRoute } from '@angular/router';
var EventsComponent = (function() {
    function EventsComponent(fb, modalService, commonService, httpclient, renderer, parserFormatter, route, elm) {
        this.fb = fb;
        this.modalService = modalService;
        this.commonService = commonService;
        this.httpclient = httpclient;
        this.renderer = renderer;
        this.parserFormatter = parserFormatter;
        this.route = route;
        this.elm = elm;
        this.enableRightPanel = false;
        this.isenableRightPanel = true;
        this.eventOption = false;
        this.tracks = '';
        this.filteredList = { albums: [], artists: [], tracks: [] };
        this.activityData = [];
        this.searchDetail = { id: '', track_name: '' };
        this.collaboratorActivity = { start: 0, limit: 5 };
        this.resultList = [];
        this.show_no_result_list = false;
        this.searchHistoryList = (this.commonService.json(this.commonService.getLocalStorage('searchData')) !== null && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== undefined && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== '') ? this.commonService.json(this.commonService.getLocalStorage('searchData')) : [];
        this.workList = [];
        this.projectId = '';
        this.workIdStringData = '';
        this.ProjectList = [];
        this.isArchiveProject = false;
        this.collectionObj = {
            collectionList: [],
            collectionTracksList: [],
            selectedCollection: '',
        };
        this.iscollectionfetch = false;
        this.dispalyLiveDate = "";
        //set server side error message Object
        this.msg = { issuccess: false, isError: false, msg: '' };
        this.submitted = false;
        this.enableEdit = false;
        this.showOther = false;
        this.is_regular_account = "1";
        this.hideNewEvent = false;
        this.hideNewWork = false;
        this.hideFavorite = false;
        this.hideTrackAdd = false;
        this.showdatePicker = false;
        this.hideLicense = false;
        this.workaudio = 0;
        this.show_new_event_tooltip = false;
        this.show_new_work_tooltip = false;
        this.isEventWorkLicense = false;
        this.myDatePickerOptions = {
            firstDayOfWeek: 'su',
            dateFormat: 'dd/mm/yyyy',
            showClearDateBtn: false,
            editableDateField: false,
            openSelectorOnInputClick: true,
            showTodayBtn: false,
            inline: true
        };
    }
    /* This method is call when page is load
     */
    EventsComponent.prototype.ngOnInit = function() {
        this.pc = 298.1371428256714; // 2 pi r
        //Create form to add new event
        this.updateEventForm = this.fb.group({
            'project_id': [''],
            'project_name': ['', Validators.compose([Validators.required, Validators.maxLength(100)])],
            'event_type': [''],
            'live_date': [''],
        });
        //check user is collaborator or videographer
        this.is_regular_account = (this.commonService.userDetail["extra_data"].tracks_is_regular_account != null && this.commonService.userDetail["extra_data"].tracks_is_regular_account != undefined) ? this.commonService.userDetail["extra_data"].tracks_is_regular_account : "1";
        //check tooltip variable are set or not
        this.hideFavorite = Boolean(this.commonService.getCookie('hideFavorite'));
        this.hideTrackAdd = Boolean(this.commonService.getCookie('hideTrackAdd'));
        this.hideLicense = Boolean(this.commonService.getCookie('hideLicense'));
        this.hideNewEvent = Boolean(this.commonService.getCookie('hideNewEvent'));
        this.hideNewWork = Boolean(this.commonService.getCookie('hideNewWork'));
        /* Get all project when page load */
        this.getAllProject();
    };
    /**
     * accordian click event
     */
    EventsComponent.prototype.accordianClick = function(event) {
        var classname = event.currentTarget.parentElement.parentElement.getAttribute('class');
        if (classname.indexOf('active') >= 0) {
            event.currentTarget.children[0].children[0].style.display = 'inline-block';
            // event.currentTarget.children[1].children[0].style.display = 'inline-block';
        } else {
            event.currentTarget.children[0].children[0].style.display = 'none';
            // event.currentTarget.children[1].children[0].style.display = 'none';
        }
    };
    /**
     * prevent event
     */
    EventsComponent.prototype.preventEvent = function($event) {
        $event.stopPropagation();
        return false;
    };
    EventsComponent.prototype.eventcoverdefault = function() {

    };
    /**
     * Avtive Event Scroll top
     */
    EventsComponent.prototype.scrolltopEvent = function() {
        this.actvieProjectList.nativeElement.scrollTop = 0;
    };
    /**
     * close right panel
     */
    EventsComponent.prototype.closeRightPanel = function() {
        this.enableRightPanel = false;
    };
    /**
     * change right panel
     */
    EventsComponent.prototype.changeRightPanel = function() {
        if (this.isArchiveProject) {
            this.isArchiveProject = false;
            this.getAllProject();
        }
        this.enableRightPanel = !this.enableRightPanel;
    };
    /**
     * document click
     */
    EventsComponent.prototype.documentclick = function(event) {
        this.commonService.successMsg['show'] = false;
        this.showdatePicker = false;
    };
    EventsComponent.prototype.ngAfterViewInit = function() {
        document.getElementById('searchTab').removeAttribute("href");
    };
    EventsComponent.prototype.onDateChanged = function(event) {
        var _this = this;
        setTimeout(function() {
            _this.updateEventForm.controls['live_date'].setValue({
                day: ("0" + event.date.day).slice(-2),
                month: ("0" + event.date.month).slice(-2),
                year: event.date.year
            });
            _this.showdatePicker = false;
        }, 0);
    };
    /* Undo Option */
    EventsComponent.prototype.undoOption = function(option, dataObj) {
        if (option == 'addProjectWork') {
            this.addProjectWork(dataObj.trackDetail, dataObj.mediaId, dataObj.trackName, '', '', dataObj.trackImage, dataObj.projectId, '', dataObj.workName);
        }
        if (option == 'removeMedia') {
            this.removeMedia(dataObj.trackDetail, dataObj.projectId, dataObj.mediaId, this.projectId, dataObj.workName, dataObj.trackName, dataObj.trackImage);
        }
    };;
    /**
     * Drop Target
     */
    EventsComponent.prototype.onDrop = function(data, workDetail, childIndex) {
        data.nativeEvent.currentTarget.parentElement.parentElement.parentElement.style.border = '';
        if (workDetail.license_code !== null && workDetail.license_code !== undefined && workDetail.license_code !== '') {
            var modalRef = this.modalService.open(MessageComponent);
            var work_type_msg = "";
            if (workDetail.extra_properties.license_type == this.commonService.licenseTypes['video']) {
                work_type_msg = this.commonService.globalVar['license_video'];
            } else if (workDetail.extra_properties.license_type == this.commonService.licenseTypes['photo']) {
                work_type_msg = this.commonService.globalVar['license_photo'];
            } else if (workDetail.extra_properties.license_type == this.commonService.licenseTypes['shortphoto']) {
                work_type_msg = this.commonService.globalVar['license_short_photo'];
            }
            modalRef.componentInstance.message = this.commonService.globalVar['issue_license_work_restrict1'] + work_type_msg + this.commonService.globalVar['issue_license_work_restrict2'];
            modalRef.componentInstance.title = this.commonService.globalVar['warning'];
            modalRef.result.then(function(result) {

            }, function(reason) {

            });
        } else {
            var dataObject = data.dragData;
            this.addProjectWork(dataObject.result, dataObject.media_id, dataObject.track_name, dataObject.artist_name, dataObject.track_url, dataObject.album_pic, workDetail.id, childIndex, workDetail.name);
        }
    };
    /**
     * on drag over
     */
    EventsComponent.prototype.dragover = function(event) {
        event.currentTarget.parentElement.parentElement.parentElement.style.border = '#00bfff dashed 2px';
    };
    /**
     * on drag leave
     */
    EventsComponent.prototype.dragleave = function(event) {
        event.currentTarget.parentElement.parentElement.parentElement.style.border = '';
    };
    /**
     * Filter Result
     */
    EventsComponent.prototype.filterTracks = function(event) {
        var _this = this;
        if (this.tracks !== "" && this.tracks.length > 2) {
            //document.getElementById('tracks').blur();
            this.httpclient.post('search/autocomplete', { txt: this.tracks })
                .subscribe(function(data) {
                    if (data["code"] == 500) {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                    } else {
                        _this.filteredList = {
                            albums: data['data']['albums'],
                            artists: data['data']['artists'],
                            tracks: data['data']['tracks']
                        };
                    }
                }, function(error) {});
        } else {
            this.filteredList = { albums: [], artists: [], tracks: [] };
            this.resultList = [];
        }
    };
    /**
     * Search Data
     */
    EventsComponent.prototype.getSearchData = function(searchdata, type) {
        var _this = this;
        if (searchdata === void 0) { searchdata = null; }
        this.filteredList = { albums: [], artists: [], tracks: [] };
        if (type == "tracks") {
            this.searchDetail = {
                id: searchdata.artist_id,
                track_name: searchdata.track_name
            };
        } else if (type == "artists") {
            this.searchDetail = {
                id: searchdata.artist_id,
                track_name: ''
            };
        } else if (type == "albums") {
            this.searchDetail = {
                id: searchdata.album_id,
                track_name: ''
            };
        } else if (type == "full") {
            this.searchDetail = {
                id: '',
                track_name: this.tracks
            };
        }
        /**
         * Search History save Client Side
         */
        if (type !== "full") {
            this.searchHistoryList = (this.commonService.json(this.commonService.getLocalStorage('searchData')) !== null && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== undefined && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== '') ? this.commonService.json(this.commonService.getLocalStorage('searchData')) : [];
            var isAvailable = false;
            for (var k = 0; k < this.searchHistoryList.length; k++) {
                if (this.searchHistoryList[k].type == type && this.searchHistoryList[k].id == this.searchDetail.id) {
                    isAvailable = true;
                }
            }
            if (!isAvailable) {
                this.searchHistoryList.push({ searchdata: searchdata, type: type, id: this.searchDetail.id });
            }
            this.searchHistoryList = (this.searchHistoryList.length > 5) ? this.searchHistoryList.slice(Math.max(this.searchHistoryList.length - 5, 1)) : this.searchHistoryList;
            this.commonService.setLocalStorage('searchData', this.commonService.stringifyObject(this.searchHistoryList));
            this.searchHistoryList = this.commonService.json(this.commonService.getLocalStorage('searchData'));
        }
        /**
         * End Search History save Client Side
         */
        var api = "";
        var data;
        switch (type) {
            case "albums":
                api = "search/album_tracks/" + this.searchDetail.id;
                break;
            case "artists":
                api = "search/artist_tracks/" + this.searchDetail.id;
                break;
            case "tracks":
                api = "search/similar_tracks/" + this.searchDetail.id + '/' + this.searchDetail.track_name;
                break;
            case "full":
                api = "search/full/" + this.searchDetail.track_name;
                break;
        }
        /*Get search result*/
        if (api != "") {
            // this.tracks = "";
            this.filteredList = { albums: [], artists: [], tracks: [] };
            this.httpclient.get(api)
                .subscribe(function(data) {
                    _this.filteredList = { albums: [], artists: [], tracks: [] };
                    if (data['code'] == 200) {
                        _this.resultList = data['data'];
                    } else {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message']);
                    }
                }, function(error) {});
        }
    };
    /**
     * Add/Delete track to/from user favorite list
     */
    EventsComponent.prototype.updateFavorite = function(trackId, api, trackName, trackImage, event) {
        var _this = this;
        if (trackImage === void 0) { trackImage = ""; }
        if (trackId !== "") {
            this.renderer.setElementClass(event.target, "active", (api == 'delete') ? false : true);
            this.httpclient.post('favorites/' + api, { media_id: trackId, media_kind: "track" })
                .subscribe(function(data) {
                    if (data['code'] == 200) {
                        //get updated user favorite Ids
                        _this.commonService.getUserFavorite();
                        //update favorite list
                        _this.getFavoritesList();
                        //update Collection List
                        _this.collectionObj["collectionTracksList"] = _this.collectionObj["collectionTracksList"];
                        //update search result
                        _this.resultList = _this.resultList;
                        //update event details
                        _this.eventData = _this.eventData;
                        //set success message
                        _this.commonService.successMsg = { "show": true, "image": trackImage, "msg": "<strong><i>" + trackName + "</i>&nbsp;&nbsp;" + _this.commonService.globalVar[(api == 'add') ? 'added_to' : 'removed_from'] + " " + _this.commonService.globalVar['favorite'] + " </strong>" };
                    } else {
                        _this.renderer.setElementClass(event.target, "active", (api == 'delete') ? true : false);
                    }
                }, function(error) {});
        }
    };
    /**
     * Audio Timer
     */
    EventsComponent.prototype.reportPosition = function(index, player) {
        var currentaudio = this[player]._results[index];
        var dur = ((currentaudio.nativeElement.currentTime / currentaudio.nativeElement.duration) * this.pc);
        var value = this.pc - dur;
        currentaudio.nativeElement.nextElementSibling.childNodes[1].childNodes[3].style.strokeDashoffset = value;
        if (value === 0) {
            currentaudio.nativeElement.nextElementSibling.setAttribute("class", "not-started");
            currentaudio.nativeElement.removeEventListener('timeupdate', this.reportPosition);
        }
    };
    /**
     * Audio Control
     */
    EventsComponent.prototype.controlBtn = function(event, index, player) {
        var _this = this;
        this.currentaudio = this[player]._results[index];
        switch (this.currentaudio.nativeElement.nextElementSibling.getAttribute('class')) {
            case "not-started":
                if (this.lastplayid !== undefined && this.lastplayid !== null && this.lastplayid !== '') {
                    this.lastplayid.nativeElement.pause();
                    if (!isNaN(this.lastplayid.nativeElement.duration)) {
                        this.lastplayid.nativeElement.currentTime = 0;
                    }
                    this.lastplayid.nativeElement.nextElementSibling.setAttribute("class", "not-started");
                    this.lastplayid.nativeElement.removeEventListener('timeupdate', this.reportPosition);
                }
                this.renderer.listen(this.currentaudio.nativeElement, 'timeupdate', function(event) {
                    _this.reportPosition(index, player);
                });
                this.currentaudio.nativeElement.play();
                this.lastplayid = this.currentaudio;
                this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
                break;
            case "playing":
                this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "paused");
                this.currentaudio.nativeElement.pause();
                break;
            case "paused":
                this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
                this.currentaudio.nativeElement.play();
                break;
        }
    };
    EventsComponent.prototype.workcontrolBtn = function(event, workindex, mediaindex, player) {
        var _this = this;
        var index = 0;
        for (var key in this.eventData.child_list) {
            if (parseInt(key) < workindex) {
                index += (this.eventData.child_list[key].media !== null && this.eventData.child_list[key].media !== undefined && this.eventData.child_list[key].media !== '') ? this.eventData.child_list[key].media.length : 0;
            }
        }
        index += mediaindex;
        this.currentaudio = this[player]._results[index];
        switch (this.currentaudio.nativeElement.nextElementSibling.getAttribute('class')) {
            case "not-started":
                if (this.lastplayid !== undefined && this.lastplayid !== null && this.lastplayid !== '') {
                    this.lastplayid.nativeElement.pause();
                    if (!isNaN(this.lastplayid.nativeElement.duration)) {
                        this.lastplayid.nativeElement.currentTime = 0;
                    }
                    this.lastplayid.nativeElement.nextElementSibling.setAttribute("class", "not-started");
                    this.lastplayid.nativeElement.removeEventListener('timeupdate', this.reportPosition);
                }
                this.renderer.listen(this.currentaudio.nativeElement, 'timeupdate', function(event) {
                    _this.reportPosition(index, player);
                });
                this.currentaudio.nativeElement.play();
                this.lastplayid = this.currentaudio;
                this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
                break;
            case "playing":
                this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "paused");
                this.currentaudio.nativeElement.pause();
                break;
            case "paused":
                this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
                this.currentaudio.nativeElement.play();
                break;
        }
    };
    /** Get event type request */
    EventsComponent.prototype.getEventType = function() {
        var _this = this;
        this.httpclient.get('projects/get_event_types')
            .subscribe(function(data) {
                if (data['code'] == 200) {
                    _this.eventTypes = data['data'];
                }
            }, function(error) {});
    };
    /**
     * add track into selected Work
     */
    EventsComponent.prototype.addProjectWork = function(trackDetail, media_id, track_name, artist_name, track_url, album_thumb, workId, childIndex, workName, licenseType) {
        var _this = this;
        if (licenseType === void 0) { licenseType = ""; }
        if (workId !== "" && workId !== undefined && workId !== null && this.projectId != '') {
            if (this.workList[childIndex] !== undefined && this.workList[childIndex] !== null && this.workList[childIndex] !== '' && this.workList[childIndex]['license_code'] !== null && this.workList[childIndex]['license_code'] !== undefined && this.workList[childIndex]['license_code'] !== '') {
                var modalRef = this.modalService.open(MessageComponent);
                var work_type_msg = "";
                if (licenseType == this.commonService.licenseTypes['video']) {
                    work_type_msg = this.commonService.globalVar['license_video'];
                } else if (licenseType == this.commonService.licenseTypes['photo']) {
                    work_type_msg = this.commonService.globalVar['license_photo'];
                } else if (licenseType == this.commonService.licenseTypes['shortphoto']) {
                    work_type_msg = this.commonService.globalVar['license_short_photo'];
                }
                modalRef.componentInstance.message = this.commonService.globalVar['issue_license_work_restrict1'] + work_type_msg + this.commonService.globalVar['issue_license_work_restrict2'];
                modalRef.componentInstance.title = this.commonService.globalVar['warning'];
                modalRef.result.then(function(result) {

                }, function(reason) {

                });
            } else {
                var data = { "media": [{ "media_id": media_id, "kind": "track" }] };
                this.httpclient.post('project/' + workId + '/append_media', data)
                    .subscribe(function(data) {
                        if (data['code'] == 200) {
                            /* If track added then append object to work*/
                            var trackObj = {
                                album_image_thumb: album_thumb,
                                name: track_name,
                                artist_name: artist_name,
                                media_id: media_id,
                                showLike: true,
                                likeCount: 0,
                                dislikeCount: 0,
                                extra_properties: {
                                    "track_url": track_url
                                },
                            };
                            /* Display success message */
                            _this.commonService.successMsg = {
                                "show": true,
                                "image": album_thumb,
                                "msg": "<i>" + track_name + "</i>&nbsp;&nbsp;<strong>" + _this.commonService.globalVar['added_to'] + " " + workName + "</strong>",
                                "callback": "removeMedia",
                                "callbackObj": { trackDetail: trackDetail, "projectId": workId, "mediaId": media_id, "eventId": _this.projectId, workName: workName, "trackName": track_name, "trackImage": album_thumb }
                            };
                            _this.getAllProject();
                        } else if (data['code'] == 500) {
                            _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                        }
                    }, function(error) {});
            }
        } else {
            return false;
        }
    };
    /**
     * Clear Search
     */
    EventsComponent.prototype.clearSearch = function() {
        this.tracks = '';
        this.filteredList = { albums: [], artists: [], tracks: [] };
        this.resultList = [];
        document.getElementById('tracks').focus();
    };
    /**
     * get All Project List
     */
    EventsComponent.prototype.getAllProject = function() {
        var _this = this;
        this.httpclient.get((!this.isArchiveProject) ? 'projects/get_all_projects' : 'projects/get_all_projects?archived=true')
            .subscribe(function(data) {
                /* check come from payment page or not */
                var paymentResponse = _this.route.snapshot.queryParams;
                var isPurchase = Boolean(_this.commonService.getCookie('isPurchase'));
                if (paymentResponse != null && paymentResponse != undefined && (Object.keys(paymentResponse).length) > 0 && isPurchase) {
                    if (paymentResponse["st"] == "success") {
                        _this.commonService.successMsg = { "show": true, "msg": "<strong>" + _this.commonService.globalVar['payment_success'] + "</strong>" };
                    } else if (paymentResponse["st"] == "fail") {
                        _this.commonService.successMsg = { "show": true, "msg": "<strong>" + _this.commonService.globalVar['payment_fail'] + "</strong>" };
                        _this.cancelOrder(paymentResponse["order"]);
                    }
                    _this.commonService.getUserCredit();
                    _this.commonService.removeLocalStorage('purdata');
                }
                _this.commonService.removeCookie('isPurchase');
                if (data['code'] == 200) {
                    _this.ProjectList = data['data']['projects'];
                    /* If event list found then get 3 unique album cover from its work */
                    if (_this.ProjectList.length > 0) {
                        for (var project in _this.ProjectList) {
                            _this.ProjectList[project]["cover_images"] = [];
                            if (_this.ProjectList[project].child_list != undefined && _this.ProjectList[project].child_list.length > 0 && _this.ProjectList[project]["cover_images"].length < 3) {
                                var childList = _this.ProjectList[project].child_list;
                                for (var work_list in childList) {
                                    if (childList[work_list].extra_properties != undefined && childList[work_list].extra_properties.images != undefined && childList[work_list].extra_properties.images.length > 0 && _this.ProjectList[project]["cover_images"].length < 3) {
                                        var imageList = childList[work_list].extra_properties.images;
                                        for (var image in imageList) {
                                            if (_this.ProjectList[project]["cover_images"].length < 3) {
                                                _this.ProjectList[project]["cover_images"].push(imageList[image]['image_thumb']);
                                            }
                                        }
                                    }
                                }
                            }
                            if (_this.ProjectList[project]["cover_images"].length == 0) {
                                _this.ProjectList[project]["cover_images"].push(_this.commonService.imagePath['noImage']);
                                _this.ProjectList[project]["cover_images"].push(_this.commonService.imagePath['noImage']);
                                _this.ProjectList[project]["cover_images"].push(_this.commonService.imagePath['noImage']);
                            }
                            if (_this.ProjectList[project]["cover_images"].length == 1) {
                                _this.ProjectList[project]["cover_images"].push(_this.commonService.imagePath['noImage']);
                                _this.ProjectList[project]["cover_images"].push(_this.commonService.imagePath['noImage']);
                            }
                            if (_this.ProjectList[project]["cover_images"].length == 2) {
                                _this.ProjectList[project]["cover_images"].push(_this.commonService.imagePath['noImage']);
                            }
                        }
                    } else {
                        _this.show_new_event_tooltip = true;
                    }
                    /*Select first event from event list */
                    if (_this.ProjectList[0] != null && _this.ProjectList[0] != undefined && !_this.isArchiveProject) {
                        var projectId = '';
                        if (_this.projectId !== '' && _this.projectId !== undefined && _this.projectId !== null) {
                            projectId = _this.projectId;
                        } else {
                            if (_this.commonService.getCookie('projectId') !== undefined && _this.commonService.getCookie('projectId') !== null && _this.commonService.getCookie('projectId') !== '') {
                                projectId = _this.commonService.getCookie('projectId');
                                _this.commonService.removeCookie('projectId');
                            } else {
                                projectId = data['data']['projects'][0]['id'];
                            }
                        }
                        _this.selectProject(projectId);
                    } else {
                        _this.workList = [];
                        _this.eventData = {};
                        _this.updateEventForm.controls["project_id"].setValue(_this.projectId);
                        _this.updateEventForm.controls["live_date"].setValue(_this.commonService.getDateObject(''));
                        _this.updateEventForm.controls["project_name"].setValue('');
                    }
                } else if (data['code'] == 500) {
                    /* If no event found then clear previous data */
                    _this.workList = [];
                    _this.eventData = {};
                    _this.updateEventForm.controls["project_id"].setValue(_this.projectId);
                    _this.updateEventForm.controls["live_date"].setValue(_this.commonService.getDateObject(''));
                    _this.updateEventForm.controls["project_name"].setValue('');
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                }
            }, function(error) {});
    };
    /**
     * Archive event request
     */
    EventsComponent.prototype.createArchive = function(projectId, eventName, isselectproject) {
        var _this = this;
        if (isselectproject === void 0) { isselectproject = false; }
        this.commonService.confirmMessagePopup(this.commonService.globalVar['confirmation'], this.commonService.globalVar['event_archive_confirm'] + "<b>" + eventName + "</b>" + " ?", true, true).then(function(result) {
            if (result) {
                _this.httpclient.get('project/' + projectId + '/archive')
                    .subscribe(function(data) {
                        if (data['code'] == 200) {
                            (isselectproject) ? _this.commonService.removeCookie("projectId"): '';
                            var modalRef = _this.modalService.open(MessageComponent);
                            modalRef.componentInstance.message = _this.commonService.globalVar['archive_success'];
                            modalRef.componentInstance.title = _this.commonService.globalVar['confirmation'];
                            modalRef.result.then(function(result) {
                                _this.projectId = (isselectproject) ? '' : _this.projectId;
                                _this.getAllProject();
                                _this.eventData = {};
                            }, function(reason) {
                                _this.projectId = (isselectproject) ? '' : _this.projectId;
                                _this.getAllProject();
                                _this.eventData = {};
                            });
                        } else if (data['code'] == 500) {
                            _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                        }
                    }, function(error) {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                    });
            }
        }, function(reason) {});
    };
    /**
     * Copy event
     */
    EventsComponent.prototype.copyProject = function(projectId) {
        /*if (this.is_regular_account == '1') {
          const modalRef = this.modalService.open(CreateEventComponent);
          modalRef.componentInstance.copy_of_project = projectId;
          modalRef.result.then((result) => {
            this.projectId = result['project_id'];
            this.getAllProject();
          }, (reason) => {
    
          })
        }*/
    };
    /**
     * View archive events
     */
    EventsComponent.prototype.viewArchiveProject = function() {
        this.isenableRightPanel = false;
        this.isArchiveProject = !this.isArchiveProject;
        this.getAllProject();
    };
    /**
     * Open create event modal
     */
    EventsComponent.prototype.createNewEvent = function() {
        var _this = this;
        if (this.is_regular_account == '1') {
            var modalRef = this.modalService.open(CreateEventComponent);
            modalRef.componentInstance.copy_of_project = '';
            modalRef.result.then(function(result) {
                _this.projectId = result['project_id'];
                _this.getAllProject();
            }, function(reason) {});
        }
    };
    /**
     * Select event and get detail
     */
    EventsComponent.prototype.selectProject = function(projectId) {
        var _this = this;
        if (projectId != "" && projectId != null && projectId != undefined && !isNaN(projectId)) {
            this.isEventWorkLicense = false;
            this.httpclient.get('project/' + projectId + '/details')
                .subscribe(function(data) {
                    if (data['code'] == 200) {
                        _this.commonService.setCookie('projectId', projectId);
                        if (_this.isenableRightPanel) {
                            _this.enableRightPanel = false;
                        }
                        _this.isenableRightPanel = true;
                        _this.workList = [];
                        _this.enableEdit = false;
                        _this.eventData = data['data'];
                        _this.getActivity(_this.eventData['id']);
                        _this.projectId = projectId;
                        _this.updateEventForm.controls["project_id"].setValue(_this.projectId);
                        _this.updateEventForm.controls["project_name"].setValue(_this.eventData.name);
                        if (_this.eventData.is_owner != undefined && _this.eventData.is_owner) {
                            /* If owner then get event type for edit detail */
                            _this.getEventType();
                        }
                        if (_this.eventData.extra_data != 'undefined') {
                            if (_this.eventData.extra_data.event_type != undefined) {
                                _this.updateEventForm.controls["event_type"].setValue(_this.eventData.extra_data.event_type);
                            } else {
                                _this.updateEventForm.controls["event_type"].setValue('');
                            }
                            if (_this.eventData.extra_data.live_date != undefined) {
                                // this.dispalyLiveDate = this.eventData.extra_data.live_date;
                                _this.updateEventForm.controls["live_date"].setValue(_this.commonService.getDateObject(_this.eventData.extra_data.live_date));
                            } else {
                                _this.updateEventForm.controls["live_date"].setValue(_this.commonService.getDateObject(''));
                            }
                        }
                        /* Create work list object */
                        if (_this.eventData.child_list !== undefined && _this.eventData.child_list !== null && _this.eventData.child_list.length > 0) {
                            _this.workIdStringData = "";
                            for (var workObj in _this.eventData.child_list) {
                                if (_this.eventData.child_list[workObj].license_code !== null && _this.eventData.child_list[workObj].license_code !== '' && _this.eventData.child_list[workObj].license_code !== undefined) {
                                    _this.isEventWorkLicense = true;
                                }
                                _this.workIdStringData = _this.workIdStringData + workObj.toString() + ",";
                                var workObjData = {
                                    "id": _this.eventData.child_list[workObj].id,
                                    "name": _this.eventData.child_list[workObj].name,
                                    "license_code": _this.eventData.child_list[workObj].license_code,
                                    "license_type": _this.eventData.child_list[workObj].extra_properties.license_type,
                                };
                                _this.workList.push(workObjData);
                                if (_this.eventData.child_list[workObj].media !== undefined && _this.eventData.child_list[workObj].media !== null && _this.eventData.child_list[workObj].media.length > 0) {
                                    var mediaData = _this.eventData.child_list[workObj].media;
                                    _this.eventData.child_list[workObj].media = [];
                                    _this.eventData.child_list[workObj]['count_for_licence'] = _this.eventData.child_list[workObj].media_count;
                                    for (var mediaObj in mediaData) {
                                        _this.eventData.child_list[workObj].media[mediaObj] = mediaData[mediaObj];
                                        _this.eventData.child_list[workObj].media[mediaObj]['likeCount'] = 0;
                                        _this.eventData.child_list[workObj].media[mediaObj]['dislikeCount'] = 0;
                                        _this.eventData.child_list[workObj].media[mediaObj]['userLike'] = false;
                                        _this.eventData.child_list[workObj].media[mediaObj]['userDislike'] = false;
                                        _this.eventData.child_list[workObj].media[mediaObj]['showLike'] = true;
                                        _this.eventData.child_list[workObj].media[mediaObj]['email'] = "";
                                        _this.eventData.child_list[workObj].media[mediaObj]['consumer_id'] = "";
                                        if (mediaData[mediaObj].annotations !== undefined && mediaData[mediaObj].annotations !== null && mediaData[mediaObj].annotations.length > 0) {
                                            var annotationsValue = mediaData[mediaObj].annotations;
                                            var inSuggested = false;
                                            for (var annotationsObj in annotationsValue) {
                                                _this.eventData.child_list[workObj].media[mediaObj]['likeCount'] = (annotationsValue[annotationsObj].annotation == 'like') ? (_this.eventData.child_list[workObj].media[mediaObj]['likeCount'] + 1) : _this.eventData.child_list[workObj].media[mediaObj]['likeCount'];
                                                _this.eventData.child_list[workObj].media[mediaObj]['dislikeCount'] = (annotationsValue[annotationsObj].annotation == 'dislike') ? (_this.eventData.child_list[workObj].media[mediaObj]['dislikeCount'] + 1) : _this.eventData.child_list[workObj].media[mediaObj]['dislikeCount'];
                                                if (!(_this.eventData.child_list[workObj].media[mediaObj]['userLike'])) {
                                                    _this.eventData.child_list[workObj].media[mediaObj]['userLike'] = ((annotationsValue[annotationsObj].consumer_id == _this.commonService.userDetail['consumer_id']) && (annotationsValue[annotationsObj].annotation == 'like')) ? true : false;
                                                }
                                                if (!(_this.eventData.child_list[workObj].media[mediaObj]['userDislike'])) {
                                                    _this.eventData.child_list[workObj].media[mediaObj]['userDislike'] = ((annotationsValue[annotationsObj].consumer_id == _this.commonService.userDetail['consumer_id']) && (annotationsValue[annotationsObj].annotation == 'dislike')) ? true : false;
                                                }
                                                if (annotationsValue[annotationsObj].annotation == 'suggested') {
                                                    _this.eventData.child_list[workObj].media[mediaObj]['showLike'] = false;
                                                    if (!inSuggested) {
                                                        _this.eventData.child_list[workObj]['count_for_licence'] = _this.eventData.child_list[workObj]['count_for_licence'] - 1;
                                                        inSuggested = true;
                                                    }
                                                }
                                                _this.eventData.child_list[workObj].media[mediaObj]['email'] = annotationsValue[annotationsObj].email;
                                                _this.eventData.child_list[workObj].media[mediaObj]['consumer_id'] = annotationsValue[annotationsObj].consumer_id;
                                            }
                                        }
                                    }
                                }
                            }
                        } else {
                            _this.show_new_work_tooltip = true;
                        }
                        /* End create work list object */
                    } else if (data['code'] == 500) {
                        _this.isenableRightPanel = true;
                        /* If not getting event detail then reset all old data */
                        _this.workList = [];
                        _this.eventData = {};
                        _this.updateEventForm.controls["project_id"].setValue(_this.projectId);
                        _this.updateEventForm.controls["project_name"].setValue('');
                        _this.updateEventForm.controls["live_date"].setValue(_this.commonService.getDateObject(''));
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                    }
                }, function(error) {
                    _this.isenableRightPanel = true;
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
        }
    };
    /**
     * get Collection List
     */
    EventsComponent.prototype.getCollectionList = function() {
        var _this = this;
        this.show_no_result_list = false;
        if (this.is_regular_account === "1") {
            this.httpclient.post('admin/public_playlists/read', {})
                .subscribe(function(data) {
                    if (data['code'] == 200) {
                        _this.collectionObj['collectionList'] = data['data'];
                        if (_this.collectionObj['collectionList'][0] !== undefined && _this.collectionObj['collectionList'][0] != null) {
                            _this.getCollectionTracks(_this.collectionObj['collectionList'][0]['id']);
                        } else {
                            _this.show_no_result_list = true;
                        }
                    } else if (data['code'] == 500) {
                        _this.show_no_result_list = true;
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                    }
                }, function(error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
        } else {
            this.collectionObj['collectionList'] = {
                collectionList: [],
                collectionTracksList: [],
                selectedCollection: '',
            };
        }
    };
    /**
     * Get collection tracks by id
     */
    EventsComponent.prototype.getCollectionTracks = function(collectionId) {
        var _this = this;
        this.show_no_result_list = false;
        this.collectionObj['selectedCollection'] = collectionId;
        if (this.collectionObj['selectedCollection'] !== '') {
            this.httpclient.post('admin/public_playlists/read/' + this.collectionObj['selectedCollection'], {}).subscribe(function(data) {
                _this.iscollectionfetch = true;
                if (data['code'] == 200) {
                    _this.collectionObj['collectionTracksList'] = [];
                    if (data["data"]["media_list"] !== undefined && data["data"]["media_list"].length > 0) {
                        data["data"]["media_list"].forEach(function(trackObj) {
                            if ((trackObj["media_list"]) && (trackObj["media_list"].length > 0)) {
                                trackObj["media_list"].forEach(function(trackChildObj) {
                                    _this.collectionObj['collectionTracksList'].push(trackChildObj);
                                });
                            } else {
                                _this.collectionObj['collectionTracksList'].push(trackObj);
                            }
                        });
                    } else {
                        _this.show_no_result_list = true;
                    }
                } else if (data['code'] == 500) {
                    _this.show_no_result_list = true;
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                }
            }, function(error) {
                _this.iscollectionfetch = true;
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
            });
        }
    };
    /**
     * get Favourite Tracks List
     */
    EventsComponent.prototype.getFavoritesList = function() {
        var _this = this;
        if (this.is_regular_account === "1") {
            this.httpclient.get('favorites/all')
                .subscribe(function(data) {
                    if (data['code'] == 200) {
                        _this.favoriteList = data['data'];
                    } else if (data['code'] == 500) {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                    }
                }, function(error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
        } else {
            this.favoriteList = [];
        }
    };
    /**
     * Vote media
     */
    EventsComponent.prototype.voteMedia = function(projectId, mediaId, annotation, eventId, hasVoted, isOwner) {
        var _this = this;
        if (hasVoted === void 0) { hasVoted = false; }
        if (projectId != null && mediaId != null && eventId != null && annotation != null && annotation != 'undefined' && !isOwner) {
            if (!hasVoted) {
                var mediaData = [{
                    "media_id": mediaId,
                    "kind": "track",
                    "annotation": annotation
                }];
                this.httpclient.post('project/' + projectId + '/vote_media', { "media_data": mediaData })
                    .subscribe(function(data) {
                        if (data["code"] == 200) {
                            //update work list of this project
                            _this.selectProject(eventId);
                        } else if (data['code'] == 500) {
                            _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                        }
                    }, function(error) {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                    });
            }
        } else {
            this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
        }
    };
    /**
     * Remove media from work
     */
    EventsComponent.prototype.removeMedia = function(trackDetail, projectId, mediaId, eventId, workName, trackName, trackImage) {
        var _this = this;
        if (trackImage === void 0) { trackImage = ""; }
        if (projectId != null && mediaId != null) {
            var mediaData = {
                "project_id": projectId,
                "media_data": [{
                    "media_id": mediaId,
                    "kind": "track"
                }]
            };
            this.httpclient.post('project/' + projectId + '/remove_media', mediaData)
                .subscribe(function(data) {
                    if (data["code"] == 200) {
                        //update work list of this project
                        _this.selectProject(eventId);
                        _this.commonService.successMsg = {
                            "show": true,
                            "image": trackImage,
                            "msg": "<i>" + trackName + "</i>&nbsp;&nbsp;<strong>" + _this.commonService.globalVar['removed_from'] + " " + workName + "</strong>",
                            "callback": "addProjectWork",
                            "callbackObj": { trackDetail: trackDetail, "projectId": projectId, "mediaId": mediaId, "eventId": eventId, workName: workName, "trackName": trackName, "trackImage": trackImage }
                        };
                    } else {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], data["message"]);
                    }
                }, function(error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
        }
    };
    /**
     * Open issue license modal
     */
    EventsComponent.prototype.issueLicense = function(event, workDetail, eventId) {
        var _this = this;
        if (workDetail.count_for_licence != workDetail.media_count) {
            var showType = (workDetail.extra_properties.license_type == this.commonService.licenseTypes['video']) ? this.commonService.globalVar["license_video"] : (workDetail.extra_properties.license_type == this.commonService.licenseTypes['photo']) ? this.commonService.globalVar["license_photo"] : (workDetail.extra_properties.license_type == this.commonService.licenseTypes['shortphoto']) ? this.commonService.globalVar["license_short_photo"] : "work";
            this.commonService.messagePopup(this.commonService.globalVar["suggested_tracks"], this.commonService.globalVar["this"] + " " + showType + this.commonService.globalVar["suggested_warning"]);
        } else {
            var modalRef = this.modalService.open(LicenseComponent);
            workDetail['project_name'] = this.eventData.name;
            modalRef.componentInstance.workDetail = workDetail;
            modalRef.result.then(function(result) {
                _this.selectProject(eventId);
                _this.commonService.getUserCredit();
                _this.downloadMedia(workDetail.id);
            }, function(reason) {
                //do nothing
            });
        }
    };
    /**
     * Set event type to check is other or not
     */
    EventsComponent.prototype.setEventType = function(event, el) {
        this.updateEventForm.controls["event_type"].setValue(event);
        el.value = event;
        if (event == "Other") {
            this.showOther = true;
            el.value = event;
            setTimeout(function() {
                el.focus();
            }, 0);
        } else {
            this.showOther = false;
        }
    };
    /**
     * Update Event Request
     */
    EventsComponent.prototype.submitUpdateEvent = function() {
        var _this = this;
        if (this.updateEventForm.valid) {
            var formData = {
                "id": this.updateEventForm.value.project_id,
                "project_name": this.updateEventForm.value.project_name,
                "event_type": this.updateEventForm.value.event_type,
                live_date: ''
            };
            if (this.updateEventForm.controls['live_date'].value != null && this.updateEventForm.controls['live_date'].value != undefined && this.updateEventForm.controls['live_date'].value.day !== '' && this.updateEventForm.controls['live_date'].value.month !== '' && this.updateEventForm.controls['live_date'].value.year !== '') {
                formData["live_date"] = new Date(this.updateEventForm.value.live_date['year'], (this.updateEventForm.value.live_date['month'] - 1), this.updateEventForm.value.live_date['day']);
            }
            this.httpclient.post('project/' + formData['id'] + '/update', formData)
                .subscribe(function(data) {
                    if (data["code"] == 500) {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], data["message"][0]);
                    } else {
                        document.getElementById("editprojectname").blur();
                        _this.commonService.successMsg = { "show": true, "msg": "<strong><i>" + _this.updateEventForm.value.project_name + "</i>&nbsp;&nbsp;" + _this.commonService.globalVar['detail_updated_success'] + "</strong>" };
                        _this.enableEdit = false;
                        _this.projectId = data['data']['id'];
                        _this.getAllProject();
                    }
                }, function(error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
        } else {
            this.submitted = true;
        }
    };
    /**
     * Delete Event confirmation
     */
    EventsComponent.prototype.deleteEventModel = function(eventId, eventName, isWork) {
        var _this = this;
        if (isWork === void 0) { isWork = false; }
        if (eventId != null) {
            var modalRef = this.modalService.open(DeleteEventComponent);
            modalRef.componentInstance.event_id = eventId;
            modalRef.componentInstance.event_name = eventName;
            modalRef.componentInstance.is_work = isWork;
            modalRef.result.then(function(result) {
                if (result) {
                    _this.commonService.successMsg = {
                        "show": true,
                        "image": null,
                        "msg": result
                    };
                    if (!isWork) {
                        _this.commonService.removeCookie('projectId');
                        _this.eventData = {};
                        _this.projectId = '';
                    }
                    _this.getAllProject();
                    //this.commonService.successMsg = { "show": true, "image": trackImage, "msg": "<i>" + trackName + "</i>&nbsp;&nbsp;<strong>" + this.commonService.globalVar['added_to'] + " " + workName + "</strong>" };
                }
            }, function(reason) {
                //do nothing
            });
        }
    };
    /**
     * close tooltip
     */
    EventsComponent.prototype.closeTooltip = function(event, type) {
        if (type === void 0) { type = ""; }
        this.commonService.setCookie(type, "true");
        event.target.parentElement.remove();
        //check tooltip variable are set or not
        this.hideFavorite = Boolean(this.commonService.getCookie('hideFavorite'));
        this.hideTrackAdd = Boolean(this.commonService.getCookie('hideTrackAdd'));
        this.hideLicense = Boolean(this.commonService.getCookie('hideLicense'));
        this.hideNewEvent = Boolean(this.commonService.getCookie('hideNewEvent'));
        this.hideNewWork = Boolean(this.commonService.getCookie('hideNewWork'));
    };
    /**
     * Delete Event confirmation
     */
    EventsComponent.prototype.addCollaborator = function(eventId) {
        var _this = this;
        if (eventId != null) {
            var modalRef = this.modalService.open(CollaboratorComponent);
            modalRef.componentInstance.event_id = eventId;
            modalRef.result.then(function(result) {
                if (result) {
                    _this.selectProject(eventId);
                }
            }, function(reason) {
                //do nothing
            });
        }
    };
    /**
    Remove collaborator from event
    */
    EventsComponent.prototype.removeCollaborator = function(collaborator, eventId, eventName) {
        var _this = this;
        this.commonService.confirmMessagePopup(this.commonService.globalVar['confirmation'], this.commonService.globalVar['remove_collaborator_confirm'] + eventName + " ?", true, true).then(function(result) {
            if (result) {
                _this.httpclient.delete('project/' + eventId + '/remove_member/' + collaborator.consumer_id)
                    .subscribe(function(data) {
                        if (data['code'] == 200) {
                            _this.selectProject(eventId);
                            _this.commonService.messagePopup(_this.commonService.globalVar['success'], _this.commonService.globalVar['remove_collaborator_success']);
                        } else if (data['code'] == 500) {
                            _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                        }
                    }, function(error) {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                    });
            }
        }, function(reason) {});
    };
    /**
     * Accept collaborator media request
     */
    EventsComponent.prototype.acceptMedia = function(trackDetail, workId, mediaId, eventId, workName, trackName, trackImage) {
        var _this = this;
        if (trackImage === void 0) { trackImage = ""; }
        if (workId !== undefined && workId !== null && mediaId !== undefined && mediaId !== null && eventId !== undefined && eventId !== null) {
            var data = { "accept_suggestion": 1, "media": [{ "media_id": mediaId, "kind": "track" }] };
            this.httpclient.post('project/' + workId + '/append_media', data)
                .subscribe(function(data) {
                    if (data['code'] == 200) {
                        /* Display success message */
                        _this.commonService.successMsg = {
                            "show": true,
                            "image": trackImage,
                            "msg": "<i>" + trackName + "</i>&nbsp;&nbsp;<strong>" + _this.commonService.globalVar['added_to'] + " " + workName + "</strong>",
                            "callback": "removeMedia",
                            "callbackObj": { trackDetail: trackDetail, "projectId": workId, "mediaId": mediaId, "eventId": _this.projectId, workName: workName, "trackName": trackName, "trackImage": trackImage }
                        };
                        _this.selectProject(eventId);
                    } else if (data['code'] != 401) {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], data["message"][0]);
                    }
                }, function(error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
        } else {
            return false;
        }
    };
    /**
     * Open create new work modal
     */
    EventsComponent.prototype.createNewWork = function() {
        var _this = this;
        if (this.is_regular_account == '1') {
            var modalRef = this.modalService.open(CreateWorkComponent);
            modalRef.componentInstance.projectId = this.projectId;
            modalRef.result.then(function(result) {
                _this.getAllProject();
            }, function(reason) {
                //do nothing
            });
        }
    };
    /**
        Get collaborator latest activities
        */
    EventsComponent.prototype.getActivity = function(eventId) {
        var _this = this;
        if (this.is_regular_account == '1') {
            this.httpclient.get('activity/feed/' + eventId + '?limit=' + this.collaboratorActivity['limit'] + '&offset=' + this.collaboratorActivity['start'])
                .subscribe(function(data) {
                    if (data['code'] == 200) {
                        // this.collaboratorActivity['start'] = this.collaboratorActivity['start'] + this.collaboratorActivity['limit'];
                        data['data'].forEach(function(element) {
                            //this.activityData.length < 5 &&
                            if ((element.activity == "like" || element.activity == "dislike" || element.activity == "suggested")) {
                                _this.activityData.push(element);
                            }
                        });
                    } else if (data['code'] == 500) {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                    }
                }, function(error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
        }
    };
    /**
   Reinvite collaborator
   */
    EventsComponent.prototype.reinviteCollaborator = function(collaborator, eventId, eventName) {
        var _this = this;
        this.httpclient.get('project/' + eventId + '/reinvite/' + collaborator.consumer_id)
            .subscribe(function(data) {
                if (data['code'] == 200) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['success'], _this.commonService.globalVar['reinvite_collaborator_success']);
                } else if (data['code'] == 500) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                }
            }, function(error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
            });
    };
    /**
     * Upload video request
     */
    EventsComponent.prototype.uploadVideo = function(workId) {
        var _this = this;
        /* Create event array to select in form */
        var projectArr = [];
        this.ProjectList.forEach(function(project) {
            if (project["child_list"].length > 0) {
                projectArr.push({
                    id: project['id'],
                    name: project['name']
                });
            }
        });
        /* Create work array to select in form */
        var workArr = [];
        for (var workObj in this.workList) {
            if (this.workList[workObj].license_code !== null) {
                var workObjData = {
                    "id": this.workList[workObj].id,
                    "name": this.workList[workObj].name
                };
                workArr.push(workObjData);
            }
        }
        /* Open modal of video form */
        var modalRef = this.modalService.open(ChannelsComponent);
        modalRef.componentInstance.projectList = projectArr;
        modalRef.componentInstance.workList = workArr;
        modalRef.componentInstance.projectId = parseInt(this.projectId);
        modalRef.componentInstance.workId = workId;
        modalRef.result.then(function(result) {
            var projectId = _this.commonService.getCookie('uploadvideoevent');
            if (projectId !== null && projectId !== undefined && projectId !== '') {
                var videodata = {
                    id: projectId,
                    type: "gallery",
                    status: 'visible'
                };
                _this.changeStatus(projectId, videodata);
                _this.commonService.removeCookie('uploadvideoevent');
            }
        }, function(reason) {
            var projectId = _this.commonService.getCookie('uploadvideoevent');
            if (projectId !== null && projectId !== undefined && projectId !== '') {
                var videodata = {
                    id: projectId,
                    type: "gallery",
                    status: 'visible'
                };
                _this.changeStatus(projectId, videodata);
                _this.commonService.removeCookie('uploadvideoevent');
            }
        });
    };
    /**
     * Change Status
     */
    EventsComponent.prototype.changeStatus = function(projectId, data) {
        this.httpclient.post('project/' + projectId + '/video_change_status', data)
            .subscribe(function(data) {
                if (data['data']) {}
            }, function(error) {});
    };
    /**
     * Download media
     */
    EventsComponent.prototype.downloadMedia = function(workId) {
        /* Open modal of video form */
        var modalRef = this.modalService.open(DownloadMediaComponent);
        modalRef.componentInstance.projectId = parseInt(workId);
        modalRef.result.then(function(result) {}, function(reason) {});
    };
    /* cancel payment order if order is cancel */
    EventsComponent.prototype.cancelOrder = function(orderId) {
        var _this = this;
        if (orderId != "" && orderId != undefined) {
            this.httpclient.get('purchase/cancel/' + orderId)
                .subscribe(function(data) {}, function(error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
        }
    };
    /**
     * Update work detail
     */
    EventsComponent.prototype.updateWork = function(workId, isSubmit, index, event, checkParent) {
        var _this = this;
        if (checkParent === void 0) { checkParent = true; }
        if (isSubmit) {
            var updatedProjectName_1;
            if (!checkParent) {
                updatedProjectName_1 = event.target.value;
            } else {
                updatedProjectName_1 = event.currentTarget.previousElementSibling.value;
            }
            var isError = false;
            if (updatedProjectName_1 == null || updatedProjectName_1 == undefined || updatedProjectName_1 == "") {
                isError = true;
                this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['work_name_required']);
            } else if (updatedProjectName_1 != null && updatedProjectName_1 != undefined && updatedProjectName_1 != "" && updatedProjectName_1.length > 30) {
                isError = true;
                this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['work_name_maxlength_error']);
            } else if (workId == null || workId == undefined || workId == "") {
                isError = true;
                this.commonService.messagePopup(this.commonService.globalVar['error'], this.commonService.globalVar['something_went_wrong']);
            }
            if (!isError) {
                var formData = {
                    "id": workId,
                    "project_name": updatedProjectName_1
                };
                var render = this.renderer;
                this.httpclient.post('project/' + workId + '/update', formData)
                    .subscribe(function(data) {
                        if (data["code"] == 500) {
                            _this.commonService.messagePopup(_this.commonService.globalVar['error'], data["message"][0]);
                        } else {
                            document.getElementById("edit_work_name_" + workId).blur();
                            _this.eventData.child_list[index]['name'] = updatedProjectName_1;
                            render.setElementClass(document.getElementById("edit_work_form_id_" + workId), "hidetag", true);
                            render.setElementClass(document.getElementById("edit_work_id_" + workId), "hidetag", false);
                            _this.commonService.successMsg = { "show": true, "msg": "<strong><i>" + updatedProjectName_1 + "</i>&nbsp;&nbsp;" + _this.commonService.globalVar['detail_updated_success'] + "</strong>" };
                        }
                    }, function(error) {
                        _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                    });
            }
        } else {
            this.renderer.setElementClass(document.getElementById("edit_work_form_id_" + workId), "hidetag", false);
            this.renderer.setElementClass(document.getElementById("edit_work_id_" + workId), "hidetag", true);
            setTimeout(function() {
                document.getElementById("edit_work_name_" + workId).focus();
            }, 0);
        }
    };
    return EventsComponent;
}());
__decorate([
    ViewChildren('workPlayer'),
    __metadata("design:type", Object)
], EventsComponent.prototype, "workPlayer", void 0);
__decorate([
    ViewChildren('searchPlayer'),
    __metadata("design:type", Object)
], EventsComponent.prototype, "searchPlayer", void 0);
__decorate([
    ViewChildren('collectionPlayer'),
    __metadata("design:type", Object)
], EventsComponent.prototype, "collectionPlayer", void 0);
__decorate([
    ViewChildren('favouritePlayer'),
    __metadata("design:type", Object)
], EventsComponent.prototype, "favouritePlayer", void 0);
__decorate([
    ViewChild('actvieProjectList'),
    __metadata("design:type", ElementRef)
], EventsComponent.prototype, "actvieProjectList", void 0);
EventsComponent = __decorate([
    Component({
        selector: 'app-events',
        templateUrl: './events.component.html',
        styleUrls: ['./events.component.css'],
        host: {
            '(document:click)': 'documentclick($event)',
        },
    }),
    __metadata("design:paramtypes", [FormBuilder,
        NgbModal,
        CommonService,
        HttpClientService,
        Renderer,
        NgbDateParserFormatter,
        ActivatedRoute,
        ElementRef
    ])
], EventsComponent);
export { EventsComponent };
//# sourceMappingURL=events.component.js.map