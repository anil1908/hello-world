var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpClientService } from '../common/http-client.service';
import { CommonService } from '../common/common.service';
import { ValidationService } from '../common/validation.service';
var CreateWorkComponent = (function () {
    function CreateWorkComponent(fb, activeModal, httpclient, commonService, validationService) {
        this.fb = fb;
        this.activeModal = activeModal;
        this.httpclient = httpclient;
        this.commonService = commonService;
        this.validationService = validationService;
        this.submitted = false;
        //set server side error message Object
        this.msg = { issuccess: false, isError: false, msg: '' };
        this.license_type = { issuccess: false, isError: false, msg: '' };
    }
    /* This method is call when page is load
       */
    CreateWorkComponent.prototype.ngOnInit = function () {
        //Create form to add new work
        this.createWorkForm = this.fb.group({
            'project_name': [null, Validators.compose([Validators.required, Validators.maxLength(30)])],
            'work_type': ['', Validators.compose([Validators.required])],
            'sub_type': [null],
            'parent_project_id': [null],
        });
    };
    /**
     * Create Work Request
  */
    CreateWorkComponent.prototype.submitCreateWork = function () {
        var _this = this;
        if (this.createWorkForm.valid) {
            /*
      Check work name is unique or not
       */
            var formData = {
                "project_name": this.createWorkForm.value.project_name,
                "work_type": this.createWorkForm.value.work_type,
                "parent_project_id": this.projectId,
                "sub_type": "work",
                "license_type": this.commonService.licenseTypes[this.createWorkForm.value.work_type]
            };
            this.httpclient.post('project/create', formData)
                .subscribe(function (data) {
                if (data['code'] == 200) {
                    _this.activeModal.close({ work_id: data['data']['project']['id'] });
                }
                else {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0].toString());
                }
            }, function (error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
            });
        }
        else {
            this.submitted = true;
        }
    };
    /* Create work request */
    CreateWorkComponent.prototype.createWork = function () {
        var _this = this;
        var formData = {
            "project_name": this.createWorkForm.value.project_name,
            "work_type": this.createWorkForm.value.work_type,
            "parent_project_id": this.projectId,
            "sub_type": "work",
            "license_type": this.commonService.licenseTypes[this.createWorkForm.value.work_type]
        };
        this.httpclient.post('project/create', formData)
            .subscribe(function (data) {
            _this.activeModal.close({ work_id: data['data']['project']['id'] });
        }, function (error) {
            _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
        });
    };
    /**
     * select work type
     */
    CreateWorkComponent.prototype.selectWorkType = function (event, workType, element) {
        if (workType === void 0) { workType = ''; }
        element.innerHTML = event.currentTarget.innerHTML;
        this.createWorkForm.controls['work_type'].setValue(workType);
    };
    return CreateWorkComponent;
}());
__decorate([
    Input(),
    __metadata("design:type", Object)
], CreateWorkComponent.prototype, "projectId", void 0);
CreateWorkComponent = __decorate([
    Component({
        selector: 'app-create-work',
        templateUrl: './create-work.component.html',
        styleUrls: ['./create-work.component.css']
    }),
    __metadata("design:paramtypes", [FormBuilder,
        NgbActiveModal,
        HttpClientService,
        CommonService,
        ValidationService])
], CreateWorkComponent);
export { CreateWorkComponent };
//# sourceMappingURL=create-work.component.js.map