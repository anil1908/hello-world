import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal,NgbModalOptions, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { DomSanitizer, SafeHtml } from "@angular/platform-browser";
import { HttpClientService } from '../common/http-client.service';
import { CommonService } from '../common/common.service';
import { ValidationService } from '../common/validation.service';

@Component({
  selector: 'app-create-work',
  templateUrl: './create-work.component.html',
  styleUrls: ['./create-work.component.css']
})
export class CreateWorkComponent implements OnInit {
  /* initialize variables */
  createWorkForm: FormGroup;
  workTypes: Object;
  submitted: boolean = false;
  @Input() projectId:any;
  show_tooltip : boolean = false;
  //set server side error message Object
  msg: Object = { issuccess: false, isError: false, msg: '' };
  license_type: Object = { issuccess: false, isError: false, msg: '' };

  constructor(
    public fb: FormBuilder,
    public activeModal: NgbActiveModal,
    private httpclient: HttpClientService,
    private commonService: CommonService,
    private validationService: ValidationService) { }

  /* This method is call when page is load
     */
  ngOnInit() {
    //Create form to add new work
    this.createWorkForm = this.fb.group({
      'project_name': ['', Validators.compose([Validators.required, Validators.maxLength(30)])],
      'work_type': ['', Validators.compose([Validators.required])],
      'sub_type': [null],
      'parent_project_id': [null],
    });
  }
  /**
   * Create Work Request
*/
  submitCreateWork(worknamefocus): void {
    if (this.createWorkForm.valid) {
      /*
Check work name is unique or not
 */
      let formData: Object = {
        "project_name": this.createWorkForm.value.project_name,
        "work_type": this.createWorkForm.value.work_type,
        "parent_project_id": this.projectId,
        "sub_type": "work",
        "license_type": this.commonService.licenseTypes[this.createWorkForm.value.work_type]
      };

      this.httpclient.post('project/create', formData)
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.activeModal.close({ work_id: data['data']['project']['id'] });
          }
          else{
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0].toString());
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      if (this.createWorkForm.controls['project_name'].value == '') {
        worknamefocus.focus();
      }
      this.submitted = true;
    }
  }

  /* Create work request */
  private createWork() {
    let formData: Object = {
      "project_name": this.createWorkForm.value.project_name,
      "work_type": this.createWorkForm.value.work_type,
      "parent_project_id": this.projectId,
      "sub_type": "work",
      "license_type": this.commonService.licenseTypes[this.createWorkForm.value.work_type]
    };

    this.httpclient.post('project/create', formData)
      .subscribe(
      data => {
        this.activeModal.close({ work_id: data['data']['project']['id'] });
      },
      error => {
        this.commonService.messagePopup(this.commonService.globalVar['error'], error);
      });
  }
  /**
   * select work type
   */
  selectWorkType(event:any, workType = '', element:any) {
    element.innerHTML = event.currentTarget.innerHTML;
    this.createWorkForm.controls['work_type'].setValue(workType);
  }
}