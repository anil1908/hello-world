var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientService } from '../common/http-client.service';
import { CommonService } from '../common/common.service';
var DeleteEventComponent = (function () {
    function DeleteEventComponent(activeModal, httpclient, commonService) {
        this.activeModal = activeModal;
        this.httpclient = httpclient;
        this.commonService = commonService;
    }
    /* This method is call when page is load
       */
    DeleteEventComponent.prototype.ngOnInit = function () {
    };
    /** Delete event request */
    DeleteEventComponent.prototype.deleteEvent = function () {
        var _this = this;
        this.httpclient.delete('project/' + this.event_id + '/delete/')
            .subscribe(function (data) {
            if (data["code"] == 500) {
                _this.activeModal.close(data['message']);
            }
            else {
                _this.activeModal.close(_this.commonService.globalVar[(_this.is_work) ? "work_delete_success" : "event_delete_success"]);
            }
        }, function (error) {
            _this.activeModal.close(error);
        });
    };
    return DeleteEventComponent;
}());
__decorate([
    Input(),
    __metadata("design:type", Object)
], DeleteEventComponent.prototype, "event_id", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], DeleteEventComponent.prototype, "event_name", void 0);
__decorate([
    Input(),
    __metadata("design:type", Object)
], DeleteEventComponent.prototype, "is_work", void 0);
DeleteEventComponent = __decorate([
    Component({
        selector: 'app-delete-event',
        templateUrl: './delete-event.component.html',
    }),
    __metadata("design:paramtypes", [NgbActiveModal,
        HttpClientService,
        CommonService])
], DeleteEventComponent);
export { DeleteEventComponent };
//# sourceMappingURL=delete-event.component.js.map