import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal, NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientService } from '../common/http-client.service';
import { CommonService } from '../common/common.service';

@Component({
  selector: 'app-delete-event',
  templateUrl: './delete-event.component.html',
  //styleUrls: ['./delete-event.component.css']
})
export class DeleteEventComponent implements OnInit {
  /* initialize variables */
  @Input() event_id:any;
  @Input() event_name:any;
  @Input() is_work:any;
  constructor(
    public activeModal: NgbActiveModal,
    private httpclient: HttpClientService,
    private commonService: CommonService) { }

  /* This method is call when page is load
     */
  ngOnInit() {
  }

  /** Delete event request */
  deleteEvent() {
    this.httpclient.delete('project/' + this.event_id + '/delete/')
      .subscribe(
      data => {
        if (data["code"] == 500) {
          this.activeModal.close(data['message']);
        } else {
          this.activeModal.close(this.commonService.globalVar[(this.is_work) ? "work_delete_success" : "event_delete_success"]);
        }
      },
      error => {
        this.activeModal.close(error);
      });
  }
}
