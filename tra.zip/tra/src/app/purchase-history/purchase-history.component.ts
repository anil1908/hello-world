import { Component, OnInit } from '@angular/core';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';

@Component({
  selector: 'app-purchase-history',
  templateUrl: './purchase-history.component.html',
  styleUrls: ['./purchase-history.component.css']
})
export class PurchaseHistoryComponent implements OnInit {
  /* initialize variables */
  purchaseHistory: Array<any>;
  isgethistory : Boolean = false;
  constructor(
    private commonService: CommonService,
    private httpclient: HttpClientService) {

  }

  /* This method is call when page is load
     */
  ngOnInit() {
    this.getPurchaseHisory();
  }
  /* Get purchase history */
  getPurchaseHisory(isnext = true) {
    this.httpclient.get('purchase/history')
      .subscribe(
      data => {
        this.isgethistory = true;
        if (data['code'] == 200) {
          this.purchaseHistory = (data['data']) ? data['data'] : this.purchaseHistory;
        }
      },
      error => {
        this.isgethistory = true;

      });
  }
}
