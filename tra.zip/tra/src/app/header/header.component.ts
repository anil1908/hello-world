import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { Cookie } from 'angular2-cookies';
import { TranslateService } from 'ng2-translate';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
import { LoginComponent } from '../login/login.component';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  /* initialize variables */
  logindata: any = {};
  returnUrl: string;
  accountToggle: boolean = false;
  infoToggle: boolean = false;
  userData: Object;
  userGallery: Object;
  loginclass: string;
  headerclass: string;
  eventLink: boolean = false;
  menusection: boolean = true;

  constructor(
    public commonService: CommonService,
    private translate: TranslateService,
    private modalService: NgbModal,
    private router: Router,
    private route: ActivatedRoute,
    private title: Title,
    private httpclient: HttpClientService) {

  }

  /* This method is call when page is load
     */
  ngOnInit() {
    this.userGallery = this.commonService.userDetail;

    this.router.events
      .filter(event => event instanceof NavigationEnd)
      .map(() => this.route)
      .map(route => {
        while (route.firstChild) route = route.firstChild;
        return route;
      })
      .filter(route => route.outlet === 'primary')
      .mergeMap(route => route.data)
      .subscribe((url: any) => {
        this.translate.get('COMMON.SITE_NAME').subscribe((res: any) => {
          this.title.setTitle(url['title'] + res);
        });
    });

    this.router.events.subscribe(url => {
      this.commonService.updateLogin();
      window.scrollTo(0, 0);
      this.loginclass = (url['url'] == '' || url['url'] == '/') ? 'loginheader home' : 'loginheader';
      if(url['url']!==undefined){
        if (url['url'].indexOf("page/terms") >= 0 || url['url'].indexOf("page/contactus") >= 0 || url['url'].indexOf('user/reset_password') >= 0 || url['url'].indexOf('user/activation') >= 0 || ((url['url'].indexOf('/gallery/jamse-test2') >= 0 || url['url'].indexOf('/gallery/') >= 0) && !this.commonService.isLogin)) {
          this.headerclass = 'header searchr termshead';
        } else if (url['url'] == '' || url['url'].indexOf("search") >= 0) {
          this.headerclass = 'header searchr';
        } else {
          this.headerclass = 'header';
        }
        this.eventLink = (this.commonService.eventPageLink.indexOf(url['url']) >= 0 || (url['url'].indexOf('/gallery/') >= 0 && this.commonService.isLogin)) ? true : false;
      }
    });

    //check user is collaborator or videographer
    this.commonService.is_regular_account = (this.commonService.userDetail["extra_data"].tracks_is_regular_account != null && this.commonService.userDetail["extra_data"].tracks_is_regular_account != undefined) ? this.commonService.userDetail["extra_data"].tracks_is_regular_account : "1";
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
    this.userData = this.commonService.getLocalStorage('userDetail');
    if (this.commonService.isLogin && this.commonService.is_regular_account == '1') {
      this.commonService.getUserCredit();
      this.commonService.getUserFavorite();
    }
  }

  goHome() {
    this.router.navigate(['/']);
  }
  /**
   * Show Login Popup
   */
  showLoginPopup() {
    this.modalService.open(LoginComponent,{size:'sm'}).result.then((result) => {
      
    }, (reason) => {
      
    });
  };
  /**
   * Redirect To Other Page
   */
  moveTo(url:any) {
    this.router.navigate([url]);
  }
  /**
   * user Logout
   */
  userLogout(): void {
    this.httpclient.get('user/logout')
      .subscribe(
      data => {
        //this.commonService.updateLogin();
        this.commonService.removeCookie(['isLogin', 'mailSentTo', 'isReseted']);
        this.commonService.removeLocalStorage(['remember_me','collaboratorInstruction', 'userDetail','projectId', 'favoriteIds']);
        this.commonService.updateLogin();
        this.router.navigate(['/']);
      },
      error => {
        this.commonService.messagePopup(this.commonService.globalVar['error'], error);
      });
  }

  openmenusection(sectionval:any) {
    this.menusection = !sectionval;
  }
  /**
   * move to gallery
   */
  movetoGallery() {
    this.commonService.galleryPage['isGuest'] = false;
    this.router.navigate(['/gallery', this.commonService.userDetail['gallery_page']]);
  }

}
