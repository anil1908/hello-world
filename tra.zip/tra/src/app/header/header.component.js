var __decorate = (this && this.__decorate) || function(decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
        d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else
        for (var i = decorators.length - 1; i >= 0; i--)
            if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function(k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from 'ng2-translate';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
import { LoginComponent } from '../login/login.component';
import { Title } from '@angular/platform-browser';
var HeaderComponent = (function() {
    function HeaderComponent(commonService, translate, modalService, router, route, title, httpclient) {
        this.commonService = commonService;
        this.translate = translate;
        this.modalService = modalService;
        this.router = router;
        this.route = route;
        this.title = title;
        this.httpclient = httpclient;
        /* initialize variables */
        this.logindata = {};
        this.accountToggle = false;
        this.infoToggle = false;
        this.eventLink = false;
        this.menusection = true;
    }
    /* This method is call when page is load
     */
    HeaderComponent.prototype.ngOnInit = function() {
        var _this = this;
        this.userGallery = this.commonService.userDetail;
        this.router.events
            .filter(function(event) { return event instanceof NavigationEnd; })
            .map(function() { return _this.route; })
            .map(function(route) {
                while (route.firstChild)
                    route = route.firstChild;
                return route;
            })
            .filter(function(route) { return route.outlet === 'primary'; })
            .mergeMap(function(route) { return route.data; })
            .subscribe(function(url) {
                _this.translate.get('COMMON.SITE_NAME').subscribe(function(res) {
                    _this.title.setTitle(url['title'] + res);
                });
            });
        this.router.events.subscribe(function(url) {
            _this.commonService.updateLogin();
            window.scrollTo(0, 0);
            _this.loginclass = (url['url'] == '' || url['url'] == '/') ? 'loginheader home' : 'loginheader';
            if (url['url'] !== undefined) {
                if (url['url'].indexOf("page/terms") >= 0 || url['url'].indexOf("page/contactus") >= 0 || url['url'].indexOf('user/reset_password') >= 0 || url['url'].indexOf('user/activation') >= 0 || ((url['url'].indexOf('/gallery/jamse-test2') >= 0 || url['url'].indexOf('/gallery/') >= 0) && !_this.commonService.isLogin)) {
                    _this.headerclass = 'header searchr termshead';
                } else if (url['url'] == '' || url['url'].indexOf("search") >= 0) {
                    _this.headerclass = 'header searchr';
                } else {
                    _this.headerclass = 'header';
                }
                _this.eventLink = (_this.commonService.eventPageLink.indexOf(url['url']) >= 0 || (url['url'].indexOf('/gallery/') >= 0 && _this.commonService.isLogin)) ? true : false;
            }
        });
        //check user is collaborator or videographer
        this.commonService.is_regular_account = (this.commonService.userDetail["extra_data"].tracks_is_regular_account != null && this.commonService.userDetail["extra_data"].tracks_is_regular_account != undefined) ? this.commonService.userDetail["extra_data"].tracks_is_regular_account : "1";
        this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
        this.userData = this.commonService.getLocalStorage('userDetail');
        if (this.commonService.isLogin && this.commonService.is_regular_account == '1') {
            this.commonService.getUserCredit();
            this.commonService.getUserFavorite();
        }
    };
    HeaderComponent.prototype.goHome = function() {
        this.router.navigate(['/']);
    };
    /**
     * Show Login Popup
     */
    HeaderComponent.prototype.showLoginPopup = function() {
        this.modalService.open(LoginComponent).result.then(function(result) {

        }, function(reason) {

        });
    };;
    /**
     * Redirect To Other Page
     */
    HeaderComponent.prototype.moveTo = function(url) {
        this.router.navigate([url]);
    };
    /**
     * user Logout
     */
    HeaderComponent.prototype.userLogout = function() {
        var _this = this;
        this.httpclient.get('user/logout')
            .subscribe(function(data) {
                //this.commonService.updateLogin();
                _this.commonService.removeCookie(['isLogin', 'mailSentTo', 'isReseted', 'projectId']);
                _this.commonService.removeLocalStorage(['remember_me', 'userDetail', 'favoriteIds']);
                _this.commonService.updateLogin();
                _this.router.navigate(['/']);
            }, function(error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
            });
    };
    HeaderComponent.prototype.openmenusection = function(sectionval) {
        this.menusection = !sectionval;
    };
    /**
     * move to gallery
     */
    HeaderComponent.prototype.movetoGallery = function() {
        this.commonService.galleryPage['isGuest'] = false;
        this.router.navigate(['/gallery', this.commonService.userDetail['gallery_page']]);
    };
    return HeaderComponent;
}());
HeaderComponent = __decorate([
    Component({
        selector: 'app-header',
        templateUrl: './header.component.html',
        styleUrls: ['./header.component.css']
    }),
    __metadata("design:paramtypes", [CommonService,
        TranslateService,
        NgbModal,
        Router,
        ActivatedRoute,
        Title,
        HttpClientService
    ])
], HeaderComponent);
export { HeaderComponent };
//# sourceMappingURL=header.component.js.map