var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { HttpModule, JsonpModule, BaseRequestOptions } from '@angular/http';
import { MockBackend } from '@angular/http/testing';
import { NgbModule, NgbInputDatepicker, NgbDatepickerConfig } from '@ng-bootstrap/ng-bootstrap';
import { LocalStorageModule } from 'angular-2-local-storage';
import { MomentModule } from 'angular2-moment';
import { TranslateModule, TranslateService } from 'ng2-translate';
import { Ng2AutoCompleteModule } from 'ng2-auto-complete';
import { Ng2PageScrollModule } from 'ng2-page-scroll';
import { NgUploaderModule } from 'ngx-uploader';
import { MyDatePickerModule } from 'mydatepicker';
import { Ng2DragDropModule } from "ng2-drag-drop";
import { ShareButtonsModule } from "ng2-sharebuttons";
import 'rxjs/Rx';
import { AppComponent } from './app.component';
import { routing } from './common/app.routes';
import { AuthGuard } from './common/auth.guard';
import { UnauthGuard } from './common/auth.guard';
import { HttpClientService } from './common/http-client.service';
import { ValidationService } from './common/validation.service';
import { CommonService } from './common/common.service';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ChannelsComponent } from './channels/channels.component';
import { MessageComponent } from './message/message.component';
import { LicenseComponent } from './license/license.component';
import { SearchResultComponent } from './search-result/search-result.component';
import { EventsComponent } from './events/events.component';
import { CreateEventComponent } from './create-event/create-event.component';
import { CreateWorkComponent } from './create-Work/create-work.component';
import { DeleteEventComponent } from './delete-event/delete-event.component';
import { GalleryComponent } from './gallery/gallery.component';
import { CollaboratorComponent } from './collaborator/collaborator.component';
import { DownloadMediaComponent } from './download-media/download-media.component';
import { ValuesPipe } from './pipe/values.pipe';
import { trackIsFavoritePipe } from './pipe/values.pipe';
import { workIdStringPipe } from './pipe/values.pipe';
import { getMonthShortNamePipe } from './pipe/values.pipe';
import { TruncatePipe } from './pipe/values.pipe';
import { YoutubePlayerModule } from 'ng2-youtube-player';
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    NgModule({
        declarations: [
            AppComponent,
            LoginComponent,
            HomeComponent,
            HeaderComponent,
            FooterComponent,
            ChannelsComponent,
            ValuesPipe,
            trackIsFavoritePipe,
            getMonthShortNamePipe,
            TruncatePipe,
            workIdStringPipe,
            MessageComponent,
            LicenseComponent,
            SearchResultComponent,
            EventsComponent,
            CreateEventComponent,
            CreateWorkComponent,
            DeleteEventComponent,
            CollaboratorComponent,
            DownloadMediaComponent,
            GalleryComponent
        ],
        imports: [
            BrowserModule,
            MomentModule,
            FormsModule,
            ReactiveFormsModule,
            HttpModule,
            JsonpModule,
            routing,
            CommonModule,
            Ng2DragDropModule,
            Ng2AutoCompleteModule,
            NgbModule.forRoot(),
            TranslateModule.forRoot(),
            LocalStorageModule.withConfig({
                storageType: 'localStorage'
            }),
            NgUploaderModule,
            MyDatePickerModule,
            Ng2PageScrollModule.forRoot(),
            ShareButtonsModule.forRoot(),
            YoutubePlayerModule
        ],
        providers: [
            AuthGuard,
            UnauthGuard,
            MockBackend,
            BaseRequestOptions,
            HttpClientService,
            CommonService,
            ValidationService,
            FormBuilder,
            TranslateService,
            NgbInputDatepicker,
            NgbDatepickerConfig
        ],
        entryComponents: [
            LoginComponent,
            CreateEventComponent,
            CreateWorkComponent,
            DeleteEventComponent,
            MessageComponent,
            LicenseComponent,
            CollaboratorComponent,
            ChannelsComponent,
            DownloadMediaComponent
        ],
        bootstrap: [AppComponent]
    })
], AppModule);
export { AppModule };
//# sourceMappingURL=app.module.js.map