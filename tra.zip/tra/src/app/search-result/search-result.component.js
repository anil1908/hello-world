var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { Component, ViewChildren, Renderer } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
var SearchResultComponent = (function () {
    function SearchResultComponent(commonService, httpclient, route, renderer, router) {
        this.commonService = commonService;
        this.httpclient = httpclient;
        this.route = route;
        this.renderer = renderer;
        this.router = router;
        this.tracks = '';
        this.filteredList = { albums: [], artists: [], tracks: [] };
        this.resultList = [];
        this.favoriteMsg = "";
        this.searchData = { track_name: '', id: '', type: "" };
        this.is_regular_account = "1";
        this.ProjectList = [];
        this.projArr = [];
        this.is_project_called = false;
        this.show_no_data_found = false;
    }
    /* This method is call when page is load
         */
    SearchResultComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.pc = 298.1371428256714; // 2 pi r
        this.route
            .queryParams
            .subscribe(function (params) {
            _this.searchData = {
                track_name: (params['track_name'] !== undefined) ? params['track_name'] : _this.searchData['track_name'],
                id: (params['id'] !== undefined) ? params['id'] : _this.searchData['id'],
                type: (params['type'] !== undefined) ? params['type'] : _this.searchData['type'],
            };
            _this.getSearchData();
        });
        //check user is collaborator or videographer
        this.is_regular_account = (this.commonService.userDetail["extra_data"].tracks_is_regular_account != null && this.commonService.userDetail["extra_data"].tracks_is_regular_account != undefined) ? this.commonService.userDetail["extra_data"].tracks_is_regular_account : "1";
    };
    /**
    * Filter Result
    */
    SearchResultComponent.prototype.filterTracks = function (event) {
        var _this = this;
        if (this.tracks !== "" && this.tracks.length > 2) {
            this.httpclient.post('search/autocomplete', { txt: this.tracks })
                .subscribe(function (data) {
                _this.filteredList = {
                    albums: data['data']['albums'],
                    artists: data['data']['artists'],
                    tracks: data['data']['tracks']
                };
            }, function (error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
            });
        }
        else {
            this.filteredList = { albums: [], artists: [], tracks: [] };
        }
    };
    /*
    Redirect to search page based on selection
     */
    SearchResultComponent.prototype.searchResult = function (data, type) {
        if (data === void 0) { data = null; }
        var queryParams = {};
        if (type == "tracks") {
            queryParams = {
                track_name: data.track_name,
                id: data.artist_id,
                type: "tracks",
            };
        }
        else if (type == "artist_tracks") {
            queryParams = {
                id: data.artist_id,
                type: "artists",
            };
        }
        else if (type == "album_tracks") {
            queryParams = {
                id: data.album_id,
                type: "albums",
            };
        }
        else if (type == "collection") {
            queryParams = {
                id: data.id,
                type: "collection",
            };
        }
        else if (type == "full") {
            queryParams = {
                type: "full",
                track_name: this.tracks,
            };
        }
        this.router.navigate(['/search'], { queryParams: queryParams });
    };
    /**
     * Search Data
     */
    SearchResultComponent.prototype.getSearchData = function () {
        var _this = this;
        var api = "";
        var tempResultInfo;
        var data;
        switch (this.searchData['type']) {
            case "albums":
                api = "search/album_tracks/" + this.searchData['id'];
                break;
            case "artists":
                api = "search/artist_tracks/" + this.searchData['id'];
                break;
            case "tracks":
                api = "search/similar_tracks/" + this.searchData['id'] + '/' + this.searchData['track_name'];
                break;
            case "collection":
                api = "/admin/public_playlists/read/" + this.searchData['id'];
                break;
            case "full":
                api = "search/full/" + this.searchData['track_name'];
                tempResultInfo = this.searchData['track_name'];
                break;
        }
        if (api != "") {
            //  this.tracks = "";
            this.resultInfo = "";
            this.filteredList = { albums: [], artists: [], tracks: [] };
            if (this.searchData['type'] == "collection") {
                this.httpclient.post(api, data)
                    .subscribe(function (data) {
                    if (data['code'] == 200) {
                        _this.show_no_data_found = true;
                        var dataObj_1 = [];
                        _this.resultInfo = data["data"]["name"];
                        if (data["data"]["media_list"]) {
                            data["data"]["media_list"].forEach(function (element) {
                                if ((element["media_list"]) && (element["media_list"].length > 0)) {
                                    element["media_list"].forEach(function (element2) {
                                        dataObj_1 = {
                                            "track_url": element2.track_url,
                                            "album_pic": element2.album_image_thumb,
                                            "track_name": element2.name,
                                            "artist_name": element2.artist_name,
                                            "album_name": element2.album_name,
                                            "track_id": element2.media_id
                                        };
                                        _this.resultList.push(dataObj_1);
                                    });
                                }
                                else {
                                    dataObj_1 = {
                                        "track_url": element["track_url"],
                                        "album_pic": element["album_image_thumb"],
                                        "track_name": element["name"],
                                        "artist_name": element["artist_name"],
                                        "album_name": element["album_name"],
                                        "track_id": element["media_id"]
                                    };
                                    _this.resultList.push(dataObj_1);
                                }
                            });
                        }
                    }
                }, function (error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
            }
            else {
                this.httpclient.get(api)
                    .subscribe(function (data) {
                    _this.filteredList = { albums: [], artists: [], tracks: [] };
                    if (data['code'] == 200) {
                        _this.resultList = data['data'];
                        if (_this.resultList.length > 0) {
                            if (_this.searchData['type'] == "albums") {
                                _this.resultInfo = _this.resultList[0].album_name;
                            }
                            if (_this.searchData['type'] == "artists") {
                                _this.resultInfo = _this.resultList[0].artist_name;
                            }
                            if (_this.searchData['type'] == "tracks") {
                                _this.resultInfo = _this.resultList[0].track_name;
                            }
                            if (_this.searchData['type'] == "full") {
                                _this.resultInfo = tempResultInfo;
                            }
                        }
                    }
                }, function (error) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
                });
            }
            if (this.commonService.isLogin) {
                this.getAllProject();
            }
        }
    };
    SearchResultComponent.prototype.clearSearch = function () {
        this.resultInfo = "";
        this.tracks = '';
        this.filteredList = { albums: [], artists: [], tracks: [] };
        this.resultList = [];
        document.getElementById('tracks').focus();
    };
    /**
       * get All Project List
       */
    SearchResultComponent.prototype.getAllProject = function (callSelectProject) {
        var _this = this;
        if (callSelectProject === void 0) { callSelectProject = true; }
        if (!this.is_project_called) {
            this.projArr = [];
            this.httpclient.get('projects/get_all_projects')
                .subscribe(function (data) {
                if (data['code'] == 200) {
                    _this.ProjectList = data['data']['projects'];
                    if (_this.ProjectList.length > 0) {
                        for (var projObj in _this.ProjectList) {
                            if (_this.ProjectList[projObj]['child_list'].length > 0) {
                                var singleProjet = _this.ProjectList[projObj]['child_list'];
                                var testArr = {
                                    title: _this.ProjectList[projObj]["name"],
                                    works: []
                                };
                                for (var workObj in singleProjet) {
                                    var workObjData = {
                                        "id": singleProjet[workObj].id,
                                        "name": singleProjet[workObj].name,
                                        "license_code": singleProjet.license_code,
                                        "license_type": singleProjet[workObj].extra_properties.license_type,
                                    };
                                    testArr.works.push(workObjData);
                                }
                                _this.projArr.push(testArr);
                            }
                        }
                    }
                }
                else if (data['code'] == 500) {
                    _this.projArr = [];
                }
            }, function (error) {
            });
            this.is_project_called = true;
        }
    };
    /**
      * add Track Into selected Work
      */
    SearchResultComponent.prototype.addTrackWork = function (media_id, workId, track_name, workName) {
        var _this = this;
        if (workId !== "" && workId !== undefined && workId !== null) {
            var data = { "media": [{ "media_id": media_id, "kind": "track" }] };
            this.httpclient.post('project/' + workId + '/append_media', data)
                .subscribe(function (data) {
                if (data['code'] == 200) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['success'], track_name + " " + _this.commonService.globalVar['added_to'] + " " + workName);
                }
                else if (data['code'] == 500) {
                    _this.commonService.messagePopup(_this.commonService.globalVar['error'], data['message'][0]);
                }
            }, function (error) {
            });
        }
        else {
            return false;
        }
    };
    /**
     * Audio Timer
     */
    SearchResultComponent.prototype.reportPosition = function (index, player) {
        var currentaudio = this[player]._results[index];
        var dur = ((currentaudio.nativeElement.currentTime / currentaudio.nativeElement.duration) * this.pc);
        var value = this.pc - dur;
        currentaudio.nativeElement.nextElementSibling.childNodes[1].childNodes[3].style.strokeDashoffset = value;
        if (value === 0) {
            currentaudio.nativeElement.nextElementSibling.setAttribute("class", "not-started");
            currentaudio.nativeElement.removeEventListener('timeupdate', this.reportPosition);
        }
    };
    /**
      * Audio Control
      */
    SearchResultComponent.prototype.controlBtn = function (event, index, player) {
        var _this = this;
        this.currentaudio = this[player]._results[index];
        switch (this.currentaudio.nativeElement.nextElementSibling.getAttribute('class')) {
            case "not-started":
                if (this.lastplayid !== undefined && this.lastplayid !== null && this.lastplayid !== '') {
                    this.lastplayid.nativeElement.pause();
                    if (!isNaN(this.lastplayid.nativeElement.duration)) {
                        this.lastplayid.nativeElement.currentTime = 0;
                    }
                    this.lastplayid.nativeElement.nextElementSibling.setAttribute("class", "not-started");
                    this.lastplayid.nativeElement.removeEventListener('timeupdate', this.reportPosition);
                }
                this.renderer.listen(this.currentaudio.nativeElement, 'timeupdate', function (event) {
                    _this.reportPosition(index, player);
                });
                this.currentaudio.nativeElement.play();
                this.lastplayid = this.currentaudio;
                this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
                break;
            case "playing":
                this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "paused");
                this.currentaudio.nativeElement.pause();
                break;
            case "paused":
                this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
                this.currentaudio.nativeElement.play();
                break;
        }
    };
    /*
    Add/Delete track to/from user favorite list
     */
    SearchResultComponent.prototype.updateFavorite = function (trackId, api, trackName, trackImage, event) {
        var _this = this;
        if (trackImage === void 0) { trackImage = ""; }
        if (trackId !== "" && this.commonService.isLogin) {
            this.renderer.setElementClass(event.target, "active", (api == 'delete') ? false : true);
            this.httpclient.post('favorites/' + api, { media_id: trackId, media_kind: "track" })
                .subscribe(function (data) {
                if (data['code'] == 200) {
                    _this.commonService.getUserFavorite();
                    _this.resultList = _this.resultList;
                    _this.favoriteMsg = data['data'];
                    //set success message
                    //this.commonService.successMsg = { "show": true, "image": trackImage, "msg": "<strong><i>" + trackName + "</i> " + this.commonService.globalVar[(api == 'add') ? 'added_to' : 'removed_from'] + " " + this.commonService.globalVar['favorite'] + " </strong>" };
                }
                else {
                    _this.renderer.setElementClass(event.target, "active", (api == 'delete') ? true : false);
                }
            }, function (error) {
                _this.commonService.messagePopup(_this.commonService.globalVar['error'], error);
            });
        }
    };
    return SearchResultComponent;
}());
__decorate([
    ViewChildren('searchPlayer'),
    __metadata("design:type", Object)
], SearchResultComponent.prototype, "searchPlayer", void 0);
SearchResultComponent = __decorate([
    Component({
        selector: 'app-search-result',
        templateUrl: './search-result.component.html',
        styleUrls: ['./search-result.component.css'],
    }),
    __metadata("design:paramtypes", [CommonService,
        HttpClientService,
        ActivatedRoute,
        Renderer,
        Router])
], SearchResultComponent);
export { SearchResultComponent };
//# sourceMappingURL=search-result.component.js.map