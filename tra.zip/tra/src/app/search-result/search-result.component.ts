import { Component, OnInit, ViewChildren, Renderer } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbActiveModal, NgbModal, ModalDismissReasons, NgbDateParserFormatter, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { AccountHolderComponent } from '../account-holder/account-holder.component';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
import { trackIsFavoritePipe } from '../pipe/values.pipe';

@Component({
  selector: 'app-search-result',
  templateUrl: './search-result.component.html',
  styleUrls: ['./search-result.component.css'],
})
export class SearchResultComponent implements OnInit {
  /* initialize variables */
  @ViewChildren('searchPlayer') searchPlayer:any;
  tracks = '';
  filteredList: Object = { albums: [], artists: [], tracks: [] };
  selectedIdx: number;
  resultList: any = [];
  resultInfo: any;
  currentaudio: any;
  lastplayid: any;
  favoriteIds: any;
  favoriteMsg: any = "";
  pc: any;
  searchData: Object = { track_name: '', id: '', type: "" }
  is_regular_account = "1";
  ProjectList: Array<any> = [];
  projArr: Array<any> = [];
  is_project_called: Boolean = false;
  show_no_data_found = false;
  searchHistoryList: Array<any> = (this.commonService.json(this.commonService.getLocalStorage('searchData')) !== null && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== undefined && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== '') ? this.commonService.json(this.commonService.getLocalStorage('searchData')) : [];

  constructor(
    public commonService: CommonService,
    private modalService: NgbModal,
    private httpclient: HttpClientService,
    private route: ActivatedRoute,
    private renderer: Renderer,
    private router: Router) {
  }
  /* This method is call when page is load
       */
  ngOnInit() {
    this.pc = 298.1371428256714; // 2 pi r
    this.route
      .queryParams
      .subscribe(params => {
        this.searchData = {
          track_name: (params['track_name'] !== undefined) ? params['track_name'] : this.searchData['track_name'],
          id: (params['id'] !== undefined) ? params['id'] : this.searchData['id'],
          type: (params['type'] !== undefined) ? params['type'] : this.searchData['type'],
        }

         /**
         * Search History save Client Side
         */
        if (this.searchData['type'] !== "full") {
          this.searchHistoryList = (this.commonService.json(this.commonService.getLocalStorage('searchData')) !== null && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== undefined && this.commonService.json(this.commonService.getLocalStorage('searchData')) !== '') ? this.commonService.json(this.commonService.getLocalStorage('searchData')) : [];
          var isAvailable = false;
          for (let k = 0; k < this.searchHistoryList.length; k++) {
            if (this.searchHistoryList[k].type == this.searchData['type'] && this.searchHistoryList[k].id == this.searchData['id']) {
              isAvailable = true;
            }
          }
          if (!isAvailable) {
            this.searchHistoryList.push({ searchdata: {id: this.searchData['id'],track_name: this.searchData['track_name']}, type: this.searchData['type'], id: this.searchData['id'] });
          }
          this.searchHistoryList = (this.searchHistoryList.length > 5) ? this.searchHistoryList.slice(Math.max(this.searchHistoryList.length - 5, 1)) : this.searchHistoryList;
          this.commonService.setLocalStorage('searchData', this.commonService.stringifyObject(this.searchHistoryList));
          this.searchHistoryList = this.commonService.json(this.commonService.getLocalStorage('searchData'));
        }
        /**
         * End Search History save Client Side
         */
        this.getSearchData();
      });
    //check user is collaborator or videographer
    this.is_regular_account = (this.commonService.userDetail["extra_data"].tracks_is_regular_account != null && this.commonService.userDetail["extra_data"].tracks_is_regular_account != undefined) ? this.commonService.userDetail["extra_data"].tracks_is_regular_account : "1";
  }

  /**
  * Filter Result
  */
  filterTracks(event: any) {
    if (this.tracks !== "" && this.tracks.length > 2) {
      this.httpclient.post('search/autocomplete', { txt: this.tracks })
        .subscribe(
        data => {
          this.filteredList = {
            albums: data['data']['albums'],
            artists: data['data']['artists'],
            tracks: data['data']['tracks']
          };
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    } else {
      this.filteredList = { albums: [], artists: [], tracks: [] };
    }
  }

  /*
  Redirect to search page based on selection
   */
  searchResult(data: any = null, type: any) {
    let queryParams: Object = {};
    if (type == "tracks") {
      queryParams = {
        track_name: data.track_name,
        id: data.artist_id,
        type: "tracks",
      }
      this.tracks = (data['track_name']!==undefined && data['track_name']!==null && data['track_name']!=='')?data['track_name']:'';
    } else if (type == "artist_tracks") {
      queryParams = {
        id: data.artist_id,
        type: "artists",
      }
      this.tracks = (data['artist_name']!==undefined && data['artist_name']!==null && data['artist_name']!=='')?data['artist_name']:'';
    } else if (type == "album_tracks") {
      queryParams = {
        id: data.album_id,
        type: "albums",
      }
      this.tracks = (data['album_name']!==undefined && data['album_name']!==null && data['album_name']!=='')?data['album_name']:'';
    } else if (type == "collection") {
      queryParams = {
        id: data.id,
        type: "collection",
      }
    } else if (type == "full") {
      queryParams = {
        type: "full",
        track_name: this.tracks,
      }
    }

    
    this.router.navigate(['/search'], { queryParams: queryParams });
  }

  /**
   * Search Data
   */
  getSearchData() {
    let api = "";
    let tempResultInfo:any;
    let data;
    switch (this.searchData['type']) {
      case "albums":
        api = "search/album_tracks/" + this.searchData['id'];
        break;
      case "artists":
        api = "search/artist_tracks/" + this.searchData['id'];
        break;
      case "tracks":
        api = "search/similar_tracks/" + this.searchData['id'] + '/' + this.searchData['track_name'];
        break;
      case "collection":
        api = "/admin/public_playlists/read/" + this.searchData['id'];
        break;
      case "full":
        api = "search/full/" + this.searchData['track_name'];
        tempResultInfo = this.searchData['track_name'];
        break;
    }
    if (api != "") {
    //  this.tracks = "";
      this.resultInfo = "";
      this.filteredList = { albums: [], artists: [], tracks: [] };
      if (this.searchData['type'] == "collection") {
        this.httpclient.post(api, data)
          .subscribe(
          data => {
            if (data['code'] == 200) {
              this.show_no_data_found = true;
              let dataObj: Object = [];
              this.resultInfo = data["data"]["name"];
              if (data["data"]["media_list"]) {
                data["data"]["media_list"].forEach((element:any) => {
                  if ((element["media_list"]) && (element["media_list"].length > 0)) {
                    element["media_list"].forEach((element2:any) => {
                      dataObj = {
                        "track_url": element2.track_url,
                        "album_pic": element2.album_image_thumb,
                        "track_name": element2.name,
                        "artist_name": element2.artist_name,
                        "album_name": element2.album_name,
                        "track_id": element2.media_id
                      };
                      this.resultList.push(dataObj);
                    });
                  } else {
                    dataObj = {
                      "track_url": element["track_url"],
                      "album_pic": element["album_image_thumb"],
                      "track_name": element["name"],
                      "artist_name": element["artist_name"],
                      "album_name": element["album_name"],
                      "track_id": element["media_id"]
                    };
                    this.resultList.push(dataObj);
                  }
                });
              }
            }
          },
          error => {
            this.commonService.messagePopup(this.commonService.globalVar['error'], error);
          });
      } else {
        this.httpclient.get(api)
          .subscribe(
          data => {
            this.filteredList = { albums: [], artists: [], tracks: [] };
            if (data['code'] == 200) {
              this.resultList = data['data'];
              if (this.resultList.length > 0) {
                if (this.searchData['type'] == "albums") {
                  this.resultInfo = this.resultList[0].album_name;
                }
                if (this.searchData['type'] == "artists") {
                  this.resultInfo = this.resultList[0].artist_name;
                }
                if (this.searchData['type'] == "tracks") {
                  this.resultInfo = this.resultList[0].track_name;
                }
                if (this.searchData['type'] == "full") {
                  this.resultInfo = tempResultInfo;
                }
              }
            }
          },
          error => {
            this.commonService.messagePopup(this.commonService.globalVar['error'], error);
          });
      }
      if (this.commonService.isLogin) {
        this.getAllProject();
      }
    }
  }

  clearSearch() {
    this.resultInfo = "";
    this.tracks = '';
    this.filteredList = { albums: [], artists: [], tracks: [] };
    this.resultList = [];
    document.getElementById('tracks').focus();
  }
  /**
     * get All Project List
     */
  getAllProject(callSelectProject = true) {
    if (!this.is_project_called) {
      this.projArr = [];
      this.httpclient.get('projects/get_all_projects')
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.ProjectList = data['data']['projects'];
            if (this.ProjectList.length > 0) {
              for (var projObj in this.ProjectList) {
                if (this.ProjectList[projObj]['child_list'].length > 0) {
                  let singleProjet = this.ProjectList[projObj]['child_list'];
                  let testArr : any = { 
                    title: this.ProjectList[projObj]["name"], 
                    works: []
                  };
                  for (var workObj in singleProjet) {
                    let workObjData = {
                      "id": singleProjet[workObj].id,
                      "name": singleProjet[workObj].name,
                      "license_code": singleProjet.license_code,
                      "license_type": singleProjet[workObj].extra_properties.license_type,
                    };
                    testArr.works.push(workObjData);
                  }
                  this.projArr.push(testArr);
                }
              }
            }
          }
          else if (data['code'] == 500) {
            this.projArr = [];
          }
        },
        error => {

        });
      this.is_project_called = true;
    }
  }
  /**
    * add Track Into selected Work
    */
  addTrackWork(media_id:any, workId:any, track_name:any, workName:any) {
    if (workId !== "" && workId !== undefined && workId !== null) {
      let data = { "media": [{ "media_id": media_id, "kind": "track" }] };
      this.httpclient.post('project/' + workId + '/append_media', data)
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.commonService.messagePopup(this.commonService.globalVar['success'], track_name + " " + this.commonService.globalVar['added_to'] + " " + workName);
          }
          else if (data['code'] == 500) {
            this.commonService.messagePopup(this.commonService.globalVar['error'], data['message'][0]);
          }
        },
        error => {

        });
    }
    else {
      return false;
    }
  }

  /**
   * Audio Timer
   */
  reportPosition(index:any, player:any) {
    let currentaudio = this[player]._results[index];
    let dur = ((currentaudio.nativeElement.currentTime / currentaudio.nativeElement.duration) * this.pc);
    let value = this.pc - dur;
    currentaudio.nativeElement.nextElementSibling.childNodes[1].childNodes[3].style.strokeDashoffset = value;
    if (value === 0) {
      currentaudio.nativeElement.nextElementSibling.setAttribute("class", "not-started");
      currentaudio.nativeElement.removeEventListener('timeupdate', this.reportPosition);
    }
  }
  /**
    * Audio Control
    */
  controlBtn(event:any, index: number, player: string) {
    this.currentaudio = this[player]._results[index];
    switch (this.currentaudio.nativeElement.nextElementSibling.getAttribute('class')) {
      case "not-started":
        if (this.lastplayid !== undefined && this.lastplayid !== null && this.lastplayid !== '') {
          this.lastplayid.nativeElement.pause();
          if (!isNaN(this.lastplayid.nativeElement.duration)) {
              this.lastplayid.nativeElement.currentTime = 0;
          }
          this.lastplayid.nativeElement.nextElementSibling.setAttribute("class", "not-started");
          this.lastplayid.nativeElement.removeEventListener('timeupdate', this.reportPosition);
        }
        this.renderer.listen(this.currentaudio.nativeElement, 'timeupdate', (event:any) => {
          this.reportPosition(index, player);
        })
        this.currentaudio.nativeElement.play();
        this.lastplayid = this.currentaudio;
        this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
        break;
      case "playing":
        this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "paused");
        this.currentaudio.nativeElement.pause();
        break;
      case "paused":
        this.currentaudio.nativeElement.nextElementSibling.setAttribute("class", "playing");
        this.currentaudio.nativeElement.play();
        break;
    }
  }

  /*
  Add/Delete track to/from user favorite list
   */
  updateFavorite(trackId:any, api:any, trackName:any, trackImage = "",event:any) {
    if (trackId !== "" && this.commonService.isLogin) {
      this.renderer.setElementClass(event.target, "active", (api == 'delete') ? false : true);
      this.httpclient.post('favorites/' + api, { media_id: trackId, media_kind: "track" })
        .subscribe(
        data => {
          if (data['code'] == 200) {
            this.commonService.getUserFavorite();
            this.resultList = this.resultList;
            this.favoriteMsg = data['data'];
            //set success message
            //this.commonService.successMsg = { "show": true, "image": trackImage, "msg": "<strong><i>" + trackName + "</i> " + this.commonService.globalVar[(api == 'add') ? 'added_to' : 'removed_from'] + " " + this.commonService.globalVar['favorite'] + " </strong>" };
          } else {
            this.renderer.setElementClass(event.target, "active", (api == 'delete') ? true : false);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
  }

  /**
   * Account Holder Popup
   */
  accountHolderPopup(){
    const modalRef = this.modalService.open(AccountHolderComponent);
      modalRef.componentInstance.title = this.commonService.globalVar['information'];
      modalRef.result.then((result) => {
        
      }, (reason) => {
        
      });
  }

}