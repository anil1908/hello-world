import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClientService } from '../common/http-client.service';
import { CommonService } from '../common/common.service';
import { ValidationService } from '../common/validation.service';

@Component({
  //selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
  /* initialize variables */
  passwordForm: FormGroup;
  submitted: boolean = false;
  forReset: Number = 0;
  token: any;
  //set server side error message Object
  msg: Object = { issuccess: false, isError: false, msg: '' };
  pathname: any = '';
  logincount : number =0;
  constructor(
    public fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private httpclient: HttpClientService,
    private validationService: ValidationService,
    private commonService: CommonService
  ) {
    this.validateToken();
    //Create reset password form and set validation rules
    this.passwordForm = this.fb.group({
      'token': [this.token, Validators.compose([Validators.required])],
      'password': ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(50)])],
      'is_activate_account': [this.forReset, Validators.compose([Validators.required])],
      'confirm_password': ['', Validators.compose([Validators.required, Validators.minLength(6), Validators.maxLength(50)])]
    }, { validator: this.validationService.compareField('password', 'confirm_password') });
  }
  /* This method is call when page is load
     */
  ngOnInit() {

  }
  /**Check reset password token is vali or not */
  validateToken() {
    this.token = this.route.snapshot.params['id'];
    let pathName: String = this.route.snapshot.url[0]['path'];
    this.pathname = pathName;
    this.forReset = (pathName == 'activation') ? 1 : 0;
    (this.token == "" && (pathName != 'reset_password' || pathName != 'activation')) ? this.router.navigate(['']) : "";

    this.httpclient.get('user/validate_token/' + this.token)
      .subscribe(
      data => {
        //redirect OR show error based on response code
        if (data['code'] == 500) {
          this.commonService.confirmMessagePopup(this.commonService.globalVar['error'], data["message"], true).then((result) => {
            if (result) { this.router.navigate(['']); }
          }, (reason) => {
            this.router.navigate(['']);
          });
        }
      },
      error => {
        this.commonService.messagePopup(this.commonService.globalVar['error'], error);
      });
  }

  /*
  Form submit action
  If validation fail thens show error message
  If validation success then call reset password API
   */
  submitForm(passwordfocus,confirmpasswordfocus) {
    if (this.passwordForm.valid) {
      this.httpclient.post('user/reset_password_submit', this.passwordForm.value)
        .subscribe(
        data => {
          //redirect OR show error based on response code
          if (data['code'] == 500) {
            this.msg = { issuccess: true, isError: false, msg: data['message'] };
          } else {
            // this.commonService.setLocalStorage('isloginpopup',true);
            ////this.commonService.setLocalStorage('iscredential',true);
            // this.msg = { issuccess: false, isError: false, msg: '' };
            // this.router.navigate(['']);
            let logindata = {
              username: data['data']['email'],
              password: this.passwordForm.controls['password'].value,
              remember_me: false
            };
            this.usersignin(logindata);
          }
        },
        error => {
          this.commonService.messagePopup(this.commonService.globalVar['error'], error);
        });
    }
    else {
      if(!this.passwordForm.controls['password'].valid){
        passwordfocus.focus();
      }
      else if(!this.passwordForm.controls['confirm_password'].valid){
        confirmpasswordfocus.focus();
      }
      this.msg = { issuccess: false, isError: false, msg: '' };
      this.submitted = true;
    }
  }

  usersignin(logindata) {
    this.logincount++;
    this.httpclient.post('user/signin_submit', logindata, {}, false)
      .subscribe(
      data => {
        if (data['code'] == 200) {
          if (this.pathname == 'activation') {
            this.commonService.setLocalStorage('collaboratorInstruction', true);
          }
          this.msg['isError'] = this.msg['isSuccess'] = false;
          this.commonService.setCookie("isLogin", "true");
          this.commonService.setLocalStorage('remember_me', false);
          this.commonService.setLocalStorage('userDetail', data['data']);
          this.commonService.updateLogin();
          //check user is collaborator or videographer
          this.commonService.is_regular_account = (this.commonService.userDetail["extra_data"].tracks_is_regular_account != null && this.commonService.userDetail["extra_data"].tracks_is_regular_account != undefined) ? this.commonService.userDetail["extra_data"].tracks_is_regular_account : "1";
          if (this.commonService.is_regular_account == '1') {
            this.commonService.getUserCredit();
            this.commonService.getUserFavorite();
          }
          this.router.navigate(['/events']);
        } else if (data['code'] == 500) {
          if(this.logincount<=2){
            this.userLogout(logindata);
          }
          else{
            this.msg = { issuccess: false, isError: true, msg: data['message'][0] };
          }
        }
      },
      error => {
        this.commonService.messagePopup(this.commonService.globalVar['warning'], error);
      });
  }
  /**
   * user Logout
   */
  userLogout(logindata): void {
    this.httpclient.get('user/logout')
      .subscribe(
      data => {
        this.commonService.removeCookie(['isLogin', 'mailSentTo', 'isReseted']);
        this.commonService.removeLocalStorage(['remember_me','collaboratorInstruction', 'userDetail','projectId', 'favoriteIds']);
        this.usersignin(logindata);
      },
      error => {
        this.commonService.messagePopup(this.commonService.globalVar['error'], error);
      });
  }


}