import { Component, Input, trigger, state, style, transition, animate } from '@angular/core';
import { NgSwitch, NgSwitchCase, NgSwitchDefault } from '@angular/common';
import { TranslateService } from 'ng2-translate';
import { CommonService } from './common/common.service';
import { HttpClientService } from './common/http-client.service';
import { NgbModule, NgbInputDatepicker, NgbDatepicker } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

export class AppComponent {
  stateUrl : any;
  constructor(
    private translate: TranslateService,
    public httpclient: HttpClientService,
    private commonService: CommonService
  ) {

  }

  ngOnInit() {
    /**
     * for language change
    */
    this.commonService.updateLogin();
    this.translate.addLangs(['en', 'fr']);
    this.translate.setDefaultLang('en');
    let browserLang = this.translate.getBrowserLang();
    this.translate.use(browserLang.match(/en|fr/) ? browserLang : 'en');
    this.commonService.setLanguageVar();
  }

}