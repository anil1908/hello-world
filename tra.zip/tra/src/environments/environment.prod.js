export var environment = {
    production: true
};
//# sourceMappingURL=environment.prod.js.map