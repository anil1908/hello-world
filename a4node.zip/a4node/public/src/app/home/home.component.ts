import { Component, NgZone, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
import { Validators, FormGroup, FormArray, FormBuilder } from '@angular/forms';
import { ChatService }       from './home.service';

@Component({
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  public customerForm: FormGroup; // our form model
  customerDetail: Array<any>;
  bookData: Array<any> = [];
  submitted: boolean = false;
  customeId : string = '';

  messages = [];
  connection;
  message;

  constructor(
    public fb: FormBuilder,
    public chatService: ChatService,
    private commonService: CommonService,
    private httpclient: HttpClientService,
    private router: Router
  ) {

  }
  /* This method is call when page is load
   */
  ngOnInit() {
    this.connection = this.chatService.getMessages().subscribe(message => {
      this.messages.push(message);
    })

    this.customerForm = this.fb.group({
      name: ['', Validators.compose([Validators.required,])],
      billno: ['', Validators.compose([Validators.required])],
      email: ['', Validators.compose([Validators.required])],
      phone: ['', Validators.compose([Validators.required])],
      books: this.fb.array([
        this.initBook({})
      ]),
    });
    this.getCustomerDetails();
    this.getAllBooks();

  }

  initBook(bookobj) {
    return this.fb.group({
      id: [(Object.keys(bookobj).length>0)?bookobj.id:'', Validators.required],
      quantity: [(Object.keys(bookobj).length>0)?bookobj.quantity:0, Validators.required],
      price: [(Object.keys(bookobj).length>0)?bookobj.price:0, Validators.required],
      total_price: [(Object.keys(bookobj).length>0)?bookobj.total_price:0, Validators.required]
    })
  }

  addBooks(bookobj) {
    const control = <FormArray>this.customerForm.controls['books'];
    control.push(this.initBook(bookobj));
  }

  removeBook(i: number) {
    const control = <FormArray>this.customerForm.controls['books'];
    control.removeAt(i);
  }

  getCustomerDetails() {
    this.httpclient.get('customers')
      .subscribe(
      data => {
        this.customerDetail = data['data'];
      },
      error => {
        console.log(error);
      });
  }

  getAllBooks() {
    this.httpclient.get('books')
      .subscribe(
      data => {
        this.bookData = data['data'];
      },
      error => {
        console.log(error);
      });
  }

  bookChange(index, bookobj) {
    for (let book of this.bookData) {
      if (parseInt(bookobj) == book.id) {
        this.customerForm.controls['books']['controls'][index].controls['price'].setValue(book.price);
        let total = this.customerForm.controls['books']['controls'][index].controls['quantity'].value * this.customerForm.controls['books']['controls'][index].controls['price'].value;
        this.customerForm.controls['books']['controls'][index].controls['total_price'].setValue(total);
      }
    }
  }

  qtyChange(index) {
    let total = this.customerForm.controls['books']['controls'][index].controls['quantity'].value * this.customerForm.controls['books']['controls'][index].controls['price'].value;
    this.customerForm.controls['books']['controls'][index].controls['total_price'].setValue(total);
  }

  save() {
    if (this.customerForm.valid) {
      let url = (this.customeId!=='')?'customers/edit/'+this.customeId:'customers/add';
      this.httpclient.post(url, this.customerForm.value)
        .subscribe(
        data => {
          this.customeId = '';
          this.customerForm = this.fb.group({
            name: ['', Validators.compose([Validators.required,])],
            billno: ['', Validators.compose([Validators.required])],
            email: ['', Validators.compose([Validators.required])],
            phone: ['', Validators.compose([Validators.required])],
            books: this.fb.array([
              this.initBook({})
            ]),
          });
          this.getCustomerDetails();
        },
        error => {
          console.log(error);
        });
    }
    else {
      this.submitted = true;
    }
  }

  removeCustomer(customeId) {
    this.httpclient.get('customers/delete/' + customeId)
      .subscribe(
      data => {
        this.getCustomerDetails();
      },
      error => {
        console.log(error);
      });
  }

  editCustomer(customeId) {
    this.customeId = customeId;
    this.httpclient.get('customers/edit/' + customeId)
      .subscribe(
      data => {
        this.customerForm = this.fb.group({
          name: [data['data']['name'], Validators.compose([Validators.required,])],
          billno: [data['data']['billno'], Validators.compose([Validators.required])],
          email: [data['data']['email'], Validators.compose([Validators.required])],
          phone: [data['data']['phone'], Validators.compose([Validators.required])],
          books: this.fb.array([

          ]),
        });
        if(data['data']['books'].length>0){
          for (var i in data['data']['books']) {
            this.addBooks({
              id:data['data']['books'][i]['id'],
              quantity : data['data']['books'][i]['quantity'],
              price : data['data']['books'][i]['price'],
              total_price : data['data']['books'][i]['total_price']
            })
          }
        }

      },
      error => {
        console.log(error);
      });
  }
  sendMessage(){
    this.chatService.sendMessage(this.message);
    this.message = '';
  }

  ngOnDestroy() {
    this.connection.unsubscribe();
  }

  logout(){
    localStorage.removeItem('token');
    this.connection.unsubscribe();
          this.router.navigate(['/']);
  }

}