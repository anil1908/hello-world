import { Component } from '@angular/core';
import { CommonService } from './common/common.service';
import { HttpClientService } from './common/http-client.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';
  stateUrl : any;
  constructor(
    private httpclient: HttpClientService,
    private commonService: CommonService
  ) {

  }
}
