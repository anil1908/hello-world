import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { CommonService } from '../common/common.service';
import { HttpClientService } from '../common/http-client.service';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  /* initialize variables */
  logindata: any = {};
  returnUrl: string;
  accountToggle: boolean = false;
  infoToggle: boolean = false;
  userData: Object;
  userGallery: Object;
  loginclass: string;
  headerclass: string;
  eventLink: boolean = false;
  menusection: boolean = true;

  constructor(
    private commonService: CommonService,
    private router: Router,
    private route: ActivatedRoute,
    private title: Title,
    private httpclient: HttpClientService) {

  }

  /* This method is call when page is load
     */
  ngOnInit() {

  }


}
