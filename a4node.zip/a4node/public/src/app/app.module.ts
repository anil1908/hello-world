import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BrowserXhr, XHRBackend, RequestOptions, HttpModule, JsonpModule, BaseRequestOptions } from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import 'rxjs/Rx';

import { AppComponent } from './app.component';
import { routing } from './common/app.routes';
import { AuthGuard } from './common/auth.guard';
import { UnauthGuard } from './common/auth.guard';
import { HttpClientService } from './common/http-client.service';
import { ValidationService } from './common/validation.service';
import { CommonService } from './common/common.service';
import { ChatService }       from './home/home.service';


import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    JsonpModule,
    routing,
  ],
  providers: [
    AuthGuard,
    UnauthGuard,
    MockBackend,
    BaseRequestOptions,
    HttpClientService,
    CommonService,
    ValidationService,
    FormBuilder,
    ChatService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
