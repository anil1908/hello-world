import { Injectable } from '@angular/core';
import { HttpModule, URLSearchParams, ConnectionBackend, RequestOptionsArgs, Headers, RequestOptions, Http, Request, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/add/operator/map';

@Injectable()

export class HttpClientService {
  apiUrl: string = 'http://localhost:4300/';
  domainUrl: string = 'http://localhost:4200/';

  headers: Object = this.publicheader();
  loader: Array<any> = [];
  errormessage: string;
  constructor(
    private http: Http,
    private router: Router,
  ) {

  }
  /**
    *  Request
    */
  request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> {
    this.loader.push(true);
    return this.http.request(
      this.apiUrl + url,
      this.headers
    )
      .map(this.extractData)
      .catch(this.handleError)
      .finally(() => { this.finalResponse(); });
  }
  /**
   * Get Request
   */
  get(url: string, options?: RequestOptionsArgs): Observable<Response> {
    this.loader.push(true);
    return this.http.get(
      this.apiUrl + url,
      this.headers
    )
      .map(this.extractData)
      .catch(this.handleError)
      .finally(() => { this.finalResponse(); });
    ;
  }
  /**
   * Post Request
   */
  post(url: string, data, options?: RequestOptionsArgs, withCredentials?): Observable<Response> {
    this.loader.push(true);
    return this.http.post(
      this.apiUrl + url,
      data,
      this.publicheader(withCredentials)
    )
      .map(this.extractData)
      .catch(this.handleError)
      .finally(() => { this.finalResponse(); });
  }
  /**
   * delete Request
   */
  delete(url: string, options?: RequestOptionsArgs): Observable<Response> {
    this.loader.push(true);
    return this.http.delete(
      this.apiUrl + url,
      this.headers
    )
      .map(this.extractData)
      .catch(this.handleError)
      .finally(() => { this.finalResponse(); });
  }
  /**
     * Success Handler
     */
  private extractData(res: Response) {
    let body = (res['_body'] !== '' && res['_body'] !== undefined && res['_body'] !== null) ? res.json() : {};
    return body || {};
  }
  /**
   * Error Handler
   */
  private handleError(error: Response | any) {
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.message || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
      this.errormessage = errMsg;
    } else {
      errMsg = error.message ? error.message : error.toString();
      this.errormessage = errMsg;
    }
    return Observable.throw(errMsg);
  }
  /**
   * Final Response
   */
  finalResponse() {
    this.loader.pop();
  }
  /**
   * Set Logout user Http Header
   */
  publicheader(withCredentials = true) {
    let headers = new Headers({
    });
    return new RequestOptions({ headers: headers });
  }

}