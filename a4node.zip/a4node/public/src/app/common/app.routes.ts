import { NgModule } from '@angular/core';
import { Routes, RouterModule, ROUTER_CONFIGURATION } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { AuthGuard } from './auth.guard';
import { UnauthGuard } from './auth.guard';
import { LoginComponent } from '../login/login.component';
// Route Configuration
const appRoutes: Routes = [
    {
        path: 'home',
        component: HomeComponent,
        canActivate: [AuthGuard],
        data: {
            title: 'Home'
        }
    },
    {
        path: '',
        component: LoginComponent,
        canActivate: [UnauthGuard],
        data: {
            title: 'Login'
        }
    },
    { path: '**', redirectTo: '' }
]
export const routing = RouterModule.forRoot(appRoutes);
