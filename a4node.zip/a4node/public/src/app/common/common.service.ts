import { Injectable, Inject } from '@angular/core';
import { HttpModule, Headers, Http, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { Observer } from 'rxjs/Observer';
import { HttpClientService } from './http-client.service';
import { AbstractControl, AsyncValidatorFn } from '@angular/forms';


@Injectable()
export class CommonService {
  dateConfig: any = {
    dateFormat: 'dd/mm/yyyy',
    showClearDateBtn: false,
    editableDateField: false,
    openSelectorOnInputClick: true,
    minYear: 1950,
    showTodayBtn: false,
    disableSince: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() + 1
    }
  };
  constructor(
    private httpclient: HttpClientService,) {

  }
  /**
   * Stringify Object (object to string)
   */
  stringifyObject(data) {
    return (typeof data == "object") ? JSON.stringify(data) : data;
  }
  /**
   * string to object
   */
  json(str) {
    return JSON.parse(str);
  }
}
