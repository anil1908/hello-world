import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClientService } from '../common/http-client.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  model: any = {};
  loading: boolean = false;
  error: string = '';

  constructor(
    private router: Router,
    private httpclient: HttpClientService,
  ) {

  }

  ngOnInit() {
    // reset login status
  }

  login() {
    this.loading = true;
    this.httpclient.post('user/login',{ username: this.model.username, password: this.model.password })
      .subscribe(
      data => {
        if(data['status']==200){
          debugger;
          localStorage.setItem('token',data['data']['token']);
          localStorage.setItem('username',data['data']['username']);
          this.router.navigate(['/home']);
        }
      },
      error => {
        console.log(error);
      });
  }

}
