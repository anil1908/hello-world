var express = require('express');
var router = express();
var userService = require('services/user.service');
var mysql = require('mysql');
var con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database: 'mean1'
});
router.post('/login', signinUser);
module.exports = router;

function signinUser(req, res) {
    var input = JSON.parse(JSON.stringify(req.body));
    var data = {
        username: input.username,
        password: input.password
    };
    userService.signin(data)
        .then(function(user) {
            if (user) {
                res.send({ status: 200, data: user })
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function(err) {
            res.status(400).send(err);
        })
}