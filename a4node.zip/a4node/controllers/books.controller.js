var express = require('express');
var router = express();
var bookService = require('services/book.service');
var mysql = require('mysql');
var con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database: 'mean1'
});
router.get('/', getBookslist);
module.exports = router;

function getBookslist(req, res) {
    bookService.getBooks()
        .then(function(book) {
            if (book) {
                res.send({ status: 200, data: book })
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function(err) {
            res.status(400).send(err);
        });
}