var express = require('express');
var router = express();
var customerService = require('services/customer.service');

var mysql = require('mysql');
var con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database: 'mean1'
});

router.get('/', getCustomerslist);
router.post('/add', addCustomers);
router.get('/edit/:id', getCustomerDetail);
router.post('/edit/:id', updateCustomers);
router.get('/delete/:id', deleteCustomers);

module.exports = router;

function getCustomerslist(req, res) {
    customerService.getCustomers()
        .then(function(user) {
            if (user) {
                res.send({ status: 200, data: user })
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function(err) {
            res.status(400).send(err);
        });
}

function addCustomers(req, res) {
    var input = JSON.parse(JSON.stringify(req.body));
    var data = {
        name: input.name,
        billno: input.billno,
        email: input.email,
        phone: input.phone,
        books: input.books
    };
    customerService.addCustomers(data)
        .then(function(user) {
            if (user) {
                res.send({ status: 200 })
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function(err) {
            res.status(400).send(err);
        });
}

function getCustomerDetail(req, res) {
    var id = req.params.id;
    customerService.getCustomerDetail(id)
        .then(function(user) {
            if (user) {
                res.send({ status: 200, data: user })
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function(err) {
            res.status(400).send(err);
        });
}

function updateCustomers(req, res) {
    var input = JSON.parse(JSON.stringify(req.body));
    var id = req.params.id;
    var data = {
        name: input.name,
        billno: input.billno,
        email: input.email,
        phone: input.phone,
        books: input.books
    };
    customerService.editCustomers(id, data)
        .then(function(user) {
            if (user) {
                res.send({ status: 200 })
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function(err) {
            res.status(400).send(err);
        });
}

function deleteCustomers(req, res) {

    var id = req.params.id;
    customerService.deleteCustomer(id)
        .then(function(user) {
            if (user) {
                res.send({ status: 200, data: user })
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function(err) {
            res.status(400).send(err);
        });

}