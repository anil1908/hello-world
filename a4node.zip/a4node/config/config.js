module.exports = {
    server: {
        host: 'localhost',
        port: 4300
    },
    database: {
        host: 'localhost',
        user: 'root',
        password: '',
        port: 3306,
        database: 'mean1'
    },
    key: {
        privateKey: '37LvDSm4XvjYOh9Y',
        tokenExpiry: 1 * 30 * 1000 * 60 //1 hour
    },
    email: {
        username: "*****@gmail.com",
        password: "******",
        accountName: "gmail",
        verifyEmailUrl: "verifyEmail"
    }
};