require('rootpath')();
var express = require('express');
var app = express();
var http = require('http');
var path = require('path');
var connection = require('express-myconnection');
var mysql = require('mysql');
var session = require('express-session');
var bodyParse = require('body-parser');
var expressJwt = require('express-jwt');
app.set('port', process.env.PORT || 4300);
app.use(express.logger('dev'));
app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(express.static(path.join(__dirname, 'public')));
// development only
if ('development' == app.get('env')) {
    app.use(express.errorHandler());
}
/*------------------------------------------
    connection peer, register as middleware
    type koneksi : single,pool and request
-------------------------------------------*/
app.use(
    connection(mysql, {
        host: 'localhost',
        user: 'root',
        password: '',
        port: 3306, //port mysql
        database: 'mean1'
    }, 'pool') //or single
);

app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', 'http://localhost:4200');

    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

    // Pass to next layer of middleware
    next();
});

app.use('/customers', require('controllers/customer.controller'));
app.use('/books', require('controllers/books.controller'));
app.use('/user', require('controllers/user.controller'));

app.use(app.router);

var server = http.createServer(app);
var io = require('socket.io').listen(server);

server.listen(app.get('port'));


io.on('connection', (socket) => {
    console.log('user connected');
    socket.on('disconnect', function() {
        console.log('user disconnected');
    });
    socket.on('add-message', (message) => {
        io.emit('message', { type: 'new-message', text: message });
    });
});