var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var mysql = require('mysql');
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database: 'mean1'
});
var service = {};

service.getCustomers = getCustomers;
service.addCustomers = addCustomers;
service.getCustomerDetail = getCustomerDetail;
service.editCustomers = editCustomers;
service.deleteCustomer = deleteCustomer;

module.exports = service;

function getCustomers() {
    var deferred = Q.defer();
    var query = connection.query('SELECT * FROM customer', function(err, rows) {
        if (err)
            deferred.reject(err);
        deferred.resolve(rows);
    });
    return deferred.promise;
}

function addCustomers(data) {
    var books = data.books;
    delete data['books'];
    var deferred = Q.defer();
    var query = connection.query("INSERT INTO customer set ? ", data, function(err, rows) {
        var insertId = rows.insertId;
        if (err)
            deferred.reject(err);
        if (books.length > 0) {
            for (var i = 0; i < books.length; i++) {
                var data = {
                    cid: insertId,
                    bookid: books[i].id,
                    quantity: books[i].quantity,
                    price: books[i].price,
                    total_price: books[i].total_price,
                };
                var query = connection.query("INSERT INTO customer_book_detail set ? ", data, function(err, rows) {
                    if (err)
                        deferred.reject(err);
                });
            }
        }
        deferred.resolve({ status: 200 });
    });
    return deferred.promise;
}

function getCustomerDetail(id) {
    var deferred = Q.defer();
    var query = connection.query('select c.id as `cid`,c.name as `name`,c.billno as `billno`,c.email as `email`,c.phone as `phone`,GROUP_CONCAT(cbd.bookid) as `id`,GROUP_CONCAT(cbd.quantity) as `quantity`,GROUP_CONCAT(cbd.price) as `price`,GROUP_CONCAT(cbd.total_price) as `total_price` from customer as c,customer_book_detail as cbd where c.id=cbd .cid AND c.id = ? group by c.id', [id], function(err, rows) {
        if (err)
            deferred.reject(err);
        var customerArr = {
            cid: rows[0]['cid'],
            name: rows[0]['name'],
            billno: rows[0]['billno'],
            email: rows[0]['email'],
            phone: rows[0]['phone'],
            books: []
        }
        var bookidarr = rows[0]['id'].split(',');
        var bookquantityarr = rows[0]['quantity'].split(',');
        var bookpricearr = rows[0]['price'].split(',');
        var booktotalpricearr = rows[0]['total_price'].split(',');
        for (var i in bookidarr) {
            var obj = {
                id: bookidarr[i],
                quantity: bookquantityarr[i],
                price: bookpricearr[i],
                total_price: booktotalpricearr[i],
            }
            customerArr.books.push(obj);
        }
        deferred.resolve(customerArr);
    });
    return deferred.promise;
}

function editCustomers(id, data) {
    var books = data.books;
    delete data['books'];
    var deferred = Q.defer();
    connection.query("UPDATE customer set ? WHERE id = ? ", [data, id], function(err, rows) {
        if (err)
            deferred.reject(err);
        connection.query("DELETE FROM customer_book_detail  WHERE cid = ? ", [id], function(err, rows) {
            if (err)
                deferred.reject(err);
            for (var i = 0; i < books.length; i++) {
                var data = {
                    cid: id,
                    bookid: books[i].id,
                    quantity: books[i].quantity,
                    price: books[i].price,
                    total_price: books[i].total_price,
                };
                var query = connection.query("INSERT INTO customer_book_detail set ? ", data, function(err, rows) {
                    if (err)
                        deferred.reject(err);
                });
            }
        });
        deferred.resolve({ status: 200 });
    });
    return deferred.promise;
}

function deleteCustomer(id) {
    var deferred = Q.defer();
    connection.query("DELETE FROM customer  WHERE id = ? ", [id], function(err, rows) {
        if (err)
            deferred.reject(err);
        deferred.resolve({ status: 200 });
    });
    return deferred.promise;
}