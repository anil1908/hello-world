var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var mysql = require('mysql');
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database: 'mean1'
});
var service = {};

service.getBooks = getBooks;

module.exports = service;

function getBooks() {
    var deferred = Q.defer();
    var query = connection.query('SELECT * FROM book', function(err, rows) {
        if (err)
            deferred.reject(err);
        deferred.resolve(rows);
    });
    return deferred.promise;
}