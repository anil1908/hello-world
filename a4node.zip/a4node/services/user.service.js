var _ = require('lodash');
const Jwt = require('jsonwebtoken');
const Config = require('../config/config')
const privateKey = Config.key.privateKey
var bcrypt = require('bcryptjs');
var Q = require('q');
var mysql = require('mysql');
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    port: 3306,
    database: 'mean1'
});
var service = {};

service.signin = signin;

module.exports = service;

function signin(data) {
    var deferred = Q.defer();
    var query = connection.query('SELECT * FROM register where username="' + data.username + '" AND password="' + data.password + '" ', function(err, rows) {
        if (err)
            deferred.reject(err);
        var tokenData = {
            username: data.username,
            id: rows.id
        };
        var result = {
            username: data.username,
            token: Jwt.sign(tokenData, privateKey)
        };
        deferred.resolve(result);
    });
    return deferred.promise;
}