/*
* @description
*  App Confirmation Modal*/
angular.module('OneWorld').controller('deleteConfirmationCtrl', ['$scope', '$uibModalInstance', 'deleteData',
    function ($scope, $uibModalInstance, deleteData) {
        $scope.deleteData = deleteData;
        $scope.DeleteConfirm = function () {
            $uibModalInstance.close();
        }
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);
