/**
 * @description
 * # request responce intercepter
 */
'use strict';
App.factory('authInterceptorService', ['$q', '$rootScope', '$location', '$sessionStorage', 'localStorageService',
    function ($q, $rootScope, $location, $sessionStorage, localStorageService) {
        var authInterceptorServiceFactory = {};
        var _request = function (config) {
            config.headers = config.headers || {};
            var authData = cookies.get('adminauthorizationData');
            if(config.data!==undefined && config.data.dataLoader!==undefined && config.data.dataLoader){
                var div = document.createElement('div');
                div.className = 'dataloading-block';
                div.innerHTML = '<div class="dataloading"><img align="" ng-src="../assets/images/loading-spinner-grey.gif"> <span> LOADING...</span></div>';
                document.getElementsByClassName('scrollerx')[0].appendChild(div);
            }
            else{
                $rootScope.loadingBlock = true;
            }
            return config;
        };

        var _response = function (config) {
            $rootScope.loadingBlock = false;
            if(document.getElementsByClassName('dataloading-block')[0]!==undefined){
                document.getElementsByClassName('dataloading-block')[0].outerHTML = '';
            }
            if (config.data.error === 2) {
                $rootScope.logo = 'home-logo.png';
                cookies.del('adminauthorizationData');
                localStorageService.remove('adminauthorizeTokenDetail');
                $location.path('/');
            }
            return config;
        };

        var _responseError = function (rejection) {
            if (rejection.status === 401) {
                // $location.path('/');
            }
            return $q.reject(rejection);
        };
        authInterceptorServiceFactory.request = _request;
        authInterceptorServiceFactory.responseError = _responseError;
        authInterceptorServiceFactory.response = _response;
        return authInterceptorServiceFactory;
    }
]);