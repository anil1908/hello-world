angular.module('OneWorld').controller('adminhomeController', ['$scope', '$rootScope', '$sessionStorage', '$translate', 'authService', '$location', 'localStorageService','USERTYPE',
    function ($scope, $rootScope, $sessionStorage, $translate, authService, $location, localStorageService,USERTYPE) {
        /*
        * @description
        Login And Signup Menu display*/
        var authTokenData = localStorageService.get('adminauthorizeTokenDetail');
        var adminData = cookies.get('adminauthorizationData');
        $scope.currentYear = new Date().getFullYear();
        $scope.usertypeObj = USERTYPE;
        $rootScope.usertypeval = (authTokenData!==null && authTokenData!==undefined && authTokenData!=='')?authTokenData.usertype:'';
        $scope.activate_message = ($rootScope.activate_message) ? $rootScope.activate_message : false;
        $scope.navCollapsed = true;
        $rootScope.adminData = adminData;

        $scope.goHome = function () {
            $location.path('/');
        }
        /*
         * @description
         * Logout
         * */
        $scope.logOut = function () {
            authService.logOut()
                .then(function (data) {
                    if (data.error <= 0) {
                        $rootScope.message = '';
                        $location.search({});
                        $location.path('/');
                    } else {
                        $scope.isError = true;
                        $scope.message = data.errorMsg;
                    }
                },
                function (err, status) {
                });
        };
        /*End Login And Signup Menu display*/

        $scope.changeLeftSlidebar = function() {
            $scope.navCollapsed = !$scope.navCollapsed;
        };

    }
]);