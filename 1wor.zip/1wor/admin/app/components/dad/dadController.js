angular.module('OneWorld').controller('dadController', ['$scope', '$rootScope', '$uibModal', '$sessionStorage', '$translate', '$location', 'localStorageService','dadService','$filter','USERTYPE',
    function ($scope, $rootScope,$uibModal, $sessionStorage, $translate, $location, localStorageService,dadService,$filter,USERTYPE) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        var adminData = cookies.get('adminauthorizationData');
        $rootScope.adminData = adminData;
        $scope.goHome = function () {
            $location.path('/');
        };
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'name',
            sorttype: 'ASC',
            maxsize: 10
        };
        $scope.publisherList = [];
        $scope.dadpublisherList = [];
        $scope.publisherDetail = [];
        $scope.dadPublisherListData = {
            publisherArr :[],
            allchecked   : false
        };
        $scope.dadDetail = {
            publishername : ''
        };
        $scope.isSubmitted = false;
        /*
         * @description
         * Grid Option
         * */
        $scope.checkAll = function () {
            if ($scope.dadPublisherListData.allchecked) {
                _.each($scope.dadpublisherList, function (element) {
                    var isavl = true;
                    _.each($scope.dadPublisherListData.publisherArr, function (obj) {
                        if (obj.id === element.id) {
                            isavl = false;
                        }
                    });
                    if (isavl) {
                        $scope.dadPublisherListData.publisherArr.push(element);
                    }
                });
            } else {
                var arr = [];
                angular.forEach($scope.dadPublisherListData.publisherArr, function (element) {
                    if ($scope.pageIds!==undefined && $scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.dadPublisherListData.publisherArr = arr;
            }
        };

        $scope.uncheckMain = function () {
            $scope.dadPublisherListData.allchecked = false;
        };

        $scope.$watch('currentPage', function (pageNo) {
            var publisherData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getdadpublisherList(publisherData);
            //or any other code here
        });

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var publisherData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getdadpublisherList(publisherData);
            var pagesizeelm = angular.element( document.querySelectorAll( '#pagesize' ) );
            angular.forEach(pagesizeelm,function(val,key){
                pagesizeelm[key].blur();
            });
        };

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var publisherData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype
            };
           $scope.getdadpublisherList(publisherData);
        };

        $scope.globalSearch = function(){
            var publisherData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getdadpublisherList(publisherData);
        };

        $scope.getpublisher = function(){
            var publisherData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getdadpublisherList(publisherData);
        };
        /*
         * @description
         * End Grid Option
         * */
        /**
         * DAD Publisher List
         */
        $scope.getdadpublisherList = function (publisherData) {
            dadService.getdadPublisherList(publisherData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.dadpublisherList = data.response;
                            $scope.gridOption.filteredItems = data.total_rows;
                            $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                            if ($scope.gridOption.maxsize > 5) {
                                $scope.gridOption.maxsize = 5;
                            }
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        /**
         * Publisher List
         */
        $scope.getPublisherList = function(){
            dadService.getPublisherList({admin_access_token: TokenData.admin_access_token,language: $rootScope.language})
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.publisherDetail = data.response;
                            $scope.publisherList = _.pluck(data.response, 'publisher_name');
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        /**
         * Delete Selected Publisher
         */
        $scope.deleteSelectedPublisher = function () {
            if ($scope.dadPublisherListData.publisherArr.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/dad/publisherDelete.html',
                    controller: 'publisherDeleteCtrl',
                    resolve: {
                        publisherData: function () {
                            return {publisherArr: $scope.dadPublisherListData.publisherArr};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.deletePublisherArr(dataObj.publisherArr);
                }, function () {
                    console.log('error');
                });
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL')};
                        }
                    }
                });
                modalInstance.result.then(function () {

                }, function () {
                    console.log('error');
                });
            }
        };
        $scope.deletePublisherRow = function (bookObj) {
            var arr = [];
            arr.push({id: bookObj.id});
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function () {
                        return {ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('CATALOG_REMOVE_CONFIRMATION_LABEL')};
                    }
                }
            });
            modalInstance.result.then(function () {
                $scope.deletePublisherArr(arr);
            }, function () {
                console.log('error');
            });

        };
        $scope.deletePublisherArr = function (dataObj) {
            var publisherIdArr = [];
            angular.forEach(dataObj, function (value, key) {
                this.push(value.id);
            },publisherIdArr);
            var publisherData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                publisherArr: publisherIdArr
            };
            dadService.deleteDADPublisher(publisherData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.getpublisher();
                            $scope.getPublisherList();
                            $scope.updatePublisherList();
                            $scope.dadPublisherListData = {
                                publisherArr :[],
                                allchecked   : false
                            };
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    })
                    .catch(function(err){
                        $scope.updatePublisherList();
                    });
        };
        /*
         * @description
         * End Delete Selected Publisher*/
        /**
         * Add DAD Publisher
         */
        $scope.addDadPublisher = function(){
            if($scope.adddadpublisher.$valid){
                if($scope.publisherList.indexOf($scope.dadDetail.publishername)>=0){
                    $scope.isError = false;
                    $scope.isMessage = false;
                    $scope.message ='';
                    var publisher = _.where($scope.publisherDetail,{publisher_name:$scope.dadDetail.publishername});
                     var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/components/dad/dadDetail.html',
                        controller: 'dadDetailCtrl',
                        resolve: {
                            publisherData: function () {
                                return {
                                    publisher_id : publisher[0].id
                                };
                            }
                        }
                    });
                    modalInstance.result.then(function (dataObj) {
                        $scope.isSubmitted = false;
                        $scope.dadDetail = {
                            publishername : ''
                        };
                        $scope.isError = false;
                        $scope.isMessage = true;
                        $scope.message = dataObj.msg;

                        var publisherData = {
                            admin_access_token: TokenData.admin_access_token,
                            language: $rootScope.language,
                            pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                            pageLimit: $scope.gridOption.pageLimit,
                            sortField: $scope.gridOption.sortField,
                            sorttype: $scope.gridOption.sorttype
                        };
                        $scope.getdadpublisherList(publisherData);
                        $scope.getpublisher();
                        $scope.getPublisherList();
                        $scope.updatePublisherList();

                    }, function () {
                        $scope.isSubmitted = false;
                        $scope.dadDetail = {
                            publishername : ''
                        };
                    });
                }
                else{
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = $filter('translate')('ENTER_VALID_PUBLISHER');
                }
            }
            else{
                $scope.isSubmitted = true;
            }
        };
        /**
         * edit publisher row
         */
        $scope.editPublisherRow = function(id){
            if(id!==undefined && id!==null && id!==''){
                $scope.isError = false;
                $scope.isMessage = false;
                $scope.message ='';
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/dad/dadDetail.html',
                    controller: 'dadDetailCtrl',
                    resolve: {
                        publisherData: function () {
                            return {
                                dp_id : id
                            };
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.dadDetail = {
                        publishername : ''
                    };
                    $scope.getPublisherList();
                    $scope.getpublisher();
                    $scope.isError = false;
                    $scope.isMessage = true;
                    $scope.message = dataObj.msg;
                }, function () {
                    $scope.dadDetail = {
                                        publishername : ''
                                    };
                });
            }
        };
        /**
         * update publisher list
         */
        $scope.updatePublisherList = function(){
            var autocom = new autoComplete({
                selector: '#publishername',
                source: function(term, suggest){
                    term = term.toLowerCase();
                    var choices = $scope.publisherList;
                    var suggestions = [];
                    for (i=0;i<choices.length;i++)
                        if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                    suggest(suggestions);
                },
                onSelect: function(e, term, item){
                    // old and new value check
                    if ($scope.dadDetail.publishername && $scope.dadDetail.publishername !== term) {
                        $scope.$apply(function () {
                            $scope.dadDetail.publishername = term;
                        });
                    }
                }
            });
        };

        $scope.getPublisherList();
    }
]);
/**
 * publisher delete controller
 */
angular.module('OneWorld').controller('publisherDeleteCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'publisherData', 'localStorageService','$filter',
    function ($scope, $rootScope, $uibModalInstance, publisherData, localStorageService,$filter) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.ModalTitle = $filter('translate')('CONFIRMATION_LABEL');
        $scope.bookDelete = function () {
            $uibModalInstance.close({publisherArr: publisherData.publisherArr});
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
}]);