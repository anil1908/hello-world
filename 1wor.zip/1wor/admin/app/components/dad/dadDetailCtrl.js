angular.module('OneWorld').controller('dadDetailCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'publisherData', 'localStorageService','dadService','$filter',
    function ($scope, $rootScope, $uibModalInstance, publisherData, localStorageService,dadService,$filter) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.ModalTitle = $filter('translate')('DAD_DETAILS');
        $scope.form = {};
        $scope.isSubmitted = false;
        $scope.currencyList = [];
        $scope.dadAdminUserList = [];
        /**
         * get Company info
         */
        $scope.getCompanyInfo = function() {
            var companyData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                publisher_id : $scope.dadDetail.publisher_id
            };
            dadService.getCompanyData(companyData)
                    .then(function (data) {
                        if(data.error<=0){
                            $scope.dadDetail.company_name = data.response.name;
                            $scope.dadDetail.company_address = data.response.address;
                        }
                        else{
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    },
                    function (err, status) {
                    })
                    .catch(function(error){

                    });
        };
        if(publisherData.dp_id!==undefined && publisherData.dp_id!==null && publisherData.dp_id!==''){
            var data = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                dp_id : publisherData.dp_id
            };
            dadService.getDADPublisherDetail(data)
                    .then(function (data) {
                        if(data.error<=0){
                            $scope.dadDetail = {
                                publisher_id: data.response.publisher_id,
                                dad_admin_user_id: data.response.dad_admin,
                                contact_name: data.response.contact_name_dad_service,
                                email : data.response.billing_email,
                                phone : data.response.contact_phone,
                                currency_id: data.response.currency_id,
                                full_distribution_price: parseFloat(data.response.full_distribution_price),
                                metadata_file_transmitted_price : parseFloat(data.response.metadata_file_transmitted_price),
                                content_transmitted_price : parseFloat(data.response.content_transmitted_price),
                                setup_fee: parseFloat(data.response.setup_fee),
                                dp_id : publisherData.dp_id,
                                company_name: '',
                                company_address: ''
                            }
                            $scope.getCompanyInfo();
                        }
                        else{
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    },
                    function (err, status) {
                    })
                    .catch(function(error){

                    });
        }
        else{
            $scope.dadDetail = {
                publisher_id: publisherData.publisher_id,
                dad_admin_user_id : '',
                contact_name: '',
                email : '',
                phone : '',
                currency_id: '',
                full_distribution_price: '',
                metadata_file_transmitted_price : '',
                content_transmitted_price : '',
                setup_fee: '',
                dp_id : '',
                company_name: '',
                company_address: ''
            };
            $scope.getCompanyInfo();
        }

        /**
         * @description
         * Update DAD Detail
         */
        $scope.updateDADDeatil = function(){
            if($scope.daddetail.$valid){
                var DADData = $scope.dadDetail;
                DADData.admin_access_token = TokenData.admin_access_token;
                DADData.language = $rootScope.language;
                dadService.updateDADDetail(DADData)
                        .then(function (data) {
                            if(data.error<=0){
                                $uibModalInstance.close({msg:data.msg});
                            }
                            else{
                                $scope.message = data.errorMsg;
                                $scope.isError = true;
                                $scope.isMessage = false;
                            }
                        },
                        function (err, status) {

                        })
                        .catch(function(error){

                        });
            }
            else{
                $scope.isSubmitted = true;
            }
        };
        /**
         * @description
         * Currency List
         */
        $scope.getCurrencyList = function () {
            var currencyData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language
            };
            dadService.getCurrencyList(currencyData)
                    .then(function (data) {
                        if(data.error<=0){
                            $scope.currencyList = data.response;
                        }
                        else{
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    },
                    function (err, status) {
                    })
                    .catch(function(error){

                    });
        };

        /**
         * @description
         * get DAD Admin User
        */
        $scope.getDadAdminUser = function() {
            var data = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language
            };
            dadService.getDadAdminUserList(data)
                    .then(function (data) {
                        if(data.error<=0){
                            $scope.dadAdminUserList = data.response;
                        }
                        else{
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    },
                    function (err, status) {
                    })
                    .catch(function(error){

                    });
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.getCurrencyList();
        $scope.getDadAdminUser();

}]);