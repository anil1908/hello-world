 /**
 * @description
 * # module rights check
 */
'use strict';
App.factory('dadService', ['$http', '$q', function ($http, $q) {
        var dadServiceFactory = {};
        /*
         * @description
         * get DAD Publisher
         * */
        var _getdadPublisherList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_dad_publishers',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
            /*
         * @description
         * get Publisher
         * */
        var _getPublisherList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_publishers',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
            /*
         * @description
         * add dad Publisher
         * */
        var _addPublisher = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/insert_dad_publisher',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
           /**
         * @description
         * # currency  list
         */
        var _getCurrencyList = function (currecyData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/general/get_currency',
                method: "GET",
                data: currecyData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
           /**
         * @description
         * # Add DAD Detail
         */
        var _addDADDetail = function (DADData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/insert_dad_publisher',
                method: "POST",
                data: DADData,
                cache: true,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
           /**
         * @description
         * # Company Daat
         */
        var _getCompanyData = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_company_info',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
           /**
         * @description
         * # get dad Details
         */
        var _getDADPublisherDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_dad_publisher_details',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
           /**
         * @description
         * # update dad Details
         */
        var _updateDADDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/update_dad_publisher',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
           /**
         * @description
         * # delete dad Details
         */
        var _deleteDADPublisher = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/delete_dad_publishers',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
           /**
         * @description
         * # Enable dad publisher Details
         */
        var _getdadPublisherDeliveryList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_dad_enabled_publisher',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
           /**
         * @description
         * # Enable dad publisher Details
         */
        var _getdaddeliveryList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_dad_deliveries',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
           /**
         * @description
         * # get dad delivery detail
         */
        var _getDeliveryDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_dad_delivery_details',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * @description
         * # group list
         */
        var _getGroupList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: { 'Content-Type': 'application/json' },
                url: '../api/admin/get_group',
                method: "POST",
                data: data
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (err, code) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };
        /**
         * @description
         * # group list
         */
        var _addDeliveryDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: { 'Content-Type': 'application/json' },
                url: '../api/admin/insert_dad_deliveries',
                method: "POST",
                data: data
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (err, code) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };
        /**
         * @description
         * # dad delivery update
         */
        var _updateDeliveryDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: { 'Content-Type': 'application/json' },
                url: '../api/admin/update_dad_deliveries',
                method: "POST",
                data: data
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (err, code) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };
        /**
         * @description
         * # dad delivery delete
         */
        var _deleteDeliveryDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: { 'Content-Type': 'application/json' },
                url: '../api/admin/delete_dad_deliveries',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * @description
         * # country-region list
         */
        var _getCountryRegionList = function (Data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/catalog/get_region_with_country',
                method: "POST",
                data: Data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _getBooksList = function(Data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/group/get_group_books_by_id',
                method: "POST",
                data: Data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * get DAd Admin user list
        */
        var _getDadAdminUserList = function(Data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_dad_user_list',
                method: "POST",
                data: Data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        dadServiceFactory.getdadPublisherList = _getdadPublisherList;
        dadServiceFactory.getPublisherList = _getPublisherList;
        dadServiceFactory.addPublisher = _addPublisher;
        dadServiceFactory.getCurrencyList = _getCurrencyList;
        dadServiceFactory.addDADDetail = _addDADDetail;
        dadServiceFactory.getCompanyData = _getCompanyData;
        dadServiceFactory.getDADPublisherDetail = _getDADPublisherDetail;
        dadServiceFactory.updateDADDetail = _updateDADDetail;
        dadServiceFactory.deleteDADPublisher = _deleteDADPublisher;
        dadServiceFactory.getdadPublisherDeliveryList = _getdadPublisherDeliveryList;
        dadServiceFactory.getdaddeliveryList = _getdaddeliveryList;
        dadServiceFactory.getDeliveryDetail = _getDeliveryDetail;
        dadServiceFactory.getGroupList = _getGroupList;
        dadServiceFactory.addDeliveryDetail = _addDeliveryDetail;
        dadServiceFactory.updateDeliveryDetail = _updateDeliveryDetail;
        dadServiceFactory.deleteDeliveryDetail = _deleteDeliveryDetail;
        dadServiceFactory.getCountryRegionList = _getCountryRegionList;
        dadServiceFactory.getBooksList = _getBooksList;
        dadServiceFactory.getDadAdminUserList = _getDadAdminUserList;
        return dadServiceFactory;
}]);