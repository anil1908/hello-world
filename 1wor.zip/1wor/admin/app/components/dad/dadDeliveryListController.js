angular.module('OneWorld').controller('dadDeliveryListController', ['$scope', '$rootScope', '$uibModal', '$sessionStorage', '$translate', '$location', 'localStorageService','dadService','$filter',
    function ($scope, $rootScope,$uibModal, $sessionStorage, $translate, $location, localStorageService,dadService,$filter) {
        var parameter = $location.search();
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        var adminData = cookies.get('adminauthorizationData');
        $scope.goHome = function () {
            $location.search({});
            $location.path('/dad');
        };
        if(parameter.id!==undefined && parameter.id!==null && parameter.id!==''){
             $scope.gridOption = {
                filteredItems: 0,
                pageSizeArr: [1, 5, 10, 20, 50, 100],
                currentPage: 1,
                pageLimit: 10,
                sortField: 'name',
                sorttype: 'ASC',
                publisherid : parameter.id,
                maxsize: 10
            };
            $scope.deliveryList = [];
            $scope.dadPublisherList = [];
            $scope.deliveryData = {
                deliveryArr :[],
                allchecked   : false
            };
            $scope.publisherid_error = false;
            $scope.isSubmitted = false;
            /*
            * @description
            * Grid Option
            * */
            $scope.checkAll = function () {
                if ($scope.deliveryData.allchecked) {
                    _.each($scope.deliveryList, function (element) {
                        var isavl = true;
                        _.each($scope.deliveryData.deliveryArr, function (obj) {
                            if (obj.id === element.id) {
                                isavl = false;
                            }
                        });
                        if (isavl) {
                            $scope.deliveryData.deliveryArr.push(element);
                        }
                    });
                } else {
                    var arr = [];
                    angular.forEach($scope.deliveryData.deliveryArr, function (element) {
                        if ($scope.pageIds!==undefined && $scope.pageIds.indexOf(element.id) < 0) {
                            arr.push(element);
                        }
                    });
                    $scope.deliveryData.deliveryArr = arr;
                }
            };

            $scope.uncheckMain = function () {
                $scope.deliveryData.allchecked = false;
            };

            $scope.changePageSize = function () {
                $scope.gridOption.currentPage = 1;
                var deliveryData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    publisherid : $scope.gridOption.publisherid,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype
                };
                $scope.getdaddeliveryList(deliveryData);
                var pagesizeelm = angular.element( document.querySelectorAll( '#pagesize' ) );
                angular.forEach(pagesizeelm,function(val,key){
                    pagesizeelm[key].blur();
                });
            };

            $scope.sort_by = function (sortField) {
                $scope.gridOption.sortField = sortField;
                $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
                var deliveryData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    publisherid : $scope.gridOption.publisherid,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: sortField,
                    sorttype: $scope.gridOption.sorttype
                };
                $scope.getdaddeliveryList(deliveryData);
            };

            $scope.globalSearch = function(){
                var deliveryData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    publisherid : $scope.gridOption.publisherid,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype
                };
                $scope.getdaddeliveryList(deliveryData);
            };

            $scope.changedaddeliveryList = function(){
                var deliveryData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    publisherid : $scope.gridOption.publisherid,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype
                };
                $scope.getdaddeliveryList(deliveryData);
            };

            $scope.$watch('currentPage', function (pageNo) {
                var deliveryData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    publisherid : $scope.gridOption.publisherid,
                    pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype
                };
                $scope.gridOption.currentPage = pageNo;
                $scope.getdaddeliveryList(deliveryData);
                //or any other code here
            });
            /*
            * @description
            * End Grid Option
            * */
            /**
             * DAD Publisher List
             */
            $scope.getdaddeliveryList = function (deliveryData) {
                $scope.publisherid_error = false;
                dadService.getdaddeliveryList(deliveryData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.deliveryList = data.response;
                                $scope.gridOption.filteredItems = data.total_rows;
                                $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                                if ($scope.gridOption.maxsize > 5) {
                                    $scope.gridOption.maxsize = 5;
                                }

                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {

                        })
                        .catch(function(error){

                        });
            };
            /**
             * DAD Enable Publisher List
            */
            $scope.getdadPublisherDeliveryList = function () {
                dadService.getdadPublisherDeliveryList({
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language})
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.dadPublisherList = data.response;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        })
                        .catch(function(error){

                        });
            };
            /**
             * Add DAD Delivery
             */
            $scope.addDADDelivery = function(){
                if($scope.gridOption.publisherid!==undefined && $scope.gridOption.publisherid!==null && $scope.gridOption.publisherid!==''){
                    $scope.publisherid_error = false;
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/components/dad/dadDeliveryDetails.html',
                        controller: 'dadDeliveryDetailsCtrl',
                        resolve: {
                            dadDeliveryData: function () {
                                return {
                                    id : '',
                                    dad_publisher_id:$scope.gridOption.publisherid
                                };
                            }
                        }
                    });
                    modalInstance.result.then(function (dataObj) {
                        var deliveryData = {
                            admin_access_token: TokenData.admin_access_token,
                            language: $rootScope.language,
                            publisherid : $scope.gridOption.publisherid,
                            pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                            pageLimit: $scope.gridOption.pageLimit,
                            sortField: $scope.gridOption.sortField,
                            sorttype: $scope.gridOption.sorttype
                        };
                        $scope.getdaddeliveryList(deliveryData);
                        $scope.isError = false;
                        $scope.isMessage = true;
                        $scope.message = dataObj.msg;
                    }, function () {

                    });
                }
                else{
                    $scope.publisherid_error = true;
                }
            };
            /**
             * Edit DAD Delivery
             */
            $scope.editDADDelivery = function(id){
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/dad/dadDeliveryDetails.html',
                    controller: 'dadDeliveryDetailsCtrl',
                    resolve: {
                        dadDeliveryData: function () {
                            return {
                                id : id,
                                dad_publisher_id:$scope.gridOption.publisherid
                            };
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    var deliveryData = {
                        admin_access_token: TokenData.admin_access_token,
                        language: $rootScope.language,
                        publisherid : $scope.gridOption.publisherid,
                        pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                        pageLimit: $scope.gridOption.pageLimit,
                        sortField: $scope.gridOption.sortField,
                        sorttype: $scope.gridOption.sorttype
                    };
                    $scope.getdaddeliveryList(deliveryData);
                    $scope.isError = false;
                    $scope.isMessage = true;
                    $scope.message = dataObj.msg;
                }, function () {

                });
            };
            /**
             * delete DAD Delivery
             */
            $scope.deleteDADDelivery = function(id){
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('CATALOG_REMOVE_CONFIRMATION_LABEL')};
                        }
                    }
                });
                modalInstance.result.then(function () {
                    $scope.deleteDADDeliveryRow(id);
                }, function () {
                    console.log('error');
                });
            };

            $scope.deleteDADDeliveryRow = function(id){
                var deliveryData = {
                    dpd_id : id,
                    admin_access_token : TokenData.admin_access_token,
                    language : $rootScope.language
                }
                dadService.deleteDeliveryDetail(deliveryData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                            var deliveryData = {
                                admin_access_token: TokenData.admin_access_token,
                                language: $rootScope.language,
                                publisherid : $scope.gridOption.publisherid,
                                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                                pageLimit: $scope.gridOption.pageLimit,
                                sortField: $scope.gridOption.sortField,
                                sorttype: $scope.gridOption.sorttype
                            };
                            $scope.getdaddeliveryList(deliveryData);
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    })
                    .catch(function(error){

                    });
            };
            /**
             * End delete DAD Delivery
             */
            $scope.getdadPublisherDeliveryList();

        }
    }
]);