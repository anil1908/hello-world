angular.module('OneWorld').controller('dadDeliveryDetailsCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'dadDeliveryData', 'localStorageService', '$filter', 'dadService', 'ivhTreeviewMgr', '$timeout','COUNTRY_PREFERENCE',
    function ($scope, $rootScope, $uibModalInstance, dadDeliveryData, localStorageService, $filter, dadService, ivhTreeviewMgr, $timeout,COUNTRY_PREFERENCE) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.ModalTitle = $filter('translate')('DAD_DELIVERY_DETAILS_LABEL');;
        $scope.form = {};
        $scope.isSubmitted = false;
        $scope.groupList = [];
        $scope.bookList = [];
        $scope.countryRegionArr = [];
        $scope.country_error = false;
        $scope.metadataFlavorList = [{'id':'ONIX 3.0','name':'ONIX 3.0'}];
        if (dadDeliveryData.id !== '' && dadDeliveryData.id !== null && dadDeliveryData.id !== undefined) {
            var deliveryData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                dpd_id: dadDeliveryData.id
            }
            dadService.getDeliveryDetail(deliveryData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.getCountryRegionArr();
                        $scope.deliveryDetail = data.response;
                        $scope.deliveryDetail.copy_metadata = ($scope.deliveryDetail.copy_metadata==1)?true:false;
                        $scope.deliveryDetail.metadata_folder_per_delivery = (data.response.metadata_folder_per_delivery==1)?true:false;
                        $scope.deliveryDetail.send_new_title = (data.response.send_new_title==1)?true:false;
                        $scope.deliveryDetail.content_folder_per_delivery = (data.response.content_folder_per_delivery==1)?true:false;
                        $scope.deliveryDetail.book_id = data.dad_books;
                        $scope.deliveryDetail.dad_countries = data.dad_countries;
                        $scope.getGroupList();
                        $scope.getGroupBooks();
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                })
                .catch(function (error) {

                });

        }
        else {
            $scope.deliveryDetail = {
                id: '',
                dad_publisher_id: dadDeliveryData.dad_publisher_id,
                delivery_name: '',
                metadata_flavour:'ONIX 3.0',
                title: 1,
                group_id: "",
                metadata_only_content: 0,
                send_new_title: true,
                copy_metadata: false,
                book_id :[],
                dad_countries: [],
                metadata_ip: "",
                metadata_username: "",
                metadata_password: "",
                metadata_subfolder: "",
                metadata_folder_per_delivery: "",
                metadata_protocol: "",
                content_ip: '',
                content_username: '',
                content_password: '',
                content_subfolder: '',
                content_folder_per_delivery: "",
                content_protocol: ''
            };
        }
        $scope.protocols = ['FTP', 'SFTP'];
        /**
        * @description
        * Country Region config
        */
        $scope.getCountryRegionArr = function () {
            var Data = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language
            };
            dadService.getCountryRegionList(Data)
                .then(function (data) {
                    $scope.setCountryRegion(data.response,function () {
                        ivhTreeviewMgr.collapseRecursive($scope.countryRegionArr, $scope.countryRegionArr);

                        ivhTreeviewMgr.deselectAll($scope.countryRegionArr);
                        if ($scope.deliveryDetail.dad_countries.length > 0) {
                            $scope.getDuplicateArr(function(){
                                ivhTreeviewMgr.selectEach($scope.countryRegionArr, $scope.deliveryDetail.dad_countries);
                            });
                        }
                        var isWorld = true;
                        angular.forEach($scope.countryRegionArr, function (rval, rkey) {
                            if (rkey!==0 && !rval.selected) {
                                isWorld = false;
                            }
                        });
                        if(isWorld){
                         ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                        }
                    });
                },
                function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                })
                .catch(function (data) {

                });
        };

        $scope.getDuplicateArr = function(call){
            angular.forEach(COUNTRY_PREFERENCE,function(couval,coukey){
                angular.forEach(couval,function(child_couval,child_coukey){
                    var index = $scope.deliveryDetail.dad_countries.indexOf(child_couval.main_id);
                    if(index>=0){
                        $scope.deliveryDetail.dad_countries.push(child_couval.id);
                    }
                });
            });
            call();
        }

        $scope.setCountryRegion = function(data,call) {
            angular.forEach(data, function (element) {
                if(COUNTRY_PREFERENCE[element.label]!==undefined && COUNTRY_PREFERENCE[element.label].length>0){
                    angular.forEach(COUNTRY_PREFERENCE[element.label],function(val,key) {
                        element.children.unshift(val)
                    });
                }
                $scope.countryRegionArr.push(element);
            });
            call();
        };

        $scope.countryMade = function (Node, IsSelected, Tree) {
            _.find($scope.countryRegionArr, function(objval){
                if(objval.children!==undefined && objval.children.length>0){
                    var dupArr = _.where(objval.children, {country_id: Node.country_id});
                    if(IsSelected){
                        angular.forEach(dupArr,function(dupval,dupkey){
                            ivhTreeviewMgr.select($scope.countryRegionArr,dupval);
                        });
                    }
                    else{
                        angular.forEach(dupArr,function(dupval,dupkey){
                            ivhTreeviewMgr.deselect($scope.countryRegionArr,dupval);
                        });
                    }
                }
            });

            if (Node.label === 'World' && Node.children === undefined && IsSelected) {
                $scope.country_error = false;
                ivhTreeviewMgr.selectAll($scope.countryRegionArr);
            }
            if (Node.label === 'World' && Node.children === undefined && !IsSelected) {
                ivhTreeviewMgr.deselectAll($scope.countryRegionArr);
            }
            if (Node.label !== 'World' && IsSelected) {
                $scope.country_error = false;
                ivhTreeviewMgr.deselect($scope.countryRegionArr, $scope.countryRegionArr[0]);
                $timeout(function () {
                    var isselectAll = true;
                    angular.forEach($scope.countryRegionArr, function (val, key) {
                        if (key !== 0 && !val.selected) {
                            isselectAll = false;
                        }
                    });
                    if (isselectAll) {
                        ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                    }
                }, 100);
            }
            if (Node.label !== 'World' && !IsSelected) {
                ivhTreeviewMgr.deselect($scope.countryRegionArr, $scope.countryRegionArr[0]);
            }
        };
        /**
        * @description
        * End Country Region config
        */

        /**
        * @description
        * Group List
        */
        $scope.getGroupList = function () {
            var groupData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                dpd_id: $scope.deliveryDetail.dad_publisher_id
            }
            dadService.getGroupList(groupData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.groupList = data.response;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                })
                .catch(function (error) {

                });
        };
        /**
         * Reset Group
         */
        $scope.resetGroup = function() {
            $scope.deliveryDetail.group_id = '';
            $scope.deliveryDetail.book_id = [];
            $scope.bookList = [];
        };
        /**
         * get Group Books
         */
        $scope.getGroupBooks = function () {
            if ($scope.deliveryDetail.group_id !== undefined && $scope.deliveryDetail.group_id !== null && $scope.deliveryDetail.group_id !== '') {
                var booksData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    group_id: $scope.deliveryDetail.group_id
                }
                dadService.getBooksList(booksData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.bookList = data.response;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    })
                    .catch(function (error) {

                    });
            }
        };
        /**
        * @description
        * Add Delivery Detail
        */
        $scope.addDeliveryDetail = function () {
            angular.forEach($scope.countryRegionArr, function (value, key) {
                if (value.children !== undefined && value.children.length > 0) {
                    angular.forEach(value.children, function (childvalue, childkey) {
                        if (childvalue.selected) {
                            var arr = childvalue.id.split('_');
                            $scope.deliveryDetail.dad_countries.push(arr[0]);
                        }
                    });
                }
            });
            $scope.deliveryDetail.dad_countries = $scope.deliveryDetail.dad_countries.filter(function(item, i, ar){ return ar.indexOf(item) === i; });

            if ($scope.adddaddelivery.$valid) {
                if ($scope.deliveryDetail.dad_countries.length > 0) {
                    $scope.country_error = false;
                    var deliveryData = $scope.deliveryDetail;
                    deliveryData.admin_access_token = TokenData.admin_access_token;
                    deliveryData.language = $rootScope.language;
                    dadService.addDeliveryDetail(deliveryData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $uibModalInstance.close({ msg: data.msg });
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        })
                        .catch(function (error) {

                        });
                }
                else {
                    $scope.country_error = true;
                }
            }
            else {
                if ($scope.deliveryDetail.dad_countries.length <= 0) {
                    $scope.country_error = true;
                }
                $scope.isSubmitted = true;
            }
        };
        /**
         * @description
         * Update Delivery Detail
         */
        $scope.updateDeliveryDetail = function () {
            if ($scope.adddaddelivery.$valid) {
                $scope.deliveryDetail.dad_countries = [];
                angular.forEach($scope.countryRegionArr, function (value, key) {
                    if (value.children !== undefined && value.children.length > 0) {
                        angular.forEach(value.children, function (childvalue, childkey) {
                            if (childvalue.selected) {
                                var arr = childvalue.id.split('_');
                                $scope.deliveryDetail.dad_countries.push(arr[0]);
                            }
                        });
                    }
                });
                $scope.deliveryDetail.dad_countries = $scope.deliveryDetail.dad_countries.filter(function(item, i, ar){ return ar.indexOf(item) === i; });

                if ($scope.deliveryDetail.dad_countries.length > 0) {
                    $scope.country_error = false;
                    var deliveryData = $scope.deliveryDetail;
                    deliveryData.admin_access_token = TokenData.admin_access_token;
                    deliveryData.language = $rootScope.language;
                    dadService.updateDeliveryDetail(deliveryData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $uibModalInstance.close({ msg: data.msg });
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        })
                        .catch(function (error) {

                        });
                }
                else {
                    $scope.country_error = true;
                }

            }
            else {
                if ($scope.deliveryDetail.dad_countries.length <= 0) {
                    $scope.country_error = true;
                }
                $scope.isSubmitted = true;
            }
        };
        /**
         * @description
         * Copy metadata to content
         */
        $scope.copyMetadata = function () {
            if ($scope.deliveryDetail.copy_metadata) {
                $scope.deliveryDetail.content_ip = $scope.deliveryDetail.metadata_ip;
                $scope.deliveryDetail.content_username = $scope.deliveryDetail.metadata_username;
                $scope.deliveryDetail.content_password = $scope.deliveryDetail.metadata_password;
                $scope.deliveryDetail.content_subfolder = $scope.deliveryDetail.metadata_subfolder;
                $scope.deliveryDetail.content_folder_per_delivery = $scope.deliveryDetail.metadata_folder_per_delivery;
                $scope.deliveryDetail.content_protocol = $scope.deliveryDetail.metadata_protocol;
            }
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        if (dadDeliveryData.id === '' || dadDeliveryData.id === null || dadDeliveryData.id === undefined) {
            $scope.getGroupList();
            $scope.getCountryRegionArr();
        }
    }]);
