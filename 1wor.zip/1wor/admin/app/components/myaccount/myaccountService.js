/**
 * @description
 * # module myaccount
 */
'use strict';
App.factory('myaccountService', ['$http', '$q', function ($http, $q) {
        var myaccountServiceFactory = {};
        /*
         * @description
         * get Account Details
         * */
        var _getAccountDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_admin_user_details_by_id',
                method: "POST",
                data: data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        /*
         * @description
         * edit Account Details
         * */
        var _editAccountDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/update_admin_user_profile',
                method: "POST",
                data: data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        myaccountServiceFactory.getAccountDetail = _getAccountDetail;
        myaccountServiceFactory.editAccountDetail = _editAccountDetail;
        return myaccountServiceFactory;
    }]);