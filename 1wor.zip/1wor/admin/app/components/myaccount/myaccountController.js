angular.module('OneWorld').controller('myaccountController', ['$scope', '$rootScope', '$sessionStorage', '$translate', 'myaccountService', '$location', 'localStorageService',
    function ($scope, $rootScope, $sessionStorage, $translate, myaccountService, $location, localStorageService) {
        /*
        * @description
        Login And Signup Menu display*/
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        var adminData = cookies.get('adminauthorizationData');
        $scope.accountData = {
            first_name : '',
            last_name : '',
            email : '',
            password : ''
        }
        $scope.isSubmitted = false;
        $scope.isError = false;
        $scope.isMessage = false;
        $scope.goHome = function () {
            $location.path('/');
        };
        /**
         * get account detail
         */
        $scope.getAccountDetail = function() {
            var data = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language
            };
            myaccountService.getAccountDetail(data)
                .then(function (data) {
                    if (data.error <= 0) {
                         $scope.accountData.first_name = data.response.first_name;
                         $scope.accountData.last_name = data.response.last_name;
                         $scope.accountData.email = data.response.email;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * edit account detail
        */
        $scope.editAccountDetail = function() {
            if($scope.myaccount.$valid){
                var data = $scope.accountData;
                data.admin_access_token = TokenData.admin_access_token;
                data.language = $rootScope.language;
                myaccountService.editAccountDetail(data)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            }else{
                $scope.isSubmitted = true;
            }
        };

        $scope.getAccountDetail();
    }
]);