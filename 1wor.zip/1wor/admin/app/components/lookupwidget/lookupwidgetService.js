 /**
 * @description
 * # module rights check
 */
'use strict';
App.factory('lookupwidgetService', ['$http', '$q', function ($http, $q) {
        var lookupwidgetServiceFactory = {};
        /*
         * @description
         * get curation
         * */
        var _getWidgetDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/my_widget/get_widget_details_by_custom_widget_id',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };/*
         * @description
         * get widget code
         * */
        var _getWidgetCodeDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/general/get_widget_code',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        lookupwidgetServiceFactory.getWidgetDetail = _getWidgetDetail;
        lookupwidgetServiceFactory.getWidgetCodeDetail = _getWidgetCodeDetail;
        return lookupwidgetServiceFactory;
}]);