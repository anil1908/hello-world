angular.module('OneWorld').controller('lookupwidgetController', ['$scope', '$rootScope', '$uibModal', '$sessionStorage','$location', 'localStorageService','lookupwidgetService',
    function ($scope, $rootScope,$uibModal, $sessionStorage, $location, localStorageService,lookupwidgetService) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.widgetCodeList = [];
        $scope.goHome = function () {
            $location.path('/');
        };
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            pageStart : 0,
            sortField: 'b.title',
            sorttype: 'ASC',
            widget_id : '',
            maxsize: 10
        };
        $scope.isSubmitted = false;
        $scope.widgetDetail = {};
        $scope.bookArr      = [];
        /*
         * @description
         * Grid Option
         * */
        $scope.$watch('currentPage', function (pageNo) {
            var widgetData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                custom_widget_id: $scope.gridOption.custom_widget_id
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getWidgetData(widgetData);
            //or any other code here
        });

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var widgetData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                custom_widget_id: $scope.gridOption.custom_widget_id
            };
            $scope.getWidgetData(widgetData);
            var pagesizeelm = angular.element( document.querySelectorAll( '#pagesize' ) );
            angular.forEach(pagesizeelm,function(val,key){
                pagesizeelm[key].blur();
            });
        };

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var widgetData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
                custom_widget_id: $scope.gridOption.custom_widget_id
            };
           $scope.getWidgetData(widgetData);
        };

        $scope.widgetSearchById = function(){
            var widgetData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                custom_widget_id: $scope.gridOption.custom_widget_id
            };
            $scope.getWidgetData(widgetData);
        };

        $scope.getWidgetData = function (widgetData) {
            if($scope.widgetSearch.$valid){
                if(widgetData.custom_widget_id!==undefined){
                    lookupwidgetService.getWidgetDetail(widgetData)
                            .then(function (data) {
                                if (data.error <= 0) {
                                    $scope.widgetDetail = data.response.widgets;
                                    $scope.bookArr = data.response.book;
                                    $scope.gridOption.filteredItems = data.total_rows;
                                    $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                                    if ($scope.gridOption.maxsize > 5) {
                                        $scope.gridOption.maxsize = 5;
                                    }

                                    $scope.isError = false;
                                    $scope.isMessage = false;
                                    $scope.message = data.msg;
                                } else {
                                    $scope.gridOption = {
                                        filteredItems: 0,
                                        pageSizeArr: [1, 5, 10, 20, 50, 100],
                                        currentPage: 1,
                                        pageLimit: 10,
                                        pageStart : 0,
                                        sortField: 'b.title',
                                        sorttype: 'ASC',
                                        maxsize: 10,
                                        custom_widget_id: $scope.gridOption.custom_widget_id
                                    };
                                    $scope.isSubmitted = false;
                                    $scope.widgetDetail = {};
                                    $scope.bookArr = [];
                                    $scope.isError = true;
                                    $scope.isMessage = false;
                                    $scope.message = data.errorMsg;
                                }
                            }, function (err, status) {
                                $scope.gridOption = {
                                    filteredItems: 0,
                                    pageSizeArr: [1, 5, 10, 20, 50, 100],
                                    currentPage: 1,
                                    pageLimit: 10,
                                    pageStart : 0,
                                    sortField: 'b.title',
                                    sorttype: 'ASC',
                                    maxsize: 10,
                                    custom_widget_id: $scope.gridOption.custom_widget_id
                                };
                                $scope.isSubmitted = false;
                                $scope.widgetDetail = {};
                                $scope.bookArr = [];
                                $scope.isError = true;
                                $scope.isMessage = false;
                            });
                }
            }else{
                $scope.isSubmitted = true;
            }
        };

        $scope.resetData = function() {
            $scope.gridOption = {
                filteredItems: 0,
                pageSizeArr: [1, 5, 10, 20, 50, 100],
                currentPage: 1,
                pageLimit: 10,
                pageStart : 0,
                sortField: 'b.title',
                sorttype: 'ASC',
                widget_id : '',
                maxsize: 10
            };
            $scope.isSubmitted = false;
            $scope.widgetDetail = {};
            $scope.bookArr = [];
            $scope.isError = false;
            $scope.isMessage = false;
            $scope.message = '';
        };

        /*
         * @description
         * End Grid Option
         */

        /**
         * get Widget Code List
         */
        $scope.getWidgetCodeList = function() {
            var widgetData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language
            };
            lookupwidgetService.getWidgetCodeDetail(widgetData)
                            .then(function (data) {
                                if (data.error <= 0) {
                                    $scope.widgetCodeList = _.pluck(data.response, 'custom_widget_id');
                                } else {
                                    $scope.isError = true;
                                    $scope.isMessage = false;
                                    $scope.message = data.errorMsg;
                                }
                            }, function (err, status) {
                                $scope.isError = true;
                                $scope.isMessage = false;
                            });
        };

        $scope.getWidgetCodeList();
    }
]);