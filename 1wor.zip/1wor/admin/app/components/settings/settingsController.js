angular.module('OneWorld').controller('settingsController', ['$scope', '$rootScope', '$uibModal', '$sessionStorage', '$location', 'localStorageService', 'settingsService', '$filter', '$window','$timeout',
    function ($scope, $rootScope, $uibModal, $sessionStorage, $location, localStorageService, settingsService, $filter, $window,$timeout) {
        /*
         * @description
         setting*/
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.goHome = function () {
            $location.path('/');
        };
        $scope.isSubmitted = false;
        $scope.settingData = {
            conversion_spread: '',
            bundle_image: '../assets/images/bundle-cover.png',
            dad_retries: '',
            administrative_contact: '',
            technical_support: '',
            no_of_redelivery : '',
            isImage: false,
            id: '',
            original_image: '',
            isEditImage: false,
            isDeleteImage: false
        };
        /**
         * @description
         * Image Upload
         */
        $scope.setFile = function (element) {
            var isvalid = true;
            $scope.currentFile = element.files[0];
            if ($scope.currentFile.size !== undefined && $scope.currentFile.size > 3099999) {
                isvalid = false;
            }
            if (isvalid) {
                var reader = new FileReader();
                reader.onload = function (event) {
                    var img = new Image();
                    img.src = event.target.result;
                    $timeout(function(){
                        if (img.width > 600 || img.width < 300 || img.height < 450 || img.height > 900) {
                            console.log(img + ' '+ img.width + ' '+img.height)
                            $window.scrollTo(0, 0);
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = $filter('translate')('IMAGE_DIMENSION_ERROR');
                            $scope.$apply();
                        } else {
                            $scope.isError = false;
                            $scope.isMessage = false;
                            $scope.message = '';
                            $scope.settingData.bundle_image = event.target.result;
                            $scope.settingData.isEditImage = true;
                            $scope.settingData.isDeleteImage = true;
                            $scope.$apply();
                        }
                    },100);

                }
                reader.readAsDataURL(element.files[0]);
            } else {
                $window.scrollTo(0, 0);
                $scope.isError = true;
                $scope.isMessage = false;
                $scope.message = $filter('translate')('BOOK_IMAGE_THREEMB_TOO_LARGE');
                $scope.$apply();
            }
        };
        /**
         * @description
         *remove bundle image
         */
        $scope.removeBundleImage = function () {
            $scope.settingData.isImage = false;
            $scope.settingData.bundle_image = '../assets/images/bundle-cover.png';
            $scope.settingData.isEditImage = true;
            $scope.settingData.isDeleteImage = false;
        };
        /**
         * @description
         *get Setting Data
         */
        $scope.getSettingData = function () {
            settingsService.getSettingData({admin_access_token: TokenData.admin_access_token, language: $rootScope.language})
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.settingData = {
                                conversion_spread: (data.response.conversion_spread !== undefined && data.response.conversion_spread !== null && data.response.conversion_spread != '') ? parseFloat(data.response.conversion_spread) : '',
                                bundle_image: (data.response.bundle_image !== undefined && data.response.bundle_image !== null && data.response.bundle_image != '') ? data.response.bundle_image : '../assets/images/bundle-cover.png',
                                isImage: (data.response.model_cover_image !== undefined && data.response.model_cover_image !== null && data.response.model_cover_image != '') ? true : false,
                                id: (data.response.id !== undefined && data.response.id !== null && data.response.id != '') ? parseInt(data.response.id) : '',
                                original_image: (data.response.model_cover_image !== undefined && data.response.model_cover_image !== null && data.response.model_cover_image != '') ? data.response.model_cover_image : '',
                                isEditImage: false,
                                isDeleteImage: (data.response.bundle_image !== undefined && data.response.bundle_image !== null && data.response.bundle_image != '') ? true : false,
                                dad_retries: (data.response.dad_retries !== undefined && data.response.dad_retries !== null && data.response.dad_retries != '') ? parseInt(data.response.dad_retries) : '',
                                no_of_redelivery: (data.response.no_of_redelivery !== undefined && data.response.no_of_redelivery !== null && data.response.no_of_redelivery != '') ? parseInt(data.response.no_of_redelivery) : '',
                                administrative_contact: (data.response.administrative_contact_email !== undefined && data.response.administrative_contact_email !== null && data.response.administrative_contact_email != '') ? data.response.administrative_contact_email : '',
                                technical_support: (data.response.technical_support_email !== undefined && data.response.technical_support_email !== null && data.response.technical_support_email != '') ? data.response.technical_support_email : '',
                            };
                        } else {
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    },
                            function (err, status) {
                                $scope.isError = true;
                                $scope.isMessage = false;
                            });
        };

        /**
         * @description
         *save Setting Data
         */
        $scope.saveAdminSetting = function () {
            if ($scope.settingform.$valid) {
                var settingData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    conversion_spread: $scope.settingData.conversion_spread,
                    original_image: $scope.settingData.original_image,
                    bundle_image: $scope.settingData.bundle_image,
                    id: $scope.settingData.id,
                    isEditImage: $scope.settingData.isEditImage,
                    dad_retries: $scope.settingData.dad_retries,
                    no_of_redelivery: $scope.settingData.no_of_redelivery,
                    administrative_contact: $scope.settingData.administrative_contact,
                    technical_support: $scope.settingData.technical_support,
                };
                settingsService.insertAdminSetting(settingData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.settingData.id = data.id;
                                $scope.settingData.original_image = data.original_image;
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                $scope.isSubmitted = false;
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isSubmitted = false;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            } else {
                $scope.isSubmitted = true;
            }
        };

        $scope.getSettingData();

    }
]);