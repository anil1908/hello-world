 /**
 * @description
 * # module rights check
 */
'use strict';
App.factory('settingsService', ['$http', '$q', function ($http, $q) {
        var settingsServiceFactory = {};

        /*
         * @description
         * get setting data
         * */
        var _getSettingData = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/general/get_admin_setting',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
         /*
         * @description
         * add setting data
         * */
        var _insertAdminSetting = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/insert_settings',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        settingsServiceFactory.getSettingData = _getSettingData;
        settingsServiceFactory.insertAdminSetting = _insertAdminSetting;
        return settingsServiceFactory;
}]);