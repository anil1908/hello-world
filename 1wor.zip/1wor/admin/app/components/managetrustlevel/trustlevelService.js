/**
 * @description
 * # module rights check
 */
'use strict';
App.factory('trustlevelService', ['$http', '$q', function ($http, $q) {
        var trustlevelServiceFactory = {};

        /*
         * @description
         * get retailers with trust level
         * */
        var _getRetailerList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/trust_level/get_retailer_trust_list',
                method: "POST",
                data: data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        /*
         * @description
         * add curation
         * */
        var _updateTrustLevel = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/trust_level/update_level',
                method: "POST",
                data: data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        trustlevelServiceFactory.getRetailerList = _getRetailerList;
        trustlevelServiceFactory.updateTrustLevel = _updateTrustLevel;
        return trustlevelServiceFactory;
    }]);