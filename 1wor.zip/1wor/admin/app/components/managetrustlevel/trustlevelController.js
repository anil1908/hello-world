angular.module('OneWorld').controller('trustlevelController', ['$scope', '$rootScope', '$uibModal', '$sessionStorage', '$translate', '$location', 'localStorageService', 'trustlevelService', '$filter',
    function ($scope, $rootScope, $uibModal, $sessionStorage, $translate, $location, localStorageService, trustlevelService, $filter) {
        /*
         * @description
         Login And Signup Menu display*/
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        var adminData = cookies.get('adminauthorizationData');
        $rootScope.adminData = adminData;
        $scope.goHome = function () {
            $location.path('/');
        };
        $scope.isSubmitted = false;
        $scope.levelList = [
            {
                id: 1,
                name: $filter('translate')('LEVEL1_LABEL'),
            }, {
                id: 2,
                name: $filter('translate')('LEVEL2_LABEL'),
            }, {
                id: 3,
                name: $filter('translate')('LEVEL3_LABEL'),
            }

        ];
        $scope.changeLevelList = [
            {
                id: 1,
                name: $filter('translate')('CAHNGE_SELECTED_LEVEL1_LABEL'),
            }, {
                id: 2,
                name: $filter('translate')('CAHNGE_SELECTED_LEVEL2_LABEL'),
            }, {
                id: 3,
                name: $filter('translate')('CAHNGE_SELECTED_LEVEL3_LABEL'),
            }

        ];

        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'trust_level',
            sorttype: 'ASC',
            search_name: '',
            maxsize: 10
        };
        $scope.retailerList = [];
        $scope.retailerListData = {
            retailerArr: [],
            allchecked: false
        };
        $scope.isError = ($rootScope.islevelError !== undefined) ? $rootScope.islevelError : false;
        $scope.isMessage = ($rootScope.islevelMessage !== undefined) ? $rootScope.islevelMessage : false;
        $scope.message = ($rootScope.levelmessage !== undefined) ? $rootScope.levelmessage : '';

        /*
         * @description
         * Grid Option
         * */
        $scope.checkAll = function () {
            if ($scope.retailerListData.allchecked) {
                _.each($scope.retailerList, function (element) {
                    var isavl = true;
                    _.each($scope.retailerListData.retailerArr, function (obj) {
                        if (obj.id === element.id) {
                            isavl = false;
                        }
                    });
                    if (isavl) {
                        $scope.retailerListData.retailerArr.push(element);
                    }
                });
            } else {
                var arr = [];
                angular.forEach($scope.retailerListData.retailerArr, function (element) {
                    if ($scope.pageIds !== undefined && $scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.retailerListData.retailerArr = arr;
            }
        };

        $scope.uncheckMain = function () {
            $scope.retailerListData.allchecked = false;
        };

        $scope.$watch('currentPage', function (pageNo) {
            var retailerData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
            };
            if ($scope.level_search != null) {
                retailerData.searchtext = $scope.level_search.id;
            }
            $scope.gridOption.currentPage = pageNo;
            $scope.getRetailerList(retailerData);
            //or any other code here
        });

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var retailerData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
            };
            if ($scope.level_search != null) {
                retailerData.searchtext = $scope.level_search.id;
            }
            $scope.getRetailerList(retailerData);
            var pagesizeelm = angular.element( document.querySelectorAll( '#pagesize' ) );
            angular.forEach(pagesizeelm,function(val,key){
                pagesizeelm[key].blur();
            });
        };

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var retailerData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
            };
            if ($scope.level_search != null) {
                retailerData.searchtext = $scope.level_search.id;
            }
            $scope.getRetailerList(retailerData);
        };
        /*
         * @description
         * End Grid Option
         * */
        $scope.getRetailer = function () {
            var retailerData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
            };
            if ($scope.level_search != null) {
                retailerData.searchtext = $scope.level_search.id;
            }
            $scope.getRetailerList(retailerData);
        };

        /**
         * change trust level
         */
        $scope.changeSelectedTrustLevel = function () {
            if ($scope.retailerListData.retailerArr.length > 0) {
                var retailerIdArr = [];
                angular.forEach($scope.retailerListData.retailerArr, function (value, key) {
                    retailerIdArr.push(value.id);
                });

                if ($scope.updatelevel.$valid) {
                    var data = {
                        admin_access_token: TokenData.admin_access_token,
                        language: $rootScope.language,
                        retailerArr: retailerIdArr,
                        level_id: $scope.change_level.id
                    };
                    trustlevelService.updateTrustLevel(data)
                        .then(function (data) {
                            $scope.retailerListData = {
                                retailerArr: [],
                                allchecked: false
                            };
                            $scope.getRetailer();
                            $scope.message = data.msg;
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.isSubmitted = false;

                        },
                        function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });

                } else {
                    $scope.isSubmitted = true;
                }
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return { ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL') };
                        }
                    }
                });
                modalInstance.result.then(function () {
                }, function () {
                    console.log('error');
                });
            }
        };
        /**
         * get Retailer List
         */
        $scope.getRetailerList = function (retailerData) {
            trustlevelService.getRetailerList(retailerData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.pageIds = data.ids.split(',');
                        $scope.retailerListData.allchecked = false;
                        $scope.retailerList = data.response;
                        $scope.gridOption.filteredItems = data.total_rows;
                        $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                        if ($scope.gridOption.maxsize > 5) {
                            $scope.gridOption.maxsize = 5;
                        }
                        $rootScope.islevelError = false;
                        $rootScope.islevelMessage = false;
                        $rootScope.levelmessage = '';
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

    }
]);