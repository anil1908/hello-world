angular.module('OneWorld').controller('adminresetpasswordchkController', ['$scope', '$rootScope', '$location', 'authService','$filter',
    function ($scope, $rootScope, $location, authService,$filter) {

        authService.logOut()
            .then(function (data) {
                if (data.error <= 0) {
                    $scope.resetPasswordCheck();
                } else {
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $rootScope.error_message = data.errorMsg;
                    $location.path('/');
                }
            },
            function (err, status) {
                $scope.isError = true;
                $scope.isMessage = false;
            });
        $scope.resetPasswordCheck = function(){
            if ($location.search().u != '' && $location.search().u != undefined &&
                $location.search().t != '' && $location.search().t != undefined &&
                $location.search().h != '' && $location.search().h != undefined) {
                $rootScope.isreset = ($location.search().i==1)?true:false;
                $rootScope.headertitle = ($location.search().i==1)?$filter('translate')('SET_PASSWORD_TEXT'):$filter('translate')('RESET_PASSWORD_TITLE');
                var userData = {};
                userData.language = $rootScope.language;
                userData.user_id = $location.search().u;
                userData.time = $location.search().t;
                userData.hash = $location.search().h;
                /*
                * @description
                Check Reset Password Link Is Expire or not*/
                authService.checkResetPassword(userData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $location.$$search = {};
                            $location.path('/resetpassword');
                        } else {
                            $location.$$search = {};
                            $rootScope.errmessage = data.errorMsg;
                            $location.path('/');
                        }
                    },
                    function (err) {
                        $location.path('/');
                    })
            } else {
                $location.path('/');
            }
        }
}]);

angular.module('OneWorld').controller('adminresetpasswordController', ['$scope', '$rootScope', '$location', 'authService','$filter',
    function ($scope, $rootScope, $location, authService,$filter) {
        $scope.resetPasswordData = { password: '', confirmpassword: '' };
        $scope.isSubmitted = false;
        $scope.formname = 'resetpassword';
        /**
        * @description
         * Reset Password Config
         */
        $scope.resetPassword = function () {
            if ($scope.resetpassword.$valid) {
                var resetData = {};
                resetData.language = $rootScope.language;
                resetData.new_password = $scope.resetPasswordData.password;
                resetData.is_admin = $rootScope.isreset;
                authService.resetPassword(resetData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $rootScope.activate_message = ($rootScope.isreset)?$filter('translate')('PASSWORD_RESET_SUCCESSFULLY'):$filter('translate')('PASSWORD_SET_SUCCESSFULLY');
                            $location.path('/');
                        } else {
                            $scope.resetPasswordData = { password: '', confirmpassword: '' };
                            $scope.isError = true;
                            $scope.errmessage = data.errorMsg;
                        }
                    },
                    function (err) {
                        $scope.resetPasswordData = { password: '', confirmpassword: '' };
                        $scope.isError = true;
                    });
            } else {
                $scope.isSubmitted = true;
            }
        };
        $scope.goBack = function () {
            $location.path('/');
        }
    }]);

