angular.module('OneWorld').controller('verifyController', ['$scope', '$rootScope', '$http', '$location', '$window','authService','$sessionStorage',
    function ($scope, $rootScope, $http, $location, $window,authService,$sessionStorage) {
        /**
        * @description
         * Verify User Config
         */

        authService.logOut()
            .then(function (data) {
                if (data.error <= 0) {
                    if ($location.search().u != '' && $location.search().u != undefined) {
                        $scope.activateUser();
                    }
                    else{
                        $location.path('/');
                    }
                } else {
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $rootScope.error_message = data.errorMsg;
                    $location.path('/');
                }
            },
            function (err, status) {
                $scope.isError = true;
                $scope.isMessage = false;
            });

        /**
         * Activate Admin user
        */
        $scope.activateUser = function() {
            var  data = {
                user_id: $location.search().u,
                language: $rootScope.language
            };
            authService.activateAdminUser(data)
                .then(function (data) {
                    $location.$$search = {};
                    if (data.error <= 0) {
                        $rootScope.activate_message = data.msg;
                        $location.path('/');
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $rootScope.error_message = data.errorMsg;
                    }
                },
                function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

    }]);