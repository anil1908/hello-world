angular.module('OneWorld').controller('editUserController', ['$scope', '$rootScope', '$uibModalInstance', 'adminuserService', '$location', '$sessionStorage', 'localStorageService', 'userData',
    function ($scope, $rootScope, $uibModalInstance, adminuserService, $location, $sessionStorage, localStorageService, userData) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.form = {};
        $scope.isAllowPassword = (userData.userData.invited_by=='' || userData.userData.invited_by==null || userData.userData.invited_by==undefined)?false:true;
        $scope.UserDetail = {
            user_id : userData.userData.id,
            first_name : userData.userData.first_name,
            last_name : userData.userData.last_name,
            status : (userData.userData.status=="Active")?true:false,
            password : ''
        };
        $scope.usertypeList = [];
        $scope.isSubmitted = false;

        $scope.editUserDetail = function () {
            if ($scope.form.edituserdetail.$valid) {
                var editUserObj = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    user_id: $scope.UserDetail.user_id,
                    first_name: $scope.UserDetail.first_name,
                    last_name: $scope.UserDetail.last_name,
                    status: ($scope.UserDetail.status)?1:0,
                    password: $scope.UserDetail.password
                };
                adminuserService.editUserDetail(editUserObj)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $uibModalInstance.close({data: data});
                            } else {
                                $scope.message = data.errorMsg;
                                $scope.isError = true;
                                $scope.isMessage = false;
                            }
                        }, function (err) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $uibModalInstance.dismiss('cancel');
                        });
            } else {
                $scope.isSubmitted = true;
            }
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
}]);