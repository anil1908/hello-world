'use strict';
App.factory('adminuserService', ['$http', '$q', function ($http, $q) {
        var adminuserServiceFactory = {};
        /*
         * @description
         * get user data
        */
        var _getUserData = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_admin_users',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * Invite Admin User
        */
        var _inviteAdminUser = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/send_invitation',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        /**
         * Edit User Detail
        */
        var _editUserDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/update_invited_admin_user',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        /**
         * admin usertpe list
        */
        var _adminUsertypeList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_admin_usertypes',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * admin publisher list
        */
        var _getadminPublisher = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_dad_publisher_list_by_dad_admin',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        adminuserServiceFactory.getUserData = _getUserData;
        adminuserServiceFactory.inviteAdminUser = _inviteAdminUser;
        adminuserServiceFactory.editUserDetail = _editUserDetail;
        adminuserServiceFactory.adminUsertypeList = _adminUsertypeList;
        adminuserServiceFactory.getadminPublisher = _getadminPublisher;
        return adminuserServiceFactory;
}]);