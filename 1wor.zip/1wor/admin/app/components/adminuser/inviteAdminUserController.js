angular.module('OneWorld').controller('inviteAdminUserController', ['$scope', '$rootScope', '$uibModalInstance', 'adminuserService', '$location', '$sessionStorage', 'localStorageService', 'userData',
    function ($scope, $rootScope, $uibModalInstance, adminuserService, $location, $sessionStorage, localStorageService, userData) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.form = {};
        $scope.inviteAdminUserData = {
            name : '',
            email : '',
            usertype : ''
        };
        $scope.adminUsertype = [];
        $scope.isSubmitted = false;
        /**
         * invite user
         */
        $scope.inviteAdminUser = function () {
            if ($scope.form.inviteAdminUser.$valid) {
                var inviteAdminUserObj = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    first_name: $scope.inviteAdminUserData.first_name,
                    last_name: $scope.inviteAdminUserData.last_name,
                    email_id: $scope.inviteAdminUserData.email,
                    usertype_id: $scope.inviteAdminUserData.usertype
                };
                adminuserService.inviteAdminUser(inviteAdminUserObj)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $uibModalInstance.close({data: data});
                            } else {
                                $scope.message = data.errorMsg;
                                $scope.isError = true;
                                $scope.isMessage = false;
                            }
                        }, function (err) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $uibModalInstance.dismiss('cancel');
                        });
            } else {
                $scope.isSubmitted = true;
            }
        };
        /**
         * close model popup
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        /**
         *
        */
        $scope.getAdminUsertype = function() {
            var data = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language
                };
            adminuserService.adminUsertypeList(data)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.adminUsertype = data.response;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.getAdminUsertype();
}]);