angular.module('OneWorld').controller('userPublisherController', ['$scope', '$rootScope', '$uibModalInstance', 'adminuserService', '$location', 'localStorageService', 'userData',
    function ($scope, $rootScope, $uibModalInstance, adminuserService, $location, localStorageService, userData) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');

        $scope.publisherUserList = [];
        $scope.userdata = userData.data;
        /**
         * invite user
         */
        $scope.getAdminPublisherUser = function () {
                var userObj = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    dad_admin: $scope.userdata.id
                };
                adminuserService.getadminPublisher(userObj)
                        .then(function (data) {
                        if (data.error <= 0) {
                            $scope.publisherUserList = data.response;
                        } else {
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    }, function (err) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        /**
         * close model popup
         */
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.getAdminPublisherUser();

}]);