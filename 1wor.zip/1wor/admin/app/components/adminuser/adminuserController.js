angular.module('OneWorld').controller('adminuserController', ['$scope', '$rootScope', '$uibModal', '$sessionStorage','$location', 'localStorageService','adminuserService','$filter','$window',
    function ($scope, $rootScope,$uibModal, $sessionStorage, $location, localStorageService,adminuserService,$filter,$window) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.userList = [];
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'u.created_on',
            sorttype: 'DESC',
            maxsize: 10
        };
        $scope.usersListData = { userArr: [], allchecked: false };
        /*
        * go back
        */
        $scope.goHome = function () {
            $location.path('/');
        };
        /**
         * Grid Option
        */
        $scope.$watch('gridOption.currentPage', function (pageNo) {
            var userData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getUserData(userData);
            //or any other code here
        });

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var userData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getUserData(userData);
        };

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var userData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getUserData(userData);
            var pagesizeelm = angular.element( document.querySelectorAll( '#pagesize' ) );
            angular.forEach(pagesizeelm,function(val,key){
                pagesizeelm[key].blur();
            });
        };

        $scope.cancleSearch = function () {
            var userData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.usersListData = { userArr: [], allchecked: false };
            $scope.getUserData(userData);
        };
        /**
         * User Data fetch
         */
        $scope.getUserData = function (userData) {
            userData.dataLoader = true;
            adminuserService.getUserData(userData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.usersListData.allchecked = false;
                        $scope.userList = data.response;
                        $scope.gridOption.filteredItems = data.total_rows;
                        $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                        if ($scope.gridOption.maxsize > 5) {
                            $scope.gridOption.maxsize = 5;
                        }
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /*
        * @description
        invite new user config */
        $scope.toggleInviteNewUserModal = function () {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/adminuser/adminInviteNewUser.html',
                controller: 'inviteAdminUserController',
                resolve: {
                    userData: function () {
                        return {};
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                if (dataObj.data.error <= 0) {
                    var userData = {
                        admin_access_token: TokenData.admin_access_token,
                        language: $rootScope.language,
                        pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                        pageLimit: $scope.gridOption.pageLimit,
                        sortField: $scope.gridOption.sortField,
                        sorttype: $scope.gridOption.sorttype
                    };
                    $scope.getUserData(userData);
                    $scope.isError = false;
                    $scope.isMessage = true;
                    $scope.message = dataObj.data.msg;
                } else {
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = dataObj.data.errorMsg;
                }
            }, function () {
                console.log('error');
            });
        };

        /*
        * @description edit user
        */
        $scope.editUserModal = function (index,userData) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/adminuser/editUserDetail.html',
                controller: 'editUserController',
                resolve: {
                    userData: function () {
                        return {userData:userData};
                    }
                }
            });

            modalInstance.result.then(function (dataObj) {
                if (dataObj.data.error <= 0) {
                    var userData = {
                        admin_access_token: TokenData.admin_access_token,
                        language: $rootScope.language,
                        pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                        pageLimit: $scope.gridOption.pageLimit,
                        sortField: $scope.gridOption.sortField,
                        sorttype: $scope.gridOption.sorttype
                    };
                    $scope.getUserData(userData);
                    $scope.isError = false;
                    $scope.isMessage = true;
                    $scope.message = dataObj.data.msg;
                } else {
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = dataObj.data.errorMsg;
                }
            }, function () {
                console.log('error');
            });
        };
        /**
         * publisher Modal
        */
        $scope.publisherModal = function(userdata) {
             var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/adminuser/userPublisher.html',
                controller: 'userPublisherController',
                resolve: {
                    userData: function () {
                        return {data:userdata};
                    }
                }
            });

            modalInstance.result.then(function () {

            }, function () {
                console.log('error');
            });
        };

    }
]);