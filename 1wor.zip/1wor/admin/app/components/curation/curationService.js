 /**
 * @description
 * # module rights check
 */
'use strict';
App.factory('curationService', ['$http', '$q', function ($http, $q) {
        var curationServiceFactory = {};
        /*
         * @description
         * get curation
         * */
        var _getCurationList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/retailer_catalog/get_curation_list',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /*
         * @description
         * delete curation
         * */
        var _deleteCuration = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/retailer_catalog/delete_curation',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /*
         * @description
         * add curation
         * */
        var _addCuration = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/retailer_catalog/insert_curation',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        curationServiceFactory.getCurationList = _getCurationList;
        curationServiceFactory.deleteCuration = _deleteCuration;
        curationServiceFactory.addCuration     = _addCuration;
        return curationServiceFactory;
}]);