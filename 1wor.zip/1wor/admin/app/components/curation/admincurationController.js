angular.module('OneWorld').controller('admincurationController', ['$scope', '$rootScope', '$uibModal', '$sessionStorage', '$translate', '$location', 'localStorageService','curationService','$filter',
    function ($scope, $rootScope,$uibModal, $sessionStorage, $translate, $location, localStorageService,curationService,$filter) {
        /*
        * @description
        Login And Signup Menu display*/
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        var adminData = cookies.get('adminauthorizationData');
        $rootScope.adminData = adminData;
        $scope.goHome = function () {
            $location.path('/');
        };
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'name',
            sorttype: 'ASC',
            search_name : '',
            maxsize: 10,
            flag:1
        };
        $scope.curationList = [];
        $scope.curationListData = {
            curationArr :[],
            allchecked   : false
        };
        $scope.isError = ($rootScope.iscurationError !== undefined) ? $rootScope.iscurationError : false;
        $scope.isMessage = ($rootScope.iscurationMessage !== undefined) ? $rootScope.iscurationMessage : false;
        $scope.message = ($rootScope.curationmessage !== undefined) ? $rootScope.curationmessage : '';

        /*
         * @description
         * Grid Option
         * */
        $scope.checkAll = function () {
            if ($scope.curationListData.allchecked) {
                _.each($scope.curationList, function (element) {
                    var isavl = true;
                    _.each($scope.curationListData.curationArr, function (obj) {
                        if (obj.id === element.id) {
                            isavl = false;
                        }
                    });
                    if (isavl) {
                        $scope.curationListData.curationArr.push(element);
                    }
                });
            } else {
                var arr = [];
                angular.forEach($scope.curationListData.curationArr, function (element) {
                    if ($scope.pageIds!==undefined && $scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.curationListData.curationArr = arr;
            }
        };

        $scope.uncheckMain = function () {
            $scope.curationListData.allchecked = false;
        };

        $scope.$watch('currentPage', function (pageNo) {
            var curationData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                dataLoader : true,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                searchtext: $scope.gridOption.search_name,
                flag:$scope.gridOption.flag
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getCurationList(curationData);
            //or any other code here
        });

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var curationData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                dataLoader : true,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                searchtext: $scope.gridOption.search_name,
                flag:$scope.gridOption.flag
            };
            $scope.getCurationList(curationData);
            var pagesizeelm = angular.element( document.querySelectorAll( '#pagesize' ) );
            angular.forEach(pagesizeelm,function(val,key){
                pagesizeelm[key].blur();
            });
        };

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var curationData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
                searchtext: $scope.gridOption.search_name,
                flag:$scope.gridOption.flag
            };
           $scope.getCurationList(curationData);
        };

        $scope.globalSearch = function(){
            var curationData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                searchtext: $scope.gridOption.search_name,
                flag:$scope.gridOption.flag
            };
            $scope.getCurationList(curationData);
        };

        $scope.getCuration = function(){
            var curationData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                searchtext: $scope.gridOption.search_name
            };
            $scope.getCurationList(curationData);
        };

        $scope.getCurationList = function (curationData) {
            curationService.getCurationList(curationData)
                    .then(function (data) {
                        if (data.error <= 0) {
                           // $scope.pageIds = data.ids.split(',');
                            $scope.curationListData.allchecked = false;
                            $scope.curationList = data.response;
                            $scope.gridOption.filteredItems = data.total_rows;
                            $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                            if ($scope.gridOption.maxsize > 5) {
                                $scope.gridOption.maxsize = 5;
                            }
                            $rootScope.iscurationError = false;
                            $rootScope.iscurationMessage = false;
                            $rootScope.curationmessage = '';
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        /*
         * @description
         * End Grid Option
         * */
        /*
         * @description
         * Curation delete
         * */
        $scope.deleteCurationRow = function (curationObj) {
            var arr = [];
            arr.push({id: curationObj.id});
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function () {
                        return {ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('CATALOG_REMOVE_CONFIRMATION_LABEL')};
                    }
                }
            });
            modalInstance.result.then(function () {
                $scope.deleteCurationArr(arr,false);
            }, function () {
                console.log('error');
            });

        };

        $scope.deleteSelectedCuration = function () {
            if ($scope.curationListData.curationArr.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/curation/curationdelete.html',
                    controller: 'curationDeleteCtrl',
                    resolve: {
                        curationData: function () {
                            return {curationArr: $scope.curationListData.curationArr};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.deleteCurationArr(dataObj.curationArr,true);
                }, function () {
                    console.log('error');
                });
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL')};
                        }
                    }
                });
                modalInstance.result.then(function () {

                }, function () {
                    console.log('error');
                });
            }
        };

        $scope.deleteCurationArr = function (dataObj,isArr) {
            var curationIdArr = [];
            angular.forEach(dataObj, function (value, key) {
                curationIdArr.push(value.id);
            });
            var curationData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                curationArr: curationIdArr
            };
            curationService.deleteCuration(curationData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                            if(isArr){
                                $scope.curationListData.curationArr = [];
                            }
                            else{
                                var curationArr = [];
                                angular.forEach($scope.curationListData.curationArr,function(listval,listkey){
                                    if(curationIdArr[0]!=listval.id){
                                        this.push(listval);
                                    }
                                },curationArr);
                                $scope.curationListData.curationArr = curationArr;
                            }
                            $scope.getCuration();
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        /*
         * @description
         * End Curation delete
         * */

        /*
         * @description
         * New category create
         * */
        $scope.createNewCategoryModal = function(){
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/curation/addcuration.html',
                controller: 'addCurationCtrl',
                resolve: {
                    curationData: function () {
                        return {};
                    }
                }
            });
            modalInstance.result.then(function (curationObj) {
                $location.path('editcuration').search({id: curationObj.curation_id});
            }, function () {
                console.log('error');
            });
        }

    }
]);

/**
 * Delete Curation Controller
 */
angular.module('OneWorld').controller('curationDeleteCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'curationData', 'localStorageService','$filter',
    function ($scope, $rootScope, $uibModalInstance, curationData, localStorageService,$filter) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.ModalTitle = $filter('translate')('CONFIRMATION_LABEL');
        $scope.curationDelete = function () {
            $uibModalInstance.close({curationArr: curationData.curationArr});
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
}]);

/**
 * Add Curation Controller
 */
angular.module('OneWorld').controller('addCurationCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'curationData', 'localStorageService','curationService','$filter',
    function ($scope, $rootScope, $uibModalInstance, curationData, localStorageService,curationService,$filter) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.ModalTitle = $filter('translate')('CREATE_NEW_CATEGORY_LABEL');
        $scope.curationformData = {categoryname:''};
        $scope.isSubmitted = false;
        /*
         * @description
         * category create
         * */
        $scope.createcuration = function(){
            if($scope.addcuration.$valid){
                var curationData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    curation_name: $scope.curationformData.categoryname
                };
                curationService.addCuration(curationData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $uibModalInstance.close({curation_id: data.curation_id,msg: data.msg});
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            }
            else{
                $scope.isSubmitted = true;
            }
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
}]);
