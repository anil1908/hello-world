 /**
 * @description
 * # module rights check
 */
'use strict';
App.factory('admincatalogService', ['$http', '$q', function ($http, $q) {
        var admincatalogServiceFactory = {};
        /*
         * @description
         * category Detail
         * */
        var _getCategoryDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/retailer_catalog/curation_details',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /*
         * @description
         * book list
         * */
        var _getBooksList = function (booksData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/retailer_catalog/get_all_books_list',
                method: "POST",
                data: booksData,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /*
         * @description
         * update curation
         * */
        var _updatecuration = function (curationData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/retailer_catalog/update_curation',
                method: "POST",
                data: curationData,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /*
         * @description
         * all book get
         * */
        var _getAllBook = function (bookData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/retailer_catalog/get_catalog_list_by_selection',
                method: "POST",
                data: bookData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /*
         * @description
         * delete book
         * */
        var _deleteCurationBooks = function (curationData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/retailer_catalog/delete_curation_books',
                method: "POST",
                data: curationData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /*
         * @description
         * Add book
         * */
        var _addcurationBooks = function (curationData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/retailer_catalog/add_curation_books',
                method: "POST",
                data: curationData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        admincatalogServiceFactory.getCategoryDetail = _getCategoryDetail;
        admincatalogServiceFactory.getBooksList      = _getBooksList;
        admincatalogServiceFactory.updatecuration    = _updatecuration;
        admincatalogServiceFactory.getAllBook = _getAllBook;
        admincatalogServiceFactory.deleteCurationBooks = _deleteCurationBooks;
        admincatalogServiceFactory.addcurationBooks = _addcurationBooks;
        return admincatalogServiceFactory;
}]);