'use strict';
angular.module('OneWorld').controller('addCategoryBooksController', ['$scope', '$rootScope', '$state', '$location', 'admincatalogService', '$uibModal', 'localStorageService','$filter',
    function ($scope, $rootScope, $state, $location, admincatalogService, $uibModal, localStorageService,$filter) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        var parameter = $location.search();
        if(parameter.id!==undefined && parameter.id!==null && parameter.id!==''){
            $scope.curationId = parameter.id;
            $scope.booksList = [];
            $scope.gridOption = {
                filteredItems: 0,
                pageSizeArr: [1, 5, 10, 20, 50, 100],
                currentPage: 1,
                pageLimit: 10,
                sortField: 'b.title',
                sorttype: 'ASC',
                maxsize: 10,
                search_title :'',
                search_author :'',
                search_imprint :'',
                search_publisher :''
            };
            $scope.isCurationSubmited = false;
            $scope.state = false;
            $scope.selectedBookList = [];
            $scope.booksListData = {bookArr: [], allchecked: false};
            $scope.showDeleteConfirmationModal = false;
            $scope.pageIds = [];
            $scope.autoSearchTagArr = [];
            $scope.toggleState = function () {
                $scope.state = !$scope.state;
            };
            $scope.curationDetail = {
                curation_name :''
            };
            /*
            * @description
            * move to list
            */
            $scope.goBack = function(){
                $location.search({});
                $location.path('curation');
            };
            /*
            * @description
            * Grid Option
            */

            $scope.checkAll = function () {
                if ($scope.booksListData.allchecked) {
                    _.each($scope.booksList, function (element) {
                        var isavl = true;
                        _.each($scope.booksListData.bookArr, function (obj) {
                            if (obj.id === element.id) {
                                isavl = false;
                            }
                        });
                        if (isavl) {
                            $scope.booksListData.bookArr.push(element);
                        }
                    });
                } else {
                    var arr = [];
                    angular.forEach($scope.booksListData.bookArr, function (element) {
                        if ($scope.pageIds.indexOf(element.id) < 0) {
                            arr.push(element);
                        }
                    });
                    $scope.booksListData.bookArr = arr;
                }
            };
            $scope.uncheckMain = function () {
                $scope.booksListData.allchecked = false;
            };
            $scope.getBooks = function () {
                var booksData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    search_title: $scope.gridOption.search_title,
                    search_author: $scope.gridOption.search_author,
                    search_imprint: $scope.gridOption.search_imprint,
                    search_publisher: $scope.gridOption.search_publisher
                };
                $scope.getBooksData(booksData);
            };

            $scope.$watch('currentPage', function (pageNo) {
                var booksData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    search_title: $scope.gridOption.search_title,
                    search_author: $scope.gridOption.search_author,
                    search_imprint: $scope.gridOption.search_imprint,
                    search_publisher: $scope.gridOption.search_publisher
                };
                $scope.gridOption.currentPage = pageNo;
                $scope.getBooksData(booksData);
                //or any other code here
            });

            $scope.sort_by = function (sortField) {
                $scope.gridOption.sortField = sortField;
                $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
                var booksData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: sortField,
                    sorttype: $scope.gridOption.sorttype,
                    search_title: $scope.gridOption.search_title,
                    search_author: $scope.gridOption.search_author,
                    search_imprint: $scope.gridOption.search_imprint,
                    search_publisher: $scope.gridOption.search_publisher
                };
                $scope.getBooksData(booksData);
            };

            $scope.changePageSize = function () {
                $scope.gridOption.currentPage = 1;
                var booksData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    search_title: $scope.gridOption.search_title,
                    search_author: $scope.gridOption.search_author,
                    search_imprint: $scope.gridOption.search_imprint,
                    search_publisher: $scope.gridOption.search_publisher
                };
                $scope.getBooksData(booksData);
            };

            $scope.searchBooks = function () {
                var booksData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    search_title: $scope.gridOption.search_title,
                    search_author: $scope.gridOption.search_author,
                    search_imprint: $scope.gridOption.search_imprint,
                    search_publisher: $scope.gridOption.search_publisher
                };
                $scope.getBooksData(booksData);
            };

            $scope.cancleSearch = function () {
                $scope.booksListData = {bookArr: [], allchecked: false};
                $scope.gridOption = {
                    filteredItems: 0,
                    pageSizeArr: [1, 5, 10, 20, 50, 100],
                    currentPage: 1,
                    pageLimit: 10,
                    sortField: 'b.title',
                    sorttype: 'ASC',
                    maxsize: 10,
                    search_title :'',
                    search_author :'',
                    search_imprint :'',
                    search_publisher :''
                };
                var booksData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: 'ASC',
                    search_title: '',
                    search_author: '',
                    search_imprint: '',
                    search_publisher: ''
                };
                $scope.getBooksData(booksData);
            };

            $scope.getBooksData = function (booksData) {
                admincatalogService.getBooksList(booksData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.pageIds = data.ids.split(',');
                                $scope.booksListData.allchecked = false;
                                $scope.booksList = data.response;
                                $scope.gridOption.filteredItems = data.total_rows;
                                $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                                if ($scope.gridOption.maxsize > 5) {
                                    $scope.gridOption.maxsize = 5;
                                }
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            };
            /*
            * @description
            * End Grid Option*/

            /*
            * @description
            * Add  Book in Curation*/
            $scope.selectBook = function (book) {
                var bookObj = {id: book.id, image: book.image, title: book.title};
                var isAvailable = false;
                angular.forEach($scope.selectedBookList, function (value, key) {
                    if (value.id == book.id) {
                        isAvailable = true;
                    }
                });
                if (!isAvailable) {
                    $scope.selectedBookList.push(bookObj);
                }
                if ($scope.selectedBookList.length > 0) {
                    $scope.state = true;
                }
            };
            /*
            * @description
            * delete  Book in Curation*/
            $scope.deleteSelectBook = function (book) {
                var bookarray = [];
                bookarray.push(book.id);
                var curationData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    curation_id :$scope.curationId,
                    bookArr :bookarray
                };
                admincatalogService.deleteCurationBooks(curationData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = "Curation Book Deleted.";
                                $scope.selectedBookList.splice($scope.selectedBookList.indexOf(book), 1);
                                $scope.state = true;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            }
            /*
            * @description
            *  Add All Book in Curation*/
            $scope.addAllBook = function () {
                var allBookData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    curation_id:$scope.curationId
                };
                admincatalogService.getAllBook(allBookData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.selectedBookList = data.response;
                                $scope.state = true;

                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            };
            /*
            * @description
            *  Add Selected Book in Curation*/
            $scope.addSelectedBook = function () {
                if ($scope.booksListData.bookArr.length > 0) {
                    var addBookArr = [];
                    angular.forEach($scope.booksListData.bookArr, function (element) {
                        var idCheck = _.find($scope.selectedBookList, function (value) {
                            return value.id == element.id;
                        });
                        if (idCheck === undefined) {
                            addBookArr.push(element.id);
                            $scope.selectedBookList.push(element);
                        }
                    });
                    if(addBookArr.length>0){
                        var curationData = {
                            admin_access_token: TokenData.admin_access_token,
                            language: $rootScope.language,
                            curation_id : $scope.curationId,
                            bookArr     : addBookArr
                        }
                        admincatalogService.addcurationBooks(curationData)
                            .then(function (data) {
                                if (data.error <= 0) {
                                    $scope.isError = false;
                                    $scope.isMessage = true;
                                    $scope.message = data.msg;
                                } else {
                                    $scope.isError = true;
                                    $scope.isMessage = false;
                                    $scope.message = data.errorMsg;
                                }
                            }, function (err, status) {
                                $scope.isError = true;
                                $scope.isMessage = false;
                            });
                    }
                    $scope.state = true;
                    $scope.booksListData = {bookArr: [], allchecked: false};
                }
            };

            $scope.getCategoryDetail = function(){
                var categoryData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    curation_id : $scope.curationId
                }
                admincatalogService.getCategoryDetail(categoryData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.curationDetail.curation_name = data.response.curation.name;
                                $scope.selectedBookList = data.response.curation_books;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            };

            /*
            * @description
            * Update Curation
            */
            $scope.updateCuration = function(){
                if($scope.updatecuration.$valid){
                    var curationData = {
                        admin_access_token: TokenData.admin_access_token,
                        language: $rootScope.language,
                        curation_id : $scope.curationId,
                        curation_name : $scope.curationDetail.curation_name
                    }
                    admincatalogService.updatecuration(curationData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $rootScope.iscurationError = false;
                                $rootScope.iscurationMessage = true;
                                $rootScope.curationmessage = data.msg;
                                $location.search({});
                                $location.path('/curation');
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
                }
                else{
                    $scope.isCurationSubmited = true;
                }
            };

            $scope.deleteAllBookConfirmationModal = function(){
                if($scope.selectedBookList.length>0){
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                        controller: 'deleteConfirmationCtrl',
                        resolve: {
                            deleteData: function () {
                                return {ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('CATALOG_REMOVE_CONFIRMATION_LABEL')};
                            }
                        }
                    });
                    modalInstance.result.then(function () {
                        var bookarray = [];
                        angular.forEach($scope.selectedBookList,function(bval,bkey){
                            this.push(bval.id);
                        },bookarray);
                        var curationData = {
                            admin_access_token: TokenData.admin_access_token,
                            language: $rootScope.language,
                            curation_id :$scope.curationId,
                            bookArr :bookarray
                        };
                        admincatalogService.deleteCurationBooks(curationData)
                                .then(function (data) {
                                    if (data.error <= 0) {
                                        $scope.isError = false;
                                        $scope.isMessage = true;
                                        $scope.message = "Curation Book(s) Deleted.";
                                        $scope.selectedBookList = [];
                                        $scope.state = false;
                                    } else {
                                        $scope.isError = true;
                                        $scope.isMessage = false;
                                        $scope.message = data.errorMsg;
                                    }
                                }, function (err, status) {
                                    $scope.isError = true;
                                    $scope.isMessage = false;
                                });

                    }, function () {
                        console.log('error');
                    });
                }
                else{
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                        controller: 'deleteConfirmationCtrl',
                        resolve: {
                            deleteData: function () {
                                return {ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('NO_RECORD_FOR_DELETE')};
                            }
                        }
                    });
                    modalInstance.result.then(function () {

                    }, function () {
                        console.log('error');
                    });
                }
            };
            /*
            * @description
            * Tag Popup Update Book */
            $rootScope.$on('updateBookList', function (event, data) {
                $scope.getBooks();
            });
            $scope.getCategoryDetail();
        }
        else{
            $location.path('/curation')
        }
    }]);
