 /**
 * @description
 * # module rights check
 */
'use strict';
App.factory('salespersonService', ['$http', '$q', function ($http, $q) {
        var salespersonServiceFactory = {};
        /*
         * @description
         * get curation
         * */
        var _getSalesPersonList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/get_company_sales_person_list',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /*
         * @description
         * delete curation
         * */
        var _deleteSalesPerson = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/retailer_catalog/delete_curation',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /*
         * @description
         * add curation
         * */
        var _editSalesPerson = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: '../api/admin/update_company_sales_person',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        salespersonServiceFactory.getSalesPersonList = _getSalesPersonList;
        salespersonServiceFactory.deleteSalesPerson = _deleteSalesPerson;
        salespersonServiceFactory.editSalesPerson     = _editSalesPerson;
        return salespersonServiceFactory;
}]);