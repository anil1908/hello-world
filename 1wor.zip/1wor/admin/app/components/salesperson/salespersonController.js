angular.module('OneWorld').controller('salespersonController', ['$scope', '$rootScope', '$uibModal', '$sessionStorage', '$translate', '$location', 'localStorageService', 'salespersonService', '$filter',
    function ($scope, $rootScope, $uibModal, $sessionStorage, $translate, $location, localStorageService, salespersonService, $filter) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        var adminData = cookies.get('adminauthorizationData');
        $rootScope.adminData = adminData;
        $scope.goHome = function () {
            $location.path('/');
        };
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'name',
            sorttype: 'ASC',
            search_name: '',
            found_rows : '',
            maxsize: 10
        };
        $scope.salesPersonList = [];
        $scope.salesPersonListData = {
            salesPersonArr: [],
            allchecked: false
        };
        /*
         * @description
         * Grid Option
        * */
        $scope.checkAll = function () {
            if ($scope.salesPersonListData.allchecked) {
                _.each($scope.salesPersonList, function (element) {
                    var isavl = true;
                    _.each($scope.salesPersonListData.salesPersonArr, function (obj) {
                        if (obj.id === element.id) {
                            isavl = false;
                        }
                    });
                    if (isavl) {
                        $scope.salesPersonListData.salesPersonArr.push(element);
                    }
                });
            } else {
                var arr = [];
                angular.forEach($scope.salesPersonListData.salesPersonArr, function (element) {
                    if ($scope.pageIds !== undefined && $scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.salesPersonListData.salesPersonArr = arr;
            }
        };

        $scope.uncheckMain = function () {
            $scope.salesPersonListData.allchecked = false;
        };

        $scope.$watch('currentPage', function (pageNo) {
            var salesPersonData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                dataLoader: true,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getsalesPersonList(salesPersonData);
        });

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var salesPersonData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                dataLoader: true,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getsalesPersonList(salesPersonData);
            var pagesizeelm = angular.element(document.querySelectorAll('#pagesize'));
            angular.forEach(pagesizeelm, function (val, key) {
                pagesizeelm[key].blur();
            });
        };

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var salesPersonData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getsalesPersonList(salesPersonData);
        };

        $scope.getSalesPerson = function () {
            var salesPersonData = {
                admin_access_token: TokenData.admin_access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getsalesPersonList(salesPersonData);
        };

        $scope.getsalesPersonList = function (salesPersonData) {
            salespersonService.getSalesPersonList(salesPersonData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.salesPersonListData.allchecked = false;
                        $scope.salesPersonList = data.response;
                        $scope.gridOption.filteredItems = data.total_rows;
                        $scope.gridOption.found_rows = data.found_rows;
                        $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                        if ($scope.gridOption.maxsize > 5) {
                            $scope.gridOption.maxsize = 5;
                        }
                    } else {
                        $scope.message = data.msg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        /*
         * @description
         * End Grid Option
         *
       */

        /*
         * @description
         * edit Sales Person
         * */
        $scope.editsalesperson = function (salesPerson) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/salesperson/editsalesperson.html',
                controller: 'editSalesPersonCtrl',
                resolve: {
                    salesPersonData: function () {
                        return { salesPerson: salesPerson };
                    }
                }
            });
            modalInstance.result.then(function (salesPersonObj) {
                $scope.message = (salesPersonObj.data.error<=0)?salesPersonObj.data.msg:salesPersonObj.data.errorMsg;
                $scope.isError = (salesPersonObj.data.error<=0)?false:true;
                $scope.isMessage = (salesPersonObj.data.error<=0)?true:false;
                $scope.getSalesPerson();
            }, function () {
                console.log('error');
            });
        }

    }
]);

/**
 * Edit Sales Person Controller
 */
angular.module('OneWorld').controller('editSalesPersonCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'salesPersonData', 'localStorageService', 'salespersonService', '$filter',
    function ($scope, $rootScope, $uibModalInstance, salesPersonData, localStorageService, salespersonService, $filter) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.ModalTitle = $filter('translate')('UPDATE_SALES_PERSON');
        $scope.form = {};
        $scope.salespersonformData = {
            company_id: salesPersonData.salesPerson.company_id,
            company_name: salesPersonData.salesPerson.company_name,
            name: salesPersonData.salesPerson.salesperson_name,
            email: salesPersonData.salesPerson.salesperson_email,
            usertype: salesPersonData.salesPerson.usertype
        };
        $scope.isSubmitted = false;
        /*
         * @description
         * category create
         * */
        $scope.editSalesPerson = function () {
            if ($scope.salespersondetail.$valid) {
                var salesPersonData = {
                    admin_access_token: TokenData.admin_access_token,
                    language: $rootScope.language,
                    company_id: $scope.salespersonformData.company_id,
                    salesperson_name: $scope.salespersonformData.name,
                    salesperson_email: $scope.salespersonformData.email,
                };
                salespersonService.editSalesPerson(salesPersonData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $uibModalInstance.close({ data: data });
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.msg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            }
            else {
                $scope.isSubmitted = true;
            }
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);
