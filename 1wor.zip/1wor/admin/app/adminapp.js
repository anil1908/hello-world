var App = angular.module('OneWorld', [
    'ui.router',
    'ui.grid',
    'ui.grid.pagination',
    'ui.grid.autoResize',
    'ui.bootstrap',
    'ui.checkbox',
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngSanitize',
    'pascalprecht.translate',
    'tmh.dynamicLocale',
    'LocalStorageModule',
    'ngStorage',
    'checklist-model',
    'xeditable',
    'ngTagsInput',
    'angular-cache',
    'ui.select2',
    'ivh.treeview',
    'dndLists',
    'colorpicker.module',
    'angular-clipboard',
    'oc.lazyLoad'
])
        .constant('DEBUG_MODE', true)
        .constant('DATE_FORMAT', 'MM/dd/yyyy')
        .constant('LOCALES', {
            'locales': {
                'ru_RU': 'Русский',
                'en_US': 'English'
            },
            'preferredLocale': 'en_US'
        })
        .constant('USERTYPE', {
            'SUPER_USER' : 4,
            'DAD_USER' : 5,
            'daduserModule' : ['dad','daddeliverylist','myaccount']
        })
        .constant('COUNTRY_PREFERENCE', (function () {
            return {
                'North America': [
                    { country_id: "2", id: "2_duplicate1Canada", main_id: "2_Canada", label: "Canada" },
                    { country_id: "1", id: "1_duplicate1United States", main_id: "1_United States", label: "United States" }
                ],
                'Central America': [{ country_id: "33", id: "33_duplicate1Mexico", main_id: "33_Mexico", label: "Mexico" }],
                'South America': [
                    { country_id: "43", id: "43_duplicate1Venezuela", main_id: "43_Venezuela", label: "Venezuela" },
                    { country_id: "42", id: "42_duplicate1Argentina", main_id: "42_Argentina", label: "Argentina" },
                    { country_id: "41", id: "41_duplicate1Brazil", main_id: "41_Brazil", label: "Brazil" }
                ],
                'Europe (EU)': [
                    { country_id: "59", id: "59_duplicate1Spain", main_id: "59_Spain", label: "Spain" },
                    { country_id: "58", id: "58_duplicate1Italy", main_id: "58_Italy", label: "Italy" },
                    { country_id: "57", id: "57_duplicate1France", main_id: "57_France", label: "France" },
                    { country_id: "55", id: "55_duplicate1Germany", main_id: "55_Germany", label: "Germany" },
                    { country_id: "56", id: "56_duplicate1United Kingdom", main_id: "56_United Kingdom", label: "United Kingdom" }
                ],
                'Europe (Non-EU)': [
                    { country_id: "90", id: "90_duplicate1Switzerland", main_id: "90_Switzerland", label: "Switzerland" },
                    { country_id: "89", id: "89_duplicate1Russia", main_id: "89_Russia", label: "Russia" }
                ],
                'South Asia': [{ country_id: "180", id: "180_duplicate1India", main_id: "180_India", label: "India" }],
                'South East Asia': [
                    { country_id: "193", id: "193_duplicate1Philippines", main_id: "193_Philippines", label: "Philippines" },
                    { country_id: "192", id: "192_duplicate1Singapore", main_id: "192_Singapore", label: "Singapore" }
                ],
                'Middle East': [
                    { country_id: "200", id: "200_duplicate1Turkey", main_id: "200_Turkey", label: "Turkey" },
                    { country_id: "201", id: "201_duplicate1Saudi Arabia", main_id: "201_Saudi Arabia", label: "Saudi Arabia" },
                    { country_id: "203", id: "203_duplicate1United Arab Emirates", main_id: "203_United Arab Emirates", label: "United Arab Emirates" },
                    { country_id: "204", id: "204_duplicate1Israel", main_id: "204_Israel", label: "Israel" }
                ],
                'Australia-Oceania': [
                    { country_id: "216", id: "216_duplicate1New Zealand", main_id: "216_New Zealand", label: "New Zealand" },
                    { country_id: "215", id: "215_duplicate1Australia", main_id: "215_Australia", label: "Australia" }
                ]
            };
        })())
        // Angular state change
        .config(['$stateProvider','$urlRouterProvider', '$locationProvider', '$translateProvider', 'tmhDynamicLocaleProvider','$ocLazyLoadProvider',
                function ($stateProvider, $urlRouterProvider, $locationProvider, $translateProvider, tmhDynamicLocaleProvider,$ocLazyLoadProvider) {
                $locationProvider.html5Mode(true);
                $urlRouterProvider.otherwise('/');
                // Now set up the states
                $stateProvider
                        .state('admin', {
                            title: 'ADMIN_HEADER_TITLE',
                            url: '/',
                            templateUrl: 'app/components/adminlogin/adminlogin.html',
                            controller: 'adminloginController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [
                                            'app/components/adminlogin/adminloginController.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('resetpasswordchk', {
                            title: 'SIGNUP_HEADER_TITLE',
                            url: '/resetpasswordchk',
                            controller: 'adminresetpasswordchkController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [                                                    'app/components/resetpassword/adminresetpasswordController.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('resetpassword', {
                            title: 'SIGNUP_HEADER_TITLE',
                            url: '/resetpassword',
                            templateUrl: 'app/components/resetpassword/adminresetpassword.html',
                            controller: 'adminresetpasswordController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [                                                    'app/components/resetpassword/adminresetpasswordController.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('verify', {
                            title: 'Verify',
                            url: '/verify',
                            controller: 'verifyController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [
                                            'app/components/verify/verifyController.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('curation', {
                            title: 'RETAILER_CURATION_TITLE_LABEL',
                            url: '/curation',
                            templateUrl: 'app/components/curation/curationList.html',
                            controller: 'admincurationController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [                                                                                                'app/components/curation/admincurationController.js',
                                            'app/components/curation/curationService.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('editcuration', {
                            title: 'RETAILER_CURATION_TITLE_LABEL',
                            url: '/editcuration',
                            templateUrl: 'app/components/curation/admincategorybook.html',
                            controller: 'addCategoryBooksController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [                                                                                                'app/components/curation/addCategoryBooksController.js',
                                            'app/components/curation/admincatalogService.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('lookupwidget', {
                            title: 'LOOKUP_WIDGET_HEADER_TITLE',
                            url: '/lookupwidget',
                            templateUrl: 'app/components/lookupwidget/lookupwidget.html',
                            controller: 'lookupwidgetController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [                                                                                                'app/components/lookupwidget/lookupwidgetController.js',                                            'app/components/lookupwidget/lookupwidgetService.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('dad', {
                            title: 'LOOKUP_DAD_TITLE',
                            url: '/dad',
                            templateUrl: 'app/components/dad/dad.html',
                            controller: 'dadController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [                                                                                                'app/components/dad/dadController.js',                                                              'app/components/dad/dadDetailCtrl.js',                                                              'app/components/dad/dadService.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('daddeliverylist', {
                            title: 'LOOKUP_DAD_DETAILS_TITLE',
                            url: '/daddeliverylist',
                            templateUrl: 'app/components/dad/dadDeliveryList.html',
                            controller: 'dadDeliveryListController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [                                                                                                'app/components/dad/dadDeliveryListController.js',                                                  'app/components/dad/dadDeliveryDetailsCtrl.js',                                                     'app/components/dad/dadService.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('settings', {
                            title: 'SETTINGS_LABLE',
                            url: '/settings',
                            templateUrl: 'app/components/settings/settings.html',
                            controller: 'settingsController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [                                                                                                'app/components/settings/settingsController.js',                                                    'app/components/settings/settingsService.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('managetrustlevel', {
                            title: 'MANAGE_TRUST_LEVEL',
                            url: '/managetrustlevel',
                            templateUrl: 'app/components/managetrustlevel/managetrustlevel.html',
                            controller: 'trustlevelController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [                                                                                            'app/components/managetrustlevel/trustlevelController.js',                                          'app/components/managetrustlevel/trustlevelService.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('adminuser', {
                            title: 'ADMIN_USERS_LIST',
                            url: '/adminuser',
                            templateUrl: 'app/components/adminuser/adminuser.html',
                            controller: 'adminuserController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [                                                                                            'app/components/adminuser/adminuserController.js',                                          'app/components/adminuser/adminuserService.js',
                                        'app/components/adminuser/inviteAdminUserController.js',
                                        'app/components/adminuser/editUserController.js',
                                        'app/components/adminuser/userPublisherController.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('myaccount', {
                            title: 'MY_ACCOUNT_LABLE',
                            url: '/myaccount',
                            templateUrl: 'app/components/myaccount/myaccount.html',
                            controller: 'myaccountController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [
                                            'app/components/myaccount/myaccountController.js',
                                            'app/components/myaccount/myaccountService.js'
                                        ]
                                    })
                                }
                            }
                        })
                        .state('salesperson', {
                            title: 'SALES_PERSON_LABEL',
                            url: '/salesperson',
                            templateUrl: 'app/components/salesperson/salesperson.html',
                            controller: 'salespersonController',
                            resolve: {
                                loadMyFiles: function ($ocLazyLoad) {
                                    return $ocLazyLoad.load({
                                        name: '1world',
                                        files: [
                                        'app/components/salesperson/salespersonController.js',
                                        'app/components/salesperson/salespersonService.js',
                                        ]
                                    })
                                }
                            }
                        });
            }])
        // Angular debug info
        .config(function ($compileProvider, DEBUG_MODE) {
            if (!DEBUG_MODE) {
                $compileProvider.debugInfoEnabled(false);// disables AngularJS debug info
            }
        })
        // Angular Translate
        .config(function ($translateProvider, DEBUG_MODE, LOCALES) {
            if (DEBUG_MODE) {
                $translateProvider.useMissingTranslationHandlerLog();// warns about missing translates
            }
            $translateProvider.useStaticFilesLoader({
                files: [{
                        prefix: '../assets/resources/locale-', // path to translations files
                        suffix: '.json'// suffix, currently- extension of the translations
                    },
                    {
                        prefix: '../assets/resources/validate/locale-validate-', // path to translations files
                        suffix: '.json'// suffix, currently- extension of the translations
                    }]
            });
            //$translateProvider.useSanitizeValueStrategy('sanitize');
            $translateProvider.preferredLanguage(LOCALES.preferredLocale);
            // Enable escaping of HTML
            $translateProvider.useSanitizeValueStrategy('escape');
            $translateProvider.useLocalStorage();
        })
        // Angular Dynamic Locale
        .config(function (tmhDynamicLocaleProvider) {
            tmhDynamicLocaleProvider.localeLocationPattern('../bower_components/angular-i18n/angular-locale_{{locale}}.js');
        })
        .config(function ($httpProvider) {
            //  $httpProvider.defaults.cache = true;
            $httpProvider.interceptors.push('authInterceptorService');
        })
        //angular cache data
        .run(function ($http, CacheFactory) {
            $http.defaults.cache = CacheFactory('defaultCache', {
                maxAge: 20 * 60 * 1000,
                cacheFlushInterval: 120 * 60 * 1000,
                deleteOnExpire: 'aggressive'
            });
        })
        .run(['authService', 'LOCALES', '$rootScope', function (authService, LOCALES, $rootScope) {
                $rootScope.language = LOCALES.preferredLocale;
                authService.fillAuthData($rootScope.language);
            }])
//
        .run(function ($rootScope, $state, $window, $cookieStore, $sessionStorage, $location, authService, LOCALES, localStorageService,USERTYPE) {
            $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState) {
                $window.scrollTo(0, 0);
                $rootScope.title = toState.title;
                $rootScope.selectedMenu = toState.name;
              //  $rootScope.$watch($rootScope.adminData);
             //   $rootScope.$watch($rootScope.isHeader);
            //    $rootScope.$watch($rootScope.logo);
                //$rootScope.$watch($rootScope.title);
                //$rootScope.$watch($rootScope.usertypeval);
                var authArr = ['verify','resetpassword','resetpasswordchk','admin'];
                var userTokenData = localStorageService.get('adminauthorizeTokenDetail');
                var adminData = cookies.get('adminauthorizationData');
                $rootScope.adminData = adminData;
                if (adminData !== null && adminData !== undefined && adminData !== '') {
                    $rootScope.isDadUser = (userTokenData.usertype==USERTYPE.DAD_USER)?true:false;
                    $rootScope.isHeader = true;
                    if(authArr.indexOf(toState.name)<0){
                        if(userTokenData.usertype==USERTYPE.DAD_USER && USERTYPE.daduserModule.indexOf(toState.name)<0){
                            $location.path('/dad');
                        }
                        else{
                            $location.path('/' + toState.name);
                        }
                    }
                    else{
                        if(toState.name=='verify' || toState.name=='resetpasswordchk'){
                             $location.path('/' + toState.name);
                        }
                        else{
                            if(userTokenData.usertype==USERTYPE.DAD_USER){
                                $location.path('/dad');
                            }
                            else{
                                $location.path('/curation');
                            }
                        }
                    }
                }
                else
                {
                    $rootScope.isDadUser = '';
                    $rootScope.isHeader = false;
                    if(authArr.indexOf(toState.name)<0){
                        $location.path('/admin');
                    }
                }
            });
    });