App.directive('autoComplete', function ($timeout) {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attrs, ngModel) {
            $timeout(function () {
                var autocom = new autoComplete({
                    selector: '#'+attrs.id,
                    minChars: 1,
                    source: function(term, suggest){
                        term = term.toLowerCase();
                        var choices = scope[attrs.uiItems];
                        var suggestions = [];
                        for (i=0;i<choices.length;i++)
                            if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                        suggest(suggestions);
                    },
                    onSelect: function(e, term, item){
                        // old and new value check
                        if (ngModel.$viewValue && ngModel.$viewValue !== element.val()) {
                            scope.$apply(function () {
                                ngModel.$setViewValue(element.val());
                            });
                        }
                    }
                });
            }, 1000);
        }
    };
});