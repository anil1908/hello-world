/*global module:false*/
module.exports = function (grunt) {
  // Project configuration.
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json'),
     jshint: {
      options: {
        jshintrc: '.jshintrc',
        reporter: require('jshint-stylish')
      },
      gruntfile: {
        src: 'Gruntfile.js'
      },
      scripts: {
       // src: 'app/**/*.js'
      },
      all: [
        'Gruntfile.js',
        //'app/controllers/catalogController.js'
      ]
    },
    clean: {
      test: ['tmp']
    },
    cssmin: {
      options: {
        shorthandCompacting: false,
        roundingPrecision: -1
      },
      // absolute: {
      //   bowercss: [{
      //     src: ['bower_components/**/*.css'].map(path.join(__dirname, file)),
      //     dest: 'lib/bowercss.css'
      //   }]
      // },
      // application: {
      //   src: [ 'assets/css/simple-line-icons.css', 'assets/css/bootstrap.min.css', 'assets/css/oneworldcontent.css', 'assets/css/responsive.css',
      //      'assets/css/lazyloading.css', 'assets/css/advanced.css','assets/css/article.css','assets/css/font-awesome.min.css'],
      //   dest: 'lib/application.min.css'
      // },
      bower: {
        src: [
          "bower_components/angular-ivh-treeview/dist/ivh-treeview.css",
          "bower_components/angular-ivh-treeview/dist/ivh-treeview-theme-basic.css",
          "bower_components/angular-xeditable/dist/css/xeditable.css",
          "bower_components/ng-tags-input/ng-tags-input.min.css",
          "bower_components/select2/select2.css",
          "bower_components/fancyBox/source/jquery.fancybox.css",
          "bower_components/angular-bootstrap-colorpicker/css/colorpicker.min.css",
          "bower_components/angularjs-slider/dist/rzslider.css"
        ],
        dest: 'lib/bower.min.css'
      },
      adminbower : {
        src : [
          "bower_components/angular-ivh-treeview/dist/ivh-treeview.css",
          "bower_components/angular-ivh-treeview/dist/ivh-treeview-theme-basic.css",
          "bower_components/angular-xeditable/dist/css/xeditable.css",
          "bower_components/ng-tags-input/ng-tags-input.min.css",
          "bower_components/fancyBox/source/jquery.fancybox.css",
          "bower_components/angular-bootstrap-colorpicker/css/colorpicker.min.css"
        ],
        dest : 'lib/adminbower.min.css'
      }
    },
    uglify: {
      options: {
        drop_console: true, //Turn off console warnings
        beautify: true,
        banner: '/*! <%= pkg.name %> - v<%= pkg.version %> - <%= grunt.template.today("yyyy-mm-dd") %> */',
        global_defs: {
          'DEBUG': false
        },
        dead_code: true
      },
      bowers:{
        src: [
              "bower_components/jquery/dist/jquery.min.js",
              "bower_components/fancyBox/source/jquery.fancybox.js",
              "bower_components/angular/angular.min.js",
              "bower_components/bootstrap/dist/js/bootstrap.min.js",
              "bower_components/angular-bootstrap/ui-bootstrap-tpls.js",
              "bower_components/jquery-bridget/jquery-bridget.js",
              "bower_components/get-size/get-size.js",
              "bower_components/ev-emitter/ev-emitter.js",
              "bower_components/matches-selector/matches-selector.js",
              "bower_components/fizzy-ui-utils/utils.js",
              "bower_components/outlayer/item.js",
              "bower_components/outlayer/outlayer.js",
              "bower_components/masonry/masonry.js",
              "bower_components/imagesloaded/imagesloaded.js",
              "bower_components/angular-masonry/angular-masonry.js",
              "bower_components/angular-ui-sortable/sortable.js",
              "bower_components/select2/select2.js",
              "bower_components/angular-ui-select2/src/select2.js",
              "bower_components/angular-ivh-treeview/dist/ivh-treeview.js",
              "bower_components/jquery-ui/jquery-ui.min.js",
              "bower_components/angular-ui-router/release/angular-ui-router.min.js",
              "bower_components/angular-animate/angular-animate.js",
              "bower_components/angular-cookies/angular-cookies.min.js",
              "bower_components/angular-resource/angular-resource.js",
              "bower_components/angular-sanitize/angular-sanitize.js",
              "bower_components/angular-translate/angular-translate.js","bower_components/angular-translate-storage-cookie/angular-translate-storage-cookie.js",
              "bower_components/angular-translate-storage-local/angular-translate-storage-local.js",             "bower_components/angular-translate-loader-static-files/angular-translate-loader-static-files.js",
              "bower_components/angular-translate-handler-log/angular-translate-handler-log.js",
              "bower_components/angular-dynamic-locale/tmhDynamicLocale.min.js",
              "bower_components/angular-local-storage/dist/angular-local-storage.min.js",
              "bower_components/ngstorage/ngStorage.min.js",
              "bower_components/angular-cookies/angular-cookies.js",
              "bower_components/checklist-model/checklist-model.js",
              "bower_components/angular-xeditable/dist/js/xeditable.min.js",
              "bower_components/underscore/underscore-min.js",
              "bower_components/ng-tags-input/ng-tags-input.min.js",
              "bower_components/jaaulde-cookies/lib/jaaulde-cookies.js",
              "bower_components/angular-bootstrap-colorpicker/js/bootstrap-colorpicker-module.js",
              "bower_components/angular-cache/dist/angular-cache.js",
              "bower_components/angular-wysiwyg/dist/angular-wysiwyg.min.js",
              "bower_components/angular-clipboard/angular-clipboard.js",
              "bower_components/javascript-auto-complete/auto-complete.js",
              "bower_components/angular-toArrayFilter/toArrayFilter.js",
              "bower_components/ng-idle/angular-idle.min.js",
              "bower_components/ng-remote-validate/release/ngRemoteValidate.js",
              "bower_components/oclazyload/dist/oclazyload.min.js",
              "bower_components/angularjs-slider/dist/rzslider.min.js"
            ],
        dest: 'lib/bowers.min.js'
      },
      adminbowers:{
        src: [
              "bower_components/jquery/dist/jquery.min.js",
              "bower_components/fancyBox/source/jquery.fancybox.js",
              "bower_components/angular/angular.min.js",
              "assets/js/bootstrap.min.js",
              "bower_components/angular-bootstrap/ui-bootstrap-tpls.js",
              "bower_components/angular-drag-and-drop-lists/angular-drag-and-drop-lists.js",
              "bower_components/angular-ivh-treeview/dist/ivh-treeview.js",
              "bower_components/angular-ui-select2/src/select2.js",
              "bower_components/jquery-ui/jquery-ui.min.js",
              "bower_components/angular-ui-router/release/angular-ui-router.min.js",
              "bower_components/angular-animate/angular-animate.js",
              "bower_components/angular-ui-grid/ui-grid.js",
              "bower_components/angular-cookies/angular-cookies.min.js",
              "bower_components/angular-resource/angular-resource.js",
              "bower_components/angular-sanitize/angular-sanitize.js",
              "bower_components/angular-translate/angular-translate.js",                       "bower_components/angular-translate-storage-cookie/angular-translate-storage-cookie.js",
              "bower_components/angular-translate-storage-local/angular-translate-storage-local.js",  "bower_components/angular-translate-loader-static-files/angular-translate-loader-static-files.js",
              "bower_components/angular-translate-handler-log/angular-translate-handler-log.js",
              "bower_components/angular-dynamic-locale/tmhDynamicLocale.min.js",
              "bower_components/angular-local-storage/dist/angular-local-storage.min.js",
              "bower_components/ngstorage/ngStorage.min.js",
              "bower_components/angular-cookies/angular-cookies.js",
              "bower_components/checklist-model/checklist-model.js",
              "bower_components/angular-xeditable/dist/js/xeditable.min.js",
              "bower_components/underscore/underscore-min.js",
              "bower_components/ng-tags-input/ng-tags-input.min.js",
              "bower_components/jaaulde-cookies/lib/jaaulde-cookies.js",
              "bower_components/angular-bootstrap-colorpicker/js/bootstrap-colorpicker-module.js",
              "bower_components/angular-bootstrap-checkbox/angular-bootstrap-checkbox.js",
              "bower_components/angular-cache/dist/angular-cache.js",
              "bower_components/angular-clipboard/angular-clipboard.js",
              "bower_components/javascript-auto-complete/auto-complete.js",
              "bower_components/oclazyload/dist/oclazyload.min.js",
              "bower_components/angularjs-slider/dist/rzslider.min.js",
            ],
        dest: 'lib/adminbowers.min.js'
      },
      // controllers: {
      //   src: [
      //     "app/controllers/homeController.js",
      //     "app/controllers/bookDetailCtrl.js",
      //     "app/controllers/deleteConfirmationCtrl.js",
      //     "app/controllers/widgetCodeCtrl.js",
      //     "app/controllers/widgetDetailCtrl.js",
      //     "app/controllers/bundleDetailCtrl.js"
      //   ],
      //   dest: 'lib/controllers.min.js'
      // },
      // directives: {
      //   src: 'app/directives/*.js',
      //   dest: 'lib/directives.min.js'
      // },
      // factories: {
      //   src: [
      //       "app/factories/authInterceptorService.js",
      //       "app/factories/userRightsService.js",
      //       "app/factories/beforeUnloadService.js",
      //       "app/factories/authService.js"
      //         ],
      //   dest: 'lib/factories.min.js'
      // },
      // filter: {
      //   src: 'app/filter/*.js',
      //   dest: 'lib/filter.min.js'
      // },
      // service: {
      //   src: 'app/service/*.js',
      //   dest: 'lib/service.min.js'
      // }
    },
    qunit: {
      files: ['app/components/common/accordianTemplate.html']
    },
    watch: {
      gruntfile: {
        files: [
                'Gruntfile.js'
              ],
        tasks: ['default'],
      },
      src: {
        files: ['assets/css/*.css'],
        tasks: ['cssmin'],
      },
      controllersfiles: {
        files: [
                'app/controllers/*.js'
              ],
        tasks: ['uglify:controllers'],
      },
      directivesfiles: {
        files: [
                'app/directives/*.js'
              ],
        tasks: ['uglify:directives'],
      },
      factoriesfiles: {
        files: [
                'app/factories/*.js'
              ],
        tasks: ['uglify:factories'],
      },
      filterfiles: {
        files: [
                'app/filter/*.js'
              ],
        tasks: ['uglify:filter'],
      },
      servicefiles: {
        files: [
                'app/service/*.js'
              ],
        tasks: ['uglify:service'],
      },
    },
  });

  grunt.loadNpmTasks('grunt-contrib-jshint');
  // grunt.loadNpmTasks('grunt-contrib-qunit');
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-clean');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-contrib-watch');
// Default task.
  grunt.registerTask('default', ['jshint', /*'qunit',*/'cssmin','uglify', 'clean',  'watch']);
};
