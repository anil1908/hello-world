'use strict';
angular.module('OneWorld').controller('purchaseauthController', ['$scope', '$rootScope', '$uibModal', 'purchaseauthService', '$location', '$sessionStorage', 'localStorageService', '$filter',
    function ($scope, $rootScope, $uibModal, purchaseauthService, $location, $sessionStorage, localStorageService, $filter) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $rootScope.logo = 'home-logo.png';
        $scope.purchaseauthData = {
            email : ''
        };
        $scope.isSubmitted = false;

        $scope.purchaseAuthenticate = function(){
            if ($scope.purchaseauth.$valid) {
                purchaseauthService.purchaseEmailAuth($scope.purchaseauthData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.isError = false;
                            $scope.message = data.msg;
                            $scope.isMessage = true;
                            $scope.purchaseauthData = { email: '' };
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    },
                    function (err) {
                        $scope.isError = false;
                        $scope.isMessage = false;
                    });
            }
            else{
                $scope.isSubmitted = true;
            }
        };


    }]);