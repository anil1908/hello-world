'use strict';
App.factory('purchaseauthService', ['$http', '$q', function ($http, $q) {
    var purchaseauthServiceFactory = {};

    /**
     * @description
     * # purchase authenticate email
    */
    var _purchaseEmailAuth = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/payment/ebook_redeliver',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };

    purchaseauthServiceFactory.purchaseEmailAuth = _purchaseEmailAuth;
    return purchaseauthServiceFactory;
}]);