'use strict';
angular.module('OneWorld').controller('groupsController', ['$scope', '$rootScope', 'groupService', '$uibModal', '$location', '$sessionStorage', 'localStorageService','$filter',
    function ($scope, $rootScope, groupService, $uibModal, $location, $sessionStorage, localStorageService,$filter) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.groupsList = [];
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'created_on',
            sorttype: 'DESC',
            maxsize: 10
        };
        $scope.state = false;
        $scope.selectedGroupList = [];
        $scope.groupListData = {groupArr: [], allchecked: false};
        $scope.showDeleteConfirmationModal = false;
        $scope.pageIds = [];
        $scope.showButtonBar = false;
        $scope.format = 'MM/dd/yyyy';
        $scope.showbuttonbar = false;
        $scope.popup1 = {opened: false};
        $scope.popup2 = {opened: false};
        $scope.showSelectGroupModal = false;

        $scope.isError = ($rootScope.groupsisError !== undefined) ? $rootScope.groupsisError : false;
        $scope.isMessage = ($rootScope.groupsisMessage !== undefined) ? $rootScope.groupsisMessage : false;
        $scope.message = ($rootScope.groupsmessage !== undefined) ? $rootScope.groupsmessage : '';

        $scope.goBack = function(){
            $location.path('dashboard');
        };
        $scope.getGroups = function () {
            var groupsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getGroupsData(groupsData);
        };

        $scope.getGroupsData = function (groupsData) {
            groupsData.dataLoader = true;
            groupService.getGroupsList(groupsData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.pageIds = data.ids.split(',');
                            $scope.groupListData.allchecked = false;
                            $scope.groupsList = data.response;
                            $scope.gridOption.filteredItems = data.total_rows;
                            $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                            if ($scope.gridOption.maxsize > 5) {
                                $scope.gridOption.maxsize = 5;
                            }

                            $rootScope.groupsmessage = '';
                            $rootScope.groupsisError = false;
                            $rootScope.groupsisMessage = false;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.groupSearch = function () {
            if ($scope.search_from_date != '' && $scope.search_from_date != undefined) {
                var from_date = new Date($scope.search_from_date);
                from_date = from_date.toLocaleDateString();
            }
            if ($scope.search_to_date != '' && $scope.search_to_date != undefined) {
                var to_date = new Date($scope.search_to_date);
                to_date = to_date.toLocaleDateString();
            }
            var groupsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_from_date: from_date,
                search_to_date: to_date,
                search_created_by: $scope.search_created_by
            };
            $scope.getGroupsData(groupsData);
        };

        $scope.cancelSearch = function () {
            $scope.search_name = '';
            $scope.search_from_date = '';
            $scope.search_to_date = '';
            $scope.search_created_by = '';
            $scope.groupListData = {groupArr: [], allchecked: false};
            var groupsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_from_date: $scope.search_from_date,
                search_to_date: $scope.search_to_date,
                search_created_by: $scope.search_created_by
            };
            $scope.getGroupsData(groupsData);
        };

        $scope.$watch('currentPage', function (pageNo) {
            if ($scope.search_from_date != '' && $scope.search_from_date != undefined) {
                var from_date = new Date($scope.search_from_date);
                from_date = from_date.toLocaleDateString();
            }
            if ($scope.search_to_date != '' && $scope.search_to_date != undefined) {
                var to_date = new Date($scope.search_to_date);
                to_date = to_date.toLocaleDateString();
            }
            var groupsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_from_date: from_date,
                search_to_date: to_date,
                search_created_by: $scope.search_created_by
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getGroupsData(groupsData);
            //or any other code here
        });

        /*
        * @description
        Grid Option*/
        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';

            if ($scope.search_from_date != '' && $scope.search_from_date != undefined) {
                var from_date = new Date($scope.search_from_date);
                from_date = from_date.toLocaleDateString();
            }
            if ($scope.search_to_date != '' && $scope.search_to_date != undefined) {
                var to_date = new Date($scope.search_to_date);
                to_date = to_date.toLocaleDateString();
            }

            var groupsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_from_date: from_date,
                search_to_date: to_date,
                search_created_by: $scope.search_created_by
            };
            $scope.getGroupsData(groupsData);
        };

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            if ($scope.search_from_date != '' && $scope.search_from_date != undefined) {
                var from_date = new Date($scope.search_from_date);
                from_date = from_date.toLocaleDateString();
            }
            if ($scope.search_to_date != '' && $scope.search_to_date != undefined) {
                var to_date = new Date($scope.search_to_date);
                to_date = to_date.toLocaleDateString();
            }

            var groupsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_from_date: from_date,
                search_to_date: to_date,
                search_created_by: $scope.search_created_by
            };
            $scope.getGroupsData(groupsData);
            var pagesizeelm = angular.element( document.querySelectorAll( '#pagesize' ) );
            angular.forEach(pagesizeelm,function(val,key){
                pagesizeelm[key].blur();
            });
        };


        $scope.toggleState = function () {
            $scope.state = !$scope.state;
        };

        $scope.checkAll = function () {
            if ($scope.groupListData.allchecked) {
                _.each($scope.groupsList, function (element) {
                    var isavl = true;
                    _.each($scope.groupListData.groupArr, function (obj) {
                        if (obj.id === element.id) {
                            isavl = false;
                        }
                    });
                    if (isavl) {
                        $scope.groupListData.groupArr.push(element);
                    }
                });
            } else {
                var arr = [];
                angular.forEach($scope.groupListData.groupArr, function (element) {
                    if ($scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.groupListData.groupArr = arr;
            }
        };

        $scope.uncheckMain = function () {
            $scope.groupListData.allchecked = false;
        };


        $scope.addSelectedGroup = function () {
            if ($scope.groupListData.groupArr.length > 0) {
                angular.forEach($scope.groupListData.groupArr, function (element) {

                    var idCheck = _.find($scope.selectedGroupList, function (value) {
                        return value.id == element.id;
                    });
                    if (idCheck === undefined) {
                        $scope.selectedGroupList.push(element.id);
                    }
                });
                $scope.state = true;
            }
        };

        /*
        * @description
        Delete Group */
        $scope.deleteSelectedGroup = function () {
            if ($scope.groupListData.groupArr.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/groups/publisherGroupDelete.html',
                    controller: 'groupDeleteCtrl',
                    resolve: {
                        GroupData: function () {
                            return {groupArr: $scope.groupListData.groupArr};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.deleteGroupArr(dataObj);
                }, function () {
                    console.log('error');
                });
            } else {
                 var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL')};
                        }
                    }
                });
                modalInstance.result.then(function () {

                }, function () {
                    console.log('cancle');
                });
            }
        };

        $scope.deleteGroupRow = function (groupObj) {
            var arr = [];
            arr.push({id: groupObj.id});
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function () {
                        return {ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('CATALOG_REMOVE_CONFIRMATION_LABEL')};
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                var dataObj = {groupArr: arr};
                $scope.deleteGroupArr(dataObj);
            }, function () {
                console.log('error');
            });
        };

        $scope.deleteGroupArr = function (dataObj) {
            var groupIdArr = [];
            angular.forEach(dataObj.groupArr, function (value, key) {
                groupIdArr.push(value.id);
            });
            var groupData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                groupArr: groupIdArr
            };
            groupService.deleteGroup(groupData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.groupListData.groupArr = [];
                            $scope.getGroups();
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        /*
        * @description
        End Delete Group */
    }]);

angular.module('OneWorld').controller('groupDeleteCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'GroupData', 'localStorageService',
    function ($scope, $rootScope, $uibModalInstance, GroupData, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.ModalTitle = 'Confirmation';
        $scope.groupDelete = function () {
            $uibModalInstance.close({groupArr: GroupData.groupArr});
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.rowDelete = function () {
            $uibModalInstance.close({groupArr: GroupData.groupObj});
        };
    }]);