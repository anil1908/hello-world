'use strict';
App.factory('groupService', ['$http', '$q', function ($http, $q) {
        var groupServiceFactory = {};
        /**
         * @description
         * # group list
         */
        var _getGroupsList = function (groupsData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/group/get_group_list',
                method: "POST",
                data: groupsData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # group data
         */
        var _getGroupData = function (BookGroupData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/group/get_group',
                method: "POST",
                data: BookGroupData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # Create group
         */
        var _createGroup = function (bookGroupData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/group/create_group',
                method: "POST",
                data: bookGroupData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # delete group
         */
        var _deleteGroup = function (groupData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/group/delete_group',
                method: "POST",
                data: groupData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # group detail
         */
        var _getGroupDetails = function (groupData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/group/group_details',
                method: "POST",
                data: groupData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # delete group book
         */
        var _deleteGroupBookDetails = function (groupData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/group/delete_group_books',
                method: "POST",
                data: groupData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # edit group
         */
        var _editGroupDetail = function (groupData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/group/update_group_name',
                method: "POST",
                data: groupData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

         /**
         * @description
         * # get group row
         */
        var _getGroupRow = function (groupData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/group/get_group_name_by_id',
                method: "POST",
                data: groupData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        groupServiceFactory.getGroupsList = _getGroupsList;
        groupServiceFactory.getGroupData = _getGroupData;
        groupServiceFactory.createGroup = _createGroup;
        groupServiceFactory.deleteGroup = _deleteGroup;
        groupServiceFactory.getGroupDetails = _getGroupDetails;
        groupServiceFactory.deleteGroupBookDetails = _deleteGroupBookDetails;
        groupServiceFactory.editGroupDetail = _editGroupDetail;
        groupServiceFactory.getGroupRow = _getGroupRow;
        return groupServiceFactory;
    }]);