'use strict';
angular.module('OneWorld').controller('dashboardController', ['$scope', '$rootScope', 'dashboardService', '$location', '$sessionStorage', 'localStorageService',
    function ($scope, $rootScope, dashboardService, $location, $sessionStorage, localStorageService) {
        $scope.userData = $rootScope.userData;
        $scope.dashboardData = {
            name: '',
            usertype: '',
            photo: ''
        };
         /*
         * @description
         * company detail */
        $scope.companyAccountDetail = function () {
            var TokenData = localStorageService.get('authorizeTokenDetail');
            $scope.usertype = (TokenData !== null) ? parseInt(TokenData.usertype) : '';
            var companyDetail = {access_token: TokenData.access_token, language: $rootScope.language, usertype: $scope.usertype}
            dashboardService.getcompanyDetail(companyDetail)
                    .then(function (data) {
                        $rootScope.userData = $scope.userData;
                        $rootScope.$watch($rootScope.userData);
                        if (data.error <= 0) {
                            $scope.dashboardData = data.response;
                            $scope.isImage = data.is_image;
                            $scope.isError = false;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        $scope.companyAccountDetail();
    }]);