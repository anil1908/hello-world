'use strict';
App.factory('dashboardService', ['$http', '$q', function ($http, $q) {
        var dashboardServiceFactory = {};
        /**
         * @description
         * # company detail
         */
        var _getcompanyDetail = function (userDetail) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/dashboard/get_dashboard',
                method: "POST",
                data: userDetail,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        dashboardServiceFactory.getcompanyDetail = _getcompanyDetail;
        return dashboardServiceFactory;
    }]);