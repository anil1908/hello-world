'use strict';
angular.module('OneWorld').controller('loginController', ['$scope', '$rootScope', '$sessionStorage', '$translate', '$location', 'authService', 'localStorageService', 'Idle',
    function($scope, $rootScope, $sessionStorage, $translate, $location, authService, localStorageService, Idle) {
        $sessionStorage.contentDisplay = {
            signinMenu: false,
            signupMenu: true,
            userAccount: false,
            menuTab: false,
            purchaseTab: false,
            usertype: ''
        };
        $rootScope.contentDisplay = $sessionStorage.contentDisplay;
        $scope.isSubmitted = false;
        $scope.forgetSubmitted = false;
        $scope.signinblock = true;
        $scope.loginData = {
            userName: "",
            password: ""
        };
        $scope.message = "";
        $scope.isMessage = false;
        $scope.myInterval = 10002;
        $scope.signin = { email: '', password: '' };
        $scope.slides = [];
        var currIndex = 0;
        var dashboarName = '';
        var sessionErr = localStorageService.get('sessionTimeoutError');
        $rootScope.error_no = (sessionErr !== undefined && sessionErr !== null && sessionErr != '') ? 2 : '';
        localStorageService.remove('sessionTimeoutError');
        /*
        * @description
         slider option*/
        $scope.addSlide = function() {
            $scope.slides.push({
                image: 'assets/images/img-publisher.png',
                titletext: ['Publishers', 'Retailers'][$scope.slides.length % 2],
                text: ['Make your ebook catalog available to thousands of outlets worldwide under the terms you dictate', 'Easily Sell ebooks and related content on your site, blog or social media'][$scope.slides.length % 2],
                id: currIndex++
            });
        };
        for (var i = 0; i < 2; i++) {
            $scope.addSlide();
        }
        /*
        * @description
         End slider option*/
        $scope.activate_message = ($rootScope.message) ? $rootScope.message : false;
        $scope.error_message = ($rootScope.errmessage) ? $rootScope.errmessage : false;
        $rootScope.errmessage = '';
        $scope.loginData = { email: '', password: '' };
        $scope.forgetData = { email: '' };
        /*
        * @description
        End Home Slider*/
        $scope.goHome = function() {
            $location.path('/');
        };
        /*
       * @description
       login config*/
        $scope.login = function() {
            if ($scope.signin.$valid) {
                $scope.loginData.language = $rootScope.language;
                authService.login($scope.loginData)
                    .then(function(data) {
                            if (data.error <= 0) {
                                Idle.watch();
                                $rootScope.error_no = '';
                                dashboarName = (data.usertype == 1) ? 'dashboard' : 'retailerdashboard';
                                if (data.invited_by > 0) {
                                    $location.path('/' + dashboarName);
                                } else {
                                    if (data.usertype === 3) {
                                        $location.path('/userselection');
                                    } else {
                                        if (data.logins > 1) {
                                            $location.path('/' + dashboarName);
                                        } else {
                                            $location.path('/userselection');
                                        }
                                    }
                                }
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.activate_message = '';
                                $scope.message = data.errorMsg;
                            }
                        },
                        function(err) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.activate_message = '';
                        });
            } else {
                $scope.isSubmitted = true;
            }
        };
        $scope.changeTab = function(status) {
            $scope.signinblock = status;
            $scope.loginData = { email: '', password: '' };
            $scope.forgetData = { email: '' };
            $scope.forgetSubmitted = false;
        };
        /*
       * @description
       forgetPassword config*/
        $scope.forgetPassword = function() {
            if ($scope.forgetpassword.$valid) {
                $scope.forgetData.language = $rootScope.language;
                authService.forgetPassword($scope.forgetData)
                    .then(function(data) {
                            if (data.error <= 0) {
                                $scope.signinblock = true;
                                $scope.isError = false;
                                $scope.activate_message = data.msg;
                                $scope.forgetData = { email: '' };
                            } else {
                                $scope.isError = true;
                                $scope.activate_message = false;
                                $scope.message = data.errorMsg;
                            }
                        },
                        function(err) {
                            $scope.isError = true;
                            $scope.activate_message = false;
                        });
            } else {
                $scope.forgetSubmitted = true;
            }
        };
        $scope.authentication = authService.authentication;
    }
]);