'use strict';
App.factory('widgetsService', ['$http', '$q', 'localStorageService',
    function ($http, $q, localStorageService) {
        var widgetsServiceFactory = {};
         /**
         * @description
         * # get book detail
         */
        var _getBooksDetail = function (bookData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/retailer_catalog/get_retailer_catalog_by_id',
                method: "POST",
                data: bookData
            })
                    .success(function (response) {
                        deferred.resolve(response);
                    }).error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * @description
         * # get widget data
         */
        var _getWidgetList  = function(widgetsData){
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_widget/get_my_widget_list',
                method: "POST",
                data: widgetsData
            })
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * @description
         * # create widget
         */
        var _createwidget  = function(widgetsData){
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_widget/create_my_widget',
                method: "POST",
                data: widgetsData
            })
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * @description
         * # delete widget
         */
        var _deleteWidget  = function(widgetsData){
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_widget/delete_widget',
                method: "POST",
                data: widgetsData
            })
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var _getWidgetDetail = function(widgetsData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_widget/get_widget_details_by_id',
                method: "POST",
                data: widgetsData
            })
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        var _updatewidget = function(widgetsData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_widget/update_my_widget',
                method: "POST",
                data: widgetsData
            })
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        var _getMylistBooksDetail = function(widgetsData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_list/get_my_lists_book_details_by_id',
                method: "POST",
                data: widgetsData
            })
            .success(function (response) {
                deferred.resolve(response);
            })
            .error(function (err, status) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        widgetsServiceFactory.getBooksDetail = _getBooksDetail;
        widgetsServiceFactory.getWidgetList  = _getWidgetList;
        widgetsServiceFactory.createwidget   = _createwidget;
        widgetsServiceFactory.deleteWidget   = _deleteWidget;
        widgetsServiceFactory.getWidgetDetail= _getWidgetDetail;
        widgetsServiceFactory.updatewidget   = _updatewidget;
        widgetsServiceFactory.getMylistBooksDetail = _getMylistBooksDetail;
        return widgetsServiceFactory;
    }]);