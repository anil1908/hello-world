'use strict';
angular.module('OneWorld').controller('retailerwidgetsController', ['$scope', '$rootScope','$filter','$location','$uibModal', '$sessionStorage', 'localStorageService','widgetsService',
    function ($scope, $rootScope,$filter,$location,$uibModal, $sessionStorage, localStorageService,widgetsService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.widgetsList = [];
        $scope.pageIds = [];
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'created_on',
            sorttype: 'DESC',
            maxsize: 10,
            widget_name : ''
        };
        $scope.widgetsListData = {widgetsArr: [], allchecked: false};

        $scope.isError = ($rootScope.widgetsisError !== undefined) ? $rootScope.widgetsisError : false;
        $scope.isMessage = ($rootScope.widgetsisMessage !== undefined) ? $rootScope.widgetsisMessage : false;
        $scope.message = ($rootScope.widgetsmessage !== undefined) ? $rootScope.widgetsmessage : '';
        /**
        * @description
        * grid Option
        */
       $scope.goBack = function () {
            $location.path('retailerdashboard');
        };
        $scope.checkAll = function () {
            if ($scope.widgetsListData.allchecked) {
                _.each($scope.widgetsList, function (element) {
                    var isavl = true;
                    _.each($scope.widgetsListData.widgetsArr, function (obj) {
                        if (obj.id === element.id) {
                            isavl = false;
                        }
                    });
                    if (isavl) {
                        $scope.widgetsListData.widgetsArr.push(element);
                    }
                });
            } else {
                var arr = [];
                angular.forEach($scope.widgetsListData.widgetsArr, function (element) {
                    if ($scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.widgetsListData.widgetsArr = arr;
            }
        };

        $scope.uncheckMain = function () {
            $scope.widgetsListData.allchecked = false;
        };

        $scope.getWidgets = function () {
            var widgetsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                widget_name : $scope.gridOption.widget_name
            };
            $scope.getWidgetsData(widgetsData);
        };

        $scope.widgetSearch = function(){
            var widgetsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                widget_name : $scope.gridOption.widget_name
            };
            $scope.getWidgetsData(widgetsData);
        };

        $scope.cancelSearch = function () {
            $scope.gridOption.widget_name = '';
            $scope.widgetsListData = {widgetsArr: [], allchecked: false};
            var widgetsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                widget_name : $scope.gridOption.widget_name
            };
            $scope.getWidgetsData(widgetsData);
        };

        $scope.$watch('currentPage', function (pageNo) {
            var widgetsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                widget_name : $scope.gridOption.widget_name
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getWidgetsData(widgetsData);
            //or any other code here
        });

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var widgetsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
                widget_name : $scope.gridOption.widget_name
            };
            $scope.getWidgetsData(widgetsData);
        };

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var widgetsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                widget_name : $scope.gridOption.widget_name
            };
            $scope.getWidgetsData(widgetsData);
            var pagesizeelm = angular.element( document.querySelectorAll( '#pagesize' ) );
            angular.forEach(pagesizeelm,function(val,key){
                pagesizeelm[key].blur();
            });
        };
        /**
        * @description
        * End grid Option
        */

        /**
        * @description
        * get Widget Data
        */
        $scope.getWidgetsData = function (widgetsData) {
            widgetsData.dataLoader = true;
            widgetsService.getWidgetList(widgetsData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.pageIds = data.ids.split(',');
                            $scope.widgetsListData.allchecked = false;
                            $scope.widgetsList = data.response;
                            $scope.gridOption.filteredItems = data.total_rows;
                            $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                            if ($scope.gridOption.maxsize > 5) {
                                $scope.gridOption.maxsize = 5;
                            }
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                        $rootScope.widgetsmessage = '';
                        $rootScope.widgetsisError = false;
                        $rootScope.widgetsisMessage = false;
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        /**
        * @description
        * delete Widget row
        */
        $scope.deleteWidgetRow = function(widgetObj){
            var arr = [];
            arr.push({id: widgetObj.id});
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function () {
                        return {ModalTitle: "Confirmation", msg: "Are you sure you want to delete the record(s)?"};
                    }
                }
            });
            modalInstance.result.then(function () {
                $scope.deleteWidgetArr(arr);
            }, function () {
                console.log('error');
            });
        };

        $scope.deleteSelectedWidget = function(){
            if ($scope.widgetsListData.widgetsArr.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/maintainbooks/publisherBookDelete.html',
                    controller: 'bookDeleteCtrl',
                    resolve: {
                        BookData: function () {
                            return {bookArr: $scope.widgetsListData.widgetsArr};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.deleteWidgetArr(dataObj.bookArr);
                }, function () {
                    console.log('error');
                });
            } else {
                 var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL')};
                        }
                    }
                });
                modalInstance.result.then(function () {

                }, function () {
                    console.log('cancle');
                });
            }
        };

        $scope.deleteWidgetArr = function(dataObj){
            var widgetIdArr = [];
            angular.forEach(dataObj, function (value, key) {
                widgetIdArr.push(value.id);
            });
            var widgetData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                widgetArr: widgetIdArr
            };

            widgetsService.deleteWidget(widgetData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.widgetsListData = {widgetsArr: [], allchecked: false};
                            $scope.getWidgets();
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });

        };
        /**
        * @description
        * End delete Widget row
        */

         /**
        * @description
        *  Widget Modal
        */
        $scope.widgetPreview = function(id) {
            if(id!==undefined && id!==null && id!==''){
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/retailerwidgets/widgetDetail.html',
                    controller: 'widgetDetailCtrl',
                    windowClass:'widgetdetail',
                    resolve: {
                        widgetData: function () {
                            return {widget_id: id};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.isError = false;
                    $scope.isMessage = true;
                    $scope.message = $filter('translate')('WIDGET_COPY_CLIPBOARD');
                }, function () {
                    console.log('Closed');
                });
            }
        }
}]);

angular.module('OneWorld').controller('bookDeleteCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'BookData', 'localStorageService',
    function ($scope, $rootScope, $uibModalInstance, BookData, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.ModalTitle = 'Confirmation';
        $scope.bookDelete = function () {
            $uibModalInstance.close({bookArr: BookData.bookArr});
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);