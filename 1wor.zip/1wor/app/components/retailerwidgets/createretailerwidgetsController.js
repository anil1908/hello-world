'use strict';
angular.module('OneWorld').controller('createretailerwidgetsController', ['$scope', '$rootScope', '$filter', '$timeout', '$uibModal', '$location', 'localStorageService', 'widgetsService', '$window', 'CURRENCY_ARRAY', 'NgEditor',
    function ($scope, $rootScope, $filter, $timeout, $uibModal, $location, localStorageService, widgetsService, $window, CURRENCY_ARRAY, NgEditor) {
        $scope.sortingLog = [];
        $scope.sortableOptions = {
            update: function(e, ui) {
            var logEntry = $scope.books.map(function(i){
                return i.value;
            }).join(', ');
            $scope.sortingLog.push('Update: ' + logEntry);
            },
            stop: function(e, ui) {
            // this callback has the changed model
            var logEntry = $scope.books.map(function(i){
                return i.value;
            }).join(', ');
            $scope.sortingLog.push('Stop: ' + logEntry);
            }
        };
        var TokenData = localStorageService.get('authorizeTokenDetail');
        var parameter = $location.search();
        $scope.bookArr = [];
        $scope.bundleArr = [];
        $scope.bookPriceArr = [];
        $scope.bundlePriceArr = [];
        $scope.submitData = false;
        $scope.default_markup = 0;
        $scope.editor = new NgEditor({
            top: 0
        });
        $scope.isEditMode = false;
        $scope.isbusiness = false;
        $scope.gridOption = {
            pageStart: 0,
            pageLimit: 10
        }
        $scope.books = [];
        $scope.isscroll = false;
        $scope.widgetTitle = $filter('translate')('CREATE_WIDGET_LABEL');
        $scope.wholesalemodel = [3, 9];
        /**
         * @description
         * get Wisget Data
        */
        $scope.getWidgetDetailData = function (widgetData) {
            if ($scope.isEditMode) {
                widgetsService.getWidgetDetail(widgetData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            if (!$scope.isscroll) {
                                $scope.widgetData = data.response.widgets;
                                $scope.widgetData.widgetiamge = 'assets/images/widget-logo-header.png';
                                if ($scope.widgetData.color == '#ffffff') {
                                    $scope.widgetData.colortype = 'white';
                                }
                                else if ($scope.widgetData.color == '#000000') {
                                    $scope.widgetData.colortype = 'black';
                                }
                                else {
                                    $scope.widgetData.colortype = 'custom';
                                }
                            }
                            $scope.widgetData.widgetiamge = data.widgetiamge;
                            $scope.widgetData.placementlogo = 'TopMiddle'
                            if (data.response.book.length > 0) {
                                angular.forEach(data.response.book, function (val, key) {
                                    this.push(val);
                                }, $scope.books);

                                angular.forEach($scope.books, function (bookval, bookkey) {
                                    var business_arr = [];
                                    var price_arr = {};
                                    var businessArrStatus = {};
                                    if (bookval.business_model !== undefined && bookval.business_model.length > 0) {
                                        angular.forEach(bookval.business_model, function (businessvalue, businesskey) {
                                            if ($scope.wholesalemodel.indexOf(parseInt(businessvalue.id)) >= 0) {
                                                $scope.isbusiness = true;
                                            }
                                            business_arr.push(businessvalue);
                                            businessArrStatus[businessvalue.id] = businessvalue.is_visible;
                                        });
                                    }
                                    if (bookval.price !== undefined && !_.isEmpty(bookval.price)) {
                                        angular.forEach(bookval.price, function (priceval, pricekey) {
                                            $scope.default_markup = priceval.default_markup;
                                            var isvisible = businessArrStatus[priceval.business_model_id];
                                            $scope.books[bookkey]['price'][pricekey]['is_visible'] = isvisible;
                                            price_arr[pricekey] = priceval;
                                            //price_arr.push(priceval);
                                        });
                                    }
                                    if (bookval.book_id !== undefined && bookval.book_id !== null && bookval.book_id !== '') {
                                        $scope.bookArr[bookval.book_id] = business_arr;
                                        $scope.bookPriceArr[bookval.book_id] = price_arr;
                                    }
                                    else {
                                        $scope.bundleArr[bookval.bundle_id] = business_arr;
                                        $scope.bundlePriceArr[bookval.bundle_id] = price_arr;
                                    }
                                });
                                $scope.isscroll = true;
                            }
                        } else {
                            if (data.error == 3) {
                                $rootScope.widgetsmessage = data.errorMsg;
                                $rootScope.widgetsisError = true;
                                $rootScope.widgetsisMessage = false;
                                $location.search({});
                                $location.path('/retailerwidgets');
                            }
                            else {
                                $scope.message = data.errorMsg;
                                $scope.isError = true;
                                $scope.isMessage = false;
                            }
                        }
                    }, function (err, status) {
                        $scope.message = '';
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            }
        };
        /**
         * edit Widget
         */
        if (parameter.id !== undefined && parameter.id !== null && parameter.id !== '') {
            $scope.widgetTitle = $filter('translate')('EDIT_WIDGET_LABEL');
            $scope.isEditMode = true;
            var widgetData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                widget_id: parameter.id,
                pageStart: $scope.gridOption.pageStart,
                pageLimit: $scope.gridOption.pageLimit
            };
            $scope.getWidgetDetailData(widgetData);
        }
        /**
         * create widget on listid
         */
        else if (parameter.list_id !== undefined && parameter.list_id !== null && parameter.list_id !== '') {
            $scope.widgetData = {
                widgetname: '', metadata: 'Below', coversaccross: 2, coversdown: 1,
                coverssize: 'Large', showsearchbox: 1, colortype: 'white', color: '#ffffff',
                placementlogo: 'TopMiddle', hadlinetext: '', widgetiamge: 'assets/images/widget-logo-header.png',
                customcolor: false
            };
            var widgetData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                list_id: parameter.list_id,
                isWidget: true
            };
            widgetsService.getMylistBooksDetail(widgetData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.books = data.response;
                        $scope.widgetData.widgetiamge = data.widgetiamge;
                        if (data.response.length > 0) {
                            angular.forEach(data.response, function (bookval, bookkey) {
                                var ismodel = false;
                                var businessArr = [];
                                var priceArr = {};
                                $scope.default_markup = bookval.default_markup;
                                if (bookval.business_model !== undefined && bookval.business_model.length > 0) {
                                    angular.forEach(bookval.business_model, function (modelval, modelkey) {
                                        businessArr.push({
                                            id: modelval.id,
                                            name: modelval.name,
                                            short_description: modelval.short_description,
                                            is_visible: true
                                        });
                                        if ($scope.wholesalemodel.indexOf(parseInt(modelval.id)) >= 0) {
                                            ismodel = true;
                                            $scope.isbusiness = true;
                                        }
                                    });
                                }
                                if (bookval.price !== undefined && !_.isEmpty(bookval.price)) {
                                    angular.forEach(bookval.price, function (priceval, pricekey) {
                                        var bookpriceArr = {
                                            business_model: priceval.business_model,
                                            business_model_id: priceval.business_model_id,
                                            business_model_name:priceval.business_model_name,
                                            default_markup:priceval.default_markup,
                                            main_price:priceval.main_price,
                                            selling_price:priceval.selling_price,
                                            symbol_val:priceval.symbol_val,
                                            price_val:priceval.price_val,
                                            price: []
                                        };
                                        var channelPrice = [];
                                        var mainsellingprice = ((priceval.price_val * parseFloat(bookval.default_markup)) / 100) + priceval.price_val;
                                        mainsellingprice = mainsellingprice.toFixed(2);
                                        priceval.selling_price = parseFloat(mainsellingprice);
                                        if ($scope.wholesalemodel.indexOf(parseInt(priceval.business_model_id)) >= 0) {
                                            angular.forEach(priceval.price, function (pval, pkey) {
                                                var sellingprice = ((parseFloat(pval.original_digital_list) * parseFloat(bookval.default_markup)) / 100) + parseFloat(pval.original_digital_list);

                                                if(bookval.book_id!=undefined && bookval.book_id!=null && bookval.book_id!=''){
                                                    bookpriceArr.price.push({
                                                        'book_id': bookval.book_id,
                                                        //'channel_id': pricekey,
                                                        'channel_id': pval.channel_id,
                                                        'business_model_id': pval.business_model_id,
                                                        'currency': pval.currency,
                                                        'original_digital_list': pval.original_digital_list,
                                                        'currency_id': pval.currency_id,
                                                        'currency_symbol': pval.currency_symbol,
                                                        'selling_price': sellingprice,
                                                        'custom_selling_price': '',
                                                        'is_custom_price': '',
                                                    });
                                                }
                                                else{
                                                    bookpriceArr.price.push({
                                                        'bundle_id': bookval.bundle_id,
                                                        //'channel_id': pricekey,
                                                        'channel_id': pval.channel_id,
                                                        'business_model_id': pval.business_model_id,
                                                        'currency': pval.currency,
                                                        'original_digital_list': pval.original_digital_list,
                                                        'currency_id': pval.currency_id,
                                                        'currency_symbol': pval.currency_symbol,
                                                        'selling_price': parseFloat(sellingprice),
                                                        'custom_selling_price': '',
                                                        'is_custom_price': ''
                                                    });
                                                }

                                            });

                                            priceArr[pricekey] = bookpriceArr;
                                            channelPrice = bookpriceArr.price;
                                        }
                                        else {
                                            angular.forEach(priceval.price, function (pval, pkey) {
                                                var sellingprice = pval.original_digital_list;

                                                if(bookval.book_id!=undefined && bookval.book_id!=null && bookval.book_id!=''){

                                                    channelPrice.push({
                                                        'book_id': bookval.book_id,
                                                        //'channel_id': pricekey,
                                                        'channel_id': pval.channel_id,
                                                        'business_model_id': pval.business_model_id,
                                                        'currency': pval.currency,
                                                        'original_digital_list': pval.original_digital_list,
                                                        'currency_id': pval.currency_id,
                                                        'currency_symbol': pval.currency_symbol,
                                                        'selling_price': sellingprice,
                                                        'custom_selling_price': '',
                                                        'is_custom_price': '',
                                                    });
                                                }
                                                else{
                                                    channelPrice.push({
                                                        'bundle_id': bookval.bundle_id,
                                                        //'channel_id': pricekey,
                                                        'channel_id': pval.channel_id,
                                                        'business_model_id': pval.business_model_id,
                                                        'currency': pval.currency,
                                                        'original_digital_list': pval.original_digital_list,
                                                        'currency_id': pval.currency_id,
                                                        'currency_symbol': pval.currency_symbol,
                                                        'selling_price': sellingprice,
                                                        'custom_selling_price': '',
                                                        'is_custom_price': '',
                                                    });
                                                }

                                            });
                                        }
                                        $scope.books[bookkey]['price'][pricekey]['is_visible'] = true;
                                        $scope.books[bookkey]['price'][pricekey]['price'] = channelPrice;
                                    });
                                }
                                if (bookval.book_id !== undefined && bookval.book_id !== null && bookval.book_id !== '') {
                                    $scope.bookArr[bookval.book_id] = businessArr;
                                }
                                else {
                                    $scope.bundleArr[bookval.bundle_id] = businessArr;
                                }
                                if (ismodel) {
                                    if (bookval.book_id !== undefined && bookval.book_id !== null && bookval.book_id !== '') {
                                        $scope.bookPriceArr[bookval.book_id] = priceArr;
                                    }
                                    else {
                                        $scope.bundlePriceArr[bookval.bundle_id] = priceArr;
                                    }
                                }
                            });
                        }
                    } else {
                        $scope.message = data.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                }, function (err, status) {
                    $scope.message = '';
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        }
        /**
         * add Widget
         */
        else {
            var books = cookies.get('retailer_bid');
            var bundle = cookies.get('retailer_bundleid');
            $scope.widgetData = {
                widgetname: '', metadata: 'Below', coversaccross: 2, coversdown: 2,
                coverssize: 'Large', showsearchbox: 1, colortype: 'white', color: '#ffffff',
                placementlogo: 'TopMiddle', hadlinetext: '', widgetiamge: 'assets/images/widget-logo-header.png',
                customcolor: false
            };
            /**
            * get Books list
            */
            if ((books !== undefined && books !== null && books !== '') || (bundle !== undefined && bundle !== '' && bundle !== null)) {
                var widgetData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    isWidget: true,
                    book_id: books.toString(),
                    bundle_id: bundle.toString()
                };
                widgetsService.getBooksDetail(widgetData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.books = data.response;
                            $scope.widgetData.widgetiamge = data.widgetiamge;
                            if (data.response.length > 0) {
                                angular.forEach(data.response, function (bookval, bookkey) {
                                    var ismodel = false;
                                    var businessArr = [];
                                    var priceArr = {};
                                    $scope.default_markup = bookval.default_markup;
                                    if (bookval.business_model !== undefined && bookval.business_model.length > 0) {
                                        angular.forEach(bookval.business_model, function (modelval, modelkey) {
                                            businessArr.push({
                                                id: modelval.id,
                                                name: modelval.name,
                                                short_description: modelval.short_description,
                                                is_visible: true
                                            });
                                            if ($scope.wholesalemodel.indexOf(parseInt(modelval.id)) >= 0) {
                                                ismodel = true;
                                                $scope.isbusiness = true;
                                            }
                                        });
                                    }
                                    angular.forEach(bookval.price, function (priceval, pricekey) {
                                        var bookpriceArr = {
                                            business_model: priceval.business_model,
                                            business_model_id: priceval.business_model_id,
                                            business_model_name:priceval.business_model_name,
                                            default_markup:priceval.default_markup,
                                            main_price:priceval.main_price,
                                            selling_price:priceval.selling_price,
                                            symbol_val:priceval.symbol_val,
                                            price_val:priceval.price_val,
                                            price: []
                                        };
                                        var channelPrice = [];
                                        var mainsellingprice = ((priceval.price_val * parseFloat(bookval.default_markup)) / 100) + priceval.price_val;
                                        mainsellingprice = mainsellingprice.toFixed(2);
                                        priceval.selling_price = parseFloat(mainsellingprice);
                                        if ($scope.wholesalemodel.indexOf(parseInt(priceval.business_model_id)) >= 0) {
                                            angular.forEach(priceval.price, function (pval, pkey) {
                                                var sellingprice = ((parseFloat(pval.original_digital_list) * parseFloat(bookval.default_markup)) / 100) + parseFloat(pval.original_digital_list);
                                                if (CURRENCY_ARRAY.indexOf(pval.currency) <= 0) {
                                                    sellingprice = sellingprice.toFixed(2);
                                                }
                                                else {
                                                    sellingprice = sellingprice.toFixed(0);
                                                }

                                                if(bookval.book_id!=undefined && bookval.book_id!=null && bookval.book_id!=''){
                                                    bookpriceArr.price.push({
                                                        'book_id': bookval.book_id,
                                                        'channel_id': pval.channel_id,
                                                        'business_model_id': pval.business_model_id,
                                                        'currency': pval.currency,
                                                        'original_digital_list': pval.original_digital_list,
                                                        'currency_id': pval.currency_id,
                                                        'currency_symbol': pval.currency_symbol,
                                                        'selling_price': parseFloat(sellingprice),
                                                        'custom_selling_price': '',
                                                        'is_custom_price': ''
                                                    });
                                                }
                                                else{
                                                    bookpriceArr.price.push({
                                                        'bundle_id': bookval.bundle_id,
                                                        'channel_id': pval.channel_id,
                                                        'business_model_id': pval.business_model_id,
                                                        'currency': pval.currency,
                                                        'original_digital_list': pval.original_digital_list,
                                                        'currency_id': pval.currency_id,
                                                        'currency_symbol': pval.currency_symbol,
                                                        'selling_price': parseFloat(sellingprice),
                                                        'custom_selling_price': '',
                                                        'is_custom_price': ''
                                                    });
                                                }

                                            });
                                            priceArr[pricekey] = bookpriceArr;
                                            //priceArr.push(bookpriceArr);
                                            channelPrice = bookpriceArr.price;
                                        }
                                        else {
                                            angular.forEach(priceval.price, function (pval, pkey) {
                                                var sellingprice = pval.original_digital_list;
                                                if(bookval.book_id!=undefined && bookval.book_id!=null && bookval.book_id!=''){
                                                    channelPrice.push({
                                                        'book_id': bookval.book_id,
                                                        'channel_id': pval.channel_id,
                                                        'business_model_id': pval.business_model_id,
                                                        'currency': pval.currency,
                                                        'original_digital_list': pval.original_digital_list,
                                                        'currency_id': pval.currency_id,
                                                        'currency_symbol': pval.currency_symbol,
                                                        'selling_price': sellingprice,
                                                        'custom_selling_price': '',
                                                        'is_custom_price': '',
                                                    });
                                                }
                                                else{
                                                    channelPrice.push({
                                                        'bundle_id': bookval.bundle_id,
                                                        'channel_id': pval.channel_id,
                                                        'business_model_id': pval.business_model_id,
                                                        'currency': pval.currency,
                                                        'original_digital_list': pval.original_digital_list,
                                                        'currency_id': pval.currency_id,
                                                        'currency_symbol': pval.currency_symbol,
                                                        'selling_price': sellingprice,
                                                        'custom_selling_price': '',
                                                        'is_custom_price': '',
                                                    });
                                                }

                                            });
                                        }
                                        $scope.books[bookkey]['price'][pricekey]['is_visible'] = true;
                                        $scope.books[bookkey]['price'][pricekey]['price'] = channelPrice;
                                    });


                                if (bookval.book_id !== undefined && bookval.book_id !== null && bookval.book_id !== '') {
                                    $scope.bookArr[bookval.book_id] = businessArr;
                                }
                                else {
                                    $scope.bundleArr[bookval.bundle_id] = businessArr;
                                }

                               //     $scope.bookArr[(bookval.book_id!=undefined && bookval.book_id!=null && bookval.book_id!='')?bookval.book_id:bookval.bundle_id] = businessArr;


                                    if (ismodel) {
                                        if(bookval.book_id!=undefined && bookval.book_id!=null && bookval.book_id!=''){
                                            $scope.bookPriceArr[bookval.book_id] = priceArr;
                                        }
                                        else{
                                            $scope.bundlePriceArr[bookval.bundle_id] = priceArr;
                                        }
                                    }
                                });
                            }
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    })
                    .catch(function () {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            }
        }

        /**
         * @description
         * paging list
        */
        $scope.pagingList = function () {
            $scope.gridOption.pageStart = ($scope.gridOption.pageStart + $scope.gridOption.pageLimit);
            var widgetData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                widget_id: parameter.id,
                pageStart: $scope.gridOption.pageStart,
                pageLimit: $scope.gridOption.pageLimit
            };
            $scope.getWidgetDetailData(widgetData);
        };

        //$scope.ulbooks =  angular.element(document.getElementById('booksul'));
        /**
         * @description
         * back to list
        */
        $scope.goBack = function () {
            $location.path('/retailerwidgets');
        };
        /**
         * color
         */
        $scope.colorChange = function () {
            if ($scope.widgetData.colortype == 'white') {
                $scope.widgetData.color = '#ffffff';
            }
            if ($scope.widgetData.colortype == 'black') {
                $scope.widgetData.color = '#000000';
            }
        };

        /**
         * book detail popup
         */
        $scope.bookDetailModel = function (book, index) {
            var isbussiness_model = false;
            angular.forEach($scope.bookArr, function (mval, mkey) {
                if (mkey == book.book_id) {
                    angular.forEach(mval, function (saleval, salekey) {
                        if ($scope.wholesalemodel.indexOf(parseInt(saleval.id)) >= 0) {
                            isbussiness_model = true;
                        }
                    })
                }
            })
            var bookDataObj = {
                book_id: book.book_id,
                bookDetail: book,
                isbussiness_model: isbussiness_model,
                bussinessArr: (isbussiness_model) ? $scope.bookArr[book.book_id] : [],
                bookpriceArr: (isbussiness_model) ? $scope.bookPriceArr[book.book_id] : [],
                default_markup: $scope.default_markup
            }
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/retailerwidgets/widgetBookDetail.html',
                controller: 'bookDetailCtrl',
                resolve: {
                    bookData: function () {
                        return { bookDetail: bookDataObj, type: 'widget' };
                    }
                }
            });
            modalInstance.result.then(function (bookData) {
                $location.hash('');
                if(isbussiness_model){
                    angular.forEach($scope.books, function (bval, bkey) {
                        if (bval.book_id!==undefined && bval.book_id == bookData.bookObj.book_id) {
                            var businessArr = {};
                            angular.forEach(bookData.bookObj.bussinessArr, function (busval, buskey) {
                                businessArr[busval.id] = busval.is_visible;
                            })
                            angular.forEach(bval.price, function (pval, pkey) {
                                var isvisible = businessArr[pval.business_model_id];
                                $scope.books[bkey]['price'][pkey]['is_visible'] = isvisible;
                            });
                        }
                    });
                    if (bookData.saveWidget && bookData.isPriceUpdate) {

                        var priceArr = [];
                        angular.forEach($scope.bookPriceArr[bookData.bookObj.book_id], function (bval, bkey) {
                            $scope.books[index]['price'][bkey]['main_price'] = bval.symbol_val+ ' '+bval.price[0].selling_price + ' '+bval.business_model_name;
                            $scope.books[index]['price'][bkey]['selling_price'] = bval.price[0].selling_price;
                        });
                        $scope.bookPriceArr[bookData.bookObj.book_id] = $scope.bookPriceArr[bookData.bookObj.book_id];
                        $scope.bookArr[bookData.bookObj.book_id] = bookData.bookObj.bussinessArr;
                    }
                    else {
                        $scope.bookArr[bookData.bookObj.book_id] = bookData.bookObj.bussinessArr;
                    }
                }
            }, function (bookData) {
                $location.hash('');
                if(isbussiness_model){
                    var priceObj = {};
                    angular.forEach($scope.books[index]['price'], function (pval, pkey) {
                        if ($scope.wholesalemodel.indexOf(parseInt(pval.business_model_id)) >= 0) {
                            if (pval.price.length > 0) {
                                var parr = [];
                                angular.forEach(pval.price, function (va, ke) {
                                    if (va.selling_price == undefined) {
                                        var sellprice = ((va.original_digital_list * parseFloat($scope.default_markup)) / 100) + va.original_digital_list;
                                        if (CURRENCY_ARRAY.indexOf(va.currency) <= 0) {
                                            sellprice = sellprice.toFixed(2);
                                        }
                                        else {
                                            sellprice = sellprice.toFixed(0);
                                        }
                                        va.selling_price = parseFloat(sellprice);
                                    }
                                    this.push(va);
                                }, parr);
                                pval.price = parr;
                            }
                            priceObj[pkey] = pval;
                        }
                        else {
                            priceObj[pkey] = pval;
                        }
                        $scope.books[index]['price'];
                    });
                }
            });
        };

        /**
         * bundle Detail Popup
         */
        $scope.bundleDetailModel = function (bundleId, bundleName, index) {
            var isbussiness_model = false;
            angular.forEach($scope.bundleArr, function (mval, mkey) {
                if (mkey == bundleId) {
                    angular.forEach(mval, function (saleval, salekey) {
                        if ($scope.wholesalemodel.indexOf(parseInt(saleval.id)) >= 0) {
                            isbussiness_model = true;
                        }
                    })
                }
            })
            var bundleDataObj = {
                bundle_id: bundleId,
                bundle_name: bundleName,
                isbussiness_model: isbussiness_model,
                bussinessArr: (isbussiness_model) ? $scope.bundleArr[bundleId] : [],
                bookpriceArr: (isbussiness_model) ? $scope.bundlePriceArr[bundleId] : [],
                default_markup: $scope.default_markup
            };
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/retailerwidgets/widgetBundleDetail.html',
                controller: 'bundleDetailCtrl',
                resolve: {
                    bundleData: function () {
                        return { bundleDataObj:bundleDataObj, type: 'widget' };
                    }
                }
            });
            modalInstance.result.then(function (bookData) {
                $location.hash('');
               if(isbussiness_model){
                    angular.forEach($scope.books, function (bval, bkey) {
                        if (bval.bundle_id!==undefined && bval.bundle_id == bookData.bundleData.bundle_id) {
                            var businessArr = {};
                            angular.forEach(bookData.bundleData.bussinessArr, function (busval, buskey) {
                                businessArr[busval.id] = busval.is_visible;
                            })
                            angular.forEach(bval.price, function (pval, pkey) {
                                var isvisible = businessArr[pval.business_model_id];
                                $scope.books[bkey]['price'][pkey]['is_visible'] = isvisible;
                            });
                        }
                    });
                    if (bookData.saveWidget && bookData.isPriceUpdate) {
                        var priceArr = [];
                        angular.forEach($scope.bundlePriceArr[bookData.bundleData.bundle_id], function (bval, bkey) {
                            $scope.books[index]['price'][bkey]['main_price'] = bval.symbol_val+ ' '+bval.price[0].selling_price + ' '+bval.business_model_name;
                            $scope.books[index]['price'][bkey]['selling_price'] = bval.price[0].selling_price;
                            $scope.books[index]['price'][bkey]['price_val'] = bval.price[0].selling_price;

                        });
                        $scope.bundlePriceArr[bookData.bundleData.bundle_id] = $scope.bundlePriceArr[bookData.bundleData.bundle_id];
                        $scope.bundleArr[bookData.bundleData.bundle_id] = bookData.bundleData.bussinessArr;
                    }
                    else {
                        $scope.bundleArr[bookData.bundleData.bundle_id] = bookData.bundleData.bussinessArr;
                    }
               }
            }, function (bookData) {
                $location.hash('');
                if(isbussiness_model){
                    var priceObj = {};
                    angular.forEach($scope.books[index]['price'], function (pval, pkey) {
                        if ($scope.wholesalemodel.indexOf(parseInt(pval.business_model_id)) >= 0) {
                            if (pval.price.length > 0) {
                                var parr = [];
                                angular.forEach(pval.price, function (va, ke) {
                                    if (va.selling_price == undefined) {
                                        var sellprice = ((va.original_digital_list * parseFloat($scope.default_markup)) / 100) + va.original_digital_list;
                                        if (CURRENCY_ARRAY.indexOf(va.currency) <= 0) {
                                            sellprice = sellprice.toFixed(2);
                                        }
                                        else {
                                            sellprice = sellprice.toFixed(0);
                                        }
                                        va.selling_price = parseFloat(sellprice);
                                    }
                                    this.push(va);
                                }, parr);
                                pval.price = parr;
                            }
                            priceObj[pkey] = pval;
                        }
                        else {
                            priceObj[pkey] = pval;
                        }
                        $scope.books[index]['price'];
                    });
                }
            });
        };

        /**
         * @description
         * Save Widget
        */
        $scope.saveWidget = function () {
            if ($scope.createwidget.$valid) {
                var book_arr = [];
                var i = 0;
                angular.forEach($scope.books, function (bookval, bookkey) {
                    var business_model = [];
                    var book_price = [];
                    var is_business_model = false;
                    var bid = (bookval.book_id !== undefined && bookval.book_id !== null && bookval.book_id !== '') ? bookval.book_id:bookval.bundle_id;


                    if (bookval.book_id !== undefined && bookval.book_id !== null && bookval.book_id !== '' && $scope.bookArr[bid] !== undefined && $scope.bookArr[bid] !== null) {
                        angular.forEach($scope.bookArr[bid], function (bookmodelval, bookmodelkey) {
                            if ($scope.wholesalemodel.indexOf(parseInt(bookmodelval.id)) >= 0 && bookmodelval.is_visible) {
                                is_business_model = true;
                            }
                            this.push({
                                business_model_id: bookmodelval.id,
                                is_visible: bookmodelval.is_visible
                            });
                        }, business_model);
                    }
                    if (bookval.bundle_id !== undefined && bookval.bundle_id !== null && bookval.bundle_id !== '' && $scope.bundleArr[bid] !== undefined && $scope.bundleArr[bid] !== null) {
                        angular.forEach($scope.bundleArr[bid], function (bookmodelval, bookmodelkey) {
                            if ($scope.wholesalemodel.indexOf(parseInt(bookmodelval.id)) >= 0 && bookmodelval.is_visible) {
                                is_business_model = true;
                            }
                            this.push({
                                business_model_id: bookmodelval.id,
                                is_visible: bookmodelval.is_visible
                            });
                        }, business_model);
                    }



                    if (bookval.book_id !== undefined && bookval.book_id !== null && bookval.book_id !== '' && $scope.bookPriceArr[bid] !== undefined && $scope.bookPriceArr[bid] !== null) {
                        angular.forEach($scope.bookPriceArr[bid], function (bookpriceval, bookpricekey) {
                            angular.forEach(bookpriceval.price, function (priceval, pricekey) {
                                this.push(priceval);
                            }, book_price);
                        });
                    }
                    if (bookval.bundle_id !== undefined && bookval.bundle_id !== null && bookval.bundle_id !== '' && $scope.bundlePriceArr[bid] !== undefined && $scope.bundlePriceArr[bid] !== null) {
                        angular.forEach($scope.bundlePriceArr[bid], function (bookpriceval, bookpricekey) {
                            angular.forEach(bookpriceval.price, function (priceval, pricekey) {
                                this.push(priceval);
                            }, book_price);
                        });
                    }


                    this.push({
                        book_id: (bookval.book_id !== undefined && bookval.book_id !== null) ? bookval.book_id : '',
                        bundle_id: (bookval.bundle_id !== undefined && bookval.bundle_id !== null) ? bookval.bundle_id : '',
                        is_business_model: is_business_model,
                        sequence: ++i,
                        business_model: business_model,
                        book_price: book_price
                    });
                }, book_arr);
                var widgetData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    widgets: $scope.widgetData,
                    bookArr: book_arr,
                };
                widgetsService.createwidget(widgetData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            cookies.set('retailer_bid', []);
                            cookies.set('retailer_bundleid', []);
                            var modalInstance = $uibModal.open({
                                animation: true,
                                templateUrl: 'app/components/retailerwidgets/widgetCode.html',
                                controller: 'widgetCodeCtrl',
                                resolve: {
                                    widgetData: function () {
                                        return { widgetData: widgetData, widget_id: data.widget_id };
                                    }
                                }
                            });
                            modalInstance.result.then(function (bookData) {
                                $rootScope.widgetsmessage = $filter('translate')('WIDGET_COPY_CLIPBOARD');
                                $rootScope.widgetsisError = false;
                                $rootScope.widgetsisMessage = true;
                                $location.path('/retailerwidgets');
                            }, function () {

                            });
                        } else {
                            $window.scrollTo(0, 0);
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    },
                    function (err, status) {
                        $window.scrollTo(0, 0);
                        $scope.message = '';
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            }
            else {
                $window.scrollTo(0, 0);
                $scope.submitData = true;
            }
        };

        /**
         * @description
         * Edit  Widget
        */
        $scope.updateWidget = function () {
            if ($scope.createwidget.$valid) {
                var book_arr = [];
                var bookIdArr = [];
                var bundleIdArr = [];
                var i = 0;
                angular.forEach($scope.books, function (bookval, bookkey) {
                    var business_model = [];
                    var book_price = [];
                    var is_business_model = false;
                    if(bookval.book_id !== undefined && bookval.book_id !== null && bookval.book_id !== ''){
                        bookIdArr.push(bookval.book_id);
                    }
                    else{
                        bundleIdArr.push(bookval.bundle_id);
                    }

                    var bid = (bookval.book_id !== undefined && bookval.book_id !== null && bookval.book_id !== '') ? bookval.book_id:bookval.bundle_id;



                    if (bookval.book_id !== undefined && bookval.book_id !== null && bookval.book_id !== '' && $scope.bookArr[bid] !== undefined && $scope.bookArr[bid] !== null) {
                        angular.forEach($scope.bookArr[bid], function (bookmodelval, bookmodelkey) {
                            if ($scope.wholesalemodel.indexOf(parseInt(bookmodelval.id)) >= 0 && bookmodelval.is_visible) {
                                is_business_model = true;
                            }
                            this.push({
                                business_model_id: bookmodelval.id,
                                is_visible: bookmodelval.is_visible
                            });
                        }, business_model);
                    }

                    if (bookval.bundle_id !== undefined && bookval.bundle_id !== null && bookval.bundle_id !== '' && $scope.bundleArr[bid] !== undefined && $scope.bundleArr[bid] !== null) {
                        angular.forEach($scope.bundleArr[bid], function (bookmodelval, bookmodelkey) {
                            if ($scope.wholesalemodel.indexOf(parseInt(bookmodelval.id)) >= 0 && bookmodelval.is_visible) {
                                is_business_model = true;
                            }
                            this.push({
                                business_model_id: bookmodelval.id,
                                is_visible: bookmodelval.is_visible
                            });
                        }, business_model);
                    }

                    if (bookval.book_id !== undefined && bookval.book_id !== null && bookval.book_id !== '' && $scope.bookPriceArr[bid] !== undefined && $scope.bookPriceArr[bid] !== null) {
                        angular.forEach($scope.bookPriceArr[bid], function (bookpriceval, bookpricekey) {
                            angular.forEach(bookpriceval.price, function (priceval, pricekey) {
                                this.push(priceval);
                            }, book_price);
                        });
                    }

                    if (bookval.bundle_id !== undefined && bookval.bundle_id !== null && bookval.bundle_id !== '' && $scope.bundlePriceArr[bid] !== undefined && $scope.bundlePriceArr[bid] !== null) {
                        angular.forEach($scope.bundlePriceArr[bid], function (bookpriceval, bookpricekey) {
                            angular.forEach(bookpriceval.price, function (priceval, pricekey) {
                                this.push(priceval);
                            }, book_price);
                        });
                    }


                    this.push({
                        book_id: (bookval.book_id !== undefined && bookval.book_id !== null) ? bookval.book_id : '',
                        bundle_id: (bookval.bundle_id !== undefined && bookval.bundle_id !== null) ? bookval.bundle_id : '',
                        is_business_model: is_business_model,
                        sequence: ++i,
                        business_model: business_model,
                        book_price: book_price
                    });
                }, book_arr);
                var widgetData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    widgets: $scope.widgetData,
                    bookArr: book_arr,
                    widget_id: parameter.id,
                    bundleIdArr:bundleIdArr,
                    bookIdArr:bookIdArr
                };
                widgetsService.updatewidget(widgetData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            cookies.set('retailer_bid', []);
                            cookies.set('retailer_bundleid', []);
                            var modalInstance = $uibModal.open({
                                animation: true,
                                templateUrl: 'app/components/retailerwidgets/widgetCode.html',
                                controller: 'widgetCodeCtrl',
                                resolve: {
                                    widgetData: function () {
                                        return { widgetData: widgetData, widget_id: data.widget_id };
                                    }
                                }
                            });
                            modalInstance.result.then(function (bookData) {
                                $rootScope.widgetsmessage = $filter('translate')('WIDGET_COPY_CLIPBOARD');
                                $rootScope.widgetsisError = false;
                                $rootScope.widgetsisMessage = true;
                                $location.search({});
                                $location.path('/retailerwidgets');
                            }, function () {

                            });
                        } else {
                            $window.scrollTo(0, 0);
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    },
                    function (err, status) {
                        $window.scrollTo(0, 0);
                        $scope.message = '';
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            }
            else {
                $window.scrollTo(0, 0);
                $scope.submitData = true;
            }
        };
        
        
    }]);


