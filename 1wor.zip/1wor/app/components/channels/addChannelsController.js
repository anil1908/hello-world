'use strict';
angular.module('OneWorld').controller('createChannelsController', ['$scope', '$state', '$rootScope', 'channelService', '$uibModal', '$location', '$sessionStorage', 'localStorageService', 'DATE_FORMAT', 'ivhTreeviewMgr', '$timeout', '$filter', 'CURRENCY_ARRAY', '$window', 'COUNTRY_PREFERENCE',
    function ($scope, $state, $rootScope, channelService, $uibModal, $location, $sessionStorage, localStorageService, DATE_FORMAT, ivhTreeviewMgr, $timeout, $filter, CURRENCY_ARRAY, $window, COUNTRY_PREFERENCE) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.format = DATE_FORMAT;
        var parameter = $location.search();
        $scope.channelId = '';
        $scope.totalCountry = 0;
        $scope.selectCountryNo = 0;
        $scope.sortName = 'currency_name';
        $scope.reverse = true;
        $scope.businessCode = {
            'SALE001': 1, 'SALE002': 2, 'SALE003': 3, 'SALE004': 4, 'SALE005': 5,
            'SUB001': 6, 'SUB003': 7, 'BUND001': 8, 'BUND002': 9, 'BUND003': 10,
            'SPEC001': 11, 'SPEC101': 12, 'SPEC002': 13, 'SPEC102': 14, 'SPEC999': 15,
            'ADV001': 16, 'ADV002': 17, 'CLAS001': 18, 'CLAS002': 19, 'CLAS003': 20,
            'LIB001': 21, 'LIB002': 22, 'LIB102': 23, 'LIB003': 24, 'LIB004': 25,
            'LIB005': 26, 'LIB006': 27, 'LIB007': 28
        };
        $scope.disableModel = {
            'SALE001' : ['1','2','3','4','5'],
            'SALE002' : ['1','2','3','4','5'],
            'SALE003' : ['1','2','3','4','5'],
            'SALE004' : ['1','2','3','4','5'],
            'SALE005' : ['1','2','3','4','5'],
            'BUND001' : ['8','9','10'],
            'BUND002' : ['8','9','10'],
            'BUND003' : ['8','9','10'],
            'SUB001' : ['6','7'],
            'SUB003' : ['6','7'],
            'ADV001' : ['16','17'],
            'ADV002' : ['16','17'],
        };

        $scope.unusedBusinessCode = [2, 4, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28];
        $scope.isreload = false;
        $scope.isSubmitted = false;
        $scope.message = '';
        $scope.isError = false;
        $scope.isMessage = false;
        $scope.groupList = [];
        $scope.bussinessModelList = { allBusinessModel: {}, frequentlyUsedModel: {} };
        $scope.regionCountryList = [];
        $scope.whiteretailerList = [];
        $scope.blackretailerList = [];
        $scope.whiteretailerDetailList = [];
        $scope.blackretailerDetailList = [];
        $scope.includeRetailerList = [];
        $scope.excludeRetailerList = [];
        $scope.countryRegionArr = [];
        $scope.currencyList = [];
        $scope.today = new Date();
        $scope.currentTab = 1;
        $scope.submitErr = {
            tab1: false, tab2: false, tab2ErrorMsg: '', tab3: false,
            tab3ErrorMsg: '', tab4: false, tab4ErrorMsg: '', tab5: false, bundle1: false
        };
        $scope.modelDetail = { name: '', description: '' };
        $scope.bookPricingDetail = {};
        $scope.bundlePricingDetail = [];
        $scope.errpayoutDiscount = false;
        $scope.erradjustDiscount = false;
        $scope.retailerErrMesage = false;
        $scope.paydiscount = 0;
        $scope.adjdiscount = 0;
        $scope.businessDesArr = [];
        $scope.activeTab = 'tab1';
        $scope.progressBar = { text: 'Step 1  of 5', width: '20%' };
        $scope.bundle1PriceData = [];
        $scope.bundleDetailExists = false;
        $scope.isRetailerMessage = false;
        $scope.retailermessage = '';
        $scope.activestep = 1;
        /**
         * @description
         * Edit Channel Config
         */
        if (parameter.id !== undefined) {
            $scope.channelId = parameter.id;
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                channel_id: parameter.id
            };
            channelService.getChannelDetail(data)
                .then(function (data) {
                    if (data.error <= 0) {
                        var channelData = data.response;
                        $scope.bundle1PriceData = data.bundleArr;
                        $scope.channelDetail = {
                            name: channelData.name,
                            status: (channelData.status == 1 || (channelData.end_date === null || channelData.end_date === undefined || channelData.end_date === '')) ? true : false,
                            startdate: new Date(channelData.start_date),
                            enddate: (channelData.end_date !== null && channelData.end_date !== undefined && channelData.end_date !== '') ? new Date(channelData.end_date) : '',
                            group_id: channelData.group_id,
                            businessModelId: channelData.business_model_id,
                            business_model_name: channelData.business_model_name,
                            business_model_type: channelData.business_model_type,
                            retailers_list: channelData.retailers_list,
                            frequentlyUsedModel: '',
                            allBusinessModel: '',
                            country_id: [],
                            region_id: '',
                            bundle_currency_code: channelData.bundle_currency_code,
                            payoutDiscount: parseFloat(channelData.payoutDiscount),
                            adjustDiscount: parseFloat(channelData.adjustDiscount),
                            isEditImage: true, old_bundle_image: '', bundle_currency_id: '1',
                            new_group_id: channelData.group_id, chapter_price_prorate: 20, per_page_price_prorate: 20, book_owned_afetr: 110, threshold_payout: 30, per_page_price_currency: '1', payment_to_publisher_each_item_currency: '1', payment_from_publisher_each_item_currency: '1', payment_to_publisher_entire_program_currency: '1', sale004_payoutDiscount: 50, payment_from_publisher_entire_program_currency: '1', limit_ads_to: 10, adv002_adjust_discount_price: 0, clas001_adjust_discount_price: 20, clas003_adjust_discount_price: 120, clas_pay_group_titles_currency: '1', clas_pay_group_titles: 99, lib_adjust_price: 150, lib_less5k_adjust_price: 150, lib_less20k_adjust_price: 200, lib_less50k_adjust_price: 300, lib_less500_adjust_price: 150, lib_less1k_adjust_price: 200, lib_less10k_adjust_price: 300, lib003_price_per_use: 15, lib003_book_purchased_when: 110, lib004_price_per_use: 30, lib004_book_purchased_when: 110, lib005_price_per_use: 30, lib005_book_purchased_when: 110, lib006_price_per_copy: 130, lib007_price_per_copy: 120, book_requires: 0, minimum_payout_price_currency: '1', minimum_payout_price: 0, adv001_payout_discount: 50, adv001_adjust_discount: 0, adv002_payout_discount: 50
                        };
                        if ($scope.channelDetail.retailers_list == 'Blacklist') {
                            $scope.channelDetail.groupOptions = 1;
                        } else if ($scope.channelDetail.retailers_list == 'Whitelist') {
                            $scope.channelDetail.groupOptions = 0;
                        } else {
                            $scope.channelDetail.groupOptions = 2;
                        }
                        $scope.getBundleDetail();
                        $scope.getGroupList(function () {

                        });
                        $scope.getBussinessModelList();
                        $scope.getCountryRegionArr();
                    } else {
                        if (data.error == 3) {
                            $location.search({});
                            $rootScope.channelmessage = data.errorMsg;
                            $rootScope.channelisError = true;
                            $rootScope.channelisMessage = false;
                            $scope.isreload = true;
                            $location.path('/channels');
                        }
                        else {
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }

                    }

                }, function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                })
                .catch(function (err, status) {

                });
        }
        /**
         * @description
         * add Channel Config
         */
        else {
            $scope.channelDetail = {
                name: '', status: true, groupOptions: 3, startdate: new Date(),
                enddate: '', group_id: (parameter.group_id !== undefined && parameter.group_id !== null && parameter.group_id !== '') ? parameter.group_id.toString() : '', frequentlyUsedModel: '',
                allBusinessModel: '', businessModelId: '',
                business_model_type: '', retailers_list: 'All',
                country_id: [], region_id: '', payoutDiscount: 50,
                adjustDiscount: 0, bundle_image: '', admin_bundle_image: '', default_bundle_image: '', bundle_default_image: '', bundle_description: '', bundle_id: '', bundle_name: '', bundle_price: '', isEditImage: '', bundle_currency_id: '1', bundle_currency_code: '', new_group_id: '', chapter_price_prorate: 20, per_page_price_prorate: 20, book_owned_afetr: 110, threshold_payout: 30, per_page_price_currency: '1', payment_to_publisher_each_item_currency: '1', payment_from_publisher_each_item_currency: '1', payment_to_publisher_entire_program_currency: '1', sale004_payoutDiscount: 50, payment_from_publisher_entire_program_currency: '1', limit_ads_to: 10, adv002_adjust_discount_price: 0, clas001_adjust_discount_price: 20, clas003_adjust_discount_price: 120, clas_pay_group_titles_currency: '1', clas_pay_group_titles: 99, lib_adjust_price: 150, lib_less5k_adjust_price: 150, lib_less20k_adjust_price: 200, lib_less50k_adjust_price: 300, lib_less500_adjust_price: 150, lib_less1k_adjust_price: 200, lib_less10k_adjust_price: 300, lib003_price_per_use: 15, lib003_book_purchased_when: 110, lib004_price_per_use: 30, lib004_book_purchased_when: 110, lib005_price_per_use: 30, lib005_book_purchased_when: 110, lib006_price_per_copy: 130, lib007_price_per_copy: 120, book_requires: 0, minimum_payout_price_currency: '1', minimum_payout_price: 0, adv001_payout_discount: 50, adv001_adjust_discount: 0, adv002_payout_discount: 50
            };
        }

        /**
         * @description
         * state change or browser load event
         */
        $scope.$on("$stateChangeStart", function (event, toState, toParams, fromState) {
            if (toState.name == "channels" && $scope.isreload) {
            } else {
                if (!confirm($filter('translate')('CHANNEL_SETUP_NOT_COMPLETE_CONFIRMATION'))) {
                    event.preventDefault();
                }
            }
        });

        $scope.$on('onBeforeUnload', function (e, confirmation) {
            var sessionErr = localStorageService.get('sessionTimeoutError');
            if (sessionErr !== undefined && sessionErr !== null && sessionErr != '') {

            }
            else {
                confirmation.message = $filter('translate')('CHANGES_YOU_MADE_MAYBE_NOT_SAVED');
                e.preventDefault();
            }
        });

        $scope.$on('onUnload', function (e) {
            console.log('leaving page'); // Use 'Preserve Log' option in Console
        });
        /**
         * @description
         * End state change or browser load event
         */

        /**
         * @description
         * move forward or backend
         */
        $scope.goNext = function (i) {
            $scope.progressNext(++i);
        };
        $scope.progressNext = function (step) {
            var isvalid = true;
            var activestep = step;
            if (parseInt($scope.currentTab) === 1 || step > 1) {
                isvalid = $scope['addchanneltab1'].$valid;
                $scope.submitErr['tab' + $scope.currentTab] = true;
                if (!isvalid) {
                    $scope.currentTab = 1;
                    var percent = (1 / 5) * 100;
                    document.getElementById('progress_bar').innerText = 'Step 1  of 5';
                    document.getElementById('progress_bar').style.width = '20%';
                    $scope.activeTab = 'tab1';
                    $timeout(function () {
                        $scope.removeActiveTab(function () {
                            document.getElementById('tab1').className = 'tab navtabs active';
                        });
                    }, 0);
                    return false;
                }
            }
            if (parseInt($scope.currentTab) === 2 || step > 2) {
                if ($scope.channelDetail.allBusinessModel === '' &&
                    $scope.channelDetail.frequentlyUsedModel === '') {
                    isvalid = false;
                    activestep = 2;
                    $scope.submitErr['tab' + $scope.currentTab] = true;
                    $scope.submitErr.tab2ErrorMsg = $filter('translate')('SELECT_MODEL_ERROR');
                    if (step < $scope.currentTab) {
                        activestep = step;
                    }
                    $scope.currentTab = activestep;
                    var percent = (activestep / 5) * 100;
                    document.getElementById('progress_bar').innerText = 'Step ' + activestep + '  of 5';
                    document.getElementById('progress_bar').style.width = percent + '%';
                    $scope.activeTab = 'tab' + activestep;
                    $timeout(function () {
                        $scope.removeActiveTab(function () {
                            document.getElementById('tab' + activestep).className = 'tab navtabs active';
                        });
                    }, 0);
                    return false;
                }
            }
            if (parseInt($scope.currentTab) === 3 || step > 3) {
                $scope.changeModel();
                $scope.channelDetail.country_id = [];
                angular.forEach($scope.countryRegionArr, function (value, key) {
                    if ($scope.countryRegionArr[0]['selected'] !== undefined && $scope.countryRegionArr[0]['selected'] !== null && $scope.countryRegionArr[0]['selected']) {
                        if (value.children !== undefined && value.children.length > 0) {
                            angular.forEach(value.children, function (childvalue, childkey) {
                                var arr = childvalue.id.split('_');
                                $scope.channelDetail.country_id.push(arr[0]);
                            });
                        }
                    }
                    else {
                        if (value.children !== undefined && value.children.length > 0) {
                            angular.forEach(value.children, function (childvalue, childkey) {
                                if (childvalue.selected) {
                                    var arr = childvalue.id.split('_');
                                    $scope.channelDetail.country_id.push(arr[0]);
                                }
                            });
                        }
                    }
                });
                if ($scope.channelDetail.country_id.length <= 0) {//$scope.channelDetail.region_id === '' &&
                    isvalid = false;
                    activestep = 3;
                    $scope.submitErr['tab' + $scope.currentTab] = true;
                    $scope.submitErr.tab3ErrorMsg = $filter('translate')('SELECT_ATLEAST_ONE_COUNTRY_AND_REGION');
                    if (step < $scope.currentTab) {
                        activestep = step;
                    }
                    $scope.currentTab = activestep;
                    var percent = (activestep / 5) * 100;
                    document.getElementById('progress_bar').innerText = 'Step ' + activestep + '  of 5';
                    document.getElementById('progress_bar').style.width = percent + '%';
                    $scope.activeTab = 'tab' + activestep;
                    $timeout(function () {
                        $scope.removeActiveTab(function () {
                            document.getElementById('tab' + activestep).className = 'tab navtabs active';
                        });
                    }, 0);
                    return false;
                } else {
                    if (!$scope.bundleDetailExists && ($scope.channelDetail.businessModelId == $scope.businessCode.BUND001 || $scope.channelDetail.businessModelId == $scope.businessCode.BUND002 || $scope.channelDetail.businessModelId == $scope.businessCode.BUND003)) {
                        $scope.getBundleDetail();
                    }
                    if (step > 3 && step < 5 && $scope.currentTab != 5 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND001 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND002 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND003) {
                        $scope.getConversionData();
                    }
                    if (step > 3 && step < 5 && $scope.currentTab != 5 && $scope.channelDetail.businessModelId == $scope.businessCode.BUND001) {
                        $scope.convertBundlePrice(true);
                    }
                }
            }
            if (parseInt($scope.currentTab) === 4 || step > 4) {
                if ($scope.bundle1PriceData !== undefined && $scope.bundle1PriceData.length <= 0 && $scope.channelDetail.businessModelId == $scope.businessCode.BUND001) {
                    isvalid = false;
                    activestep = 4;
                    $scope.submitErr['tab' + $scope.currentTab] = true;
                    $scope.submitErr.tab4ErrorMsg = $filter('translate')('CURRENCY_NOT_FOUND');
                    if (step < $scope.currentTab) {
                        activestep = step;
                    }
                    $scope.currentTab = activestep;
                    var percent = (activestep / 5) * 100;
                    document.getElementById('progress_bar').innerText = 'Step ' + activestep + '  of 5';
                    document.getElementById('progress_bar').style.width = percent + '%';
                    $scope.activeTab = 'tab' + activestep;
                    $timeout(function () {
                        $scope.removeActiveTab(function () {
                            document.getElementById('tab' + activestep).className = 'tab navtabs active';
                        });
                    }, 0);
                    return false;
                }
                else if ($scope.channelDetail.businessModelId == $scope.businessCode.BUND002 && !$scope.bundle1form.$valid) {
                    isvalid = false;
                    activestep = 4;
                    $scope.submitErr['tab' + $scope.currentTab] = true;
                    if (step < $scope.currentTab) {
                        activestep = step;
                    }
                    $scope.currentTab = activestep;
                    var percent = (activestep / 5) * 100;
                    document.getElementById('progress_bar').innerText = 'Step ' + activestep + '  of 5';
                    document.getElementById('progress_bar').style.width = percent + '%';
                    $scope.activeTab = 'tab' + activestep;
                    $timeout(function () {
                        $scope.removeActiveTab(function () {
                            document.getElementById('tab' + activestep).className = 'tab navtabs active';
                        });
                    }, 0);
                    $scope.submitErr.bundle1 = true;
                    return false;
                }
                else {
                    $scope.getRetailerList();
                }
            }
            if (step === 5 && parseInt($scope.currentTab) !== 4) {
                if ($scope.channelDetail.businessModelId == $scope.businessCode.BUND001) {
                    $scope.convertBundlePrice(true);
                }
                else {
                    $scope.getConversionData();
                }
            }
            if (step < $scope.currentTab || isvalid) {
                $scope.currentTab = step;
                var percent = (parseInt(step) / 5) * 100;
                document.getElementById('progress_bar').innerText = 'Step ' + step + '  of 5';
                document.getElementById('progress_bar').style.width = percent + '%';
                $scope.activeTab = 'tab' + step;
                $scope.submitErr = {
                    tab1: false, tab2: false, tab2ErrorMsg: '',
                    tab3: false, tab3ErrorMsg: '', tab4: false,
                    tab5: false, bundle1: false
                };
                $timeout(function () {
                    $scope.removeActiveTab(function () {
                        document.getElementById('tab' + step).className = 'tab navtabs active';
                    });
                }, 0);
            }
        };

        $scope.goBack = function () {
            $location.search({});
            $location.path('/channels');
        };
        /**
         * get Bundle Detail
         */
        $scope.getBundleDetail = function () {
            var bundledaata = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                channel_id: (parameter.id !== undefined && parameter.id !== null && parameter.id !== '') ? parameter.id : '',
                group_id: $scope.channelDetail.group_id
            }
            channelService.getBundleData(bundledaata)
                .then(function (data) {
                    if (data.error <= 0) {
                        var desArr = data.response.bundle_description.split('|');

                        if (desArr.length > 0) {
                            $scope.channelDetail.bundle_description = '';
                            angular.forEach(desArr, function (val, key) {
                                if (val !== '') {
                                    $scope.channelDetail.bundle_description += val + '\n';
                                }
                            });
                        }
                        $scope.bundleDetailExists = true;
                        $scope.channelDetail.bundle_image = data.response.bundle_image;
                        $scope.channelDetail.admin_bundle_image = data.response.admin_bundle_image;
                        $scope.channelDetail.bundle_default_image = data.response.admin_bundle_image_path;
                        $scope.channelDetail.default_bundle_image = data.response.default_bundle_image;
                        $scope.channelDetail.bundle_currency_id = (data.response.bundle_currency_id != '') ? data.response.bundle_currency_id : $scope.channelDetail.bundle_currency_id;
                        $scope.channelDetail.bundle_id = data.response.bundle_id;
                        $scope.channelDetail.bundle_name = (data.response.bundle_name != '') ? data.response.bundle_name : $scope.channelDetail.bundle_name;
                        $scope.channelDetail.bundle_price = (data.response.bundle_price != '') ? data.response.bundle_price : $scope.channelDetail.bundle_price;



                    } else {
                        $scope.message = data.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                }, function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                })
                .catch(function (err) {

                });
        };
        /**
         * Change Model
         */
        $scope.changeModel = function () {
            var arr = [];
            if ($scope.channelDetail.frequentlyUsedModel !== '') {
                arr = $scope.channelDetail.frequentlyUsedModel.split('=');
            } else {
                arr = $scope.channelDetail.allBusinessModel.split('=');
            }
            $scope.channelDetail.businessModelId = parseFloat(arr[0]);
            $scope.modelDetail = { name: arr[1], shorttext: $scope.businessDesArr[arr[0]].shorttext, description: $scope.businessDesArr[arr[0]].longtext };
        }
        /**
         * @description
         * End move forward or backend
         */
        $scope.removeActiveTab = function (call) {
            for (var i = 1; i <= 5; i++) {
                document.getElementById('tab' + i).className = 'tab navtabs';
            }
            call();
        };
        /**
         * @description
         * Price Conversion
         */
        $scope.getConversionData = function () {
            var arr = [];
            $scope.bundle1PriceData = [];
            if ($scope.channelDetail.frequentlyUsedModel !== '') {
                arr = $scope.channelDetail.frequentlyUsedModel.split('=');
            } else {
                arr = $scope.channelDetail.allBusinessModel.split('=');
            }
            $scope.channelDetail.businessModelId = parseFloat(arr[0]);
            $scope.modelDetail = { name: arr[1], shorttext: $scope.businessDesArr[arr[0]].shorttext, description: $scope.businessDesArr[arr[0]].longtext };
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                group_id: $scope.channelDetail.group_id,
                countryArr: $scope.channelDetail.country_id,
                business_id: $scope.channelDetail.businessModelId,
                channel_id: (parameter.id !== undefined && parameter.id !== null && parameter.id !== '') ? parameter.id : ''
            };

            if ($scope.channelId !== undefined && $scope.channelId !== null && $scope.channelId !== '' && $scope.channelDetail.group_id != $scope.channelDetail.new_group_id) {
                data.group_id = $scope.channelDetail.new_group_id;
                data.new_group_id = $scope.channelDetail.group_id;
            } else {
                data.new_group_id = '';
            }

            channelService.getConversion(data)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.bookPricingDetail = data.response;
                        $scope.paydiscount = parseFloat(data.payoutDiscount);
                    } else {
                        $scope.message = data.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                }, function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                })
                .catch(function (err) {

                });
        };
        /**
         * @description
         * get group list
         */
        $scope.getGroupList = function (callback) {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            channelService.getGroupList(data)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.groupList = data.response;
                        callback();
                    } else {
                        $scope.message = data.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                }, function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                })
                .catch(function (err) {

                });
        };
        /**
         * @description
         * get bussiness list
         */
        $scope.getBussinessModelList = function () {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            channelService.getBussinessModelList(data)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.bussinessModelList = {
                            allBusinessModel: data.response.all_business_model,
                            frequentlyUsedModel: data.response.frequently_used_model
                        };
                        /**
                         * disable Non related model
                         */
                        if($scope.channelId!==undefined && $scope.channelId!==null && $scope.channelId!==''){

                            angular.forEach($scope.bussinessModelList, function (busval, buskey) {
                                if(buskey=='allBusinessModel'){
                                    angular.forEach(busval, function (bvalue, bkey) {
                                        var isenable = _.where(bvalue,{id:$scope.channelDetail.businessModelId});
                                        angular.forEach(bvalue, function (childval, childkey) {
                                            $scope.bussinessModelList[buskey][bkey][childkey]['disabled'] = (isenable.length>0)?false:true;
                                        });
                                    });
                                }
                                else{
                                    $scope.enableId = $scope.disableModel[$scope.channelDetail.business_model_name];
                                    angular.forEach(busval, function (bvalue, bkey) {
                                        angular.forEach(bvalue, function (childval, childkey) {
                                            var enableid = $scope.enableId.indexOf(childval.id);
                                            $scope.bussinessModelList[buskey][bkey][childkey]['disabled'] = (enableid>=0)?false:true;
                                        });
                                    });
                                }
                            });

                        }

                        $scope.businessDesArr = [];
                        if ($scope.channelDetail.business_model_type == 0) {
                            angular.forEach($scope.bussinessModelList.allBusinessModel, function (businessval, businesskey) {
                                angular.forEach(businessval, function (value, key) {
                                    if (value.id == $scope.channelDetail.businessModelId) {
                                        $scope.channelDetail.allBusinessModel = value.id + '=' + value.bm_name;
                                    }
                                    $scope.businessDesArr[value.id] = {
                                        longtext: value.bm_longtext,
                                        shorttext: value.bm_shorttext
                                    };
                                });
                            });
                        } else {
                            if ($scope.channelDetail.business_model_type == 1) {
                                angular.forEach($scope.bussinessModelList.frequentlyUsedModel['YOUR FAVORITES'], function (frequentlyval, frequentlykey) {
                                    if (frequentlyval.id == $scope.channelDetail.businessModelId) {
                                        $scope.channelDetail.frequentlyUsedModel = frequentlyval.id + '=' + frequentlyval.bm_name + '=YOUR FAVORITES';
                                    }
                                    $scope.businessDesArr[frequentlyval.id] = {
                                        longtext: frequentlyval.bm_longtext,
                                        shorttext: frequentlyval.bm_shorttext
                                    };
                                });
                            } else {
                                angular.forEach($scope.bussinessModelList.frequentlyUsedModel['MOST POPULAR'], function (frequentlyval, frequentlykey) {
                                    if (frequentlyval.id == $scope.channelDetail.businessModelId) {
                                        $scope.channelDetail.frequentlyUsedModel = frequentlyval.id + '=' + frequentlyval.bm_name + '=MOST POPULAR';
                                    }

                                    $scope.businessDesArr[frequentlyval.id] = {
                                        longtext: frequentlyval.bm_longtext,
                                        shorttext: frequentlyval.bm_shorttext
                                    };
                                });
                            }
                        }
                    } else {
                        $scope.message = data.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                }, function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                })
                .catch(function (err) {

                });
        };

        $scope.businessModelChange = function () {
            $scope.businessDesArr = [];
            if ($scope.channelDetail.business_model_type == 0) {
                angular.forEach($scope.bussinessModelList.allBusinessModel, function (businessval, businesskey) {
                    angular.forEach(businessval, function (value, key) {
                        if (value.id == $scope.channelDetail.businessModelId) {
                            $scope.channelDetail.allBusinessModel = value.id + '=' + value.bm_name;
                        }
                        $scope.businessDesArr[value.id] = {
                            longtext: value.bm_longtext,
                            shorttext: value.bm_shorttext
                        };
                    });
                });
            } else {
                if ($scope.channelDetail.business_model_type == 1) {
                    angular.forEach($scope.bussinessModelList.frequentlyUsedModel['YOUR FAVORITES'], function (frequentlyval, frequentlykey) {
                        if (frequentlyval.id == $scope.channelDetail.businessModelId) {
                            $scope.channelDetail.frequentlyUsedModel = frequentlyval.id + '=' + frequentlyval.bm_name + '=YOUR FAVORITES';
                        }
                        $scope.businessDesArr[frequentlyval.id] = {
                            longtext: frequentlyval.bm_longtext,
                            shorttext: frequentlyval.bm_shorttext
                        };
                    });
                } else {
                    angular.forEach($scope.bussinessModelList.frequentlyUsedModel['MOST POPULAR'], function (frequentlyval, frequentlykey) {
                        if (frequentlyval.id == $scope.channelDetail.businessModelId) {
                            $scope.channelDetail.frequentlyUsedModel = frequentlyval.id + '=' + frequentlyval.bm_name + '=MOST POPULAR';
                        }

                        $scope.businessDesArr[frequentlyval.id] = {
                            longtext: frequentlyval.bm_longtext,
                            shorttext: frequentlyval.bm_shorttext
                        };
                    });
                }
            }
        };

        $scope.getGroupData = function () {
            if ($scope.channelDetail.group_id !== '' &&
                $scope.channelDetail.group_id !== undefined &&
                $scope.channelDetail.group_id !== null) {
                $scope.getCountryRegionArr();
            } else {
                $scope.whiteretailerList = [];
                $scope.blackretailerList = [];
                $scope.countryRegionArr = [];
            }
        };
        /**
         * @description
         * made country list
         */
        $scope.getCountryRegionArr = function () {
            var Data = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                group_id: $scope.channelDetail.group_id,
                channel_id: (parameter.id !== undefined && parameter.id !== null && parameter.id !== '') ? parameter.id : ''
            };
            if ($scope.channelId !== undefined && $scope.channelId !== null && $scope.channelId !== '' && $scope.channelDetail.group_id != $scope.channelDetail.new_group_id) {
                Data.group_id = $scope.channelDetail.new_group_id;
                Data.new_group_id = $scope.channelDetail.group_id;
            } else {
                Data.new_group_id = '';
            }

            channelService.getCountryRegionList(Data)
                .then(function (data) {
                    $scope.channelDetail.region_id = '';
                    $scope.countryRegionArr = [];
                    $scope.setCountryList(data, function (data) {
                        if (parameter.id !== undefined && parameter.id !== null && parameter.id !== '') {
                            $scope.editCountryDisable(data);
                        }
                        else {
                            $scope.addCountryDisable(data);
                        }
                    });
                },
                function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * select & disabled Country
         */
        $scope.addCountryDisable = function (data) {
            $scope.totalCountry = data.total_country;
            $scope.selectCountryNo = data.selected_countries.length;
            if (data.selected_countries.length > 0) {

                angular.forEach(COUNTRY_PREFERENCE, function (couval, coukey) {
                    angular.forEach(couval, function (child_couval, child_coukey) {
                        var str = child_couval.main_id.replace(/ +/g, "");
                        var index = data.selected_countries.indexOf(str);
                        var bookedindex = data.book_countries.indexOf(str);
                        if (index >= 0) {
                            data.selected_countries.push(child_couval.id);
                        }
                        if (bookedindex >= 0) {
                            data.book_countries.push(child_couval.id);
                        }
                    });
                });

                var isselectAll = true;
                angular.forEach($scope.countryRegionArr, function (val, key) {
                    if (key !== 0 && !val.selected) {
                        isselectAll = false;
                    }
                });
                if (isselectAll) {
                    ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                }


                ivhTreeviewMgr.selectEach($scope.countryRegionArr, data.selected_countries);
                $timeout(function () {
                    var ele = document.getElementsByClassName("treelist");
                    for (var i = 0; i < ele.length; i++) {
                        ele[i].disabled = true;
                    }
                    angular.forEach(data.selected_countries, function (val, key) {
                        document.getElementById(val).disabled = false;
                    });
                    angular.forEach($scope.countryRegionArr, function (rval, rkey) {
                        document.getElementById(rval.id).disabled = false;
                    });
                }, 1000);
            }
            if (data.selected_regions !== undefined && data.selected_regions.length === 1 && data.selected_regions[0] == 1) {
                $scope.selectCountryNo = data.total_country;
                ivhTreeviewMgr.selectAll($scope.countryRegionArr);
                $scope.channelDetail.region_id = 1;
                $timeout(function () {
                    var ele = document.getElementsByClassName("treelist");
                    for (var i = 0; i < ele.length; i++) {
                        ele[i].disabled = false;
                    }
                }, 1000);
            }
            if (data.selected_countries.length <= 0 && data.selected_regions.length <= 0) {
                $timeout(function () {
                    var ele = document.getElementsByClassName("treelist");
                    for (var i = 0; i < ele.length; i++) {
                        ele[i].disabled = true;
                    }
                });
            }
        };

        $scope.editCountryDisable = function (data) {
            $scope.totalCountry = data.total_country;
            $scope.selectCountryNo = data.selected_countries.length;
            if (data.selected_countries.length > 0) {
                angular.forEach(COUNTRY_PREFERENCE, function (couval, coukey) {
                    angular.forEach(couval, function (child_couval, child_coukey) {
                        var str = child_couval.main_id.replace(/ +/g, "");
                        var index = data.selected_countries.indexOf(str);
                        var bookedindex = data.book_countries.indexOf(str);
                        if (index >= 0) {
                            data.selected_countries.push(child_couval.id);
                        }
                        if (bookedindex >= 0) {
                            data.book_countries.push(child_couval.id);
                        }
                    });
                });
                ivhTreeviewMgr.selectEach($scope.countryRegionArr, data.selected_countries);

                var isselectAll = true;
                angular.forEach($scope.countryRegionArr, function (val, key) {
                    if (key !== 0 && !val.selected) {
                        isselectAll = false;
                    }
                });
                if (isselectAll) {
                    ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                }

                $timeout(function () {
                    if (data.book_countries.length > 0) {
                        var ele = document.getElementsByClassName("treelist");
                        for (var i = 0; i < ele.length; i++) {
                            ele[i].disabled = true;
                        }
                        angular.forEach(data.book_countries, function (val, key) {
                            document.getElementById(val).disabled = false;
                        });
                        var worldRegion = false;
                        angular.forEach($scope.countryRegionArr, function (rval, rkey) {
                            document.getElementById(rval.id).disabled = false;
                        });
                        document.getElementById('1').disabled = false;// worldRegion;
                    }
                }, 1000);
            }
            if (data.selected_regions !== undefined && data.selected_regions.length === 1 && data.selected_regions[0] == 1) {
                $scope.selectCountryNo = data.total_country;
                ivhTreeviewMgr.selectAll($scope.countryRegionArr);
                $scope.channelDetail.region_id = 1;
                $timeout(function () {
                    var ele = document.getElementsByClassName("treelist");
                    for (var i = 0; i < ele.length; i++) {
                        ele[i].disabled = false;
                    }
                }, 1000);

            }
            if (data.selected_countries.length <= 0 && data.selected_regions.length <= 0) {
                $timeout(function () {
                    var ele = document.getElementsByClassName("treelist");
                    for (var i = 0; i < ele.length; i++) {
                        ele[i].disabled = true;
                    }
                });
            }
        };
        /**
         * end select & disabled Country
        */

        $scope.setCountryList = function (data, call) {
            angular.forEach(data.response, function (element) {
                if (COUNTRY_PREFERENCE[element.label] !== undefined && COUNTRY_PREFERENCE[element.label].length > 0) {
                    angular.forEach(COUNTRY_PREFERENCE[element.label], function (val, key) {
                        var isAvail = _.findWhere(element.children, { label: val.label });
                        if (!_.isEmpty(isAvail)) {
                            element.children.unshift(val);
                        }
                    });
                }
                $scope.countryRegionArr.push(element);
            });
            call(data);
        };

        $scope.countryMade = function (Node, IsSelected, Tree) {
            _.find($scope.countryRegionArr, function (objval) {
                if (objval.children !== undefined && objval.children.length > 0) {
                    var dupArr = _.where(objval.children, { label: Node.label });
                    if (IsSelected) {
                        angular.forEach(dupArr, function (dupval, dupkey) {
                            ivhTreeviewMgr.select($scope.countryRegionArr, dupval);
                        });
                    }
                    else {
                        angular.forEach(dupArr, function (dupval, dupkey) {
                            ivhTreeviewMgr.deselect($scope.countryRegionArr, dupval);
                        });
                    }
                }
            });

            if (Node.label === 'World' && Node.children === undefined) {
                if (IsSelected) {
                    ivhTreeviewMgr.selectAll($scope.countryRegionArr);
                }
                else {
                    ivhTreeviewMgr.deselectAll($scope.countryRegionArr);
                }
            }
            if (Node.label !== 'World') {
                if (IsSelected) {
                    var allRegion = true;
                    angular.forEach($scope.countryRegionArr, function (couval, coukey) {
                        if (coukey !== 0) {
                            if (!couval.selected) {
                                allRegion = false;
                            }
                        }
                    });
                    if (allRegion) {
                        ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                    }
                    else {
                        ivhTreeviewMgr.deselect($scope.countryRegionArr, $scope.countryRegionArr[0]);
                    }
                }
                else {
                    ivhTreeviewMgr.deselect($scope.countryRegionArr, $scope.countryRegionArr[0]);
                }
            }
        };
        /**
         * @description
         * End country list
         */
        $scope.getRetailerList = function () {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                group_id: $scope.channelDetail.group_id,
                country_id: $scope.channelDetail.country_id,
                channel_id: (parameter.id !== undefined && parameter.id !== null && parameter.id !== '') ? parameter.id : ''
            };

            if ($scope.channelId !== undefined && $scope.channelId !== null && $scope.channelId !== '' && $scope.channelDetail.group_id != $scope.channelDetail.new_group_id) {
                data.group_id = $scope.channelDetail.new_group_id;
                data.new_group_id = $scope.channelDetail.group_id;
            } else {
                data.new_group_id = '';
            }

            channelService.getRetailerList(data)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.whiteretailerDetailList = data.whitelist_retailers;
                        $scope.blackretailerDetailList = data.blacklist_retailers;
                        $scope.whiteretailerList = _.pluck(data.whitelist_retailers, 'name');
                        $scope.blackretailerList = _.pluck(data.blacklist_retailers, 'name');
                        var excludegroup = new autoComplete({
                            selector: '#excludeGroupName',
                            minChars: 1,
                            source: function (term, suggest) {
                                term = term.toLowerCase();
                                var choices = $scope.blackretailerList;
                                var suggestions = [];
                                for (i = 0; i < choices.length; i++)
                                    if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                                suggest(suggestions);
                            },
                            onSelect: function (e, term, item) {
                                $scope.channelDetail.excludeGroupName = item.innerText;
                            }
                        });
                        var includegroup = new autoComplete({
                            selector: '#includeGroupName',
                            minChars: 1,
                            source: function (term, suggest) {
                                term = term.toLowerCase();
                                var choices = $scope.whiteretailerList;
                                var suggestions = [];
                                for (i = 0; i < choices.length; i++)
                                    if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                                suggest(suggestions);
                            },
                            onSelect: function (e, term, item) {
                                $scope.channelDetail.includeGroupName = item.innerText;
                            }
                        });

                        if (data.selected_retailers.length > 0) {
                            var arr = [];
                            angular.forEach(data.selected_retailers, function (retval, retkey) {
                                arr.push({ name: retval.name });
                            });
                            if ($scope.channelDetail.groupOptions == 0) {
                                $scope.includeRetailerList = arr;
                            } else {
                                $scope.excludeRetailerList = arr;
                            }
                        }
                    } else {
                        $scope.message = data.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                }, function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * @description
         * change group option
         */
        $scope.changeGroupOption = function () {
            $scope.message = '';
            $scope.isError = false;
            $scope.isMessage = false;
            if ($scope.channelDetail.groupOptions == 0) {
                $scope.channelDetail.retailers_list = 'Whitelist';
                $scope.excludeRetailerList = [];
                $scope.channelDetail.excludeGroupName = '';
            }
            if ($scope.channelDetail.groupOptions == 1) {
                $scope.channelDetail.retailers_list = 'Blacklist';
                $scope.includeRetailerList = [];
                $scope.channelDetail.includeGroupName = '';
            }
        };
        /**
         * @description
         * Price Calculation
         */
        $scope.recalculatePrice = function (variable) {
            if (parseFloat($scope.channelDetail[variable]) >= 0 && parseFloat($scope.channelDetail[variable]) <= 100) {
                angular.forEach($scope.bookPricingDetail, function (bookvalue, bookkey) {
                    var arr = [];
                    angular.forEach(bookvalue, function (value, key) {
                        angular.forEach(value, function (pvalue, pkey) {
                            if (typeof (pvalue) == 'object') {
                                if (variable == 'payoutDiscount') {
                                    $scope.paydiscount = $scope.channelDetail.payoutDiscount;
                                    $scope.recalculatePayoutPrice(bookkey, key, pkey);
                                } else {
                                    $scope.adjdiscount = $scope.channelDetail.adjustDiscount;
                                    $scope.recalculateAdjustPrice(bookkey, key, pkey);
                                }
                            }
                        });
                    });
                });
                $scope.errpayoutDiscount = false;
                $scope.erradjustDiscount = false;
            } else {
                $scope.errpayoutDiscount = false;
                $scope.erradjustDiscount = false;
                $scope['err' + variable] = true;
            }
        };

        $scope.bookPrice = function (book, value) {
            var orignalObj = $scope.bookPricingDetail[book][value];
            /* For Adjustment + payable Change  */
            if ($scope.channelDetail.businessModelId == 3) {
                if ($scope.channelDetail.adjustDiscount != 0) {
                    var adjdiscount = (parseFloat(orignalObj.original_digital_list) * $scope.channelDetail.adjustDiscount) / 100;
                    if ($scope.channelDetail.payoutDiscount != 0) {
                        var discountval = parseFloat(orignalObj.original_digital_list) - parseFloat(adjdiscount);
                        var paydiscount = (parseFloat(discountval) * parseFloat($scope.channelDetail.payoutDiscount)) / 100;
                        $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = parseFloat(discountval);
                        $scope.bookPricingDetail[book][value]['publisher_share'] = parseFloat(parseFloat($scope.bookPricingDetail[book][value]['adjusted_selling_price']) - parseFloat(paydiscount));
                    } else {
                        $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = parseFloat(parseFloat(orignalObj.original_digital_list) - parseFloat(adjdiscount));
                    }
                } else {
                    var paydiscount = (parseFloat(orignalObj.adjusted_selling_price) * parseFloat($scope.channelDetail.payoutDiscount)) / 100;
                    $scope.bookPricingDetail[book][value]['publisher_share'] = parseFloat(paydiscount);
                }
            }
            /*End For Adjustment + payable Change  */
            /* For Adjustment  Change  */
            else {
                var adjdiscount = (parseFloat(orignalObj.original_digital_list) * $scope.channelDetail.adjustDiscount) / 100;
                $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = parseFloat(parseFloat(orignalObj.original_digital_list) - parseFloat(adjdiscount));
            }
            /* End For Adjustment Change  */
        };

        $scope.recalculatePayoutPrice = function (book, value, pkey) {
            var orignalObj = $scope.bookPricingDetail[book][value][pkey];
            if ($scope.paydiscount >= 0) {
                var sharePrice = parseFloat(orignalObj.adjusted_selling_price) * parseFloat($scope.paydiscount) / 100;
                sharePrice = (orignalObj.adjusted_selling_price - sharePrice);
                if (CURRENCY_ARRAY.indexOf(orignalObj.currency_name) <= 0) {
                    sharePrice = parseFloat(parseFloat(sharePrice).toFixed(2));
                }
                else {
                    sharePrice = parseFloat(parseFloat(sharePrice).toFixed(0));
                }
                $scope.bookPricingDetail[book][value][pkey]['publisher_share'] = sharePrice;
            }
        };

        $scope.recalculateAdjustPrice = function (book, value, pkey) {
            var orignalObj = $scope.bookPricingDetail[book][value][pkey];
            var adjdiscount = (parseFloat(orignalObj.original_digital_list) * $scope.channelDetail.adjustDiscount) / 100;
            if ($scope.channelDetail.businessModelId == 3) {
                var orignalPrice = parseFloat(orignalObj.original_digital_list) - parseFloat(adjdiscount);
                if ($scope.paydiscount >= 0) {
                    var adjustedPrice = parseFloat(orignalPrice);
                    var sharePrice = parseFloat(adjustedPrice) * parseFloat($scope.paydiscount) / 100;
                    sharePrice = (adjustedPrice - sharePrice);
                    if (CURRENCY_ARRAY.indexOf(orignalObj.currency_name) <= 0) {
                        sharePrice = parseFloat(parseFloat(sharePrice).toFixed(2));
                        adjustedPrice = parseFloat(parseFloat(adjustedPrice).toFixed(2));
                    }
                    else {
                        sharePrice = parseFloat(parseFloat(sharePrice).toFixed(0));
                        adjustedPrice = parseFloat(parseFloat(adjustedPrice).toFixed(0));
                    }
                    $scope.bookPricingDetail[book][value][pkey]['publisher_share'] = sharePrice;
                    $scope.bookPricingDetail[book][value][pkey]['adjusted_selling_price'] = adjustedPrice;
                }
            } else {
                var sellingprice = parseFloat(orignalObj.original_digital_list) - parseFloat(adjdiscount);
                if (CURRENCY_ARRAY.indexOf(orignalObj.currency_name) <= 0) {
                    sellingprice = parseFloat(sellingprice.toFixed(2));
                }
                else {
                    sellingprice = parseFloat(sellingprice.toFixed(0));
                }
                $scope.bookPricingDetail[book][value][pkey]['adjusted_selling_price'] = parseFloat(sellingprice);
            }
        };

        $scope.resetBookPrice = function (book, value, pkey) {
            var orignalObj = $scope.bookPricingDetail[book][value][pkey];

            var adjdiscount = (parseFloat(orignalObj.original_digital_list) * $scope.channelDetail.adjustDiscount) / 100;
            var sellingPrice = parseFloat(orignalObj.original_digital_list) - parseFloat(adjdiscount);
            if ($scope.channelDetail.businessModelId == 3) {
                var payoutPrice = parseFloat(sellingPrice) * parseFloat($scope.paydiscount) / 100;
                var publisherprice = parseFloat(sellingPrice) - parseFloat(payoutPrice);
                if (CURRENCY_ARRAY.indexOf(orignalObj.currency_name) <= 0) {
                    var adjustedPrice = parseFloat(sellingPrice.toFixed(2));
                    publisherprice = parseFloat(publisherprice.toFixed(2));
                }
                else {
                    var adjustedPrice = parseFloat(sellingPrice.toFixed(0));
                    publisherprice = parseFloat(publisherprice.toFixed(0));
                }
                $scope.bookPricingDetail[book][value][pkey]['adjusted_selling_price'] = adjustedPrice;
                $scope.bookPricingDetail[book][value][pkey]['publisher_share'] = publisherprice;
            } else {
                if (CURRENCY_ARRAY.indexOf(orignalObj.currency_name) <= 0) {
                    $scope.bookPricingDetail[book][value][pkey]['adjusted_selling_price'] = parseFloat(sellingPrice.toFixed(2));
                }
                else {
                    $scope.bookPricingDetail[book][value][pkey]['adjusted_selling_price'] = parseFloat(sellingPrice.toFixed(0));
                }
            }
        };
        /**
         * @description
         * End Price Calculation
         */

        /**
         * @description
         * Retailer config
         */
        $scope.addIncluderRetailer = function () {
            if ($scope.channelDetail.includeGroupName !== '' && $scope.channelDetail.includeGroupName !== undefined && $scope.channelDetail.includeGroupName !== null) {
                var indexId = $scope.whiteretailerList.indexOf($scope.channelDetail.includeGroupName);
                if (indexId >= 0) {
                    var isAvialable = _.where($scope.includeRetailerList, { name: $scope.channelDetail.includeGroupName });
                    if (isAvialable.length <= 0) {
                        $scope.includeRetailerList.push({ name: $scope.channelDetail.includeGroupName });
                    }
                    $scope.isRetailerError = false;
                    $scope.isRetailerMessage = false;
                    $scope.retailermessage = '';
                }
                else {
                    $scope.isRetailerError = true;
                    $scope.isRetailerMessage = false;
                    $scope.retailermessage = $filter('translate')('NO_RETAILER_BY_NAME');
                }
                $scope.channelDetail.includeGroupName = '';
            }
        };

        $scope.addExcludeRetailer = function () {
            if ($scope.channelDetail.excludeGroupName !== '' && $scope.channelDetail.excludeGroupName !== undefined && $scope.channelDetail.excludeGroupName !== null) {
                var indexId = $scope.blackretailerList.indexOf($scope.channelDetail.excludeGroupName);
                if (indexId >= 0) {
                    var isAvialable = _.where($scope.excludeRetailerList, { name: $scope.channelDetail.excludeGroupName });
                    if (isAvialable.length <= 0) {
                        $scope.excludeRetailerList.push({ name: $scope.channelDetail.excludeGroupName });
                    }
                    $scope.isRetailerError = false;
                    $scope.isRetailerMessage = false;
                    $scope.retailermessage = '';
                }
                else {
                    $scope.isRetailerError = true;
                    $scope.isRetailerMessage = false;
                    $scope.retailermessage = $filter('translate')('NO_RETAILER_BY_NAME');
                }
                $scope.channelDetail.excludeGroupName = '';
            }
        };

        $scope.deleteIncludeRetailer = function (obj) {
            $scope.isRetailerError = false;
            $scope.isRetailerMessage = false;
            $scope.retailermessage = '';
            $scope.includeRetailerList.splice($scope.includeRetailerList.indexOf(obj), 1);
        };

        $scope.deleteExcludeRetailer = function (obj) {
            $scope.isRetailerError = false;
            $scope.isRetailerMessage = false;
            $scope.retailermessage = '';
            $scope.excludeRetailerList.splice($scope.excludeRetailerList.indexOf(obj), 1);
        };
        /**
         * @description
         * End Retailer config
         */
        $scope.addChannel = function () {
            var isValidData = true;
            var retailerArr = [];
            var bundleArr = [];
            if ($scope.channelDetail.groupOptions == 0) {
                if ($scope.includeRetailerList.length <= 0) {
                    isValidData = false;
                } else {
                    angular.forEach($scope.includeRetailerList, function (value, key) {
                        var ret_arr = _.where($scope.whiteretailerDetailList, { name: value.name });
                        if (ret_arr.length > 0) {
                            retailerArr.push(ret_arr[0].id);
                        }
                    });
                }
            } else {
                if ($scope.excludeRetailerList.length <= 0) {
                    isValidData = false;
                } else {
                    angular.forEach($scope.excludeRetailerList, function (value, key) {
                        var ret_arr = _.where($scope.blackretailerDetailList, { name: value.name });
                        if (ret_arr.length > 0) {
                            retailerArr.push(ret_arr[0].id);
                        }
                    });
                }
            }
            if (isValidData) {
                if ($scope.channelDetail.businessModelId == $scope.businessCode.BUND001) {
                    bundleArr = $scope.bundle1PriceData;
                }
                var data = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    channelArr: $scope.channelDetail,
                    bundleArr: ($scope.channelDetail.businessModelId == $scope.businessCode.BUND001) ? bundleArr : [],
                    channelBook: ($scope.channelDetail.businessModelId != $scope.businessCode.BUND001 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND002 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND003) ? $scope.bookPricingDetail : [],
                    channelCountry: $scope.channelDetail.country_id,
                    channelRetailer: retailerArr
                };
                $scope.submitChannel(data);
            } else {
                $scope.isRetailerMessage = false;
                $scope.retailermessage = '';
                $scope.retailerErrMesage = true;
            }
        };

        $scope.editChannel = function () {
            var isValidData = true;
            var retailerArr = [];
            var bundleArr = [];
            if ($scope.channelDetail.groupOptions == 0) {
                if ($scope.includeRetailerList.length <= 0) {
                    isValidData = false;
                } else {
                    angular.forEach($scope.includeRetailerList, function (value, key) {
                        var ret_arr = _.where($scope.whiteretailerDetailList, { name: value.name });
                        if (ret_arr.length > 0) {
                            retailerArr.push(ret_arr[0].id);
                        }
                    });
                }
            }
            if ($scope.channelDetail.groupOptions == 1) {
                if ($scope.excludeRetailerList.length <= 0) {
                    isValidData = false;
                } else {
                    angular.forEach($scope.excludeRetailerList, function (value, key) {
                        var ret_arr = _.where($scope.blackretailerDetailList, { name: value.name });
                        if (ret_arr.length > 0) {
                            retailerArr.push(ret_arr[0].id);
                        }
                    });
                }
            }
            if ($scope.channelDetail.groupOptions == 2) {
                $scope.channelDetail.retailers_list = 'All';
            }
            if (isValidData) {
                if ($scope.channelDetail.businessModelId == $scope.businessCode.BUND001) {
                    bundleArr = $scope.bundle1PriceData;
                }
                var dataArr = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    channelArr: $scope.channelDetail,
                    bundleArr: ($scope.channelDetail.businessModelId == $scope.businessCode.BUND001) ? bundleArr : [],
                    channelBook: ($scope.channelDetail.businessModelId != $scope.businessCode.BUND001 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND002 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND003) ? $scope.bookPricingDetail : [],
                    channelCountry: $scope.channelDetail.country_id,
                    channelRetailer: ($scope.channelDetail.groupOptions == 2) ? [] : retailerArr,
                    channel_id: $scope.channelId
                };
                $scope.updateChannel(dataArr);
            } else {
                $scope.isRetailerMessage = false;
                $scope.retailermessage = '';
                $scope.retailerErrMesage = true;
            }
        };

        $scope.processAll = function () {
            var bundleArr = [];
            $scope.channelDetail.groupOptions = 2;
            $scope.channelDetail.retailers_list = 'All';
            if ($scope.channelDetail.businessModelId == $scope.businessCode.BUND001) {
                bundleArr = $scope.bundle1PriceData;
            }
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                channelArr: $scope.channelDetail,
                bundleArr: bundleArr,
                channelBook: ($scope.channelDetail.businessModelId != $scope.businessCode.BUND001 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND002 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND003) ? $scope.bookPricingDetail : [],
                channelCountry: $scope.channelDetail.country_id,
                channelRetailer: [],
                channel_id: $scope.channelId
            };
            if ($scope.channelId !== '' && $scope.channelId !== undefined && $scope.channelId !== null) {
                $scope.updateChannel(data);
            } else {
                $scope.submitChannel(data);
            }
        };

        $scope.getCurrencyList = function () {
            var currencyData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            channelService.getCurrencyList(currencyData)
                .then(function (data) {
                    $scope.currencyList = data.response;
                },
                function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.submitChannel = function (dataArr) {
            dataArr.channelArr.startdate = $filter('dateFormat')(dataArr.channelArr.startdate);
            dataArr.channelArr.enddate = $filter('dateFormat')(dataArr.channelArr.enddate);
            if ($scope.channelDetail.businessModelId != $scope.businessCode.BUND001 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND002 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND003) {
                var priceArray = [];
                if (dataArr.channelBook.length > 0) {
                    angular.forEach(dataArr.channelBook, function (bval, bkey) {
                        angular.forEach(bval, function (val, key) {
                            if (typeof (val) == 'object') {
                                priceArray.push(val);
                            }
                        });
                    });
                    dataArr.channelBook = priceArray;
                }
                if (dataArr.channelArr.bundle_currency_id !== undefined && dataArr.channelArr.bundle_currency_id !== null && dataArr.channelArr.bundle_currency_id !== '') {
                    var currency_data = _.findWhere($scope.currencyList, { id: dataArr.channelArr.bundle_currency_id });
                    ;
                    dataArr.channelArr.bundle_currency_code = currency_data.code;
                }
                dataArr.channelArr.bundle_currency_code = currency_data.code;

                channelService.createChannel(dataArr)
                    .then(function (data) {
                        $scope.retailerErrMesage = false;
                        if (data.error <= 0) {
                            $location.search({});
                            $rootScope.channelmessage = data.msg;
                            $rootScope.channelisError = false;
                            $rootScope.channelisMessage = true;
                            $scope.isreload = true;
                            $location.path('/channels');
                        } else {
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    }, function (err) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.currentTab = 1;
                        var percent = (1 / 5) * 100;
                        $scope.activeTab = 'tab1';
                        $scope.removeActiveTab(function () {
                            document.getElementById('tab1').className = 'tab navtabs active';
                        });
                        document.getElementById('progress_bar').innerText = 'Step 1  of 5';
                        document.getElementById('progress_bar').style.width = percent + '%';
                        return false;
                    });
            }
            else {
                if (dataArr.channelArr.bundle_currency_id !== undefined && dataArr.channelArr.bundle_currency_id !== null && dataArr.channelArr.bundle_currency_id !== '') {
                    var currency_data = _.findWhere($scope.currencyList, { id: dataArr.channelArr.bundle_currency_id });
                    ;
                    dataArr.channelArr.bundle_currency_code = currency_data.code;
                }
                channelService.createBundle(dataArr)
                    .then(function (data) {
                        $scope.retailerErrMesage = false;
                        if (data.error <= 0) {
                            $location.search({});
                            $rootScope.channelmessage = data.msg;
                            $rootScope.channelisError = false;
                            $rootScope.channelisMessage = true;
                            $scope.isreload = true;
                            $location.path('/channels');
                        } else {
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    }, function (err) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.currentTab = 1;
                        var percent = (1 / 5) * 100;
                        $scope.activeTab = 'tab1';
                        $scope.removeActiveTab(function () {
                            document.getElementById('tab1').className = 'tab navtabs active';
                        });
                        document.getElementById('progress_bar').innerText = 'Step 1  of 5';
                        document.getElementById('progress_bar').style.width = percent + '%';
                        return false;
                    });
            }

        };

        $scope.updateChannel = function (dataArr) {
            dataArr.channelArr.startdate = $filter('dateFormat')(dataArr.channelArr.startdate);
            dataArr.channelArr.enddate = $filter('dateFormat')(dataArr.channelArr.enddate);
            if ($scope.channelDetail.group_id != $scope.channelDetail.new_group_id) {
                var group_id = $scope.channelDetail.new_group_id;
                var new_group_id = $scope.channelDetail.group_id;
            } else {
                var group_id = $scope.channelDetail.group_id;
                var new_group_id = '';
            }

            if ($scope.channelDetail.businessModelId != $scope.businessCode.BUND001 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND002 && $scope.channelDetail.businessModelId != $scope.businessCode.BUND003) {
                var priceArray = [];
                if (dataArr.channelBook.length > 0) {
                    angular.forEach(dataArr.channelBook, function (bval, bkey) {
                        angular.forEach(bval, function (val, key) {
                            if (typeof (val) == 'object') {
                                priceArray.push(val);
                            }
                        });
                    });
                    dataArr.channelBook = priceArray;
                }
                if (dataArr.channelArr.bundle_currency_id !== undefined && dataArr.channelArr.bundle_currency_id !== null && dataArr.channelArr.bundle_currency_id !== '') {
                    var currency_data = _.findWhere($scope.currencyList, { id: dataArr.channelArr.bundle_currency_id });
                    ;
                    dataArr.channelArr.bundle_currency_code = currency_data.code;
                }
                dataArr.channelArr.group_id = group_id;
                dataArr.channelArr.new_group_id = new_group_id;
                channelService.updateChannel(dataArr)
                    .then(function (data) {
                        $scope.retailerErrMesage = false;
                        if (data.error <= 0) {
                            $location.search({});
                            $rootScope.channelmessage = data.msg;
                            $rootScope.channelisError = false;
                            $rootScope.channelisMessage = true;
                            $scope.isreload = true;
                            $location.path('/channels');
                        } else {
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    }, function (err) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.currentTab = 1;
                        var percent = (1 / 5) * 100;
                        $scope.activeTab = 'tab1';
                        $scope.removeActiveTab(function () {
                            document.getElementById('tab1').className = 'tab navtabs active';
                        });
                        document.getElementById('progress_bar').innerText = 'Step 1  of 5';
                        document.getElementById('progress_bar').style.width = percent + '%';
                        return false;
                    });
            }
            else {
                if (dataArr.channelArr.bundle_currency_id !== undefined && dataArr.channelArr.bundle_currency_id !== null && dataArr.channelArr.bundle_currency_id !== '') {
                    var currency_data = _.findWhere($scope.currencyList, { id: dataArr.channelArr.bundle_currency_id });
                    ;
                    dataArr.channelArr.bundle_currency_code = currency_data.code;
                }
                dataArr.channelArr.group_id = group_id;
                dataArr.channelArr.new_group_id = new_group_id;
                channelService.updateBundle(dataArr)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.retailerErrMesage = false;
                            $location.search({});
                            $rootScope.channelmessage = data.msg;
                            $rootScope.channelisError = false;
                            $rootScope.channelisMessage = true;
                            $scope.isreload = true;
                            $location.path('/channels');
                        } else {
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    }, function (err) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.currentTab = 1;
                        var percent = (1 / 5) * 100;
                        $scope.activeTab = 'tab1';
                        $scope.removeActiveTab(function () {
                            document.getElementById('tab1').className = 'tab navtabs active';
                        });
                        document.getElementById('progress_bar').innerText = 'Step 1  of 5';
                        document.getElementById('progress_bar').style.width = percent + '%';
                        return false;
                    });
            }
        };

        $scope.resetModel = function (isFrequentlyModel) {
            if (isFrequentlyModel) {
                var arr = $scope.channelDetail.frequentlyUsedModel.split('=');
                if (arr[2] !== undefined && arr[2] == "YOUR FAVORITES") {
                    $scope.channelDetail.business_model_type = 1;
                    $scope.channelDetail.businessModelId = arr[0];
                } else {
                    $scope.channelDetail.business_model_type = 2;
                    $scope.channelDetail.businessModelId = arr[0];
                }
                $scope.channelDetail.allBusinessModel = '';
            } else {
                var arr = $scope.channelDetail.allBusinessModel.split('=');
                $scope.channelDetail.businessModelId = arr[0];
                $scope.channelDetail.frequentlyUsedModel = '';
                $scope.channelDetail.business_model_type = 0;
            }
            $scope.businessModelChange();
        };

        /**
         * Sort by pricing tab list
         */
        $scope.priceSortBy = function (sortName) {
            $scope.reverse = ($scope.sortName === sortName) ? !$scope.reverse : false;
            $scope.sortName = sortName;
        };
        /**
         * delete Bundle image
         */
        $scope.deleteBundleImage = function () {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function () {
                        return { ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('REMOVE_BUNDLE_PHOTO_MSG') };
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                if ($scope.channelDetail.old_bundle_image !== undefined && $scope.channelDetail.old_bundle_image == '' && parameter.id !== undefined && parameter.id !== null && parameter.id !== '') {
                    $scope.channelDetail.old_bundle_image = $scope.channelDetail.default_bundle_image;
                }
                $scope.channelDetail.bundle_image = $scope.channelDetail.bundle_default_image;
                $scope.channelDetail.default_bundle_image = $scope.channelDetail.admin_bundle_image;
                $scope.channelDetail.isEditImage = false;
                angular.element('#file')[0].value = ''
            }, function () {
                console.log('error');
            });
        };
        /**
         * Edit Bundle image
         */
        $scope.editBundleImage = function (element) {
            var isvalid = true;
            $scope.currentFile = element.files[0];

            if ($scope.currentFile.size !== undefined && $scope.currentFile.size > 3099999) {
                isvalid = false;
            }
            if (isvalid) {
                var reader = new FileReader();
                reader.onload = function (event) {
                    var img = new Image();
                    img.src = event.target.result;
                    $timeout(function(){
                        if (img.width > 600 || img.width < 300 || img.height < 450 || img.height > 900) {
                            $window.scrollTo(0, 0);
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = $filter('translate')('IMAGE_DIMENSION_ERROR');
                            $scope.$apply();
                        }
                        else {
                            $scope.isError = false;
                            $scope.isMessage = false;
                            $scope.message = '';
                            $scope.channelDetail.bundle_image = event.target.result;
                            $scope.channelDetail.isEditImage = true;
                            $scope.$apply();
                        }
                    },100);
                }
                reader.readAsDataURL(element.files[0]);
            }
            else {
                $window.scrollTo(0, 0);
                $scope.isError = true;
                $scope.isMessage = false;
                $scope.message = $filter('translate')('BOOK_IMAGE_THREEMB_TOO_LARGE');
                $scope.$apply();
            }
        };
        /**
         * Convert Bundle Price
         */
        $scope.convertBundlePrice = function (isLive) {
            if ($scope.bundle1form.$valid) {
                var currencyData = _.where($scope.currencyList, { id: $scope.channelDetail.bundle_currency_id });
                var bundle1Data = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    group_id: $scope.channelDetail.new_group_id,
                    new_group_id: $scope.channelDetail.group_id,
                    business_id: $scope.channelDetail.businessModelId,
                    channel_id: (parameter.id !== undefined && parameter.id !== '' && parameter.id !== null) ? parameter.id : '',
                    price: $scope.channelDetail.bundle_price,
                    currency_code: currencyData[0].code,
                    currency_id: $scope.channelDetail.bundle_currency_id,
                    countryArr: $scope.channelDetail.country_id,
                    isLiveConvert: (parameter.id !== undefined && parameter.id !== '' && parameter.id !== null) ? isLive : false,
                }

                if ($scope.channelId !== undefined && $scope.channelId !== null && $scope.channelId !== '' && $scope.channelDetail.group_id != $scope.channelDetail.new_group_id) {
                    bundle1Data.group_id = $scope.channelDetail.new_group_id;
                    bundle1Data.new_group_id = $scope.channelDetail.group_id;
                } else {
                    bundle1Data.new_group_id = '';
                }

                channelService.bundle1CurrencyConversion(bundle1Data)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.message = '';
                            $scope.isError = false;
                            $scope.isMessage = false;
                            $scope.bundle1PriceData = data.response;
                            $scope.submitErr['tab4'] = false;
                            $scope.submitErr.tab4ErrorMsg = '';
                        } else {
                            $scope.bundle1PriceData = [];
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    })
                    .catch(function (error) {

                    });
            }
            else {
                $scope.submitErr.bundle1 = true;
            }
        };
        /**
         * Reset Bundle Price
         */
        $scope.resetBundlePrice = function (bundlekey) {
            $scope.bundle1PriceData[bundlekey]['adjusted_price'] = $scope.bundle1PriceData[bundlekey]['calculated_price'];
        };

        /**
         * select Radio
         */

        $scope.isUsedModel = function (modelid, pricetab) {
            return ($scope.unusedBusinessCode.indexOf(parseInt(modelid)) < 0) ? '' : $filter('translate')((pricetab) ? 'BUSINESS_MODEL_COMING_SOON_LABEL' : 'COMING_SOON_LABEL');
        };

        $scope.selectRadio = function (type) {
            if ($scope.channelDetail.groupOptions !== type) {
                $scope.channelDetail.groupOptions = type;
                $scope.changeGroupOption();
            }
            else {
                $scope.channelDetail.groupOptions = type;
            }
        };

        if (parameter.id === undefined) {
            $scope.getBussinessModelList();
            $scope.getGroupList(function () {
                if (parameter.group_id !== undefined && parameter.group_id !== null && parameter.group_id !== '') {
                    $scope.getGroupData();
                }
            });
        };

        $scope.getCurrencyList();

    }]);
