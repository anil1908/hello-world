'use strict';
App.factory('channelService', ['$http', '$q', '$window', function ($http, $q, $window) {
    var channelServiceFactory = {};
    /**
     * @description
     * # channel list
     */
    var _getChannelsList = function (channelsData) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/get_channel_list',
            method: "POST",
            data: channelsData
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
     * @description
     * # channel status update
     */
    var _updateChannelStatus = function (channelsData) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/update_channel_status',
            method: "POST",
            data: channelsData
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
     * @description
     * # channel book price
     */
    var _getChannelBookPrice = function (channelsData) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/get_channel_price',
            method: "POST",
            data: channelsData
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
     * @description
     * # delete channel
     */
    var _deleteChannel = function (channelData) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/delete_channel',
            method: "POST",
            data: channelData
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
     * @description
     * # group list
     */
    var _getGroupList = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/get_group',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
     * @description
     * # business model list
     */
    var _getBussinessModelList = function (bussinessData) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/get_business_model',
            method: "POST",
            data: bussinessData
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };

    /**
     * @description
     * # retailer list
     */
    var _getRetailerList = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/get_retailers',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };

    var _getCountryRegionList = function (Data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/get_region_with_country',
            method: "POST",
            data: Data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
    * @description
    * # Conversion data
    */
    var _getConversion = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/get_conversion',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
    * @description
    * # create channel
    */
    var _createChannel = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/create_channel',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
    * @description
    * #  channel detail
    */
    var _getChannelDetail = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/get_channel_detail',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
    * @description
    * # edit channel
    */
    var _updateChannel = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/update_channel',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };

    var _getBundleData = function (bundledaata) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/get_bundle_details',
            method: "POST",
            data: bundledaata
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
     * @description
     * # currency  list
     */
    var _getCurrencyList = function (currecyData) {
        var deferred = $q.defer();
        $http({
            headers: {'Content-Type': 'application/json'},
            url: 'api/general/get_currency',
            method: "GET",
            data: currecyData,
            cache: true
        })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (err, code) {
                    deferred.reject(err);
                });
        return deferred.promise;
    };
    /**
     * @description
     * # currency  list
     */
    var _bundle1CurrencyConversion = function (currecyData) {
        var deferred = $q.defer();
        $http({
            headers: {'Content-Type': 'application/json'},
            url: 'api/channel/get_bundle_conversion',
            method: "POST",
            data: currecyData
        })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (err, code) {
                    deferred.reject(err);
                });
        return deferred.promise;
    };

    /**
    * @description
    * # add Bundle
    */
    var _createBundle = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/create_bundle',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
    * @description
    * # edit bundle
    */
    var _updateBundle = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/channel/update_bundle',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };

    channelServiceFactory.getChannelsList = _getChannelsList;
    channelServiceFactory.updateChannelStatus = _updateChannelStatus;
    channelServiceFactory.getChannelBookPrice = _getChannelBookPrice;
    channelServiceFactory.deleteChannel = _deleteChannel;
    channelServiceFactory.getGroupList = _getGroupList;
    channelServiceFactory.getBussinessModelList = _getBussinessModelList;
    channelServiceFactory.getRetailerList = _getRetailerList;
    channelServiceFactory.getCountryRegionList = _getCountryRegionList;
    channelServiceFactory.getConversion = _getConversion;
    channelServiceFactory.createChannel = _createChannel;
    channelServiceFactory.getChannelDetail = _getChannelDetail;
    channelServiceFactory.updateChannel = _updateChannel;
    channelServiceFactory.getBundleData = _getBundleData;
    channelServiceFactory.getCurrencyList = _getCurrencyList;
    channelServiceFactory.bundle1CurrencyConversion = _bundle1CurrencyConversion;
    channelServiceFactory.createBundle = _createBundle;
    channelServiceFactory.updateBundle = _updateBundle;
    return channelServiceFactory;
}]);