'use strict';
angular.module('OneWorld').controller('purchasehistoryController', ['$scope', '$rootScope', '$uibModal', 'purchasehistoryService', '$location', '$sessionStorage', 'localStorageService', '$filter',
    function ($scope, $rootScope, $uibModal, purchasehistoryService, $location, $sessionStorage, localStorageService, $filter) {
        $rootScope.logo = 'home-logo.png';
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 't.created_on',
            sorttype: 'DESC',
            maxsize: 10
        };
        var parameter = $location.search();
        $scope.purchaseHistoryList = [];
        $scope.pageIds = [];

        /*
         * @description
         * Grid Option*/
        $scope.getPurchaseHistory = function () {
            var purchaseHistoryData = {
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                c: parameter.c,
                t: parameter.t
            };
            $scope.getPurchaseHistoryData(purchaseHistoryData);
        };

        $scope.getPurchaseHistoryData = function (purchaseHistoryData) {
            purchaseHistoryData.dataLoader = true;
            purchasehistoryService.getPurchaseHistory(purchaseHistoryData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.purchaseHistoryList = data.response;
                        $scope.gridOption.filteredItems = data.total_rows;
                        $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                        if ($scope.gridOption.maxsize > 5) {
                            $scope.gridOption.maxsize = 5;
                        }
                        $rootScope.message = '';
                        $rootScope.isError = false;
                        $rootScope.isMessage = false;
                    } else {
                        $scope.purchaseHistoryList = [];
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.$watch('currentPage', function (pageNo) {
            var purchaseHistoryData = {
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                c: parameter.c,
                t: parameter.t
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getPurchaseHistoryData(purchaseHistoryData);
            //or any other code here
        });

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var purchaseHistoryData = {
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
                c: parameter.c,
                t: parameter.t
            };
            $scope.getPurchaseHistoryData(purchaseHistoryData);
        };

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var purchaseHistoryData = {
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                c: parameter.c,
                t: parameter.t
            };
            $scope.getPurchaseHistoryData(purchaseHistoryData);
            var pagesizeelm = angular.element(document.querySelectorAll('#pagesize'));
            angular.forEach(pagesizeelm, function (val, key) {
                pagesizeelm[key].blur();
            });
        };
        /*
        * @description
        * Grid Option*/

        $scope.downloadMetadata = function (purchase) {
            var bookdata = {
                book_id: purchase.book_id,
                bundle_id: purchase.bundle_id,
                transaction_id: purchase.id
            }
            purchasehistoryService.downloadFile(bookdata)
                .then(function (data) {
                    if (data.error <= 0) {
                        if (data.handle !== '' && data.handle !== null && data.handle !== undefined) {
                            for(var i=0;i<data.handle.length;i++){
                                window.open(data.handle[i]);
                            }
                            $scope.getPurchaseHistory();
                        }
                    }
                    else {
                        $scope.message = data.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

    }]);