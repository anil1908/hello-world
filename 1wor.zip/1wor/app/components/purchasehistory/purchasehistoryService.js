'use strict';
App.factory('purchasehistoryService', ['$http', '$q', function ($http, $q) {
    var purchasehistoryServiceFactory = {};

    /**
     * @description
     * # purchase authenticate email
    */
    var _getPurchaseHistory = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/payment/get_purchase_history_list',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };
    /**
     * @description
     * # download file
    */
    var _downloadFile = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/payment/download_media',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };

    purchasehistoryServiceFactory.getPurchaseHistory = _getPurchaseHistory;
    purchasehistoryServiceFactory.downloadFile = _downloadFile;
    return purchasehistoryServiceFactory;
}]);