'use strict';
angular.module('OneWorld').controller('addBooksController', ['$scope', '$rootScope', '$timeout', 'bookService', '$uibModal', '$location', '$sessionStorage', 'localStorageService', 'DATE_FORMAT', 'ivhTreeviewMgr', '$filter', '$window', 'COUNTRY_PREFERENCE',
    function ($scope, $rootScope, $timeout, bookService, $uibModal, $location, $sessionStorage, localStorageService, DATE_FORMAT, ivhTreeviewMgr, $filter, $window, COUNTRY_PREFERENCE) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        var parameter = $location.search();
        var numbers = /^[0-9]+$/;
        $scope.format = DATE_FORMAT;
        $scope.relatedproduct = { identifiererror: false, identifiermessage: '' };
        $scope.awardNameError = '';
        $scope.dateOptions = {
            showWeeks: false,
        };
        $scope.bookReviewDetail = {
            reviewtype: { id: '', name: '' }, reviewsource: { id: '', name: '' },
            reviewtitle: '', reviewtext: '', reviewurl: '', reviewdate: '',
            reviewrole: { id: '', name: '' }
        };
        $scope.bookAwardDetail = {
            awardname: '', awardyear: '',
            awardcountry: { id: '', name: '' }, awardcode: { id: '', name: '' }
        };
        $scope.bookRelatedProductDetail = {
            relatedcode: { id: '', name: '' }, identifiertype: { id: '', name: '' }
            , identifiername: ''
        };
        $scope.bookReviewEdit = false;
        $scope.bookAwardEdit = false;
        $scope.bookRelatedProductEdit = false;
        $scope.productDuplicate = false;
        $scope.countryRegionArr = [];
        $scope.editBookReviewObject = {};
        $scope.editBookAwardObject = {};
        $scope.companyDetail = {};
        $scope.editBookRelatedProductObject = {};
        $scope.contributorNameList = [];
        $scope.identifierNameList = [];
        $scope.bookAward = {};
        $scope.AwardList = [];
        $scope.bookRelatedProducts = {};
        $scope.contributorList = [];
        $scope.identifierList = [];
        $scope.currencyList = [];
        $scope.languageList = [];
        $scope.subjectList = [];
        $scope.regionList = [];
        $scope.countryList = [];
        $scope.audienceList = [];
        $scope.ageRange = [];
        $scope.gradeRange = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];
        $scope.yearList = [];
        $scope.reviewTypeList = [];
        $scope.reviewSourceList = [];
        $scope.reviewRoleList = [];
        $scope.awardCountryList = [];
        $scope.awardCodeList = [];
        $scope.RelatedCodeList = [];
        $scope.message = '';
        $scope.isError = false;
        $scope.isMessage = false;
        $scope.bookReviewFormSubmit = false;
        $scope.isSubmitted = false;
        $scope.bookAwardFormSubmit = false;
        $scope.bookProductFormSubmit = false;
        $scope.bookRelatedProductFormSubmit = false;
        $scope.validage = false;
        $scope.previewPercentageList = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50];
        for (var i = (new Date().getFullYear() + 1); i >= 1900; i--) {
            $scope.yearList.push(i);
        }

        for (var i = 1; i <= 100; i++) {
            $scope.ageRange.push(i);
        }

        /**
        * @description
        * # Edit Time Bind Data
        */
        $scope.epub_file = {};
        if (parameter.id !== undefined) {
            var bookData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                catalog_id: parameter.id
            };
            bookService.getBookDetail(bookData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.isSubmitted = true;
                        var bookObject = data.response.catalog;
                        var ageArr = (bookObject.age_range !== undefined && bookObject.age_range !== '' && bookObject.age_range !== null) ? bookObject.age_range.split('-') : [];
                        var gradeArr = (bookObject.us_grade_range !== undefined && bookObject.us_grade_range !== '' && bookObject.us_grade_range !== null) ? bookObject.us_grade_range.split('-') : [];
                        $scope.bookDetail = {
                            bookid: parameter.id, title: bookObject.title, sub_title: bookObject.sub_title,
                            volume: bookObject.volume, edition: bookObject.edition,
                            contributor: bookObject.contributor, identifier: bookObject.identifier, priceArr: [],
                            publisher: bookObject.publisher, imprint: bookObject.imprint,
                            publication_date: (bookObject.publication_date !== null && bookObject.publication_date !== undefined && bookObject.publication_date !== '') ? new Date(bookObject.publication_date) : '',
                            language_id: bookObject.language_id,
                            subject_id: bookObject.subject_id,
                            main_subject_id: bookObject.main_subject_id, description: bookObject.description,
                            keywords: bookObject.keywords,
                            min_age_range: (ageArr[0] !== undefined) ? ageArr[0] : '', max_age_range: (ageArr[1] !== undefined) ? ageArr[1] : '',
                            min_us_grade_range: (gradeArr[0] !== undefined) ? gradeArr[0] : '', max_us_grade_range: (gradeArr[1] !== undefined) ? gradeArr[1] : '',
                            region_id: (bookObject.region_id !== undefined) ? bookObject.region_id : [],
                            country_id: (bookObject.country_id !== undefined) ? bookObject.country_id : [],
                            audience_id: bookObject.audience_id,
                            copyright_year: bookObject.copyright_year, copyright_owner: bookObject.copyright_owner,
                            supplier_details: bookObject.supplier_details,
                            supply_date: (bookObject.supply_date !== '' && bookObject.supply_date !== null && bookObject.supply_date !== undefined) ? new Date(bookObject.supply_date) : '',
                            title_availability: (bookObject.title_availability !== undefined && bookObject.title_availability !== null && bookObject.title_availability !== '') ? new Date(bookObject.title_availability) : '',
                            cover_image: bookObject.cover_image, original_image: bookObject.original_image,
                            epub_file: bookObject.epub_file, epub_path: bookObject.epub_file,
                            preview_percentage: (bookObject.preview_percentage !== null && bookObject.preview_percentage !== undefined && bookObject.preview_percentage !== '') ? parseInt(bookObject.preview_percentage) : '',
                            original_epub: (bookObject.original_epub !== undefined && bookObject.original_epub !== null) ? bookObject.original_epub : '',
                            disallow_preview: (bookObject.disallow_preview !== undefined && bookObject.disallow_preview !== null && bookObject.disallow_preview !== '') ? bookObject.disallow_preview : false,
                            sellwithdrm: bookObject.sellwithdrm,
                            no_of_redelivery: bookObject.no_of_redelivery,
                            book_guid : bookObject.book_guid
                        };
                        if (bookObject.priceArr.length > 0) {
                            _.each(bookObject.priceArr, function (priceval) {
                                $scope.bookDetail.priceArr.push({
                                    currency_id: priceval.currency_id,
                                    price: parseFloat(priceval.price)
                                });
                            })
                        }
                        ;
                        $scope.bookReviewList = [];
                        $scope.bookAwardList = [];
                        $scope.bookRelatedProductsList = [];
                        if (data.response.catalog_reviews.length > 0) {
                            _.each(data.response.catalog_reviews, function (reviewsArr) {
                                $scope.bookReviewList.push({
                                    reviewtype: { name: reviewsArr.reviewtype_name, id: reviewsArr.reviewtype_id },
                                    reviewsource: { name: reviewsArr.reviewsource_name, id: reviewsArr.reviewsource_id },
                                    reviewtitle: reviewsArr.title,
                                    reviewtext: reviewsArr.review,
                                    reviewurl: reviewsArr.url,
                                    reviewdate: new Date(reviewsArr.created_on),
                                    reviewrole: { name: reviewsArr.reviewrole_name, id: reviewsArr.reviewrole_id }
                                });
                            })
                        }
                        if (data.response.catalog_awards.length > 0) {
                            _.each(data.response.catalog_awards, function (awardsArr) {
                                $scope.bookAwardList.push({
                                    awardcountry: { name: awardsArr.awardcountry_name, id: awardsArr.awardcountry_id },
                                    awardcode: { name: awardsArr.awardcode_name, id: awardsArr.awardcode_id },
                                    awardname: awardsArr.award_name,
                                    awardyear: awardsArr.year
                                });
                            })
                        }
                        if (data.response.catalog_related_products.length > 0) {
                            _.each(data.response.catalog_related_products, function (productArr) {
                                $scope.bookRelatedProductsList.push({
                                    relatedcode: { name: productArr.relatedcode_name, id: productArr.relatedcode_id },
                                    identifiertype: { name: productArr.identifiertype_name, id: productArr.identifiertype_id },
                                    identifiername: productArr.identifier_no
                                });
                            })
                        }
                        $scope.getRegionList();
                        $scope.getAllCountry();
                        $scope.getCompanyDetail();
                        $scope.getCountryRegionArr();

                    } else {
                        if (data.error == 3) {
                            $location.search({});
                            if (parameter.isCat) {
                                $location.path('/catalog');
                                $rootScope.catalogmessage = data.errorMsg;
                                $rootScope.catalogisError = true;
                                $rootScope.catalogisMessage = false;
                            }
                            else {
                                $location.path('/maintainbooks');
                                $rootScope.maintainbooksmessage = data.errorMsg;
                                $rootScope.maintainbooksisError = true;
                                $rootScope.maintainbooksisMessage = false;
                            }
                        }
                        else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }
                    //$scope.getSubjectList();
                })
                .catch(function () {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        }
        /**
        * @description
        * # new book var bind
        */
        else {
            $scope.bookDetail = {
                bookid: '', title: '', sub_title: '', volume: '', edition: '',
                contributor: [{ contributorrole: '', contributorname: '' }],
                identifier: [{ identifiertype: '', identifiername: '', identifiermessage: '', error: false }], publisher: '', imprint: '', publication_date: '',
                priceArr: [{ currency_id: '', price: '' }], language_id: '', subject_id: [], main_subject_id: '',
                description: '', keywords: '', min_age_range: '', max_age_range: '', min_us_grade_range: '',
                max_us_grade_range: '', region_id: [], country_id: [],
                audience_id: '1',
                copyright_year: '', copyright_owner: '', supplier_details: '', supply_date: '',
                title_availability: '', original_image: '', source_image: '',
                cover_image: 'assets/images/bookcovers/img-cover.png', epub_file: '', epub_path: '',
                disallow_preview: false, preview_percentage: '', allow_preview: false, no_of_redelivery: ''
            };
            $scope.bookReviewList = [];
            $scope.bookAwardList = [];
            $scope.bookRelatedProductsList = [];
        }

        $scope.bookView = function () {
            $location.search({});
            if (parameter.isCat) {
                $location.path('/catalog');
            }
            else {
                $location.path('/maintainbooks');
            }
        }
        /**
         * @description
         * contributor config
         */
        $scope.addContributor = function () {
            $timeout(function () {
                var contributor = new autoComplete({
                    selector: '#contributorname' + ($scope.bookDetail.contributor.length - 1),
                    minChars: 1,
                    source: function (term, suggest) {
                        term = term.toLowerCase();
                        var choices = $scope.contributorNameList;
                        var suggestions = [];
                        for (i = 0; i < choices.length; i++)
                            if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                        suggest(suggestions);
                    },
                    onSelect: function (e, term, item) {
                        $scope.bookDetail.contributor[($scope.bookDetail.contributor.length - 1)]['contributorname'] = item.innerText;
                    }
                });
            }, 1000);
            $scope.bookDetail.contributor.push({ contributorrole: '', contributorname: '' });
        };
        $scope.removeContributor = function (contributorDetail) {
            $scope.bookDetail.contributor.splice($scope.bookDetail.contributor.indexOf(contributorDetail), 1);
        };
        $scope.getContributorsRole = function () {
            var contributorData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getContributorsRoleList(contributorData)
                .then(function (data) {
                    $scope.updatecontributorList(data.response, function () {

                    });
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.updatecontributorList = function (data, callback) {
            $scope.contributorList = data;
            callback();
        }

        $scope.getContributorsName = function (index) {
            var cname = $scope.bookDetail['contributor'][index]['contributorname'];
            if (cname !== undefined && cname.length > 1) {
                var contributorData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    contributor_name: cname
                };
                bookService.getContributorsNameList(contributorData)
                    .then(function (data) {
                        $scope.updateContributorName(data, function () {
                            if ($scope.contributorNameList.length > 0) {
                                var contributorname = new autoComplete({
                                    selector: '#contributorname' + index,
                                    minChars: 1,
                                    source: function (term, suggest) {
                                        term = term.toLowerCase();
                                        var choices = $scope.contributorNameList;
                                        var suggestions = [];
                                        for (i = 0; i < choices.length; i++)
                                            if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                                        suggest(suggestions);
                                    },
                                    onSelect: function (e, term, item) {
                                        $scope.bookDetail.contributor[index]['contributorname'] = item.innerText;
                                        var divTag = document.getElementsByClassName('autocomplete-suggestions');
                                        var i = 0;
                                        for (i; i < divTag.length; i++) {
                                            divTag[i].innerHTML = '';
                                            divTag[i].removeAttribute('style');
                                        }
                                    }
                                });
                            }
                            else {
                                var divTag = document.getElementsByClassName('autocomplete-suggestions');
                                var i = 0;
                                for (i; i < divTag.length; i++) {
                                    divTag[i].innerHTML = '';
                                    divTag[i].removeAttribute('style');
                                }
                            }
                        });
                    })
                    .catch(function (err) {
                        $scope.isError = false;
                        $scope.isMessage = false;
                    });
            }
            else {
                $scope.contributorNameList = [];
            }
        };
        $scope.updateContributorName = function (data, call) {
            $scope.contributorNameList = _.pluck(data.response, 'name');
            call();
        };
        /**
         * @description
         * Identifier config
         */
        $scope.addIdentifier = function () {
            $scope.bookDetail.identifier.push({ identifiertype: '', identifiername: '' });
        };
        $scope.removeIdentifier = function (identifierDetail) {
            $scope.bookDetail.identifier.splice($scope.bookDetail.identifier.indexOf(identifierDetail), 1);
        };
        $scope.getIdentifierType = function () {
            var identifierData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getIdentifierTypeList(identifierData)
                .then(function (data) {
                    $scope.identifierList = data.response;
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * Check Duplicate Identifier Type
         */
        $scope.duplicateIdentifierType = function (index) {
            var isvalid = false;
            if ($scope.bookDetail.identifier[index].identifiertype === '' || $scope.bookDetail.identifier[index].identifiertype === undefined || $scope.bookDetail.identifier[index].identifiertype === null) {
                $scope.bookDetail.identifier[index]['typeerror'] = true;
                $scope.bookDetail.identifier[index]['identifiertypemessage'] = $filter('translate')('CATALOG_IDENTIFIER_TYPE_REQUIRED');
                return true;
            } else {
                $scope.bookDetail.identifier[index]['typeerror'] = false;
                $scope.bookDetail.identifier[index]['identifiertypemessage'] = '';
            }
            if ($scope.bookDetail.identifier[index].identifiertype !== null &&
                $scope.bookDetail.identifier[index].identifiertype !== undefined &&
                $scope.bookDetail.identifier[index].identifiertype !== '') {
                _.map($scope.bookDetail.identifier, function (ideval, key) {
                    if (index != key && ideval.identifiertype == $scope.bookDetail.identifier[index].identifiertype) {
                        $scope.bookDetail.identifier[index]['typeerror'] = true;
                        $scope.bookDetail.identifier[index]['identifiertypemessage'] = $filter('translate')('CATALOG_IDENTIFIER_TYPE_UNIQUE');
                        isvalid = true;
                    }
                    if(ideval.identifiertype =='9'){
                        $scope.isbn13valid = true;
                    }
                });

            }
            return isvalid;

        };
        /**
         * Check Duplicate Price
        */
        $scope.duplicateCurrency = function(index){
            var isvalid = false;
            if ($scope.bookDetail.priceArr[index].currency_id === '' || $scope.bookDetail.priceArr[index].currency_id === undefined || $scope.bookDetail.priceArr[index].currency_id === null) {
                $scope.bookDetail.priceArr[index]['currencyerror'] = true;
                $scope.bookDetail.priceArr[index]['currencymessage'] = $filter('translate')('CATALOG_CURRENCY_REQUIRED');
                return true;
            } else {
                $scope.bookDetail.priceArr[index]['currencyerror'] = false;
                $scope.bookDetail.priceArr[index]['currencymessage'] = '';
            }
            if ($scope.bookDetail.priceArr[index].currency_id !== null &&
                $scope.bookDetail.priceArr[index].currency_id !== undefined &&
                $scope.bookDetail.priceArr[index].currency_id !== '') {
                _.map($scope.bookDetail.priceArr, function (ideval, key) {
                    if (index != key && ideval.currency_id == $scope.bookDetail.priceArr[index].currency_id) {
                        $scope.bookDetail.priceArr[index]['currencyerror'] = true;
                        $scope.bookDetail.priceArr[index]['currencymessage'] = $filter('translate')('CATALOG_CURRENCY_UNIQUE');
                        isvalid = true;
                    }
                });

            }
            return isvalid;
        }

        $scope.identifierNameValid = function (index) {
            var isvalid = false;
            if ($scope.bookDetail.identifier[index].identifiername === '' || $scope.bookDetail.identifier[index].identifiername === undefined || $scope.bookDetail.identifier[index].identifiername === null) {
                $scope.bookDetail.identifier[index]['error'] = true;
                $scope.bookDetail.identifier[index]['identifiermessage'] = $filter('translate')('ENTER_IDENTIFIER');
                return true;
            } else {
                $scope.bookDetail.identifier[index]['error'] = false;
                $scope.bookDetail.identifier[index]['identifiermessage'] = '';
            }
            if ($scope.bookDetail.identifier[index].identifiername !== '' && ($scope.bookDetail.identifier[index].identifiertype == "2" || $scope.bookDetail.identifier[index].identifiertype == "9")) {
                isvalid = $scope.isValidIsbn($scope.bookDetail.identifier[index].identifiername, $scope.bookDetail.identifier[index].identifiertype);
                if (!isvalid) {
                    $scope.bookDetail.identifier[index]['error'] = true;
                    $scope.bookDetail.identifier[index]['identifiermessage'] = $filter('translate')('ENTER_VALID_ISBN');
                    isvalid = true;
                } else {
                    $scope.bookDetail.identifier[index]['error'] = false;
                    $scope.bookDetail.identifier[index]['identifiermessage'] = '';
                    isvalid = false;
                }
            }

            if ($scope.bookDetail.identifier[index].identifiername !== '' && ($scope.bookDetail.identifier[index].identifiertype == "3" || $scope.bookDetail.identifier[index].identifiertype == "8")) {
                isvalid = $scope.validateGtin($scope.bookDetail.identifier[index].identifiername, $scope.bookDetail.identifier[index].identifiertype);
                if (!isvalid) {
                    $scope.bookDetail.identifier[index]['error'] = true;
                    $scope.bookDetail.identifier[index]['identifiermessage'] = $filter('translate')('ENTER_VALID_GTIN');
                    isvalid = true;
                } else {
                    $scope.bookDetail.identifier[index]['error'] = false;
                    $scope.bookDetail.identifier[index]['identifiermessage'] = '';
                    isvalid = false;
                }
            }
            return isvalid;
        };
        $scope.productidentifierNameValid = function () {
            var isvalid = false;
            if ($scope.bookRelatedProductDetail.identifiername === '' || $scope.bookRelatedProductDetail.identifiername === undefined || $scope.bookRelatedProductDetail.identifiername === null) {
                $scope.relatedproduct.identifiererror = true;
                $scope.relatedproduct.identifiermessage = $filter('translate')('ENTER_IDENTIFIER');
                return true;
            } else {
                $scope.relatedproduct.identifiererror = false;
                $scope.relatedproduct.identifiermessage = '';
            }
            if ($scope.bookRelatedProductDetail.identifiername !== '' && $scope.bookRelatedProductDetail.identifiertype !== null &&
                $scope.bookRelatedProductDetail.identifiertype !== undefined && ($scope.bookRelatedProductDetail.identifiertype.id == "2" || $scope.bookRelatedProductDetail.identifiertype.id == "9")) {
                isvalid = $scope.isValidIsbn($scope.bookRelatedProductDetail.identifiername, $scope.bookRelatedProductDetail.identifiertype.id);
                if (!isvalid) {
                    $scope.relatedproduct.identifiererror = true;
                    $scope.relatedproduct.identifiermessage = $filter('translate')('ENTER_VALID_ISBN');
                    isvalid = true;
                } else {
                    $scope.relatedproduct.identifiererror = false;
                    $scope.relatedproduct.identifiermessage = '';
                    isvalid = false;
                }
            }
            if ($scope.bookRelatedProductDetail.identifiername !== '' && $scope.bookRelatedProductDetail.identifiertype !== null &&
                $scope.bookRelatedProductDetail.identifiertype !== undefined && ($scope.bookRelatedProductDetail.identifiertype.id == "3" || $scope.bookRelatedProductDetail.identifiertype.id == "8")) {
                isvalid = $scope.validateGtin($scope.bookRelatedProductDetail.identifiername, $scope.bookRelatedProductDetail.identifiertype.id);
                if (!isvalid) {
                    $scope.relatedproduct.identifiererror = true;
                    $scope.relatedproduct.identifiermessage = $filter('translate')('ENTER_VALID_GTIN');
                    isvalid = true;
                } else {
                    $scope.relatedproduct.identifiererror = false;
                    $scope.relatedproduct.identifiermessage = '';
                    isvalid = false;
                }
            }
            return isvalid;
        };
        /**
         * @description
         * ISBN valid
         */
        $scope.isValidIsbn = function (str, type) {
            var sum,
                weight,
                digit,
                check,
                i;
            str = str.replace(/-/gi, '');
            if (str.length != 10 && str.length != 13) {
                return false;
            } else if (str.length == 13 && type == 9) {
                sum = 0;
                for (i = 0; i < 12; i++) {
                    digit = parseInt(str[i]);
                    if (i % 2 == 1) {
                        sum += 3 * digit;
                    } else {
                        sum += digit;
                    }
                }
                check = (10 - (sum % 10)) % 10;
                return (check == str[str.length - 1]);
            } else if (str.length == 10 && type == 2) {
                weight = 10;
                sum = 0;
                for (i = 0; i < 9; i++) {
                    digit = parseInt(str[i]);
                    sum += weight * digit;
                    weight--;
                }
                check = 11 - (sum % 11);
                if (check == 10) {
                    check = 'X';
                }
                return (check == str[str.length - 1].toUpperCase());
            } else {
                return false;
            }
        };
        /**
         * @description
         * GTIN valid
         */
        $scope.validateGtin = function (value, type) {
            var barcode = value.substring(0, value.length - 1);
            var checksum = parseInt(value.substring(value.length - 1), 10);
            var calcSum = 0;
            var calcChecksum = 0;
            barcode.split('').map(function (number, index) {
                number = parseInt(number, 10);
                if (value.length % 2 === 0) {
                    index += 1;
                }
                if (index % 2 === 0) {
                    calcSum += number;
                } else {
                    calcSum += number * 3;
                }
            });
            calcSum %= 10;
            calcChecksum = (calcSum === 0) ? 0 : (10 - calcSum);
            if (calcChecksum !== checksum) {
                return false;
            }
            return true;
        };
        /**
         * @description
         * Price Config
         */
        $scope.addPrice = function () {
            $scope.bookDetail.priceArr.push({ currency_id: '', price: '' });
        };
        $scope.removePrice = function (priceDetail) {
            $scope.bookDetail.priceArr.splice($scope.bookDetail.priceArr.indexOf(priceDetail), 1);
        };
        /**
         * @description
         * Country Region config
         */
        $scope.getCountryRegionArr = function () {
            var Data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getCountryRegionList(Data)
                .then(function (data) {

                    $scope.updateCountryRegionArr(data, function () {
                        ivhTreeviewMgr.deselectAll($scope.countryRegionArr);


                        if ($scope.bookDetail.country_id !== undefined && $scope.bookDetail.country_id.length > 0) {
                            ivhTreeviewMgr.selectEach($scope.countryRegionArr, $scope.bookDetail.country_id);
                        }
                        if ($scope.bookDetail.region_id !== undefined && $scope.bookDetail.region_id.length === 1 && $scope.bookDetail.region_id[0] == 1) {
                            ivhTreeviewMgr.selectAll($scope.countryRegionArr);
                            ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                        }
                        if ($scope.countryRegionArr.length > 0) {
                            var is_region = true;
                            angular.forEach($scope.countryRegionArr, function (va, ke) {
                                if (ke != 0) {
                                    if (!va.selected) {
                                        is_region = false;
                                    }
                                }
                            });
                            if (is_region) {
                                ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                            }
                        }
                    });
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.updateCountryRegionArr = function (data, call) {
            angular.forEach(data.response, function (element) {
                if (COUNTRY_PREFERENCE[element.label] !== undefined && COUNTRY_PREFERENCE[element.label].length > 0) {
                    angular.forEach(COUNTRY_PREFERENCE[element.label], function (val, key) {

                        var index = $scope.bookDetail.country_id.indexOf(val.main_id);
                        if (index >= 0) {
                            $scope.bookDetail.country_id.push(val.id);
                        }
                        element.children.unshift(val)
                    });
                }
                $scope.countryRegionArr.push(element);
            });
            call();
        };

        $scope.countryMade = function (Node, IsSelected, Tree) {
            _.find($scope.countryRegionArr, function (objval) {
                if (objval.children !== undefined && objval.children.length > 0) {
                    var dupArr = _.where(objval.children, { country_id: Node.country_id });
                    if (IsSelected) {
                        angular.forEach(dupArr, function (dupval, dupkey) {
                            ivhTreeviewMgr.select($scope.countryRegionArr, dupval);
                        });
                    }
                    else {
                        angular.forEach(dupArr, function (dupval, dupkey) {
                            ivhTreeviewMgr.deselect($scope.countryRegionArr, dupval);
                        });
                    }
                }
            });

            if (Node.label === 'World' && Node.children === undefined && IsSelected) {
                ivhTreeviewMgr.selectAll($scope.countryRegionArr);
            }
            if (Node.label === 'World' && Node.children === undefined && !IsSelected) {
                ivhTreeviewMgr.deselectAll($scope.countryRegionArr);
            }
            if (Node.label !== 'World' && IsSelected) {
                ivhTreeviewMgr.deselect($scope.countryRegionArr, $scope.countryRegionArr[0]);
                $timeout(function () {
                    var isselectAll = true;
                    angular.forEach($scope.countryRegionArr, function (val, key) {
                        if (key !== 0 && !val.selected) {
                            isselectAll = false;
                        }
                    });
                    if (isselectAll) {
                        ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                    }
                }, 100);
            }
            if (Node.label !== 'World' && !IsSelected) {
                ivhTreeviewMgr.deselect($scope.countryRegionArr, $scope.countryRegionArr[0]);
            }
        };
        /**
         * @description
         * Currency List
         */
        $scope.getCurrencyList = function () {
            var currencyData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getCurrencyList(currencyData)
                .then(function (data) {
                    $scope.currencyList = data.response;
                })
                .catch(function () {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.getCompanyDetail = function () {
            var companyData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getCompanyDetail(companyData)
                .then(function (data) {
                    $scope.bookDetail.preview_percentage = ($scope.bookDetail.bookid !== '' && $scope.bookDetail.bookid !== null && $scope.bookDetail.bookid !== undefined && $scope.bookDetail.preview_percentage !== '') ? $scope.bookDetail.preview_percentage : parseInt(data.preview_percentage);
                    $scope.bookDetail.allow_preview = (data.allow_preview == 1) ? true : false;
                    $scope.bookDetail.publisher = data.response.name;
                    if (parameter.id === undefined || parameter.id === null || parameter.id === '') {
                        $scope.bookDetail.sellwithdrm = data.sellwithdrm;
                        $scope.bookDetail.no_of_redelivery = parseInt(data.no_of_redelivery);
                    }
                })
                .catch(function () {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * @description
         * Language List
         */
        $scope.getLanguageList = function () {
            var languageData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getLanguageList(languageData)
                .then(function (data) {
                    $scope.languageList = data.response;
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * @description
         * Subject List
         */
        $scope.getSubjectList = function () {
            if ($scope.subjectId !== undefined && $scope.subjectId.length >= 1) {
                var subjectData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    subject_name: $scope.subjectId
                };
                bookService.getSubjectList(subjectData)
                    .then(function (data) {
                        $scope.subjectList = data.response;
                        $scope.updatesubjectList(data, function () {
                            if ($scope.subjectNameList.length > 0) {
                                var subject = new autoComplete({
                                    selector: '#subjectId',
                                    minChars: 1,
                                    source: function (term, suggest) {
                                        term = term.toLowerCase();
                                        var choices = $scope.subjectNameList;
                                        var suggestions = [];
                                        for (i = 0; i < choices.length; i++)
                                            if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                                        suggest(suggestions);
                                    },
                                    onSelect: function (e, term, item) {
                                        var subject = _.where($scope.subjectList, { name: item.innerText });
                                        var index = _.where($scope.bookDetail.subject_id, subject[0]);
                                        if (index.length <= 0) {
                                            $scope.bookDetail.subject_id.push(subject[0]);
                                        }
                                        document.getElementById("subjectId").value = '';
                                        var divTag = document.getElementsByClassName('autocomplete-suggestions');
                                        var i = 0;
                                        for (i; i < divTag.length; i++) {
                                            divTag[i].innerHTML = '';
                                            divTag[i].removeAttribute('style');
                                        }
                                        $timeout(function () {
                                            document.getElementById("subjectId").focus();
                                        }, 0);
                                    }
                                });
                            }
                            else {
                                var divTag = document.getElementsByClassName('autocomplete-suggestions');
                                var i = 0;
                                for (i; i < divTag.length; i++) {
                                    divTag[i].innerHTML = '';
                                    divTag[i].removeAttribute('style');
                                }
                            }
                        });
                    })
                    .catch(function (err) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            }
            else {
                $scope.subjectNameList = [];
            }
        };

        $scope.updatesubjectList = function (data, call) {
            $scope.subjectNameList = _.pluck(data.response, 'name');
            call();
        };

        $scope.deleteSubject = function (id) {
            var subobj = _.where($scope.bookDetail.subject_id, { id: id });
            if (subobj.length >= 0) {
                var index = $scope.bookDetail.subject_id.indexOf(subobj[0]);
                $scope.bookDetail.subject_id.splice(index, 1);
            }
        };

        $scope.getRegionList = function () {
            var regionData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getRegionList(regionData)
                .then(function (data) {
                    $scope.regionList = data.response;
                    if ($scope.bookDetail.region_id.length > 0) {
                        $timeout(function () {
                            $scope.updateCountry();
                        }, 0);
                    }
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.getAudienceList = function () {
            var audienceData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getAudienceList(audienceData)
                .then(function (data) {
                    $scope.audienceList = data.response;
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.updateCountry = function () {
            var countryData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                region_array: $scope.bookDetail.region_id
            };
            bookService.getCountryList(countryData)
                .then(function (data) {
                    $scope.countryList = data.response;
                    $timeout(function () {
                    }, 0);
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.getAllCountry = function () {
            var countryData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                region_array: [1]
            };
            bookService.getCountryList(countryData)
                .then(function (data) {
                    $scope.awardCountryList = data.response;
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * @description
         * book Review Config
         */
        $scope.getReviewTypeList = function () {
            var reviewData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getReviewTypeList(reviewData)
                .then(function (data) {
                    $scope.reviewTypeList = data.response;
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.getReviewSourceList = function () {
            var reviewData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getReviewSourceList(reviewData)
                .then(function (data) {
                    $scope.reviewSourceList = data.response;
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.getReviewRoleList = function () {
            var reviewData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getReviewRoleList(reviewData)
                .then(function (data) {
                    $scope.reviewRoleList = data.response;
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.addBookReview = function () {
            if ($scope.addbookreviewform.$valid && $scope.bookReviewDetail.reviewtype.id != '' &&
                $scope.bookReviewDetail.reviewsource.id != '' && $scope.bookReviewDetail.reviewrole.id != '') {

                $scope.bookReviewList.push($scope.bookReviewDetail);
                $scope.bookReviewDetail = {
                    reviewtype: { id: '', name: '' }, reviewsource: { id: '', name: '' },
                    reviewtitle: '', reviewtext: '', reviewurl: '', reviewdate: '',
                    reviewrole: { id: '', name: '' }
                };
                $scope.bookReviewFormSubmit = false;

            } else {
                $scope.bookReviewFormSubmit = true;
                $scope.addbookreviewform.reviewtype.$invalid = ($scope.bookReviewDetail.reviewtype.id !== '') ? false : true;
                $scope.addbookreviewform.reviewsource.$invalid = ($scope.bookReviewDetail.reviewsource.id !== '') ? false : true;
                $scope.addbookreviewform.reviewrole.$invalid = ($scope.bookReviewDetail.reviewrole.id !== '') ? false : true;
            }
        };
        $scope.deleteBookReview = function (bookReview) {
            $scope.bookReviewList.splice($scope.bookReviewList.indexOf(bookReview), 1);
        };
        $scope.editBookReview = function (bookReview) {
            var reviewsourceval = _.where($scope.reviewSourceList, { id: bookReview.reviewsource.id, name: bookReview.reviewsource.name });
            var reviewtypeval = _.where($scope.reviewTypeList, { id: bookReview.reviewtype.id, name: bookReview.reviewtype.name });
            var reviewroleval = _.where($scope.reviewRoleList, { id: bookReview.reviewrole.id, name: bookReview.reviewrole.name });
            $scope.bookReviewEdit = true;
            $scope.editBookReviewObject = bookReview;
            $scope.bookReviewDetail = {
                reviewtype: (reviewtypeval[0] !== undefined) ? reviewtypeval[0] : {},
                reviewsource: (reviewsourceval[0] !== undefined) ? reviewsourceval[0] : {},
                reviewtitle: bookReview.reviewtitle, reviewtext: bookReview.reviewtext,
                reviewurl: bookReview.reviewurl, reviewdate: bookReview.reviewdate,
                reviewrole: (reviewroleval[0] !== undefined) ? reviewroleval[0] : {}
            };
        };
        $scope.updateBookReview = function () {
            if ($scope.addbookreviewform.$valid && $scope.bookReviewDetail.reviewtype.id != '' &&
                $scope.bookReviewDetail.reviewsource.id != '' && $scope.bookReviewDetail.reviewrole.id != '') {
                $scope.bookReviewList.splice($scope.bookReviewList.indexOf($scope.editBookReviewObject), 1);
                $scope.bookReviewList.push($scope.bookReviewDetail);
                $scope.bookReviewDetail = {
                    reviewtype: { id: '', name: '' }, reviewsource: { id: '', name: '' },
                    reviewtitle: '', reviewtext: '', reviewurl: '', reviewdate: '',
                    reviewrole: { id: '', name: '' }
                };
                $scope.bookReviewEdit = false;
                $scope.editBookReviewObject = {};
            } else {
                $scope.bookReviewFormSubmit = true;
                $scope.addbookreviewform.reviewtype.$invalid = ($scope.bookReviewDetail.reviewtype.id !== '') ? false : true;
                $scope.addbookreviewform.reviewsource.$invalid = ($scope.bookReviewDetail.reviewsource.id !== '') ? false : true;
                $scope.addbookreviewform.reviewrole.$invalid = ($scope.bookReviewDetail.reviewrole.id !== '') ? false : true;
            }
        };
        /**
         * @description
         * book Award Config
         */
        $scope.getAwardList = function () {
            var awardData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getAwardList(awardData)
                .then(function (data) {
                    $scope.AwardList = _.pluck(data.response, 'name');
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.getAwardCodeList = function () {
            var reviewData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getAwardCodeList(reviewData)
                .then(function (data) {
                    $scope.awardCodeList = data.response;
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.getRelatedCodeList = function () {
            var reviewData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            bookService.getRelatedCode(reviewData)
                .then(function (data) {
                    $scope.RelatedCodeList = data.response;
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.checkDuplicateAwardName = function () {
            var checkAwardName = _.where($scope.bookAwardList, { awardname: $scope.bookAwardDetail.awardname });
            if ($scope.editBookAwardObject.awardname !== undefined) {
                if (checkAwardName.length <= 1) {
                    $scope.awardNameError = '';
                } else {
                    $scope.awardNameError = $filter('translate')('ENTER_DIFFERENT_AWARD_NAME');
                }
            }
            else {
                if (checkAwardName.length <= 0) {
                    $scope.awardNameError = '';
                } else {
                    $scope.awardNameError = $filter('translate')('ENTER_DIFFERENT_AWARD_NAME');
                }
            }
        };
        $scope.addBookAward = function () {
            var checkAwardName = _.where($scope.bookAwardList, { awardname: $scope.bookAwardDetail.awardname });
            if ($scope.addbookawardform.$valid && $scope.bookAwardDetail.awardcountry.id != '' &&
                $scope.bookAwardDetail.awardcode.id != '' && checkAwardName.length <= 0) {
                $scope.bookAwardList.push($scope.bookAwardDetail);
                $scope.bookAwardDetail = {
                    awardname: '', awardyear: '',
                    awardcountry: { id: '', name: '' }, awardcode: { id: '', name: '' }
                };
                $scope.bookAwardFormSubmit = false;
                $scope.addbookawardform.awardcountry.$invalid = ($scope.addbookawardform.awardcountry.id !== '') ? false : true;
                $scope.addbookawardform.awardcode.$invalid = ($scope.addbookawardform.awardcode.id !== '') ? false : true;
            } else {
                $scope.bookAwardFormSubmit = true;
                $scope.addbookawardform.awardcountry.$invalid = ($scope.addbookawardform.awardcountry.id !== '') ? false : true;
                $scope.addbookawardform.awardcode.$invalid = ($scope.addbookawardform.awardcode.id !== '') ? false : true;
            }
        };
        $scope.deleteBookAward = function (bookAward) {
            $scope.bookAwardList.splice($scope.bookAwardList.indexOf(bookAward), 1);
        };
        $scope.editBookAward = function (bookAward) {
            $scope.awardNameError = '';
            var awardcountryval = _.where($scope.awardCountryList, { id: bookAward.awardcountry.id, name: bookAward.awardcountry.name });
            var awardcodeval = _.where($scope.awardCodeList, { id: bookAward.awardcode.id, name: bookAward.awardcode.name });
            $scope.bookAwardEdit = true;
            $scope.editBookAwardObject = bookAward;
            $scope.bookAwardDetail = {
                awardname: bookAward.awardname, awardyear: bookAward.awardyear,
                awardcountry: (awardcountryval[0] !== undefined) ? awardcountryval[0] : {},
                awardcode: (awardcodeval[0] !== undefined) ? awardcodeval[0] : {}
            };
        };
        $scope.updateBookAward = function () {
            var checkAwardName = _.where($scope.bookAwardList, { awardname: $scope.bookAwardDetail.awardname });
            if ($scope.addbookawardform.$valid && $scope.bookAwardDetail.awardcountry.id != '' &&
                $scope.bookAwardDetail.awardcode.id != '' && checkAwardName.length <= 1) {
                $scope.bookAwardList.splice($scope.bookAwardList.indexOf($scope.editBookAwardObject), 1);
                $scope.bookAwardList.push($scope.bookAwardDetail);
                $scope.bookAwardDetail = {
                    awardname: '', awardyear: '',
                    awardcountry: { id: '', name: '' }, awardcode: { id: '', name: '' }
                };
                $scope.bookAwardEdit = false;
                $scope.editBookAwardObject = {};
                $scope.bookAwardFormSubmit = false;
                $scope.addbookawardform.awardcountry.$invalid = ($scope.addbookawardform.awardcountry.id !== '') ? false : true;
                $scope.addbookawardform.awardcode.$invalid = ($scope.addbookawardform.awardcode.id !== '') ? false : true;
            } else {
                $scope.bookAwardFormSubmit = true;
                $scope.addbookawardform.awardcountry.$invalid = ($scope.addbookawardform.awardcountry.id !== '') ? false : true;
                $scope.addbookawardform.awardcode.$invalid = ($scope.addbookawardform.awardcode.id !== '') ? false : true;
            }
        };
        /**
         * @description
         * book Related Product Config
         */
        $scope.addBookRelatedProduct = function () {
            if ($scope.addbookproductform.$valid && !$scope.relatedproduct.identifiererror
                && $scope.bookRelatedProductDetail.identifiertype.id != '' && $scope.bookRelatedProductDetail.identifiertype.id != undefined
                && $scope.bookRelatedProductDetail.relatedcode.id != '' && $scope.bookRelatedProductDetail.relatedcode.id != undefined) {

                var isName = _.where($scope.bookRelatedProductsList, { identifiername: $scope.bookRelatedProductDetail.identifiername });
                if (isName.length <= 0) {
                    $scope.bookRelatedProductsList.push($scope.bookRelatedProductDetail);
                    $scope.bookRelatedProductDetail = {
                        relatedcode: { id: '', name: '' },
                        identifiertype: { id: '', name: '' },
                        identifiername: ''
                    };
                    $scope.bookProductFormSubmit = false;
                    $scope.addbookproductform.identifiertype.$invalid = false;
                    $scope.addbookproductform.relatedcode.$invalid = false;
                    $scope.productDuplicate = false;
                } else {
                    $scope.productDuplicate = true;
                }
            } else {
                $scope.bookProductFormSubmit = true;
                if ($scope.bookRelatedProductDetail.identifiertype.id == '' || $scope.bookRelatedProductDetail.identifiertype.id == undefined) {
                    $scope.addbookproductform.identifiertype.$invalid = true;
                }
                if ($scope.bookRelatedProductDetail.relatedcode.id == '' || $scope.bookRelatedProductDetail.relatedcode.id == undefined) {
                    $scope.addbookproductform.relatedcode.$invalid = true;
                }
                $scope.productDuplicate = false;
            }
        };
        $scope.deleteBookRelatedProduct = function (bookProduct) {
            $scope.bookRelatedProductsList.splice($scope.bookRelatedProductsList.indexOf(bookProduct), 1);
        };
        $scope.editBookRelatedProduct = function (bookProduct) {
            var identifiertypeval = _.where($scope.identifierList, { id: bookProduct.identifiertype.id, name: bookProduct.identifiertype.name });
            var relatedcodeval = _.where($scope.RelatedCodeList, { id: bookProduct.relatedcode.id, name: bookProduct.relatedcode.name });
            $scope.bookRelatedProductEdit = true;
            $scope.editBookRelatedProductObject = bookProduct;
            $scope.bookRelatedProductDetail = {
                relatedcode: (relatedcodeval[0] !== undefined) ? relatedcodeval[0] : {},
                identifiertype: (identifiertypeval[0] !== undefined) ? identifiertypeval[0] : {},
                identifiername: bookProduct.identifiername
            };
        };
        $scope.updateBookRelatedProduct = function () {
            if ($scope.addbookproductform.$valid && !$scope.relatedproduct.identifiererror
                && $scope.bookRelatedProductDetail.identifiertype !== undefined && $scope.bookRelatedProductDetail.identifiertype !== null && $scope.bookRelatedProductDetail.identifiertype.id != '' && $scope.bookRelatedProductDetail.identifiertype.id != undefined
                && $scope.bookRelatedProductDetail.relatedcode !== undefined && $scope.bookRelatedProductDetail.relatedcode !== null && $scope.bookRelatedProductDetail.relatedcode.id != '' && $scope.bookRelatedProductDetail.relatedcode.id != undefined) {

                var isName = _.where($scope.bookRelatedProductsList, { identifiername: $scope.bookRelatedProductDetail.identifiername });
                if (isName.length <= 1) {
                    $scope.bookRelatedProductsList.splice($scope.bookRelatedProductsList.indexOf($scope.editBookRelatedProductObject), 1);
                    $scope.bookRelatedProductsList.push($scope.bookRelatedProductDetail);
                    $scope.bookRelatedProductDetail = {
                        relatedcode: { id: '', name: '' },
                        identifiertype: { id: '', name: '' },
                        identifiername: ''
                    };
                    $scope.bookRelatedProductEdit = false;
                    $scope.editBookRelatedProductObject = {};
                    $scope.bookProductFormSubmit = false;
                    $scope.addbookproductform.identifiertype.$invalid = false;
                    $scope.addbookproductform.relatedcode.$invalid = false;
                    $scope.productDuplicate = false;
                } else {
                    $scope.productDuplicate = true;
                }
            } else {
                $scope.bookProductFormSubmit = true;
                if ($scope.bookRelatedProductDetail.identifiertype === undefined || $scope.bookRelatedProductDetail.identifiertype === null || $scope.bookRelatedProductDetail.identifiertype.id == '' || $scope.bookRelatedProductDetail.identifiertype.id == undefined) {
                    $scope.addbookproductform.identifiertype.$invalid = true;
                }
                if ($scope.bookRelatedProductDetail.relatedcode === undefined || $scope.bookRelatedProductDetail.relatedcode === null || $scope.bookRelatedProductDetail.relatedcode.id == '' || $scope.bookRelatedProductDetail.relatedcode.id == undefined) {
                    $scope.addbookproductform.relatedcode.$invalid = true;
                }
                $scope.productDuplicate = false;
            }
        };
        /**
         * @description
         * Book Image Upload
         */
        $scope.setFile = function (element) {
            var isvalid = true;
            $scope.currentFile = element.files[0];
            if ($scope.currentFile.size !== undefined && $scope.currentFile.size > 2000000) {
                isvalid = false;
            }
            if (isvalid) {
                var reader = new FileReader();
                reader.onload = function (event) {
                    $scope.isError = false;
                    $scope.isMessage = false;
                    $scope.bookDetail.cover_image = event.target.result;
                    $scope.$apply();
                }
                reader.readAsDataURL(element.files[0]);
            }
            else {
                $window.scrollTo(0, 0);
                $scope.isError = true;
                $scope.isMessage = false;
                $scope.message = $filter('translate')('BOOK_IMAGE_TOO_LARGE');
                $scope.$apply();
            }
        };

        /**
         * @description
         * Epub Upload
         */

        $scope.uploadEpubFile = function (element) {
            var isvalid = true;
            $scope.currentFile = element.files[0];
            if ($scope.currentFile.size !== undefined && $scope.currentFile.size > 10999999) {
                isvalid = false;
            }
            if (isvalid) {
                var reader = new FileReader();
                reader.onload = function (event) {
                    $scope.isError = false;
                    $scope.isMessage = false;
                    $scope.bookDetail.epub_file = event.target.result;
                    $scope.$apply();
                }
                reader.readAsDataURL(element.files[0]);
            }
            else {
                $window.scrollTo(0, 0);
                $scope.isError = true;
                $scope.isMessage = false;
                $scope.message = $filter('translate')('BOOK_EPUB_VALID');
                $scope.$apply();
            }
        };
        /**
         * check Preview Pattern
         */
        $scope.checkPreviewPattern = function () {
            if (!$scope.bookDetail.disallow_preview) {
                $scope.previewsettingserr = !numbers.test($scope.bookDetail.preview_percentage);
            }
            else {
                $scope.previewsettingserr = false;
            }
            if (!$scope.bookDetail.disallow_preview && ($scope.bookDetail.preview_percentage < 1 || $scope.bookDetail.preview_percentage > 100)) {
                $scope.previewsettingsrangeerr = true;
            }
            else {
                $scope.previewsettingsrangeerr = false;
            }
        }
        /**
         * @description
         * Add Book
         */
        $scope.addBookDetail = function () {
            $scope.previewsettingsrangeerr = false;
            $scope.previewsettingserr = ($scope.bookDetail.allow_preview && $scope.bookDetail.preview_percentage !== '' && $scope.bookDetail.preview_percentage !== undefined && $scope.bookDetail.preview_percentage !== null) ? !numbers.test($scope.bookDetail.preview_percentage) : false;
            if ($scope.bookDetail.allow_preview && !$scope.bookDetail.disallow_preview && ($scope.bookDetail.preview_percentage < 1 || $scope.bookDetail.preview_percentage > 100)) {
                $scope.previewsettingsrangeerr = true;
            }
            var iserr = false;
            $scope.isbn13valid = false;
            angular.forEach($scope.bookDetail.identifier, function (val, key) {
                if (val.error || val.typeerror) {
                    iserr = true;
                }
                if(val.identifiertype=='9'){
                    $scope.isbn13valid = true;
                }
            });
            /**
             * unique Currebcy check
             */
            angular.forEach($scope.bookDetail.priceArr, function (val, key) {
                if (val.currencyerror) {
                    iserr = true;
                }
            });

            if ($scope.addbook.$valid && !iserr && !$scope.previewsettingserr && !$scope.previewsettingsrangeerr && $scope.isbn13valid) {
                $scope.bookDetail.region_id = [];
                $scope.bookDetail.country_id = [];

                angular.forEach($scope.countryRegionArr, function (value, key) {
                    if (value.selected) {
                        $scope.bookDetail.region_id.push(value.id);
                    }
                    if (value.children !== undefined && value.children.length > 0) {
                        angular.forEach(value.children, function (childvalue, childkey) {
                            if (childvalue.selected) {
                                if ($scope.bookDetail.region_id.indexOf(value.id) < 0) {
                                    $scope.bookDetail.region_id.push(value.id)
                                }
                                var arr = childvalue.id.split('_');
                                $scope.bookDetail.country_id.push(arr[0]);
                            }
                        });
                        $scope.bookDetail.country_id = $scope.bookDetail.country_id.filter(function (item, i, ar) { return ar.indexOf(item) === i; });
                    }
                });
                $scope.bookDetail.source_image = '';
                $scope.bookDetail.publication_date = $filter('dateFormat')($scope.bookDetail.publication_date);
                $scope.bookDetail.supply_date = $filter('dateFormat')($scope.bookDetail.supply_date);
                $scope.bookDetail.title_availability = $filter('dateFormat')($scope.bookDetail.title_availability);

                var bookReviewListArr = _.map($scope.bookReviewList,
                    function (valuereview, key) {
                        valuereview.reviewdate = $filter('dateFormat')(valuereview.reviewdate);
                        return valuereview;
                    });

                var bookData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    bookDetail: $scope.bookDetail,
                    bookReview: bookReviewListArr,
                    bookAward: $scope.bookAwardList,
                    relatedProduct: $scope.bookRelatedProductsList,
                };
                bookService.insertBookDetail($scope.currentFile, bookData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $location.search({});
                            $location.path('/maintainbooks');
                            $rootScope.maintainbooksmessage = data.msg;
                            $rootScope.maintainbooksisError = false;
                            $rootScope.maintainbooksisMessage = true;
                        } else {
                            $window.scrollTo(0, 0);
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    },
                    function (err, status) {
                        $window.scrollTo(0, 0);
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });

            } else {
                $scope.isSubmitted = true;
                $scope.bookReviewFormSubmit = false;
                $scope.bookAwardFormSubmit = false;
                $scope.bookProductFormSubmit = false;
            }
        };
        /**
         * @description
         * Edit Book
         */
        $scope.editBookDetail = function () {
            $scope.previewsettingsrangeerr = false;
            $scope.previewsettingserr = ($scope.bookDetail.allow_preview && $scope.bookDetail.preview_percentage !== '' && $scope.bookDetail.preview_percentage !== undefined && $scope.bookDetail.preview_percentage !== null) ? !numbers.test($scope.bookDetail.preview_percentage) : false;
            if ($scope.bookDetail.allow_preview && !$scope.bookDetail.disallow_preview && ($scope.bookDetail.preview_percentage < 1 || $scope.bookDetail.preview_percentage > 100)) {
                $scope.previewsettingsrangeerr = true;
            }
            $scope.isbn13valid = false;
            var iserr = false;
            angular.forEach($scope.bookDetail.identifier, function (val, key) {
                if (val.error || val.typeerror) {
                    iserr = true;
                }
                if(val.identifiertype=='9'){
                    $scope.isbn13valid = true;
                }
            });
            /**
             * unique Currebcy check
             */
            angular.forEach($scope.bookDetail.priceArr, function (val, key) {
                if (val.currencyerror) {
                    iserr = true;
                }
            });


            if ($scope.addbook.$valid && !iserr && !$scope.previewsettingserr && !$scope.previewsettingsrangeerr && $scope.isbn13valid) {
                $scope.bookDetail.region_id = [];
                $scope.bookDetail.country_id = [];
                if ($scope.countryRegionArr[0].selected) {
                    $scope.bookDetail.region_id.push($scope.countryRegionArr[0].id);
                }
                else {
                    angular.forEach($scope.countryRegionArr, function (value, key) {
                        if (value.selected) {
                            $scope.bookDetail.region_id.push(value.id);
                        }
                        if (value.children !== undefined && value.children.length > 0) {
                            angular.forEach(value.children, function (childvalue, childkey) {
                                if (childvalue.selected) {
                                    if ($scope.bookDetail.region_id.indexOf(value.id) < 0) {
                                        $scope.bookDetail.region_id.push(value.id)
                                    }
                                    var arr = childvalue.id.split('_');
                                    $scope.bookDetail.country_id.push(arr[0]);
                                }
                            });
                        }
                    });
                    $scope.bookDetail.country_id = $scope.bookDetail.country_id.filter(function (item, i, ar) { return ar.indexOf(item) === i; });
                }

                $scope.bookDetail.source_image = '';
                $scope.bookDetail.publication_date = $filter('dateFormat')($scope.bookDetail.publication_date);
                $scope.bookDetail.supply_date = $filter('dateFormat')($scope.bookDetail.supply_date);
                $scope.bookDetail.title_availability = $filter('dateFormat')($scope.bookDetail.title_availability);

                var bookReviewListArr = _.map($scope.bookReviewList,
                    function (valuereview, key) {
                        valuereview.reviewdate = $filter('dateFormat')(valuereview.reviewdate);
                        return valuereview;
                    });

                var bookData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    book_id: parameter.id,
                    bookDetail: $scope.bookDetail,
                    bookReview: bookReviewListArr,
                    bookAward: $scope.bookAwardList,
                    relatedProduct: $scope.bookRelatedProductsList
                };

                bookService.updateBookDetail(bookData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $location.search({});
                            if (parameter.isCat) {
                                $location.path('/catalog');
                                $rootScope.catalogmessage = data.msg;
                                $rootScope.catalogisError = false;
                                $rootScope.catalogisMessage = true;
                            }
                            else {
                                $location.path('/maintainbooks');
                                $rootScope.maintainbooksmessage = data.msg;
                                $rootScope.maintainbooksisError = false;
                                $rootScope.maintainbooksisMessage = true;
                            }
                        } else {
                            $window.scrollTo(0, 0);
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    },
                    function (err, status) {
                        $window.scrollTo(0, 0);
                        $rootScope.maintainbooksisError = true;
                        $rootScope.maintainbooksisMessage = false;
                    });
            } else {
                $scope.isSubmitted = true;
                $scope.bookReviewFormSubmit = false;
                $scope.bookAwardFormSubmit = false;
                $scope.bookProductFormSubmit = false;
            }
        };

        /**
         * @description
         * on load get List of Data
         */
        if (parameter.id === undefined) {
            //$scope.getSubjectList();
            $scope.getRegionList();
            $scope.getAllCountry();
            $scope.getCompanyDetail();
            $scope.getCountryRegionArr();
        }
        $scope.getIdentifierType();
        $scope.getCurrencyList();
        $scope.getLanguageList();
        $scope.getAudienceList();
        $scope.getReviewTypeList();
        $scope.getReviewSourceList();
        $scope.getReviewRoleList();
        $scope.getAwardCodeList();
        $scope.getRelatedCodeList();
        $scope.getAwardList();
        //  $scope.getContributorsName();
        $scope.getContributorsRole();
    }]);
