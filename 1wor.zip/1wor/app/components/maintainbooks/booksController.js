'use strict';
angular.module('OneWorld').controller('booksController', ['$scope', '$rootScope', 'catalogService', '$uibModal', '$location', '$sessionStorage', 'localStorageService','$filter',
    function ($scope, $rootScope, catalogService, $uibModal, $location, $sessionStorage, localStorageService,$filter) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.booksList = [];
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'title',
            sorttype: 'ASC',
            maxsize: 10
        };
        $scope.state = false;
        $scope.selectedBookList = [];
        $scope.pageIds = [];
        $scope.booksListData = {bookArr: [], allchecked: false};
        $scope.isError = ($rootScope.maintainbooksisError !== undefined) ? $rootScope.maintainbooksisError : false;
        $scope.isMessage = ($rootScope.maintainbooksisMessage !== undefined) ? $rootScope.maintainbooksisMessage : false;
        $scope.message = ($rootScope.maintainbooksmessage !== undefined) ? $rootScope.maintainbooksmessage : '';


        var searchMaintainBooksData = cookies.get('searchMaintainBooksData');
        if(searchMaintainBooksData!==null && searchMaintainBooksData!==undefined && searchMaintainBooksData!==''){
            // $scope.search_title = searchMaintainBooksData.search_title;
            // $scope.search_author = searchMaintainBooksData.search_author;
            // $scope.search_imprint = searchMaintainBooksData.search_imprint;
            // $scope.search_publisher = searchMaintainBooksData.search_publisher;
        }
        //cookies.set('searchMaintainBooksData',null);


        $scope.goBack = function(){
            $location.path('dashboard');
        };
        $scope.toggleState = function () {
            $scope.state = !$scope.state;
        };
        /**
         * @description
         * List checked - unchecked event
         */
        $scope.checkAll = function () {
            if ($scope.booksListData.allchecked) {
                _.each($scope.booksList, function (element) {
                    var isavl = true;
                    _.each($scope.booksListData.bookArr, function (obj) {
                        if (obj.id === element.id) {
                            isavl = false;
                        }
                    });
                    if (isavl) {
                        $scope.booksListData.bookArr.push(element);
                    }
                });
            } else {
                var arr = [];
                angular.forEach($scope.booksListData.bookArr, function (element) {
                    if ($scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.booksListData.bookArr = arr;
            }
        };

        $scope.uncheckMain = function () {
            $scope.booksListData.allchecked = false;
        };

        $scope.getBooks = function () {
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getBooksData(booksData);
        };
        /*
         * @description
         * Grid Option
         * */
        $scope.$watch('currentPage', function (pageNo) {
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getBooksData(booksData);
            //or any other code here
        });

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            $scope.getBooksData(booksData);
            var pagesizeelm = angular.element( document.querySelectorAll( '#pagesize' ) );
            angular.forEach(pagesizeelm,function(val,key){
                pagesizeelm[key].blur();
            });
        };

        $scope.bookSearch = function () {
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            $scope.getBooksData(booksData);
        };

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            $scope.getBooksData(booksData);
        };
        $scope.cancelSearch = function () {
            $scope.search_title = '';
            $scope.search_author = '';
            $scope.search_imprint = '';
            $scope.search_publisher = '';
            $scope.booksListData = {bookArr: [], allchecked: false};
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            $scope.getBooksData(booksData);
        };
        /*
         * @description
         * End Grid Option*/
        $scope.getBooksData = function (booksData) {
            booksData.dataLoader = true;
            catalogService.getMaintainBooksList(booksData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.pageIds = data.ids.split(',');
                            $scope.booksListData.allchecked = false;
                            $scope.booksList = data.response;
                            $scope.gridOption.filteredItems = data.total_rows;
                            $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                            if ($scope.gridOption.maxsize > 5) {
                                $scope.gridOption.maxsize = 5;
                            }

                            $rootScope.maintainbooksisError = false;
                            $rootScope.maintainbooksisMessage = false;
                            $rootScope.maintainbooksmessage = '';
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        /**
         * @description
         * Delete Books
         */
        $scope.deleteSelectedBook = function () {
            if ($scope.booksListData.bookArr.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/maintainbooks/publisherBookDelete.html',
                    controller: 'bookDeleteCtrl',
                    resolve: {
                        BookData: function () {
                            return {bookArr: $scope.booksListData.bookArr};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.deleteBookArr(dataObj.bookArr);
                }, function () {
                    console.log('error');
                });
            } else {
                 var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL')};
                        }
                    }
                });
                modalInstance.result.then(function () {

                }, function () {
                    console.log('error');
                });
            }
        };
        $scope.deleteBookRow = function (bookObj) {
            var arr = [];
            arr.push({id: bookObj.id});
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function () {
                        return {ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('CATALOG_REMOVE_CONFIRMATION_LABEL')};
                    }
                }
            });
            modalInstance.result.then(function () {
                $scope.deleteBookArr(arr);
            }, function () {
                console.log('error');
            });

        };
        $scope.deleteBookArr = function (dataObj) {
            var bookIdArr = [];
            angular.forEach(dataObj, function (value, key) {
                bookIdArr.push(value.id);

            });
            var bookData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                bookListArr: bookIdArr
            };
            catalogService.deleteBook(bookData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            var booksData = {
                                access_token: TokenData.access_token,
                                language: $rootScope.language,
                                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                                pageLimit: $scope.gridOption.pageLimit,
                                sortField: $scope.gridOption.sortField,
                                sorttype: $scope.gridOption.sorttype,
                                search_title: $scope.search_title,
                                search_author: $scope.search_author,
                                search_imprint: $scope.search_imprint,
                                search_publisher: $scope.search_publisher
                            };
                            $scope.getBooksData(booksData);
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        /*
         * @description
         * Book Details*/
        $scope.bookDetailsModal = function (bookId) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/maintainbooks/publisherBookDetail.html',
                controller: 'bookDetailCtrl',
                resolve: {
                    bookData: function () {
                        return {bookId: bookId, type: 'publisher'};
                    }
                }
            });
            modalInstance.result.then(function (bookObj) {
                var searchMaintainbookData = {
                    search_title: $scope.search_title,
                    search_author: $scope.search_author,
                    search_imprint: $scope.search_imprint,
                    search_publisher: $scope.search_publisher,
                    bookId : bookId
                };
                cookies.set('searchMaintainBooksData',searchMaintainbookData);
                $location.path('editbook').search({id: bookObj.id});
            }, function () {
                console.log('Closed');
            });
        };
        /**
         * edit book
         */
        $scope.editBook = function(bookId){
            var searchMaintainbookData = {
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            cookies.set('searchMaintainBooksData',searchMaintainbookData);
            $location.path('editbook').search({id: bookId});
        }


        if(searchMaintainBooksData!==null && searchMaintainBooksData!==undefined && searchMaintainBooksData!==''){
            if(searchMaintainBooksData.bookId!==undefined && searchMaintainBooksData.bookId!==null && searchMaintainBooksData.bookId!==''){
                $scope.bookDetailsModal(searchMaintainBooksData.bookId);
            }
        }
        cookies.set('searchMaintainBooksData',null);

    }]);

angular.module('OneWorld').controller('bookDeleteCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'BookData', 'localStorageService',
    function ($scope, $rootScope, $uibModalInstance, BookData, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.ModalTitle = 'Confirmation';
        $scope.bookDelete = function () {
            $uibModalInstance.close({bookArr: BookData.bookArr});
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);