/**
 * @description
 * # book request
 */
'use strict';
App.factory('bookService', ['$http', '$q', function ($http, $q) {
        var bookServiceFactory = {};
        /**
         * @description
         * # contributor list
         */
        var _getContributorsRoleList = function (contributorData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_contributors_role',
                method: "GET",
                data: contributorData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # identifier list
         */
        var _getIdentifierTypeList = function (identifierData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_identifier_types',
                method: "POST",
                data: identifierData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # currency  list
         */
        var _getCurrencyList = function (currecyData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_currency',
                method: "GET",
                data: currecyData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # language list
         */
        var _getLanguageList = function (languageData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_language',
                method: "GET",
                data: languageData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # subject list
         */
        var _getSubjectList = function (subjectData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_subject',
                method: "POST",
                data: subjectData,
                cache: true
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # region list
         */
        var _getRegionList = function (regionData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_regions',
                method: "POST",
                data: regionData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # audience list
         */
        var _getAudienceList = function (audienceData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_audience',
                method: "POST",
                data: audienceData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # country list
         */
        var _getCountryList = function (countryData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_country',
                method: "POST",
                data: countryData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # review type list
         */
        var _getReviewTypeList = function (reviewData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_review_type',
                method: "GET",
                data: reviewData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # review source list
         */
        var _getReviewSourceList = function (reviewData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_review_source',
                method: "GET",
                data: reviewData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # review role list
         */
        var _getReviewRoleList = function (reviewData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_review_date_role',
                method: "GET",
                data: reviewData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # award code list
         */
        var _getAwardCodeList = function (reviewData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_awards_code',
                method: "GET",
                data: reviewData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # related code list
         */
        var _getRelatedCode = function (reviewData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_relation_code',
                method: "GET",
                data: reviewData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # book insert
         */
        var _insertBookDetail = function (fileData,bookData) {
            // var deferred = $q.defer();
            // var fd = new FormData();
            // fd.append('file', fileData[0]);
            // fd.append('bookData', JSON.stringify(bookData));
            // $http({
            //     headers: {'Content-Type': undefined},
            //     url: 'api/catalog/add_catalog',
            //     method: "POST",
            //     data: fd,
            // })
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': undefined},
                //headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/add_catalog',
                method: "POST",
                data: bookData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # book update
         */
        var _updateBookDetail = function (bookData) {
            // var deferred = $q.defer();
            // var fd = new FormData();
            // fd.append('file', fileData[0]);
            // fd.append('bookData', JSON.stringify(bookData));
            // $http({
            //     headers: {'Content-Type': undefined},
            //     url: 'api/catalog/update_catalog',
            //     method: "POST",
            //     data: fd,
            // })
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': undefined},
//                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/update_catalog',
                method: "POST",
                data: bookData
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * @description
         * # award list
         */
        var _getAwardList = function (awardData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_awards',
                method: "POST",
                data: awardData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # book detail
         */
        var _getBookDetail = function (bookData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/get_catalog_details_by_id',
                method: "POST",
                data: bookData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _getContributorsNameList = function (contributorData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_contributors_people',
                method: "POST",
                data: contributorData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # company detail
         */
        var _getCompanyDetail = function (companyData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_company_name',
                method: "POST",
                data: companyData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # country-region list
         */
        var _getCountryRegionList = function (Data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/get_region_with_country',
                method: "POST",
                data: Data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };


        bookServiceFactory.getContributorsRoleList = _getContributorsRoleList;
        bookServiceFactory.getIdentifierTypeList = _getIdentifierTypeList;
        bookServiceFactory.getCurrencyList = _getCurrencyList;
        bookServiceFactory.getLanguageList = _getLanguageList;
        bookServiceFactory.getSubjectList = _getSubjectList;
        bookServiceFactory.getRegionList = _getRegionList;
        bookServiceFactory.getAudienceList = _getAudienceList;
        bookServiceFactory.getCountryList = _getCountryList;
        bookServiceFactory.getReviewTypeList = _getReviewTypeList;
        bookServiceFactory.getReviewSourceList = _getReviewSourceList;
        bookServiceFactory.getReviewRoleList = _getReviewRoleList;
        bookServiceFactory.getAwardCodeList = _getAwardCodeList;
        bookServiceFactory.getRelatedCode = _getRelatedCode;
        bookServiceFactory.insertBookDetail = _insertBookDetail;
        bookServiceFactory.getAwardList = _getAwardList;
        bookServiceFactory.getBookDetail = _getBookDetail;
        bookServiceFactory.getContributorsNameList = _getContributorsNameList;
        bookServiceFactory.updateBookDetail = _updateBookDetail;
        bookServiceFactory.getCompanyDetail = _getCompanyDetail;
        bookServiceFactory.getCountryRegionList = _getCountryRegionList;
        return bookServiceFactory;
    }]);