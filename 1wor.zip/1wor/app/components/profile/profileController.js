'use strict';
angular.module('OneWorld').controller('profileController', ['$scope', '$rootScope', '$uibModal', 'profileService', 'businessmodelService', 'languageService', 'countryService', 'ivhTreeviewMgr', '$timeout', '$location', '$sessionStorage', 'localStorageService', 'publisherpreferenceService', '$filter', 'COUNTRY_PREFERENCE',
    function($scope, $rootScope, $uibModal, profileService, businessmodelService, languageService, countryService, ivhTreeviewMgr, $timeout, $location, $sessionStorage, localStorageService, publisherpreferenceService, $filter, COUNTRY_PREFERENCE) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.account_no = TokenData.account_no;
        $scope.yourinformation = {
            first_name: '',
            last_name: '',
            title: '',
            email: '',
            password: '',
            editpassword: false,
            editemail: false
        };
        $scope.achpaymentdata = {
            account_name: '',
            account_number: '',
            bank_address: '',
            bank_name: '',
            routing_number: '',
            achchecked: false
        };
        $scope.paypalpaymentdata = {
            paypal_email: '',
            paypal_confirmemail: '',
            paypalchecked: false
        };
        $scope.dwollapaymentdata = {
            dwollachecked: false
        };
        $scope.deliveryInfo = {
            ftp_address: '',
            ftp_username: '',
            ftp_password: '',
            ftp_available: false
        };
        $scope.yourinfosubmitted = false;
        $scope.paypalpaymentSubmitted = false;
        $scope.paypalemailmatch = false;

        $scope.companyData = { address: '', contact_no: '', contact_person: '', name: '' };
        $scope.financialData = { account_number: '', bank_address: '', bank_name: '', dwolla_account_number: '', routing_number: '' };
        $scope.logo = '';
        $scope.isCompanyFinancialSubmitted = false;
        $scope.showPublisherConfirmationModal = false;
        $scope.isImage = false;
        //$scope.companyInfoActive = true;
        $scope.showInviteActionModal = false;
        $scope.isUserSubmitted = false;
        $scope.inviteNewUserSubmitted = false;
        $scope.permissionArr = [];
        $scope.pageSizeArr = [1, 5, 10, 20, 50, 100];
        $scope.currentPage = 1;
        $scope.pageLimit = 10;
        $scope.maxsize = 10;
        $scope.list = [];
        $scope.sortField = 'created_on';
        $scope.sorttype = 'DESC';

        $scope.preferenceDetail = {
            businessmodel_id: [],
            language_id: [],
            country_id: [],
            markup: 30,
            main_country_id: '',
            //currency_preference : ''
        };
        $scope.languageList = [];
        $scope.businessModelList = [];
        $scope.countryList = [];
        $scope.isMarkupAvailable = false;
        $scope.isMarkupRequired = false;
        $scope.isSubmitted = false;
        $scope.countryRegionArr = [];
        $scope.selectedCountry = [];
        $scope.countryError = false;
        $scope.isMessage = false;
        $scope.isError = false;
        // Prefernce Scope
        $scope.whiteListRetailer = [];
        $scope.blackListRetailer = [];
        $scope.retailerList = [];
        $scope.retailerArr = [];
        $scope.preference_detail = {
            trust_level: 1,
            old_trust_level: 1,
            group_type: '',
            whitelist_retailer_name: '',
            blcaklist_retailer_name: '',
            preference_id: ''
        };
        $scope.currencyList = [];
        $scope.preview_settings = {};
        $scope.whiteRetailerError = '';
        $scope.blackRetailerError = '';
        $scope.trustLevelId = '';
        $scope.isSubmitted = false;
        $scope.isMessage = false;
        $scope.isError = false;
        $scope.previewPercentageList = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50];
        // Active tab
        $scope.activeInfo = {
            companyInfoActive: (TokenData.invited_by !== undefined && TokenData.invited_by == 0) ? true : false,
            yourInfoActive: (TokenData.invited_by !== undefined && TokenData.invited_by != 0) ? true : false,
            usersInfoActive: false,
            oneworldpayActive: false,
            deliveryInfoActive: false,
            publisherpreferenceActive: false,
            preference: false,
        };
        /**
         * @description
         * move to Dashboard page
         */
        $scope.goBack = function() {
            $location.path('dashboard');
        };
        /**
         * @description
         * move to Retailer Dashboard page
         */
        $scope.goBackRetailer = function() {
            $location.path('retailerdashboard');
        };
        /*
        * @description
        grid option */
        $scope.profileDetail = function() {
            if (TokenData.module_rights.indexOf(1) >= 0) {
                $scope.activeInfo = {
                        yourInfoActive: false,
                        companyInfoActive: false,
                        usersInfoActive: true,
                        oneworldpayActive: false,
                        deliveryInfoActive: false,
                        publisherpreferenceActive: false,
                        preference: false,
                    }
                    //$scope.companyInfoActive = false;
            }
            if (TokenData.module_rights.indexOf(2) >= 0) {
                $scope.activeInfo = {
                        yourInfoActive: false,
                        companyInfoActive: true,
                        usersInfoActive: false,
                        oneworldpayActive: false,
                        deliveryInfoActive: false,
                        publisherpreferenceActive: false,
                        preference: false,
                    }
                    //$scope.companyInfoActive = true;
            }

            if (TokenData.invited_by !== undefined && TokenData.invited_by == 0) {
                $scope.activeInfo = {
                    yourInfoActive: true,
                    companyInfoActive: false,
                    usersInfoActive: false,
                    oneworldpayActive: false,
                    deliveryInfoActive: false,
                    publisherpreferenceActive: false,
                    preference: false,
                };
            }
            $scope.getProfileData();
        };

        $scope.getProfileData = function() {
            if ($scope.activeInfo.companyInfoActive) {
                var profileDetail = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language
                };
                profileService.getProfileDetail(profileDetail)
                    .then(function(data) {
                        if (data.error <= 0) {
                            $scope.logo = data.response.logo;
                            $scope.companyData = data.response.company;
                            $scope.financialData = data.response.financial;
                            $scope.isImage = data.response.is_image;
                            $scope.isError = false;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function(err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            } else if ($scope.activeInfo.usersInfoActive) {
                var userDetail = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.currentPage - 1) * $scope.pageLimit,
                    pageLimit: $scope.pageLimit,
                    sortField: $scope.sortField,
                    sorttype: $scope.sorttype,
                };
                $scope.getUserData(userDetail);
            } else if ($scope.activeInfo.oneworldpayActive) {
                var userDetail = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language
                };
                profileService.getPaymentDetail(userDetail)
                    .then(function(data) {
                        if (data.error <= 0) {
                            $scope.achpaymentdata = data.response.achpaymentdata;
                            $scope.paypalpaymentdata = data.response.paypalpaymentdata;
                            $scope.paypalpaymentdata.paypal_confirmemail = $scope.paypalpaymentdata.paypal_email;
                            $scope.dwollapaymentdata = data.response.dwollapaymentdata;
                            if (($scope.achpaymentdata.account_name !== null && $scope.achpaymentdata.account_name !== '') || ($scope.achpaymentdata.account_number !== null && $scope.achpaymentdata.account_number !== '') || ($scope.achpaymentdata.bank_address !== null && $scope.achpaymentdata.bank_address !== '') || ($scope.achpaymentdata.bank_name !== null && $scope.achpaymentdata.bank_name !== '') || ($scope.achpaymentdata.routing_number !== null && $scope.achpaymentdata.routing_number !== '')) {
                                $scope.achpaymentdata.achchecked = true;
                            } else {
                                $scope.achpaymentdata.achchecked = false;
                            }
                            if ($scope.paypalpaymentdata.paypal_email !== null && $scope.paypalpaymentdata.paypal_email !== undefined && $scope.paypalpaymentdata.paypal_email !== '') {
                                $scope.paypalpaymentdata.paypalchecked = true;
                            } else {
                                $scope.paypalpaymentdata.paypalchecked = false;
                            }

                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function(err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            } else if ($scope.activeInfo.deliveryInfoActive) {
                var userDetail = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language
                };
                profileService.getDeliveryDetail(userDetail)
                    .then(function(data) {
                        if (data.error <= 0) {
                            $scope.deliveryInfo = data.response.company;
                            $scope.deliveryInfo.ftp_available = (data.response.company.ftp_address == null) ? false : true;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function(err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            } else if ($scope.activeInfo.publisherpreferenceActive) {
                $scope.getRetaileTrustList();
                $scope.getCurrencyList();
            } else if ($scope.activeInfo.preference) {
                $scope.getBusinessModel();
                $scope.getLanguageList();
                $scope.getCountryRegionArr();
            } else {
                var userDetail = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language
                };
                profileService.getYourInfoDetail(userDetail)
                    .then(function(data) {
                        if (data.error <= 0) {
                            $scope.yourinformation = data.response;
                            $scope.yourinformation.editpassword = false;
                            $scope.yourinformation.editemail = false;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function(err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            }
        };

        /*
        * @description
        user information*/
        $scope.getUserData = function(userDetail) {
            userDetail.dataLoader = true;
            var permissionDetail = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                usertype: TokenData.usertype
            };
            profileService.getPermissionList(permissionDetail)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.permissionArr = data.response;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });

            profileService.getCompanyUser(userDetail)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.currentUser = cookies.get('authorizationData').user_id;
                        $scope.list = data.response;
                        $scope.maxsize = Math.ceil(data.total_rows / $scope.pageLimit);
                        if ($scope.maxsize > 5) {
                            $scope.maxsize = 5;
                        }
                        $scope.filteredItems = data.total_rows;
                        $scope.totalItems = data.total_rows;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.setPage = function(pageNo) {
            var userDetail = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.pageLimit,
                pageLimit: $scope.pageLimit,
                sortField: $scope.sortField,
                sorttype: $scope.sorttype,
            };
            $scope.currentPage = pageNo;
            $scope.getUserData(userDetail);
        };

        $scope.sort_by = function(sortField) {
            $scope.sortField = sortField;
            $scope.sorttype = ($scope.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var userDetail = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.currentPage - 1) * $scope.pageLimit,
                pageLimit: $scope.pageLimit,
                sortField: sortField,
                sorttype: $scope.sorttype,
            };
            $scope.getUserData(userDetail);
        };

        $scope.changePageSize = function() {
            $scope.currentPage = 1;
            var userDetail = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.currentPage - 1) * $scope.pageLimit,
                pageLimit: $scope.pageLimit,
                sortField: $scope.sortField,
                sorttype: $scope.sorttype,
            };
            $scope.getUserData(userDetail);
            var pagesizeelm = angular.element(document.querySelectorAll('#pagesize'));
            angular.forEach(pagesizeelm, function(val, key) {
                pagesizeelm[key].blur();
            });
        };

        $scope.$watch('currentPage', function(pageNo) {
            var userDetail = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.currentPage - 1) * $scope.pageLimit,
                pageLimit: $scope.pageLimit,
                sortField: $scope.sortField,
                sorttype: $scope.sorttype,
            };
            $scope.currentPage = pageNo;
            $scope.getUserData(userDetail);
            //or any other code here
        });
        /*
        * @description
         grid option */

        /**
         *ach clicked
         */
        $scope.achClicked = function() {
            if (!$scope.achpaymentdata.achchecked) {
                $scope.achpaymentdata = {
                    account_name: '',
                    account_number: '',
                    bank_address: '',
                    bank_name: '',
                    routing_number: ''
                };
            }
        };
        /**
         * paypal checked
         */
        $scope.paypalClick = function() {
            if (!$scope.paypalpaymentdata.paypalchecked) {
                $scope.paypalpaymentdata = {
                    paypal_email: '',
                    paypal_confirmemail: ''
                };
            }
        };

        /**
         *Set Your Information
         */
        $scope.saveYourInformation = function() {
            var yourinformationData = $scope.yourinformation;
            yourinformationData.access_token = TokenData.access_token;
            yourinformationData.language = $rootScope.language;
            if ($scope.yourinformationform.$valid) {
                profileService.saveyourinformation(yourinformationData)
                    .then(function(data) {
                        $scope.yourinfosubmitted = false;
                        if (data.error <= 0) {
                            $scope.yourinformation.password = '';
                            $scope.yourinformation.editpassword = false;
                            $scope.yourinformation.editemail = false;
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function(err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            } else {
                $scope.yourinfosubmitted = true;
            }

        };

        $scope.saveACHPayment = function() {
            var achData = $scope.achpaymentdata;
            achData.access_token = TokenData.access_token;
            achData.language = $rootScope.language;

            profileService.achpayment(achData)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.isError = false;
                        $scope.isMessage = true;
                        $scope.message = data.msg;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.isError = false;
                    $scope.isMessage = false;
                });
        };

        $scope.savePaypalPayment = function() {
            if ($scope.paypalpayment.$valid) {
                if ($scope.paypalpaymentdata.paypal_email == $scope.paypalpaymentdata.paypal_confirmemail) {
                    $scope.paypalemailmatch = false;
                    var paypalData = $scope.paypalpaymentdata;
                    paypalData.access_token = TokenData.access_token;
                    paypalData.language = $rootScope.language;
                    profileService.paypalpayment(paypalData)
                        .then(function(data) {
                            $scope.paypalpaymentSubmitted = false;
                            if (data.error <= 0) {
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function(err, status) {
                            $scope.isError = false;
                            $scope.isMessage = false;
                        });
                } else {
                    $scope.paypalemailmatch = true;
                }
            } else {
                $scope.paypalemailmatch = false;
                $scope.paypalpaymentSubmitted = true;
            }
        };

        $scope.editPassword = function() {
            $scope.yourinformation.editpassword = true;
        };
        $scope.editEmail = function() {
            $scope.yourinformation.editemail = true;
        };

        $scope.createFTP = function() {
            var requestData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            profileService.createFTP(requestData)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.deliveryInfo = {
                            ftp_address: data.response['ftp_address'],
                            ftp_username: data.response['ftp_username'],
                            ftp_password: data.response['ftp_password'],
                            ftp_available: true
                        };
                        var modalInstance = $uibModal.open({
                            animation: true,
                            templateUrl: 'app/components/profile/ftpconfirm.html',
                            controller: 'ftpconfirmCtrl',
                            resolve: {
                                ftpData: function() {
                                    return {
                                        ModalTitle: $filter('translate')('CONFIRMATION_LABEL'),
                                        msg: $filter('translate')('FTP_ACCOUNT_SUCCESS'),
                                        ftpDetail: $scope.deliveryInfo
                                    };
                                }
                            }
                        });
                        modalInstance.result.then(function(dataObj) {

                        }, function() {
                            console.log('error');
                        });
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.isError = false;
                    $scope.isMessage = false;
                });
        };

        $scope.requestDeliveryPassword = function() {
            var requestData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            // profileService.requestPassword(requestData)
            //     .then(function (data) {
            //         if (data.error <= 0) {
            //             $scope.isError = false;
            //             $scope.isMessage = true;
            //             $scope.message = data.msg;
            //         } else {
            //             $scope.isError = true;
            //             $scope.isMessage = false;
            //             $scope.message = data.errorMsg;
            //         }
            //     }, function (err, status) {
            //         $scope.isError = false;
            //         $scope.isMessage = false;
            //     });
        };

        $scope.editCompanyContactDetail = function() {
            var companyContactData = $scope.companyData;
            companyContactData.language = $rootScope.language;
            companyContactData.access_token = TokenData.access_token;
            profileService.editCompanyContactDetail(companyContactData)
                .then(function(data) {
                    $scope.isError = false;
                    $scope.isMessage = true;
                    $scope.message = data.msg;
                }, function(err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = err.errorMsg;
                });
        };


        $scope.toggleEditInviteUserModal = function(index, id) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/profile/publishereditinviteuser.html',
                controller: 'editInviteUserCtrl',
                resolve: {
                    userData: function() {
                        return { index: index, id: id, permissionArr: $scope.permissionArr };
                    }
                }
            });
            modalInstance.result.then(function(dataObj) {
                if (dataObj.data.error <= 0) {
                    $scope.message = dataObj.data.msg;
                    $scope.isError = false;
                    $scope.isMessage = true;
                } else {
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = dataObj.data.errorMsg;
                }
                var userDetail = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.currentPage - 1) * $scope.pageLimit,
                    pageLimit: $scope.pageLimit,
                    sortField: $scope.sortField,
                    sorttype: $scope.sorttype,
                };
                $scope.getUserData(userDetail);

            }, function() {
                console.log('error');
            });
        }

        $scope.toggleInviteActionModal = function(index, id, status) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function() {
                        return { ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('CATALOG_REMOVE_CONFIRMATION_LABEL') };
                    }
                }
            });
            modalInstance.result.then(function(dataObj) {
                var userStatusData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    company_user_id: id,
                    status: !parseInt(status)
                };
                profileService.changeUserStatus(userStatusData)
                    .then(function(data) {
                        if (data.error <= 0) {
                            $scope.list[index].action = data.response.action;
                            $scope.list[index].active = data.response.active;
                            $scope.list[index].status = data.response.status;
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function(err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $uibModalInstance.dismiss('cancel');
                    });

            }, function() {
                console.log('error');
            });
        };
        /* resend invite mail config */
        $scope.resendConfirmation = function(id, email) {
            var resendData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                email: email,
                company_user_id: id
            };
            profileService.resendConfirmation(resendData)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.isError = false;
                        $scope.isMessage = true;
                        $scope.message = data.msg;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.message = err.errorMsg;
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /*
        * @description
        invite new user config */
        $scope.toggleInviteNewUserModal = function() {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/profile/publisherInviteNewUser.html',
                controller: 'inviteNewUserCtrl',
                resolve: {
                    userData: function() {
                        return { permissionArr: $scope.permissionArr };
                    }
                }
            });
            modalInstance.result.then(function(dataObj) {
                if (dataObj.data.error <= 0) {
                    $scope.profileDetail();
                    $scope.isError = false;
                    $scope.isMessage = true;
                    $scope.message = dataObj.data.msg;
                } else {
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = dataObj.data.errorMsg;
                }
            }, function() {
                console.log('error');
            });
        };

        /*
        * @description
        company profile image upload */
        $scope.uploadFile = function(event) {
            var fileData = event.target.files;
            var reader = new FileReader();
            var companyImage = '';
            reader.onload = function(event) {
                companyImage = event.target.result;
            }
            reader.readAsDataURL(event.target.files[0]);

            profileService.editCompanyPhoto(fileData, { access_token: TokenData.access_token, language: $rootScope.language })
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.logo = companyImage;
                        $scope.isImage = true;
                        $scope.isError = false;
                        $scope.isMessage = true;
                        $scope.message = data.msg;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                    document.getElementById('file').value = '';
                }, function(err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = err.errorMsg;
                });
        };

        $scope.togglePublisherConfirmationModal = function() {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function() {
                        return { ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('CATALOG_REMOVE_CONFIRMATION_LABEL') };
                    }
                }
            });
            modalInstance.result.then(function(dataObj) {
                profileService.deleteCompanyPhoto({ access_token: TokenData.access_token, language: $rootScope.language })
                    .then(function(data) {
                        if (data.error <= 0) {
                            $scope.$emit('updateCompanyFile', { filePath: data.image, isImage: data.is_image });
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function(err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            }, function() {
                console.log('error');
            });
        };

        $scope.tabChange = function(tabname) {
            $scope.activeInfo = {
                yourInfoActive: false,
                companyInfoActive: false,
                usersInfoActive: false,
                oneworldpayActive: false,
                deliveryInfoActive: false,
                publisherpreferenceActive: false,
                preference: false,
            };
            $scope.isError = false;
            $scope.isMessage = false;
            $scope.activeInfo[tabname] = true;
            $scope.getProfileData();
        };
        /**
         * Business model data
         */
        $scope.getBusinessModel = function() {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };

            businessmodelService.getBusinessModelList(data)
                .then(function(data) {
                    $scope.businessModelList = data.response;
                }, function(err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        /**
         * language data
         */
        $scope.getLanguageList = function() {
            var languageData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            languageService.getLanguageList(languageData)
                .then(function(data) {
                        $scope.languageList = data.response;
                    },
                    function(err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        /**
         * country region arr
         */
        $scope.getCountryRegionArr = function() {
            var Data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            countryService.getCountryRegionList(Data)
                .then(function(data) {
                    $scope.updateCountry(data.response, function() {
                        $scope.getPreferenceDetail();
                    });
                })
                .catch(function(err) {

                });
        };

        $scope.updateCountry = function(data, call) {
            angular.forEach(data, function(element) {
                if (COUNTRY_PREFERENCE[element.label] !== undefined && COUNTRY_PREFERENCE[element.label].length > 0) {
                    angular.forEach(COUNTRY_PREFERENCE[element.label], function(val, key) {
                        element.children.unshift(val)
                    });
                }
                $scope.countryRegionArr.push(element);
            });
            call();
        };

        $scope.getPreferenceDetail = function() {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            businessmodelService.getPreferenceDetail(data)
                .then(function(data) {
                        $scope.isSubmitted = false;
                        $scope.preferenceDetail = data.response;
                        if (data.response.country_id !== undefined && data.response.country_id.length > 0) {
                            $scope.countrySelect(data.response.country_id, function() {
                                $scope.mainCountryList();
                                if ($scope.countryRegionArr.length > 0) {
                                    var is_region = true;
                                    angular.forEach($scope.countryRegionArr, function(va, ke) {
                                        if (ke != 0) {
                                            if (!va.selected) {
                                                is_region = false;
                                            }
                                        }
                                    });
                                    if (is_region) {
                                        ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                                    }
                                }
                            });
                        }
                        $scope.isMarkup();
                    },
                    function(err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    })
                .catch(function(err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.countrySelect = function(countryData, call) {
            ivhTreeviewMgr.selectEach($scope.countryRegionArr, countryData);
            call();
        };

        $scope.mainCountryList = function() {
            $scope.selectedCountry = [];
            angular.forEach($scope.countryRegionArr, function(va, ke) {
                if (ke != 0) {
                    var extraarr = COUNTRY_PREFERENCE[va.label];
                    if (extraarr !== undefined && extraarr.length > 0) {
                        angular.forEach(va.children, function(couval, coukey) {
                            var dupindex = va.children.indexOf(couval);
                            var mainobj = _.findWhere(va.children, { id: couval.main_id });
                            if (mainobj !== undefined && mainobj.selected !== undefined && mainobj.selected !== null && mainobj.selected !== '' && mainobj.selected) {
                                ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[ke].children[dupindex]);
                            }
                        });
                    }

                    angular.forEach(va.children, function(childval, childkey) {
                        if (childval.selected) {
                            this.push({ id: childval.country_id, name: childval.label });
                        }
                    }, $scope.selectedCountry);

                }
            });
        };

        $scope.isMarkup = function() {
            $scope.isMarkupAvailable = false;
            if ($scope.preferenceDetail.businessmodel_id !== undefined && $scope.preferenceDetail.businessmodel_id.length > 0) {
                angular.forEach($scope.preferenceDetail.businessmodel_id, function(value, key) {
                    if (value == 3 || value == 9) {
                        $scope.isMarkupAvailable = true;
                    }
                });
            }
            if (!$scope.isMarkupAvailable) {
                $scope.preferenceDetail.markup = 30;
            }
            $scope.isMarkupValidate();
        };

        $scope.isMarkupValidate = function() {
            $scope.isMarkupRequired = false;
            if ($scope.preferenceDetail.businessmodel_id !== undefined && $scope.preferenceDetail.businessmodel_id.length > 0) {
                angular.forEach($scope.preferenceDetail.businessmodel_id, function(value, key) {
                    if (value == 3 || value == 9) {
                        $scope.isMarkupRequired = true;
                    }
                });
            }
        };

        $scope.countryMade = function(Node, IsSelected, Tree) {

            _.find($scope.countryRegionArr, function(objval) {
                if (objval.children !== undefined && objval.children.length > 0) {
                    var dupArr = _.where(objval.children, { country_id: Node.country_id });
                    if (IsSelected) {
                        angular.forEach(dupArr, function(dupval, dupkey) {
                            ivhTreeviewMgr.select($scope.countryRegionArr, dupval);
                        });
                    } else {
                        angular.forEach(dupArr, function(dupval, dupkey) {
                            ivhTreeviewMgr.deselect($scope.countryRegionArr, dupval);
                        });
                    }
                }
            });

            if (Node.label === 'World' && Node.children === undefined && IsSelected) {
                ivhTreeviewMgr.selectAll($scope.countryRegionArr);
                $scope.mainCountryList();
            }
            if (Node.label === 'World' && Node.children === undefined && !IsSelected) {
                ivhTreeviewMgr.deselectAll($scope.countryRegionArr);
                $scope.mainCountryList();
            }
            if (Node.label !== 'World' && IsSelected) {
                $scope.deselectCountry(function() {
                    var isselectAll = true;
                    angular.forEach($scope.countryRegionArr, function(val, key) {
                        if (key !== 0 && !val.selected) {
                            isselectAll = false;
                        }
                    });
                    if (isselectAll) {
                        ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                    }
                    $scope.mainCountryList();
                });
            }
            if (Node.label !== 'World' && !IsSelected) {
                ivhTreeviewMgr.deselect($scope.countryRegionArr, $scope.countryRegionArr[0]);
                $scope.mainCountryList();
            }
        };

        $scope.deselectCountry = function(back) {
            ivhTreeviewMgr.deselect($scope.countryRegionArr, $scope.countryRegionArr[0]);
            back();
        };

        /**
         * add Preference Data
         */

        $scope.addPreferenceData = function() {
            if ($scope.addpreference.$valid && $scope.selectedCountry.length > 0) {
                var data = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    businessmodel_id: $scope.preferenceDetail.businessmodel_id,
                    country_id: _.pluck($scope.selectedCountry, 'id').filter(function(item, i, ar) { return ar.indexOf(item) === i; }),
                    language_id: $scope.preferenceDetail.language_id,
                    main_country_id: $scope.preferenceDetail.main_country_id,
                    markup: $scope.preferenceDetail.markup
                };
                businessmodelService.addpreferenceDetail(data)
                    .then(function(data) {
                            $scope.message = data.msg;
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.isSubmitted = false;
                            $scope.countryError = false;
                            $scope.getPreferenceDetail();
                        },
                        function(err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        })
                    .catch(function(err) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });

            } else {
                if ($scope.selectedCountry.length <= 0) {
                    $scope.countryError = true;
                }
                $scope.isSubmitted = true;
            }
        };

        /*
        * @description
        update data */
        $scope.$on('updateCompanyContact', function(event, data) {
            $scope.companyData = { address: data.address, contact_no: data.contact_no, contact_person: data.contact_person, name: data.name };
        });
        $scope.$on('updateCompanyFinancial', function(event, data) {
            $scope.financialData = { account_number: data.account_number, bank_address: data.bank_address, bank_name: data.bank_name, dwolla_account_number: data.dwolla_account_number, routing_number: data.routing_number };
        });
        $scope.$on('updateCompanyFile', function(event, data) {
            $scope.logo = data.filePath;
            $scope.isImage = data.isImage;
        });
        $scope.profileDetail();
        // Publisher Preference Start
        /**
         * change Retailer Type
         */
        $scope.changeRetailerType = function() {
            $scope.preference_detail.whitelist_retailer_name = '';
            $scope.preference_detail.blcaklist_retailer_name = '';

            var length = 0;
            if ($scope.preference_detail.group_type == 1) {
                length = $scope.blackListRetailer.length;
            }
            if ($scope.preference_detail.group_type == 2) {
                length = $scope.whiteListRetailer.length;
            }
            if (length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function() {
                            return {
                                ModalTitle: $filter('translate')('CONFIRMATION_LABEL'),
                                msg: $filter('translate')('REMOVE_OTHER_RETAILER')
                            };
                        }
                    }
                });
                modalInstance.result.then(function(dataObj) {
                    var data = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language
                    };
                    $scope.whiteRetailerError = '';
                    $scope.blackRetailerError = '';
                    publisherpreferenceService.deletePublisherPreference(data)
                        .then(function(data) {
                            if (data.error <= 0) {
                                $scope.getRetaileTrustList();
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function(err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        })
                        .catch(function(error) {

                        });
                }, function() {
                    document.getElementById('blcaklist_retailer_name').blur();
                    document.getElementById('whitelist_retailer_name').blur();
                    $scope.preference_detail.group_type = '';
                });
            }
        };
        /**
         * add whitelist retailer
         */
        $scope.addWhiteListRetailer = function() {
            if ($scope.trustLevelId == $scope.preference_detail.trust_level || $scope.blackListRetailer.length <= 0) {
                $scope.addWhiteRetailer();
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function() {
                            return { ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('REMOVE_OTHER_LEVEL_RETAILER') };
                        }
                    }
                });
                modalInstance.result.then(function(dataObj) {
                    $scope.addWhiteRetailer();
                }, function() {
                    console.log('error');
                });
            }
        };

        $scope.addWhiteRetailer = function() {
            $scope.blackRetailerError = '';
            var retailerData = _.findWhere($scope.retailerArr, { name: $scope.preference_detail.whitelist_retailer_name });
            if ($scope.preference_detail.whitelist_retailer_name !== null && $scope.preference_detail.whitelist_retailer_name !== undefined && $scope.preference_detail.whitelist_retailer_name !== '') {
                if (retailerData !== undefined && retailerData !== null && retailerData !== '') {
                    $scope.whiteRetailerError = '';
                    var data = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language,
                        trust_level: $scope.preference_detail.trust_level,
                        retailers_list: $scope.preference_detail.group_type,
                        retailer_id: retailerData.id,
                        preference_id: $scope.preference_detail.preference_id,
                        group_type: $scope.preference_detail.group_type
                    };
                    publisherpreferenceService.addRetailer(data)
                        .then(function(data) {
                            if (data.error <= 0) {
                                $scope.preference_detail.whitelist_retailer_name = '';
                                $scope.preference_detail.blcaklist_retailer_name = '';
                                $scope.getRetaileTrustList();
                                $scope.getRetailer();
                                $scope.updateWhilteListRetailer();
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function(err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        })
                        .catch(function(error) {

                        });
                } else {
                    $scope.whiteRetailerError = $filter('translate')('VALID_RETAILER_NAME_REQUIRED');
                }
            } else {
                if ($scope.preference_detail.group_type !== undefined && $scope.preference_detail.group_type !== null && $scope.preference_detail.group_type !== '') {
                    $scope.whiteRetailerError = $filter('translate')('RETAILER_NAME_REQUIRED');
                }
            }
        };
        /**
         * add blacklist retailer
         */
        $scope.addBlackListRetailer = function() {
            if ($scope.trustLevelId == $scope.preference_detail.trust_level || $scope.whiteListRetailer.length <= 0) {
                $scope.addBlackRetaile();
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function() {
                            return { ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('REMOVE_OTHER_LEVEL_RETAILER') };
                        }
                    }
                });
                modalInstance.result.then(function(dataObj) {
                    $scope.addBlackRetaile();
                }, function() {
                    console.log('error');
                });
            }
        };

        $scope.addBlackRetaile = function() {
            $scope.whiteRetailerError = '';
            var retailerData = _.findWhere($scope.retailerArr, { name: $scope.preference_detail.blcaklist_retailer_name });
            if ($scope.preference_detail.blcaklist_retailer_name !== null && $scope.preference_detail.blcaklist_retailer_name !== undefined && $scope.preference_detail.blcaklist_retailer_name !== '') {
                if (retailerData !== undefined && retailerData !== null && retailerData !== '') {
                    $scope.blackRetailerError = '';
                    var data = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language,
                        trust_level: $scope.preference_detail.trust_level,
                        retailers_list: $scope.preference_detail.group_type,
                        retailer_id: retailerData.id,
                        preference_id: $scope.preference_detail.preference_id,
                        group_type: $scope.preference_detail.group_type
                    };
                    publisherpreferenceService.addRetailer(data)
                        .then(function(data) {
                            if (data.error <= 0) {
                                $scope.preference_detail.whitelist_retailer_name = '';
                                $scope.preference_detail.blcaklist_retailer_name = '';
                                $scope.getRetaileTrustList();
                                $scope.getRetailer();
                                $scope.updateBlackListRetailer();
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function(err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        })
                        .catch(function(error) {

                        });
                } else {
                    $scope.blackRetailerError = $filter('translate')('VALID_RETAILER_NAME_REQUIRED');
                }
            } else {
                if ($scope.preference_detail.group_type !== undefined && $scope.preference_detail.group_type !== null && $scope.preference_detail.group_type !== '') {
                    $scope.blackRetailerError = $filter('translate')('RETAILER_NAME_REQUIRED');
                }
            }
        };
        /**
         * Delete Retailer
         */
        $scope.deleteRetailer = function(rid, preference_id) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function() {
                        return { ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('REMOVE_RETAILER') };
                    }
                }
            });
            modalInstance.result.then(function(dataObj) {
                $scope.whiteRetailerError = '';
                $scope.blackRetailerError = '';
                var is_last = true;
                if ($scope.whiteListRetailer.length > 1) {
                    var is_last = false;
                }
                if ($scope.blackListRetailer.length > 1) {
                    var is_last = false;
                }

                var data = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    prp_id: rid,
                    preference_id: preference_id,
                    is_last: is_last
                };
                publisherpreferenceService.deleteRetailerPreference(data)
                    .then(function(data) {
                        if (data.error <= 0) {
                            $scope.getRetaileTrustList();
                            $scope.getRetailer();
                            $scope.updateWhilteListRetailer();
                            $scope.updateBlackListRetailer();
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function(err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    })
                    .catch(function(error) {

                    });
            }, function() {
                console.log('error');
            });
        };
        /**
         * get Retailer List
         */
        $scope.getRetailer = function() {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                trust_level: $scope.preference_detail.trust_level,
                preference_id: $scope.preference_detail.preference_id
            };
            publisherpreferenceService.getRetailerList(data)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.preference_detail.preference_id = data.preference_id
                        $scope.retailerArr = data.response;
                        $scope.retailerList = _.pluck(data.response, 'name');
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                })
                .catch(function(error) {

                });


        };
        /**
         * get Retailer trust list
         */
        $scope.getRetaileTrustList = function() {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            publisherpreferenceService.getRetailerTrustList(data)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.trustLevelId = data.trust_level;
                        $scope.preference_detail.trust_level = data.trust_level;
                        $scope.preference_detail.old_trust_level = data.trust_level;
                        $scope.preference_detail.group_type = ($scope.preference_detail.group_type == undefined || $scope.preference_detail.group_type == null || $scope.preference_detail.group_type == '') ? data.group_type : $scope.preference_detail.group_type;
                        $scope.preference_detail.preference_id = data.preference_id;
                        $scope.whiteListRetailer = data.Whitelist;
                        $scope.blackListRetailer = data.Blacklist;
                        $scope.preview_settings.currency_preference = data.currency_preference;
                        $scope.preview_settings.sellwithdrm = (data.sellwithdrm !== undefined && data.sellwithdrm !== null && data.sellwithdrm !== '') ? data.sellwithdrm : false;
                        $scope.preview_settings.oldsellwithdrm = (data.sellwithdrm !== undefined && data.sellwithdrm !== null && data.sellwithdrm !== '') ? data.sellwithdrm : false;
                        $scope.preview_settings.preview_percentage = parseInt(data.preview_percentage);
                        $scope.preview_settings.allow_preview = (data.allow_preview == 1) ? true : false;
                        $scope.getRetailer();
                    } else {
                        $scope.preview_settings = {
                            currency_preference: '',
                            preview_percentage: 15,
                            sellwithdrm: true,
                            oldsellwithdrm: true,
                            allow_preview: 1
                        };
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * update White list retaile
         */
        $scope.updateWhilteListRetailer = function() {
            var autocom = new autoComplete({
                selector: '#whitelist_retailer_name',
                source: function(term, suggest) {
                    term = term.toLowerCase();
                    var choices = $scope.publisherList;
                    var suggestions = [];
                    for (i = 0; i < choices.length; i++)
                        if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                    suggest(suggestions);
                },
                onSelect: function(e, term, item) {
                    // old and new value check
                    if ($scope.preference_detail.whitelist_retailer_name && $scope.preference_detail.whitelist_retailer_name !== term) {
                        $scope.$apply(function() {
                            $scope.preference_detail.whitelist_retailer_name = term;
                        });
                    }
                }
            });
        };
        /**
         * update black list retaile
         */
        $scope.updateBlackListRetailer = function() {
            var autocom = new autoComplete({
                selector: '#blcaklist_retailer_name',
                source: function(term, suggest) {
                    term = term.toLowerCase();
                    var choices = $scope.publisherList;
                    var suggestions = [];
                    for (i = 0; i < choices.length; i++)
                        if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                    suggest(suggestions);
                },
                onSelect: function(e, term, item) {
                    // old and new value check
                    if ($scope.preference_detail.blcaklist_retailer_name && $scope.preference_detail.blcaklist_retailer_name !== term) {
                        $scope.$apply(function() {
                            $scope.preference_detail.blcaklist_retailer_name = term;
                        });
                    }
                }
            });
        };
        /**
         * select Radio
         */
        $scope.selectRadio = function(type) {
            if ($scope.preference_detail.group_type !== type) {
                $scope.preference_detail.group_type = type;
                $scope.changeRetailerType();
            } else {
                $scope.preference_detail.group_type = type;
            }
        };
        /**
         * get Currency Data
         */
        $scope.getCurrencyList = function() {
            var currencyData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            publisherpreferenceService.getCurrencyList(currencyData)
                .then(function(data) {
                    $scope.currencyList = data.response;
                })
                .catch(function() {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.addPreviewSettings = function() {
            if ($scope.previewsettings.$valid) {
                if ($scope.preview_settings.oldsellwithdrm == $scope.preview_settings.sellwithdrm) {
                    $scope.savePreviewSettings();
                } else {
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                        controller: 'deleteConfirmationCtrl',
                        resolve: {
                            deleteData: function() {
                                return {
                                    ModalTitle: $filter('translate')('CONFIRMATION_LABEL'),
                                    msg: $filter('translate')('GLOABLLY_CHANGE_DRM_SETTING')
                                };
                            }
                        }
                    });
                    modalInstance.result.then(function(dataObj) {
                        $scope.savePreviewSettings();
                    }, function() {
                        $scope.preview_settings.sellwithdrm = $scope.preview_settings.oldsellwithdrm;
                    });
                }
            } else {
                $scope.isSubmitted = true;
            }
        };

        $scope.savePreviewSettings = function() {
            $scope.preview_settings.preview_percentage = ($scope.preview_settings.allow_preview) ? parseInt($scope.preview_settings.preview_percentage) : 15;
            var previewData = $scope.preview_settings;
            previewData.access_token = TokenData.access_token;
            previewData.language = $rootScope.language;
            publisherpreferenceService.addPreviewSettings(previewData)
                .then(function(data) {
                    $scope.message = data.msg;
                    $scope.isError = false;
                    $scope.isMessage = true;
                    //$scope.getRetaileTrustList();
                    $scope.preview_settings.oldsellwithdrm = $scope.preview_settings.sellwithdrm;
                })
                .catch(function() {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        }

        $scope.changeTrustLevel = function() {
            var whiteListLength = $scope.whiteListRetailer.length;
            var blackListLength = $scope.blackListRetailer.length;
            console.log($scope.preference_detail)
            if (blackListLength > 0 || whiteListLength > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function() {
                            return {
                                ModalTitle: $filter('translate')('CONFIRMATION_LABEL'),
                                msg: $filter('translate')('REMOVE_OTHER_RETAILER')
                            };
                        }
                    }
                });
                modalInstance.result.then(function(dataObj) {
                    var data = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language
                    };
                    publisherpreferenceService.deletePublisherPreference(data)
                        .then(function(data) {
                            if (data.error <= 0) {
                                $scope.getRetailer();
                                $scope.trustLevelId = $scope.preference_detail.trust_level;
                                $scope.preference_detail.trust_level = $scope.preference_detail.trust_level;
                                $scope.preference_detail.old_trust_level = $scope.preference_detail.trust_level;
                                $scope.whiteListRetailer = [];
                                $scope.blackListRetailer = [];
                                //$scope.changeTru();
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function(err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        })
                        .catch(function(error) {

                        });
                }, function() {
                    $scope.preference_detail.trust_level = $scope.preference_detail.old_trust_level;
                });
            } else {
                $scope.getRetailer();
            }
            // $scope.getRetailer();
        };

        $scope.changeTru = function() {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            publisherpreferenceService.getRetailerTrustList(data)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.trustLevelId = data.trust_level;
                        $scope.preference_detail.trust_level = data.trust_level;
                        $scope.preference_detail.old_trust_level = data.trust_level;
                        $scope.preference_detail.group_type = ($scope.preference_detail.group_type == undefined || $scope.preference_detail.group_type == null || $scope.preference_detail.group_type == '') ? data.group_type : $scope.preference_detail.group_type;
                        $scope.preference_detail.preference_id = data.preference_id;
                        $scope.whiteListRetailer = data.Whitelist;
                        $scope.blackListRetailer = data.Blacklist;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        // Publisher Preference End

        $scope.showbusinessmodel = function() {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/businessmodel_popup.html',
                controller: 'businessinstructionCtrl',
                resolve: {
                    businessData: function() {
                        return {

                        };
                    }
                }
            });
            modalInstance.result.then(function(dataObj) {

            }, function() {

            });
        };

    }
]);

angular.module('OneWorld').controller('editInviteUserCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'profileService', '$location', '$sessionStorage', 'localStorageService', 'userData',
    function($scope, $rootScope, $uibModalInstance, profileService, $location, $sessionStorage, localStorageService, userData) {
        $scope.permissionArr = userData.permissionArr;
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.form = {};
        $scope.userDetail = {};
        var userDetailData = {
            access_token: TokenData.access_token,
            language: $rootScope.language,
            company_user_id: userData.id
        };

        profileService.getUserDetail(userDetailData)
            .then(function(data) {
                if (data.error <= 0) {
                    $scope.userDetail = data.response;
                } else {
                    $scope.$parent.isError = true;
                    $scope.$parent.isMessage = false;
                    $scope.$parent.message = data.errorMsg;
                }
            }, function(err, status) {
                $scope.$parent.message = err.errorMsg;
                $scope.$parent.isError = true;
                $scope.$parent.isMessage = false;
            });

        $scope.editUserDetail = function() {
            if ($scope.form.edituser.$valid) {
                var rights = [];
                angular.forEach($scope.userDetail.rights, function(value, key) {
                    this.push(value.id);
                }, rights);
                var userRightsArr = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    first_name: $scope.userDetail.first_name,
                    last_name: $scope.userDetail.last_name,
                    company_user_id: $scope.userDetail.id,
                    rights_array: rights
                };

                profileService.updateUserDetail(userRightsArr)
                    .then(function(data) {
                        $uibModalInstance.close({ data: data });
                    }, function(err, status) {
                        $scope.$parent.message = err.errorMsg;
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                        $uibModalInstance.dismiss('cancel');
                    });
            } else {
                $scope.isUserSubmitted = true;
            }
        }

        $scope.checkAll = function() {
            if ($scope.userDetail.allchecked) {
                $scope.userDetail.rights = angular.copy($scope.permissionArr);
            } else {
                $scope.userDetail.rights = [];
            }
        };
        $scope.uncheckMain = function() {
            $scope.userDetail.allchecked = false;
        };

        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
    }
]);

angular.module('OneWorld').controller('inviteNewUserCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'profileService', '$location', '$sessionStorage', 'localStorageService', 'userData',
    function($scope, $rootScope, $uibModalInstance, profileService, $location, $sessionStorage, localStorageService, userData) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.form = {};
        $scope.inviteNewUserData = {};
        $scope.permissionArr = userData.permissionArr;
        $scope.inviteNewUser = function() {
            if ($scope.form.inviteNewUser.$valid) {
                var rights = [];
                angular.forEach($scope.inviteNewUserData.rights, function(value, key) {
                    this.push(value.id);
                }, rights);
                var inviteNewUserObj = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    email_ids: $scope.inviteNewUserData.email,
                    rights_array: rights,
                    usertype: TokenData.usertype
                };
                profileService.inviteNewUser(inviteNewUserObj)
                    .then(function(data) {
                        if (data.error <= 0) {
                            $uibModalInstance.close({ data: data });
                        } else {
                            $scope.message = data.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        }
                    }, function(err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $uibModalInstance.dismiss('cancel');
                    });
            } else {
                $scope.inviteNewUserSubmitted = true;
            }
        };
        $scope.checkAll = function() {
            if ($scope.inviteNewUserData.allchecked) {
                $scope.inviteNewUserData.rights = angular.copy($scope.permissionArr);
            } else {
                $scope.inviteNewUserData.rights = [];
            }
        };
        $scope.uncheckMain = function() {
            $scope.inviteNewUserData.allchecked = false;
        };
        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
    }
]);


/*
 * @description
 *  App Confirmation Modal*/
angular.module('OneWorld').controller('ftpconfirmCtrl', ['$scope', '$uibModalInstance', 'ftpData',
    function($scope, $uibModalInstance, ftpData) {
        $scope.ftpData = ftpData;
        $scope.DeleteConfirm = function() {
            $uibModalInstance.close();
        }
        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
    }
]);