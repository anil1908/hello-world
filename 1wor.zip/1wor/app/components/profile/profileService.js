'use strict';
App.factory('profileService', ['$http', '$q', function ($http, $q) {
        var profileServiceFactory = {};
        /**
         * @description
         * # account detail
         */
        var _getuserAccountDetail = function (userDetail) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/user_profile/get_user_profile',
                method: "POST",
                data: userDetail,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # edit user
         */
        var _editUser = function (userData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/user_profile/update_user_profile',
                method: "POST",
                data: userData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # edit user photo
         */
        var _editUserPhoto = function (fileData, postData) {
            var deferred = $q.defer();
            var fd = new FormData();
            fd.append('file', fileData[0]);
            fd.append('access_token', postData.access_token);
            fd.append('language', postData.language);
            $http({
                headers: {'Content-Type': undefined},
                url: 'api/user_profile/update_user_profile_image',
                method: "POST",
                data: fd,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # delete user photo
         */
        var _deleteUserPhoto = function (imageData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/user_profile/remove_user_profile_image',
                method: "POST",
                data: imageData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # user detail
         */
        var _getProfileDetail = function (profileDetail) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/get_company_profile',
                method: "POST",
                data: profileDetail,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # company contact detail
         */
        var _editCompanyContactDetail = function (companyContactData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/update_company_profile',
                method: "POST",
                data: companyContactData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # company financial detail
         */
        var _editCompanyFinancialDetail = function (companyFinancialData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/update_company_financial_info',
                method: "POST",
                data: companyFinancialData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # company image edit
         */
        var _editCompanyPhoto = function (fileData, postData) {
            var deferred = $q.defer();
            var fd = new FormData();
            fd.append('file', fileData[0]);
            fd.append('access_token', postData.access_token);
            fd.append('language', postData.language);
            $http({
                headers: {'Content-Type': undefined},
                url: 'api/company_profile/update_company_profile_image',
                method: "POST",
                data: fd,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # company image delete
         */
        var _deleteCompanyPhoto = function (imageData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/remove_company_profile_image',
                method: "POST",
                data: imageData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # company user detail
         */
        var _getCompanyUser = function (userData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/get_company_users',
                method: "POST",
                data: userData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # user status change
         */
        var _changeUserStatus = function (userStatusData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/user_profile/update_user_status',
                method: "POST",
                data: userStatusData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
         /**
         * @description
         * # permission list
         */
        var _getPermissionList = function (permissionDetail) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/user_profile/get_user_modules',
                method: "POST",
                data: permissionDetail,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
         /**
         * @description
         * # user detail
         */
        var _getUserDetail = function (userDetailData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/user_profile/get_user_details_with_rights',
                method: "POST",
                data: userDetailData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
         /**
         * @description
         * # user detail edit
         */
        var _updateUserDetail = function (userDetailData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/user_profile/update_user_rights',
                method: "POST",
                data: userDetailData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
         /**
         * @description
         * # resend confirmation email
         */
        var _resendConfirmation = function (resendData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/resend_invitation',
                method: "POST",
                data: resendData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        }
         /**
         * @description
         * # invite user
         */
        var _inviteNewUser = function (inviteData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/send_invitation',
                method: "POST",
                data: inviteData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        }
         /**
         * @description
         * # save user info
         */
        var _saveyourinformation = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/user_profile/update_user_profile',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
         /**
         * @description
         * # save user info
         */
        var _achpayment = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/update_company_financial_info',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
         /**
         * @description
         * # paypal
         */
        var _paypalpayment = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/update_company_paypal_info',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
         /**
         * @description
         * # request password
         */
        var _requestPassword = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/send_invitation',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
         /**
         * @description
         * # Your info
         */
        var _getYourInfoDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/user_profile/get_user_profile',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
         /**
         * @description
         * # payment info
         */
        var _getPaymentDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/get_company_financial_info',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
         /**
         * @description
         * # Delivery info
         */
        var _getDeliveryDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/get_company_ftp_details',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
         /**
         * @description
         * # Delivery info
         */
        var _createFTP = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/company_profile/generate_publisher_ftp',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        profileServiceFactory.getuserAccountDetail = _getuserAccountDetail;
        profileServiceFactory.editUser = _editUser;
        profileServiceFactory.editUserPhoto = _editUserPhoto;
        profileServiceFactory.deleteUserPhoto = _deleteUserPhoto;
        profileServiceFactory.getProfileDetail = _getProfileDetail;
        profileServiceFactory.editCompanyContactDetail = _editCompanyContactDetail;
        profileServiceFactory.editCompanyFinancialDetail = _editCompanyFinancialDetail;
        profileServiceFactory.editCompanyPhoto = _editCompanyPhoto;
        profileServiceFactory.deleteCompanyPhoto = _deleteCompanyPhoto;
        profileServiceFactory.getCompanyUser = _getCompanyUser;
        profileServiceFactory.changeUserStatus = _changeUserStatus;
        profileServiceFactory.getPermissionList = _getPermissionList;
        profileServiceFactory.getUserDetail = _getUserDetail;
        profileServiceFactory.updateUserDetail = _updateUserDetail;
        profileServiceFactory.resendConfirmation = _resendConfirmation;
        profileServiceFactory.inviteNewUser = _inviteNewUser;
        profileServiceFactory.saveyourinformation = _saveyourinformation;
        profileServiceFactory.achpayment = _achpayment;
        profileServiceFactory.paypalpayment = _paypalpayment;
        profileServiceFactory.requestPassword = _requestPassword;
        profileServiceFactory.getYourInfoDetail = _getYourInfoDetail;
        profileServiceFactory.getPaymentDetail = _getPaymentDetail;
        profileServiceFactory.getDeliveryDetail = _getDeliveryDetail;
        profileServiceFactory.createFTP = _createFTP;
        return profileServiceFactory;
    }]);