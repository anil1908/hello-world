'use strict';
App.factory('catalogService', ['$http', '$q', function ($http, $q) {
        var catalogServiceFactory = {};
        /**
         * @description
         * # book list
         */
        var _getBooksList = function (booksData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/get_catalog_list',
                method: "POST",
                data: booksData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # book detail
         */
        var _getBooksDetail = function (booksData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/get_catalog_details_by_id',
                method: "POST",
                data: booksData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # retailer book detail
         */
        var _getRetailerBooksDetail = function (booksData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/retailer_catalog/get_catalog_details_by_id',
                method: "POST",
                data: booksData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # tag list
         */
        var _getTagList = function (tagData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/get_tag_list',
                method: "POST",
                data: tagData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # Delete tag
         */
        var _deleteTag = function (tagData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/delete_tag',
                method: "POST",
                data: tagData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # Add tag
         */
        var _addTag = function (tagData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/add_tag',
                method: "POST",
                data: tagData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # Update tag
         */
        var _updateTag = function (tagData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/update_tag',
                method: "POST",
                data: tagData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # all book
         */
        var _getAllBook = function (tagData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/get_catalog_list_by_selection',
                method: "POST",
                data: tagData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # book tag add
         */
        var _addBookTag = function (BookTagData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/insert_catalog_tag_by_selection',
                method: "POST",
                data: BookTagData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * Book Tag Remove
         */
        var _removeBookTag = function(BookTagData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/remove_catalog_tag_by_selection',
                method: "POST",
                data: BookTagData
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        var _addBookRowTag = function (BookTagData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/insert_individual_catalog_tag',
                method: "POST",
                data: BookTagData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _getMaintainBooksList = function (booksData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/get_maintain_books_list',
                method: "POST",
                data: booksData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _getTagListBySearch = function (tagData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/get_tag_list_by_search',
                method: "POST",
                data: tagData,
            })
                    .success(function (data) {
                        var tagarr = [];
                        angular.forEach(data.response, function (value, key) {
                            tagarr.push({"text": value});
                        });
                        deferred.resolve(tagarr);// data.response;
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        }
        /**
         * @description
         * # delete book
         */
        var _deleteBook = function (bookData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/delete_catalog',
                method: "POST",
                data: bookData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # curration list
         */
        var _getCurationList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/retailer_catalog/get_curation_list',
                method: "POST",
                data: data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _getRetailerBookList = function (data) {
            data.loadTop = false;
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/retailer_catalog/get_retailer_catalog_by_id',
                method: "POST",
                data: data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # book search
         */
        var _getSearchedBooks = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/retailer_catalog/get_retailer_catalog_by_selection',
                method: "POST",
                data: data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * get Retailer Bundle Detail
         */
        var _getRetailerBundleDetail = function(data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/retailer_catalog/get_bundle_details_by_id',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * get Catalog Associate Detail
         */
        var _getCatalogAssociatedDetails = function(data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/get_catalog_associated_details',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };


        /**
         * get Language list
         */
        var _getLanguageList = function(data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_retailer_filter_language',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        
        /**
         * get filter currency
         */
        var _getPriceList = function(data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_retailer_filter_price',
                method: "POST",
                data: data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        catalogServiceFactory.getBooksList = _getBooksList;
        catalogServiceFactory.getBooksDetail = _getBooksDetail;
        catalogServiceFactory.getRetailerBooksDetail = _getRetailerBooksDetail;
        catalogServiceFactory.getTagList = _getTagList;
        catalogServiceFactory.deleteTag = _deleteTag;
        catalogServiceFactory.addTag = _addTag;
        catalogServiceFactory.updateTag = _updateTag;
        catalogServiceFactory.getAllBook = _getAllBook;
        catalogServiceFactory.addBookTag = _addBookTag;
        catalogServiceFactory.removeBookTag = _removeBookTag;
        catalogServiceFactory.addBookRowTag = _addBookRowTag;
        catalogServiceFactory.getMaintainBooksList = _getMaintainBooksList;
        catalogServiceFactory.getTagListBySearch = _getTagListBySearch;
        catalogServiceFactory.deleteBook = _deleteBook;
        catalogServiceFactory.getCurationList = _getCurationList;
        catalogServiceFactory.getRetailerBookList = _getRetailerBookList;
        catalogServiceFactory.getSearchedBooks = _getSearchedBooks;
        catalogServiceFactory.getRetailerBundleDetail = _getRetailerBundleDetail;
        catalogServiceFactory.getCatalogAssociatedDetails = _getCatalogAssociatedDetails;
        catalogServiceFactory.getLanguageList = _getLanguageList;
        catalogServiceFactory.getPriceList = _getPriceList;
        return catalogServiceFactory;
    }]);