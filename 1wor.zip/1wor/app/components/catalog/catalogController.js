'use strict';
angular.module('OneWorld').controller('catalogController', ['$scope', '$rootScope', '$state', '$location', 'catalogService', '$uibModal', 'localStorageService', 'groupService', '$filter',
    function ($scope, $rootScope, $state, $location, catalogService, $uibModal, localStorageService, groupService, $filter) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        var parameter = $location.search();
        var addAllBtn = false;
        $scope.booksList = [];
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'b.title',
            sorttype: 'ASC',
            maxsize: 10
        };
        $scope.state = false;
        $scope.selectedBookList = [];
        $scope.booksListData = { bookArr: [], allchecked: false };
        $scope.showDeleteConfirmationModal = false;
        $scope.pageIds = [];
        $scope.showTagDeleteModal = false;
        $scope.autoSearchTagArr = [];
        $scope.tagText = [];
        $scope.searchAllTag = [];
        $scope.deleteTag = [];
        $scope.showBookGroupModal = false;
        $rootScope.isCatalogPage = false;
        $scope.globalText = '';
        $scope.addAllBtn = false;

        $scope.isError = ($rootScope.catalogisError !== undefined) ? $rootScope.catalogisError : false;
        $scope.isMessage = ($rootScope.catalogisMessage !== undefined) ? $rootScope.catalogisMessage : false;
        $scope.message = ($rootScope.catalogmessage !== undefined) ? $rootScope.catalogmessage : '';

        var searchData = cookies.get('searchCatalogData');
        if (searchData !== null && searchData !== undefined && searchData !== '') {
           // $scope.globalText = searchData.globalText;
           // $scope.tagText = searchData.tagText;
        }

        $scope.toggleState = function () {
            $scope.state = !$scope.state;
        };
        $scope.checkAll = function () {
            if ($scope.booksListData.allchecked) {
                _.each($scope.booksList, function (element) {
                    var isavl = true;
                    _.each($scope.booksListData.bookArr, function (obj) {
                        if (obj.id === element.id) {
                            isavl = false;
                        }
                    });
                    if (isavl) {
                        $scope.booksListData.bookArr.push(element);
                    }
                });
            } else {
                var arr = [];
                angular.forEach($scope.booksListData.bookArr, function (element) {
                    if ($scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.booksListData.bookArr = arr;
            }
        };
        $scope.uncheckMain = function () {
            $scope.booksListData.allchecked = false;
        };

        $scope.goBack = function () {
            $location.path('dashboard');
        };

        /*
         * @description
         * Grid Option*/
        $scope.getBooks = function () {
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                globalText: $scope.globalText,
                tagText: $scope.tagText
            };
            $scope.getBooksData(booksData);
        };

        $scope.$watch('currentPage', function (pageNo) {
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                globalText: $scope.globalText,
                tagText: $scope.tagText
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getBooksData(booksData);
            //or any other code here
        });


        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
                globalText: $scope.globalText,
                tagText: $scope.tagText
            };
            $scope.getBooksData(booksData);
        };

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                globalText: $scope.globalText,
                tagText: $scope.tagText
            };
            $scope.getBooksData(booksData);
            var pagesizeelm = angular.element(document.querySelectorAll('#pagesize'));
            angular.forEach(pagesizeelm, function (val, key) {
                pagesizeelm[key].blur();
            });
        };

        $scope.globalSearch = function () {
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                globalText: $scope.globalText,
                tagText: $scope.tagText
            };
            $scope.getBooksData(booksData);
        };

        $scope.tagSearch = function () {
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                globalText: $scope.globalText,
                tagText: $scope.tagText
            };
            $scope.getBooksData(booksData, ($scope.tagText.length > 0) ? true : false);
        };

        $scope.cancleSearch = function () {
            $scope.globalText = '';
            $scope.tagText = [];
            $scope.$$childHead.blank();
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                globalText: $scope.globalText,
                tagText: $scope.tagText
            };
            $scope.booksListData = { bookArr: [], allchecked: false };
            $scope.getBooksData(booksData);
        };

        $scope.getBooksData = function (booksData, addAllBtn) {
            booksData.dataLoader = true;
            $scope.addAllBtn = (addAllBtn !== undefined) ? addAllBtn : false;
            $rootScope.catalogmessage = '';
            $rootScope.catalogisError = false;
            $rootScope.catalogisMessage = false;
            catalogService.getBooksList(booksData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.pageIds = data.ids.split(',');
                        $scope.booksListData.allchecked = false;
                        $scope.booksList = data.response;
                        $scope.gridOption.filteredItems = data.total_rows;
                        $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                        if ($scope.gridOption.maxsize > 5) {
                            $scope.gridOption.maxsize = 5;
                        }
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /*
         * @description
         * End Grid Option*/

        /*
         * @description
         * Book Details*/
        $scope.bookDetailsModal = function (bookId) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/maintainbooks/publisherBookDetail.html',
                controller: 'bookDetailCtrl',
                resolve: {
                    bookData: function () {
                        return { bookId: bookId, type: 'publisher' };
                    }
                }
            });
            modalInstance.result.then(function (bookObj) {
                var searchCatalogData = {
                    bookId : bookId,
                    globalText: $scope.globalText,
                    tagText: $scope.tagText
                };
                cookies.set('searchCatalogData', searchCatalogData);
                $location.path('editbook').search({ id: bookObj.id, isCat: 1 });
            }, function () {
                console.log('cancle');
            });
        };

        /*
         * @description
         * Add  Book in select List*/
        $scope.selectBook = function (book) {
            var bookObj = { id: book.id, image: book.image, title: book.title };
            var isAvailable = _.findWhere($scope.selectedBookList, { id: book.id });
            if (isAvailable !== undefined && isAvailable !== null && isAvailable !== '') {
                $scope.selectedBookList.splice($scope.selectedBookList.indexOf(isAvailable), 1);
            }
            else {
                $scope.selectedBookList.push(bookObj);
            }
            if ($scope.selectedBookList.length > 0) {
                $scope.state = true;
            } else {
                $scope.state = false;
            }
        };

        $scope.deleteSelectBook = function (book) {
            $scope.selectedBookList.splice($scope.selectedBookList.indexOf(book), 1);
            $scope.state = ($scope.selectedBookList.length > 0) ? true : false;
        };
        /*
         * @description
         * End Add  Book in select List*/

        /*
         * @description
         * Tag Modal*/

        $scope.getAllTagData = function () {
            var tagData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            catalogService.getTagList(tagData)
                .then(function (data) {
                    if (data.error <= 0) {
                        var tagarr = [];
                        angular.forEach(data.response, function (value, key) {
                            tagarr.push(value.name);
                        });
                        $scope.searchAllTag = tagarr;
                    } else {
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                        $scope.$parent.message = data.errorMsg;
                    }
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.TagModal = function () {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/catalog/publisherTag.html',
                controller: 'TagDetailCtrl',
                resolve: {
                    tagData: function () {
                        return {
                            selectedArr: $scope.booksListData.bookArr,
                            bookArr: ($scope.tagText.length > 0 || ($scope.globalText !== '' && $scope.globalText !== null && $scope.globalText !== undefined)) ? $scope.booksList : []
                        };
                    }
                }
            });
            modalInstance.result.then(function (data) {
                $scope.isError = data.isError;
                $scope.isMessage = data.isMessage;
                $scope.message = data.msg;
                $scope.getAllTagData();
                $scope.getBooks();
                $scope.booksListData = {
                    bookArr: [],
                    allchecked: false
                };
            }, function () {
                $scope.getAllTagData();
                console.log('cancle');
            });
        };

        $scope.deleteAllTagConfirmationModal = function () {
            if ($scope.selectedBookList.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return { ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('CATALOG_REMOVE_CONFIRMATION_LABEL') };
                        }
                    }
                });
                modalInstance.result.then(function () {
                    $scope.selectedBookList = [];
                    $scope.state = false;
                }, function () {
                    console.log('cancle');
                });
            }
            else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return { ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('NO_RECORD_FOR_DELETE') };
                        }
                    }
                });
                modalInstance.result.then(function () {

                }, function () {
                    console.log('cancle');
                });
            }
        };

        $scope.addAllBook = function () {
            var allBookData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                globalText: $scope.globalText,
                tagText: $scope.tagText
            };
            catalogService.getAllBook(allBookData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.selectedBookList = data.response;
                        $scope.state = true;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.addSelectedBook = function () {
            if ($scope.booksListData.bookArr.length > 0) {
                angular.forEach($scope.booksListData.bookArr, function (element) {
                    var idCheck = _.find($scope.selectedBookList, function (value) {
                        return value.id == element.id;
                    });
                    if (idCheck === undefined) {
                        $scope.selectedBookList.push(element);
                    }
                });
                $scope.state = true;
                $scope.booksListData = { bookArr: [], allchecked: false };
            }
            else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return { ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL') };
                        }
                    }
                });
                modalInstance.result.then(function () {

                }, function () {
                    console.log('cancle');
                });
            }
        };
        /*
         * @description
         * edit tag config*/
        $scope.editTagModal = function (book, tagData) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/catalog/publisherBookTag.html',
                controller: 'bookTagCtrl',
                resolve: {
                    bookData: function () {
                        return { bookid: book.id, tagData: tagData, tagList: $scope.searchAllTag };
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                if (dataObj.data.error <= 0) {
                    $scope.getAllTagData();
                    $scope.isError = false;
                    $scope.isMessage = true;
                    $scope.message = dataObj.data.msg;
                } else {
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = dataObj.data.errorMsg;
                }
                $scope.getBooks();
            }, function () {
                console.log('cancle');
            });
        };

        $scope.bookgroupModal = function () {
            if (parameter.group_id !== undefined && parameter.group_id !== '' && parameter.group_id !== null) {
                if ($scope.selectedBookList.length > 0) {
                    var bookarray = [];
                    angular.forEach($scope.selectedBookList, function (value, key) {
                        bookarray.push(value.id);
                    });
                    var bookGroupData = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language,
                        groupOptions: 2,
                        group_id: parameter.group_id,
                        group_name: '',
                        bookArr: bookarray
                    };
                    groupService.createGroup(bookGroupData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.selectedBookList = [];
                                $scope.getGroupDetail(parameter.group_id, function (groupName) {
                                    var groupInstance = $uibModal.open({
                                        animation: true,
                                        templateUrl: 'app/components/catalog/publisherbookGroupChannel.html',
                                        controller: 'bookGroupChannelCtrl',
                                        resolve: {
                                            groupChannelData: function () {
                                                return { bookGroup: { groupOptions: 2, group_id: { name: groupName } }, groupId: parameter.group_id };
                                            }
                                        }
                                    });
                                    groupInstance.result.then(function (dataObj) {
                                        $scope.state = false;
                                        if (dataObj.isRedirect) {
                                            var gid = parseInt(dataObj.group_id);
                                            $location.path('createchannel').search({ group_id: gid });
                                        }
                                        else {
                                            localStorageService.set('list_add', true);
                                            var gid = parseInt(dataObj.group_id);
                                            $location.path('editgroup').search({ id: gid });
                                        }
                                    }, function () {
                                        console.log('cancle');
                                    });
                                });

                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        })
                        .catch(function (err) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
                } else {
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                        controller: 'deleteConfirmationCtrl',
                        resolve: {
                            deleteData: function () {
                                return { ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL') };
                            }
                        }
                    });
                    modalInstance.result.then(function () {

                    }, function () {
                        console.log('cancle');
                    });
                }
            }
            else {
                if ($scope.selectedBookList.length > 0) {
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/components/catalog/publisherBookGroup.html',
                        controller: 'bookGroupCtrl',
                        resolve: {
                            bookData: function () {
                                return { bookArr: $scope.selectedBookList };
                            }
                        }
                    });
                    modalInstance.result.then(function (dataObj) {
                        if (dataObj.data.error <= 0) {
                            var groupInstance = $uibModal.open({
                                animation: true,
                                templateUrl: 'app/components/catalog/publisherbookGroupChannel.html',
                                controller: 'bookGroupChannelCtrl',
                                resolve: {
                                    groupChannelData: function () {
                                        return { bookGroup: dataObj.bookGroup, groupId: dataObj.data.group_id };
                                    }
                                }
                            });
                            groupInstance.result.then(function (dataObj) {
                                $scope.selectedBookList = [];
                                $scope.state = false;
                                if (dataObj.isRedirect) {
                                    var gid = parseInt(dataObj.group_id);
                                    $location.path('createchannel').search({ group_id: gid });
                                }
                            }, function () {
                                console.log('cancle');
                            });
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = dataObj.data.errorMsg;
                        }
                    }, function () {
                        console.log('cancle');
                    });
                } else {
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                        controller: 'deleteConfirmationCtrl',
                        resolve: {
                            deleteData: function () {
                                return { ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL') };
                            }
                        }
                    });
                    modalInstance.result.then(function () {

                    }, function () {
                        console.log('cancle');
                    });
                }
            }
        };

        $scope.getGroupDetail = function (groupId, callgroup) {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                group_id: groupId
            }
            groupService.getGroupRow(data)
                .then(function (data) {
                    if (data.error <= 0) {
                        callgroup(data.response[0].name);
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                })
                .catch(function (err) {

                });
        };

        /**
         * book row class
         */
        $scope.getbookStatus = function (books) {
            var isadded = _.findWhere($scope.selectedBookList, { id: books.id });
            return (isadded !== undefined && isadded !== null && isadded !== '') ? 'minus' : 'plus'
        };

        $scope.getAllTagData();
        /*
         * @description
         * Tag Popup Update Book */
        $rootScope.$on('updateBookList', function (event, data) {
            $scope.getBooks();
        });
        /*
         * @description
         * End Tag Popup Update Book */


        if (searchData !== null && searchData !== undefined && searchData !== '') {
           // $scope.globalText = searchData.globalText;
           // $scope.tagText = searchData.tagText;
           $scope.bookDetailsModal(searchData.bookId);
        }
        cookies.set('searchCatalogData', null);


    }]);

/*
*Tag Detail config
*/
angular.module('OneWorld').controller('TagDetailCtrl', ['$scope', '$rootScope', 'catalogService', '$uibModal', '$uibModalInstance', 'localStorageService', 'tagData', '$filter', '$timeout',
    function ($scope, $rootScope, catalogService, $uibModal, $uibModalInstance, localStorageService, tagData, $filter, $timeout) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.form = {};
        $scope.tagarr = {};
        $scope.tagRows = {};
        $scope.editTagData = {};
        $scope.ModalTitle = 'Tags';
        $scope.tagGridData = tagData;
        $scope.tagChecked = [];
        $scope.isTagError = false;
        $scope.isMessage = false;
        $scope.message = '';
        $scope.tagSubmitted = false;
        /*Delete Selected Tag*/
        $scope.deleteTagModal = function (id) {


            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/catalog/publisherDeleteTag.html',
                controller: 'TagDeleteCtrl',
                resolve: {
                    tagData: function () {
                        return { tagid: id };
                    }
                }
            });
            modalInstance.result.then(function (tagObj) {
                $scope.deleteTag(tagObj.tagid);
            }, function () {
                console.log('cancle');
            });

        };
        $scope.deleteTag = function (id) {
            var deleteTagData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                tag_id: id
            };

            catalogService.deleteTag(deleteTagData)
                .then(function (data) {
                    $scope.isTagError = false;
                    if (data.error <= 0) {
                        $scope.tagsList = data.response;
                        $scope.isError = false;
                        $scope.isMessage = true;
                        $scope.message = data.msg;
                        $scope.$emit('updateBookList', {});
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.isTagError = false;
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        /*get All Tag*/
        $scope.getTagData = function () {
            var tagData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            catalogService.getTagList(tagData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.tagsList = data.response;
                    } else {
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                        $scope.$parent.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.$parent.isError = true;
                    $scope.$parent.isMessage = false;
                });
        };
        /*add tag in selected list*/
        $scope.addTagDetail = function () {
            if ($scope.form.addtag.$valid && $scope.tagarr.tagname.trim()) {
                var addTagData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    tag_name: $scope.tagarr.tagname.trim()
                };

                catalogService.addTag(addTagData)
                    .then(function (data) {
                        $scope.isTagError = false;
                        if (data.error <= 0) {
                            $scope.tagSubmitted = false;
                            $scope.tagarr = { tagname: '' };
                            $scope.tagsList = data.response;
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isTagError = false;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            }
            else {
                $scope.tagSubmitted = true;
            }
        };

        $scope.onFocus = function (id) {
            var input = document.getElementById(id);
            var len = input.value.length;
            input.focus();
            input.setSelectionRange(len, len);
        }
        /* Popup edit tag*/
        $scope.editTagDetail = function (tagData) {
            $scope.closeOtherTag(tagData, function () {
                $scope.editTagData = { tagname: tagData.name, tagid: tagData.id };
                $scope.tagRows['editing' + tagData.id] = true;
                $timeout(function () {
                    $scope.onFocus('edittagname' + tagData.id)
                }, 0);
            });
        };

        $scope.closeOtherTag = function (tagData, call) {
            if ($scope.editTagData.tagid !== undefined && $scope.editTagData.tagid !== null) {
                $scope.tagRows['editing' + $scope.editTagData.tagid] = false;
            }
            call(tagData);
        }

        $scope.updateTag = function (oldTagName) {
            var tagname = ($scope.editTagData.tagname !== undefined) ? $scope.editTagData.tagname.trim() : '';
            if (tagname !== undefined && tagname !== null && tagname !== '') {
                var tagId = $scope.editTagData.tagid.trim();
                if (oldTagName !== tagname) {
                    var updateTagData = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language,
                        tag_name: tagname,
                        original_tag_name: oldTagName,
                        tag_id: tagId
                    };
                    catalogService.updateTag(updateTagData)
                        .then(function (data) {
                            $scope.isTagError = false;
                            if (data.error <= 0) {
                                $scope.editTagData = { tagname: '', tagid: '' };
                                $scope.tagRows['editing' + tagId] = false;
                                $scope.tagsList = data.response;
                                $scope['isError' + tagId] = false;
                                $scope['isMessage' + tagId] = true;
                                $scope['message' + tagId] = data.msg;
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                                $scope.$emit('updateBookList', {});
                            } else {
                                $scope['isError' + tagId] = true;
                                $scope['isMessage' + tagId] = false;
                                $scope['message' + tagId] = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isTagError = false;
                            $scope['isError' + tagId] = true;
                            $scope['isMessage' + tagId] = false;
                            $scope['message' + tagId] = data.errorMsg;
                        });
                } else {
                    $scope.tagRows['editing' + tagId] = false;
                }
            }
        };
        /*End Popup edit tag*/

        /**
         * add tags in books
         */
        $scope.TagAll = function () {
            if ($scope.tagChecked.id !== undefined && $scope.tagChecked.id.length > 0) {
                var bookArray = [];
                if ($scope.tagGridData.bookArr !== undefined && $scope.tagGridData.bookArr !== null && $scope.tagGridData.bookArr !== '') {
                    angular.forEach($scope.tagGridData.bookArr, function (value, key) {
                        this.push(value.id);
                    }, bookArray);
                }
                $scope.addBooksTag(bookArray);
            }
            else {
                $scope.isTagError = true;
                $scope.isMessage = false;
                $scope.message = $filter('translate')('SELECT_ATLEAST_ONE_TAG');
            }
        };

        $scope.TagSelected = function () {
            if ($scope.tagChecked.id !== undefined && $scope.tagChecked.id.length > 0) {
                var bookArray = [];
                if ($scope.tagGridData.selectedArr !== undefined && $scope.tagGridData.selectedArr !== null && $scope.tagGridData.selectedArr !== '') {
                    angular.forEach($scope.tagGridData.selectedArr, function (value, key) {
                        this.push(value.id);
                    }, bookArray);
                }
                $scope.addBooksTag(bookArray);
            }
            else {
                $scope.isTagError = true;
                $scope.isMessage = false;
                $scope.message = $filter('translate')('SELECT_ATLEAST_ONE_TAG');
            }
        };

        $scope.addBooksTag = function (bookArray) {
            var BookTagData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                bookListArr: bookArray,
                tagListArr: $scope.tagChecked.id
            };
            catalogService.addBookTag(BookTagData)
                .then(function (data) {
                    $scope.isTagError = false;
                    if (data.error <= 0) {
                        $scope.tagChecked = [];
                        $scope.tagGridData = {};
                        $scope.isError = false;
                        $scope.isMessage = true;
                        $scope.message = data.msg;
                        $uibModalInstance.close({ isError: false, isMessage: true, msg: data.msg });
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                        $uibModalInstance.close({ isError: true, isMessage: false, msg: data.errorMsg });
                    }
                }, function (err, status) {
                    $scope.isTagError = false;
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * End add tags in books
         */

        /**
         * Remove tags in books
         */
        $scope.removeAllTag = function () {
            if ($scope.tagChecked.id !== undefined && $scope.tagChecked.id.length > 0) {
                var bookArray = [];
                if ($scope.tagGridData.bookArr !== undefined && $scope.tagGridData.bookArr !== null && $scope.tagGridData.bookArr !== '') {
                    angular.forEach($scope.tagGridData.bookArr, function (value, key) {
                        this.push(value.id);
                    }, bookArray);
                }
                $scope.removeBooksTag(bookArray);
            }
            else {
                $scope.isTagError = true;
                $scope.isMessage = false;
                $scope.message = $filter('translate')('SELECT_ATLEAST_ONE_TAG');
            }
        };

        $scope.removeTagSelected = function () {
            if ($scope.tagChecked.id !== undefined && $scope.tagChecked.id.length > 0) {
                var bookArray = [];
                if ($scope.tagGridData.selectedArr !== undefined && $scope.tagGridData.selectedArr !== null && $scope.tagGridData.selectedArr !== '') {
                    angular.forEach($scope.tagGridData.selectedArr, function (value, key) {
                        this.push(value.id);
                    }, bookArray);
                }
                $scope.removeBooksTag(bookArray);
            }
            else {
                $scope.isTagError = true;
                $scope.isMessage = false;
                $scope.message = $filter('translate')('SELECT_ATLEAST_ONE_TAG');
            }
        };

        $scope.removeBooksTag = function (bookArray) {
            var BookTagData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                bookListArr: bookArray,
                tagListArr: $scope.tagChecked.id
            };
            catalogService.removeBookTag(BookTagData)
                .then(function (data) {
                    $scope.isTagError = false;
                    if (data.error <= 0) {
                        $scope.tagChecked = [];
                        $scope.tagGridData = {};
                        $scope.isError = false;
                        $scope.isMessage = true;
                        $scope.message = data.msg;
                        $uibModalInstance.close({ isError: false, isMessage: true, msg: data.msg });
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $uibModalInstance.close({ isError: false, isMessage: true, msg: data.msg });
                    }
                }, function (err, status) {
                    $scope.isTagError = false;
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * End Remove tags in books
         */

        $scope.checkErr = function (tagId) {
            return $scope['isError' + tagId];
        };

        $scope.getmessage = function (tagId) {
            return $scope['message' + tagId];
        };

        $scope.getTagData();
    }]);
/*
*Tag Popup config
*/
angular.module('OneWorld').controller('TagDeleteCtrl', ['$scope', '$uibModalInstance', 'tagData',
    function ($scope, $uibModalInstance, tagData) {
        $scope.tagData = tagData;
        $scope.deleteTagDetail = function (id) {
            $uibModalInstance.close({ tagid: id });
        }
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);

angular.module('OneWorld').controller('bookTagCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'bookData', 'localStorageService', 'catalogService',
    function ($scope, $rootScope, $uibModalInstance, bookData, localStorageService, catalogService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.bookTag = {};
        $scope.bookTag.tags = (bookData.tagData !== null && bookData.tagData !== undefined && bookData.tagData !== '') ? bookData.tagData.split(',') : [];
        $scope.allTag = bookData.tagList;
        if ($scope.bookTag.tags.length > 0) {
            $scope.bookTag.tags = _.map($scope.bookTag.tags,
                function (tagsvalue, key) {
                    return tagsvalue.trim();
                });
        }
        $scope.tags = [];
        $scope.deleteTag = [];
        $scope.ModalTitle = 'Tag';
        $scope.addBookTags = function () {
            var tagStr = ($scope.bookTag.tags.length == 0) ? '' : $scope.bookTag.tags.toString(',');
            var oldtagstr = (bookData.tagData !== null) ? bookData.tagData : '';

            if (tagStr != oldtagstr) {
                if ($scope.$$childTail.newValue !== '' && $scope.$$childTail.newValue !== undefined && $scope.$$childTail.newValue !== null) {
                    $scope.bookTag.tags.push($scope.$$childTail.newValue);
                }
                var BookTagData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    tagArr: $scope.bookTag.tags,
                    book_id: bookData.bookid,
                    deleteTag: $scope.deleteTag
                };
                catalogService.addBookRowTag(BookTagData)
                    .then(function (data) {
                        $uibModalInstance.close({ data: data });
                    }, function (err, status) {
                        $uibModalInstance.dismiss('cancel');
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                    });
            }
            else {
                if ($scope.$$childTail.newValue !== '' && $scope.$$childTail.newValue !== undefined && $scope.$$childTail.newValue !== null) {
                    $scope.bookTag.tags.push($scope.$$childTail.newValue);
                    var BookTagData = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language,
                        tagArr: $scope.bookTag.tags,
                        book_id: bookData.bookid,
                        deleteTag: $scope.deleteTag
                    };
                    catalogService.addBookRowTag(BookTagData)
                        .then(function (data) {
                            $uibModalInstance.close({ data: data });
                        }, function (err, status) {
                            $uibModalInstance.dismiss('cancel');
                            $scope.$parent.isError = true;
                            $scope.$parent.isMessage = false;
                        });
                }
                else {
                    $uibModalInstance.dismiss('cancel');
                }
            }
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);

angular.module('OneWorld').controller('bookGroupCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'localStorageService', 'groupService', 'bookData',
    function ($scope, $rootScope, $uibModalInstance, localStorageService, groupService, bookData) {
        $scope.bookGroup = { groupOptions: 1, group_id: '', group_name: '' };
        $scope.grpmessage = { groupname: false, groupnamemsg: '', groupid: false, groupidmsg: '' };
        $scope.groupList = [];

        $scope.getGroupList = function () {
            var TokenData = localStorageService.get('authorizeTokenDetail');
            var BookGroupData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            groupService.getGroupData(BookGroupData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.groupList = data.response;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.addBookGroup = function () {
            var TokenData = localStorageService.get('authorizeTokenDetail');
            var istrue = true;
            var bookarray = [];
            angular.forEach(bookData.bookArr, function (value, key) {
                bookarray.push(value.id);
            });
            var bookGroupData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                groupOptions: $scope.bookGroup.groupOptions,
                group_id: $scope.bookGroup.group_id.id,
                group_name: $scope.bookGroup.group_name,
                bookArr: bookarray
            };
            if ($scope.bookGroup.groupOptions == 1 && $scope.bookGroup.group_name == '') {
                istrue = false;
                $scope.grpmessage = { groupname: true, groupnamemsg: 'Enter Group Name.', groupid: false, groupidmsg: '' };
            }
            if ($scope.bookGroup.groupOptions == 2 && $scope.bookGroup.group_id == '') {
                istrue = false;
                $scope.grpmessage = { groupname: false, groupnamemsg: '', groupid: true, groupidmsg: 'No group available for select.' };
            }
            if (istrue) {
                groupService.createGroup(bookGroupData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $uibModalInstance.close({ data: data, bookGroup: $scope.bookGroup });
                        } else {
                            $scope.grpmessage = { groupname: true, groupnamemsg: data.errorMsg, groupid: false, groupidmsg: '' };
                        }
                    }, function (err, status) {
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                    });
            }
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.getGroupList();
    }]);

angular.module('OneWorld').controller('bookGroupChannelCtrl', ['$scope', '$rootScope', 'userRightsService', '$uibModalInstance', 'groupChannelData', 'localStorageService',
    function ($scope, $rootScope, userRightsService, $uibModalInstance, groupChannelData, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');

        $scope.groupData = groupChannelData.bookGroup;
        $scope.groupId = groupChannelData.groupId;
        $scope.title = ($scope.groupData.groupOptions == 1) ? $scope.groupData.group_name : $scope.groupData.group_id.name;

        $scope.checkBtnRights = function (moduleId) {
            return userRightsService.checkUserRights(moduleId);
        }

        $scope.groupDone = function (isRedirect) {
            $uibModalInstance.close({ isRedirect: isRedirect, group_id: $scope.groupId });
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);