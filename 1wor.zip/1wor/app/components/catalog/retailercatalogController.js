'use strict';
angular.module('OneWorld').controller('retailercatalogController', ['$scope', '$rootScope', '$uibModal', '$location', 'localStorageService', 'businessmodelService', 'listService', 'catalogService', '$filter',
    function($scope, $rootScope, $uibModal, $location, localStorageService, businessmodelService, listService, catalogService, $filter) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        cookies.set('retailer_bid', []);
        cookies.set('retailer_bundleid', []);
        var parameter = $location.search();
        $scope.list_id = (parameter.list_id !== undefined && parameter.list_id !== null && parameter.list_id !== '') ? parameter.list_id : '';
        $scope.countCatalog = {
            books: 0,
            bundles: 0
        };
        $scope.businessModelList = [];
        $scope.businessIdList = [];
        $scope.curationList = [];
        $scope.bookcheckbox = {
            bookidArr: []
        };
        //$scope.bookidArr = [];
        $scope.selectBookArr = [];
        $scope.booksList = [];
        $scope.state = false;
        $scope.totalBooks = 0;
        $scope.allBookBtn = false;
        $scope.bookListOption = {
            pagestart: 0,
            pagelimit: 10,
            searchtext: '',
            curation_id: '',
            language_id: 0,
            business_id: [],
            limit_by_price: false,
            pricevalue: 0,
            search_currency: ''
        };

        $scope.priceOption = {};

        $scope.totalBookLength = 0;
        $scope.preferenceSearch = '';
        $scope.languageList = [];
        $scope.toggleState = function() {
            $scope.state = !$scope.state;
        };

        /**
         * @description
         * move to Dashboard page
         */
        $scope.goBack = function() {
            $location.path('retailerdashboard');
        };
        /**
         * @description
         * Bussiness List
         */
        $scope.getBusinessModelList = function() {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            businessmodelService.getBusinessModelList(data)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.businessModelList = data.response;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.message = '';
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        /**
         * @description
         * Language List
         */

        $scope.getLanguageList = function() {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            catalogService.getLanguageList(data)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.languageList = data.response;
                        $scope.languageList.unshift({ id: 0, name: $filter('translate')('SHOW_ALL') });
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.message = '';
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        /**
         * @description
         * Price List
         */

        $scope.getPriceList = function() {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            catalogService.getPriceList(data)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.priceOption = data;
                        $scope.slideroptions = {
                            currency_id: data.currency_id,
                            floor: data.min_val,
                            ceil: data.max_val,
                            step: 10,
                            precision: 1,
                            translate: function(value) {
                                var val = ((data.currency_symbol !== '') ? data.currency_symbol : data.currency) + value;
                                return val;
                            }
                        };
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.message = '';
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        /**
         * @description
         * Curation List
         */
        $scope.getCurationList = function() {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            catalogService.getCurationList(data)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.curationList = data.response;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.message = '';
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * @description
         *  grid Option
         */
        $scope.getBookList = function() {
            var data = $scope.bookListOption;
            data.access_token = TokenData.access_token;
            data.language = $rootScope.language;
            $scope.bookDetailList(data, false);
        };

        $scope.searchBooks = function() {
            $scope.preferenceSearch = $scope.bookListOption.searchtext;
            $scope.allBookBtn = true;
            $scope.bookListOption.pagestart = 0;
            $scope.bookListOption.pagelimit = 10;
            var data = $scope.bookListOption;
            data.access_token = TokenData.access_token;
            data.language = $rootScope.language;
            $scope.bookDetailList(data, false);
        };

        $scope.searchByCuration = function(curation_id) {
            $scope.bookListOption.pagestart = 0;
            $scope.bookListOption.pagelimit = 10;
            $scope.bookListOption.curation_id = curation_id;
            var data = $scope.bookListOption;
            data.access_token = TokenData.access_token;
            data.language = $rootScope.language;
            $scope.bookDetailList(data, false);
        };

        $scope.searchByBusinessModel = function() {
            $scope.bookListOption.pagestart = 0;
            $scope.bookListOption.pagelimit = 10;
            var data = $scope.bookListOption;
            data.access_token = TokenData.access_token;
            data.language = $rootScope.language;
            $scope.bookDetailList(data, false);
        };

        $scope.searchByLanguage = function() {
            $scope.bookListOption.pagestart = 0;
            $scope.bookListOption.pagelimit = 10;
            var data = $scope.bookListOption;
            data.access_token = TokenData.access_token;
            data.language = $rootScope.language;
            $scope.bookDetailList(data, false);
        };

        $scope.PagingList = function() {
            $scope.bookListOption.pagestart += $scope.bookListOption.pagelimit;
            var data = $scope.bookListOption;
            data.access_token = TokenData.access_token;
            data.language = $rootScope.language;
            data.lazyLoading = true;
            $scope.bookDetailList(data, true);
        };

        $scope.$on("slideEnded", function() {
            $scope.bookListOption.pagestart = 0;
            $scope.bookListOption.pagelimit = 10;
            var data = $scope.bookListOption;
            data.access_token = TokenData.access_token;
            data.language = $rootScope.language;
            data.search_currency = $scope.slideroptions.currency_id;
            $scope.bookDetailList(data, false);
        });

        $scope.changeLimitPrice = function() {
            if ($scope.bookListOption.limit_by_price) {
                $scope.slideroptions = {
                    currency_id: $scope.priceOption.currency_id,
                    floor: $scope.priceOption.min_val,
                    ceil: $scope.priceOption.max_val,
                    step: 10,
                    precision: 1,
                    translate: function(value) {
                        var val = (($scope.priceOption.currency_symbol !== '') ? $scope.priceOption.currency_symbol : $scope.priceOption.currency) + value;
                        return val;
                    }
                };
            } else {
                $scope.bookListOption.search_currency = '';
                $scope.bookListOption.pricevalue = 0;
                $scope.bookListOption.pagestart = 0;
                $scope.bookListOption.pagelimit = 10;
                var data = $scope.bookListOption;
                data.access_token = TokenData.access_token;
                data.language = $rootScope.language;
                $scope.bookDetailList(data, false);
            }
        };

        $scope.bookDetailList = function(data, isLoad) {
            catalogService.getRetailerBookList(data)
                .then(function(data) {
                    if (data.error <= 0) {
                        if (isLoad && data.response.length > 0) {
                            angular.forEach(data.response, function(value, key) {
                                $scope.booksList.push(value);
                            });
                        }
                        if (!isLoad) {
                            $scope.booksList = data.response;
                        }
                        $scope.totalBookLength = data.total_rows;
                        $scope.isError = false;
                        $scope.isMessage = true;
                        $scope.message = data.msg;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.message = '';
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.clearSearch = function() {
            $scope.bookcheckbox = {
                bookidArr: []
            };
            $scope.bookListOption = {
                pagestart: 0,
                pagelimit: 10,
                searchtext: '',
                language_id: 0,
                business_id: [],
                limit_by_price: true,
                pricevalue: 0,
                curation_id: '',
                search_currency: ''
            };
            var divTag = document.getElementsByClassName('select2-search-choice');
            var divLength = divTag.length;
            var i = 0;
            for (i; i < divLength; i++) {
                if (divTag[0].outerHTML !== undefined) {
                    divTag[0].outerHTML = '';
                }
            }
            $scope.bookListOption.business_id = [];
            var data = $scope.bookListOption;
            data.access_token = TokenData.access_token;
            data.language = $rootScope.language;
            $scope.bookDetailList(data, false);
        };
        /**
         * @description
         * End grid Option
         */
        $scope.clearSelectedBook = function() {
            $scope.allBookBtn = false;
            $scope.bookcheckbox.bookidArr = [];
        };
        $scope.addBookgroup = function() {
            angular.forEach($scope.bookcheckbox.bookidArr, function(value, key) {
                var isAva = _.where($scope.selectBookArr, { book_id: value.book_id });
                var isBundleAva = _.where($scope.selectBookArr, { bundle_id: value.bundle_id });
                if (value.book_id !== undefined && isAva.length <= 0) {
                    var selectObj = {
                        book_id: value.book_id,
                        title: value.title,
                        image: value.image,
                        author: value.author
                    }
                    this.push(selectObj);
                    $scope.countCatalog.books++;
                }
                if (value.bundle_id !== undefined && isBundleAva.length <= 0) {
                    var selectObj = {
                        bundle_id: value.bundle_id,
                        title: value.title,
                        image: value.bundle_cover_image
                    }
                    this.push(selectObj);
                    $scope.countCatalog.bundles++;
                }
            }, $scope.selectBookArr);
            if ($scope.selectBookArr.length > 0) {
                $scope.state = true;
                $scope.bookcheckbox.bookidArr = [];
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function() {
                            return { ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL') };
                        }
                    }
                });
                modalInstance.result.then(function() {

                }, function() {
                    console.log('error');
                });
            }
        };

        $scope.deleteBook = function(bookdetail) {
            if (bookdetail.bundle_id !== undefined && bookdetail.bundle_id !== null && bookdetail.bundle_id !== '') {
                $scope.countCatalog.bundles--;
            }
            if (bookdetail.book_id !== undefined && bookdetail.book_id !== null && bookdetail.book_id !== '') {
                $scope.countCatalog.books--;
            }
            $scope.selectBookArr.splice($scope.selectBookArr.indexOf(bookdetail), 1);
        };

        $scope.deleteAllSelectedBook = function() {
            if ($scope.selectBookArr.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function() {
                            return { ModalTitle: "Confirmation", msg: "Are you sure you want to delete the record(s)?" };
                        }
                    }
                });
                modalInstance.result.then(function() {
                    $scope.countCatalog = {
                        books: 0,
                        bundles: 0
                    };
                    $scope.selectBookArr = [];
                    $scope.state = false;
                }, function() {
                    console.log('cancle');
                });
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function() {
                            return { ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('NO_RECORD_FOR_DELETE') };
                        }
                    }
                });
                modalInstance.result.then(function() {

                }, function() {
                    console.log('error');
                });
            }
        };
        $scope.createSelectBooksList = function() {
            if ($scope.selectBookArr.length > 0) {
                if ($scope.list_id !== undefined && $scope.list_id !== '' && $scope.list_id !== null) {

                    var bookarray = [];
                    var bundlearray = [];
                    angular.forEach($scope.selectBookArr, function(value, key) {
                        if (value.book_id !== undefined && value.book_id !== null && value.book_id !== '') {
                            bookarray.push(value.book_id);
                        }
                        if (value.bundle_id !== undefined && value.bundle_id !== null && value.bundle_id !== '') {
                            bundlearray.push(value.bundle_id);
                        }
                    });
                    var bookMyListData = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language,
                        listOptions: 2,
                        list_id: $scope.list_id,
                        list_name: '',
                        bookArr: bookarray,
                        bundlearray: bundlearray
                    };

                    listService.createMyList(bookMyListData)
                        .then(function(data) {
                            if (data.error <= 0) {
                                $scope.selectBookArr = [];
                                $scope.getListDetail($scope.list_id, function(listName) {
                                    var groupInstance = $uibModal.open({
                                        animation: true,
                                        templateUrl: 'app/components/catalog/retailerbookswidget.html',
                                        controller: 'bookListCtrl',
                                        resolve: {
                                            listWidgetData: function() {
                                                return { bookGroup: { groupOptions: 2, group_id: { name: listName } }, listId: $scope.list_id };

                                            }
                                        }
                                    });
                                    groupInstance.result.then(function(dataObj) {
                                        $scope.state = false;
                                        if (dataObj.isRedirect) {
                                            var gid = parseInt(dataObj.list_id);
                                            $location.path('createretailerwidgets').search({ list_id: gid });
                                        } else {
                                            localStorageService.set('list_add', true);
                                            var gid = parseInt(dataObj.list_id);
                                            $location.path('editlist').search({ id: gid });
                                        }
                                    }, function() {
                                        console.log('cancle');
                                    });

                                });

                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function(err, status) {
                            $scope.message = '';
                            $scope.isError = false;
                            $scope.isMessage = false;
                        });

                } else {
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/components/catalog/retailerCreateListTemplate.html',
                        controller: 'retailerCreateListController',
                        resolve: {
                            bookData: function() {
                                return { bookArr: $scope.selectBookArr };
                            }
                        }
                    });
                    modalInstance.result.then(function(dataObj) {
                        if (dataObj.data.error <= 0) {
                            var groupInstance = $uibModal.open({
                                animation: true,
                                templateUrl: 'app/components/catalog/retailerbookswidget.html',
                                controller: 'bookListCtrl',
                                resolve: {
                                    listWidgetData: function() {
                                        return { bookGroup: dataObj.bookGroup, listId: dataObj.data.list_id };
                                    }
                                }
                            });
                            groupInstance.result.then(function(dataObj) {
                                $scope.selectBookArr = [];
                                $scope.state = false;
                                if (dataObj.isRedirect) {
                                    var gid = parseInt(dataObj.list_id);
                                    $location.path('createretailerwidgets').search({ list_id: gid });
                                }
                            }, function() {
                                console.log('error');
                            });

                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = dataObj.data.errorMsg;
                        }

                    }, function() {
                        console.log('cancle');
                    });
                }

            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function() {
                            return { ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL') };
                        }
                    }
                });
                modalInstance.result.then(function() {

                }, function() {
                    console.log('error');
                });
            }
        };

        /**
         * get List Detail
         */
        $scope.getListDetail = function(listId, callgroup) {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                list_id: listId
            }
            listService.getListRow(data)
                .then(function(data) {
                    if (data.error <= 0) {
                        callgroup(data.response[0].name);
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                })
                .catch(function(err) {

                });
        };
        /**
         * @description
         * Create Widget
         */
        $scope.createRetailerWidget = function() {
            var bookIdArr = [];
            var bundleIdArr = [];
            if ($scope.selectBookArr.length > 0) {
                angular.forEach($scope.selectBookArr, function(val, key) {
                    if (val.book_id !== undefined && val.book_id !== null && val.book_id !== '') {
                        bookIdArr.push(val.book_id);
                    }
                    if (val.bundle_id !== undefined && val.bundle_id !== null && val.bundle_id !== '') {
                        bundleIdArr.push(val.bundle_id);
                    }
                    //this.push(val.book_id);
                });
                cookies.set('retailer_bid', bookIdArr);
                cookies.set('retailer_bundleid', bundleIdArr);
                $location.path('/createretailerwidgets');
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function() {
                            return { ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL') };
                        }
                    }
                });
                modalInstance.result.then(function() {

                }, function() {
                    console.log('error');
                });
            }
        };
        /**
         * @description
         * all book addd in grid
         */
        $scope.addAllBooks = function() {
            var data = $scope.bookListOption;
            data.access_token = TokenData.access_token;
            data.language = $rootScope.language;
            catalogService.getSearchedBooks(data)
                .then(function(data) {
                    if (data.error <= 0) {
                        angular.forEach(data.response, function(value, key) {
                            var isAva = _.where($scope.selectBookArr, { book_id: value.book_id })
                            if (isAva.length <= 0) {
                                var selectObj = {
                                    book_id: value.book_id,
                                    title: value.title,
                                    image: value.image,
                                    author: value.author
                                }
                                this.push(selectObj);
                            }
                        }, $scope.selectBookArr);
                        $scope.countCatalog.books = data.book_count;
                        $scope.countCatalog.bundles = data.bundle_count;
                        $scope.state = true;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.message = '';
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * @description
         * book detail modal
         */
        $scope.bookDetailsModal = function(bookId) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/catalog/retailerBookDetail.html',
                controller: 'bookDetailCtrl',
                resolve: {
                    bookData: function() {
                        return { bookId: bookId, type: 'retailer' };
                    }
                }
            });
            modalInstance.result.then(function() {

            }, function() {
                console.log('error');
            });
        };

        /**
         * bundle detail model
         */
        $scope.bundleDetailsModal = function(bundleId, bundleName) {
            var bundleDataObj = {
                bundle_id: bundleId,
                bundle_name: bundleName
            };
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/retailerBundleDetail.html',
                controller: 'bundleDetailCtrl',
                resolve: {
                    bundleData: function() {
                        return { bundleDataObj: bundleDataObj };
                    }
                }
            });
            modalInstance.result.then(function() {

            }, function() {
                console.log('error');
            });
        };

        $scope.showbusinessmodel = function() {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/businessmodel_popup.html',
                controller: 'businessinstructionCtrl',
                resolve: {
                    businessData: function() {
                        return {

                        };
                    }
                }
            });
            modalInstance.result.then(function(dataObj) {

            }, function() {

            });
        };

        $scope.getBusinessModelList();
        $scope.getLanguageList();
        $scope.getPriceList();
        $scope.getCurationList();
        $scope.getBookList();
    }
]);

angular.module('OneWorld').controller('retailerCreateListController', ['$scope', '$rootScope', '$uibModalInstance', 'localStorageService', 'listService', 'bookData',
    function($scope, $rootScope, $uibModalInstance, localStorageService, listService, bookData) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.bookGroup = { groupOptions: 1, group_id: '', group_name: '' };
        $scope.grpmessage = { groupname: false, groupnamemsg: '', groupid: false, groupidmsg: '' };
        $scope.bookMyList = [];
        /**
         * @description
         * get list book
         */
        $scope.getBookMyList = function() {
            var BookGroupData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            listService.getMyListData(BookGroupData)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.bookMyList = data.response;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.message = '';
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * @description
         * Create List
         */
        $scope.addBookGroup = function() {
            var istrue = true;
            var bookarray = [];
            var bundlearray = [];
            angular.forEach(bookData.bookArr, function(value, key) {
                if (value.book_id !== undefined && value.book_id !== null && value.book_id !== '') {
                    bookarray.push(value.book_id);
                }
                if (value.bundle_id !== undefined && value.bundle_id !== null && value.bundle_id !== '') {
                    bundlearray.push(value.bundle_id);
                }
            });
            var bookMyListData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                listOptions: $scope.bookGroup.groupOptions,
                list_id: $scope.bookGroup.group_id.id,
                list_name: $scope.bookGroup.group_name,
                bookArr: bookarray,
                bundlearray: bundlearray
            };
            if ($scope.bookGroup.groupOptions === 1 && $scope.bookGroup.group_name == '') {
                istrue = false;
                $scope.grpmessage = { groupname: true, groupnamemsg: 'Enter List Name.', groupid: false, groupidmsg: '' };
            }
            if ($scope.bookGroup.groupOptions === 2 && $scope.bookGroup.group_id == '') {
                istrue = false;
                $scope.grpmessage = { groupname: true, groupnamemsg: '', groupid: false, groupidmsg: 'Enter List Id.' };
            }
            if (istrue) {
                listService.createMyList(bookMyListData)
                    .then(function(data) {
                        if (data.error <= 0) {
                            data.list_id = ($scope.bookGroup.group_id !== '' && $scope.bookGroup.group_id !== undefined && $scope.bookGroup.group_id !== null) ? $scope.bookGroup.group_id.id : data.list_id;
                            $uibModalInstance.close({ data: data, bookGroup: $scope.bookGroup });
                        } else {
                            $scope.grpmessage = { groupname: true, groupnamemsg: data.errorMsg, groupid: false, groupidmsg: '' };
                        }
                    }, function(err, status) {
                        $scope.$parent.message = '';
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                    });
            }
        };
        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.getBookMyList();
    }
]);



angular.module('OneWorld').controller('bookListCtrl', ['$scope', '$rootScope', 'userRightsService', '$uibModalInstance', 'listWidgetData', 'localStorageService',
    function($scope, $rootScope, userRightsService, $uibModalInstance, listWidgetData, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.ListData = listWidgetData.bookGroup;
        $scope.listId = listWidgetData.listId;
        $scope.title = ($scope.ListData.groupOptions == 1) ? $scope.ListData.group_name : $scope.ListData.group_id.name;

        $scope.checkBtnRights = function(moduleId) {
            return userRightsService.checkUserRights(moduleId);
        }

        $scope.groupDone = function(isRedirect) {
            $uibModalInstance.close({ isRedirect: isRedirect, list_id: $scope.listId });
        };

        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
    }
]);