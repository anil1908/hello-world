angular.module('OneWorld').controller('verifyController', ['$scope', '$rootScope', '$http', '$location', '$window','authService',
    function ($scope, $rootScope, $http, $location, $window,authService) {
        /**
        * @description
         * Verify User Config
         */
        if ($location.search().u != '' && $location.search().u != undefined) {
            authService.logOut()
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.activateUser();
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                },
                function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = data.errorMsg;
                });
        }

        $scope.activateUser = function(){
            $http({
                method: 'POST',
                url: 'api/signup/verify_user',
                data: { user_id: $location.search().u, language: $rootScope.language }, // pass in data as strings
                headers: { 'Content-Type': 'application/json' },
            }).success(function (data) {
                if (data.error <= 0) {
                    $scope.isMessage = true;
                    $rootScope.message = data.msg;
                    $location.$$search = {};
                    $location.path('/');
                } else {
                    $scope.isError = true;
                    $rootScope.errmessage = data.errorMsg;
                    $location.$$search = {};
                    $location.path('/');
                }
            },
            function (err, status) {
                $scope.isError = true;
            });
        };

    }]);