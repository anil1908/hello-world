'use strict';
angular.module('OneWorld').controller('preferenceController', ['$scope', '$rootScope', '$location', 'localStorageService', 'businessmodelService', 'languageService', 'countryService', 'ivhTreeviewMgr', '$timeout','COUNTRY_PREFERENCE',
    function ($scope, $rootScope, $location, localStorageService, businessmodelService, languageService, countryService, ivhTreeviewMgr, $timeout,COUNTRY_PREFERENCE) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.preferenceDetail = {
            businessmodel_id: [],
            language_id: [],
            country_id: [],
            markup: 30,
            main_country_id: '',
            //currency_preference : ''
        };
        $scope.languageList = [];
        $scope.businessModelList = [];
        $scope.countryList = [];
        $scope.isMarkupAvailable = false;
        $scope.isMarkupRequired = false;
        $scope.isSubmitted = false;
        $scope.countryRegionArr = [];
        $scope.selectedCountry = [];
        $scope.countryError = false;
        $scope.isMessage = false;
        $scope.isError = false;
        $scope.goBack = function () {
            $location.path('retailerdashboard');
        };

        $scope.getBusinessModel = function () {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };

            businessmodelService.getBusinessModelList(data)
                .then(function (data) {
                    $scope.businessModelList = data.response;
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.getLanguageList = function () {
            var languageData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            languageService.getLanguageList(languageData)
                .then(function (data) {
                    $scope.languageList = data.response;
                },
                function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.getCountryList = function () {
            var countryData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                region_array: [1]
            };
            countryService.getCountryList(countryData)
                .then(function (data) {
                    $scope.updateCountry(data.response, function () {
                        $scope.getPreferenceDetail();
                    });
                },
                function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.updateCountry = function (data, call) {
            angular.forEach(data, function (element) {
                if(COUNTRY_PREFERENCE[element.label]!==undefined && COUNTRY_PREFERENCE[element.label].length>0){
                    angular.forEach(COUNTRY_PREFERENCE[element.label],function(val,key) {
                        element.children.unshift(val)
                    });
                }
                $scope.countryRegionArr.push(element);
            });
            call();
        };

        $scope.isMarkup = function () {
            $scope.isMarkupAvailable = false;
            if ($scope.preferenceDetail.businessmodel_id !== undefined && $scope.preferenceDetail.businessmodel_id.length > 0) {
                angular.forEach($scope.preferenceDetail.businessmodel_id, function (value, key) {
                    if (value == 3 || value == 9) {
                        $scope.isMarkupAvailable = true;
                    }
                });
            }
            if (!$scope.isMarkupAvailable) {
                $scope.preferenceDetail.markup = 30;
            }
            $scope.isMarkupValidate();
        };

        $scope.isMarkupValidate = function () {
            $scope.isMarkupRequired = false;
            if ($scope.preferenceDetail.businessmodel_id !== undefined && $scope.preferenceDetail.businessmodel_id.length > 0) {
                angular.forEach($scope.preferenceDetail.businessmodel_id, function (value, key) {
                    if (value == 3 || value == 9) {
                        $scope.isMarkupRequired = true;
                    }
                });
            }
        };

        $scope.addPreferenceData = function () {
            if ($scope.addpreference.$valid && $scope.selectedCountry.length > 0) {
                var data = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    businessmodel_id: $scope.preferenceDetail.businessmodel_id,
                    country_id: _.pluck($scope.selectedCountry, 'id').filter(function(item, i, ar){ return ar.indexOf(item) === i; }),
                    language_id: $scope.preferenceDetail.language_id,
                    main_country_id: $scope.preferenceDetail.main_country_id,
                    markup: $scope.preferenceDetail.markup
                };
                businessmodelService.addpreferenceDetail(data)
                    .then(function (data) {
                        $scope.message = data.msg;
                        $scope.isError = false;
                        $scope.isMessage = true;
                        $scope.isSubmitted = false;
                        $scope.countryError = false;
                        $scope.getPreferenceDetail();
                    },
                    function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    })
                    .catch(function (err) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });

            } else {
                if ($scope.selectedCountry.length <= 0) {
                    $scope.countryError = true;
                }
                $scope.isSubmitted = true;
            }
        };

        $scope.getPreferenceDetail = function () {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            businessmodelService.getPreferenceDetail(data)
                .then(function (data) {
                    $scope.isSubmitted = false;
                    $scope.preferenceDetail = data.response;
                    if (data.response.country_id !== undefined && data.response.country_id.length > 0) {
                        $scope.countrySelect(data.response.country_id, function () {
                            $scope.mainCountryList();
                            if ($scope.countryRegionArr.length > 0) {
                                var is_region = true;
                                angular.forEach($scope.countryRegionArr, function (va, ke) {
                                    if (ke != 0) {
                                        if (!va.selected) {
                                            is_region = false;
                                        }
                                    }
                                });
                                if (is_region) {
                                    ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                                }
                            }
                        });
                    }
                    $scope.isMarkup();
                },
                function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                })
                .catch(function (err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * @description
         * Country Region config
        */

        $scope.countrySelect = function (countryData, call) {
            ivhTreeviewMgr.selectEach($scope.countryRegionArr, countryData);
            call();
        };

        $scope.getCountryRegionArr = function () {
            var Data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            countryService.getCountryRegionList(Data)
                .then(function (data) {
                    $scope.updateCountry(data.response, function () {
                        $scope.getPreferenceDetail();
                    });
                })
                .catch(function (err) {

                });
        };

        $scope.countryMade = function (Node, IsSelected, Tree) {

            _.find($scope.countryRegionArr, function(objval){
                if(objval.children!==undefined && objval.children.length>0){
                    var dupArr = _.where(objval.children, {country_id: Node.country_id});
                    if(IsSelected){
                        angular.forEach(dupArr,function(dupval,dupkey){
                            ivhTreeviewMgr.select($scope.countryRegionArr,dupval);
                        });
                    }
                    else{
                        angular.forEach(dupArr,function(dupval,dupkey){
                            ivhTreeviewMgr.deselect($scope.countryRegionArr,dupval);
                        });
                    }
                }
            });

            if (Node.label === 'World' && Node.children === undefined && IsSelected) {
                ivhTreeviewMgr.selectAll($scope.countryRegionArr);
                $scope.mainCountryList();
            }
            if (Node.label === 'World' && Node.children === undefined && !IsSelected) {
                ivhTreeviewMgr.deselectAll($scope.countryRegionArr);
                $scope.mainCountryList();
            }
            if (Node.label !== 'World' && IsSelected) {
                $scope.deselectCountry(function () {
                    var isselectAll = true;
                    angular.forEach($scope.countryRegionArr, function (val, key) {
                        if (key !== 0 && !val.selected) {
                            isselectAll = false;
                        }
                    });
                    if (isselectAll) {
                        ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[0]);
                    }
                    $scope.mainCountryList();
                });
            }
            if (Node.label !== 'World' && !IsSelected) {
                ivhTreeviewMgr.deselect($scope.countryRegionArr, $scope.countryRegionArr[0]);
                $scope.mainCountryList();
            }
        };

        $scope.mainCountryList = function () {
            $scope.selectedCountry = [];
            angular.forEach($scope.countryRegionArr, function (va, ke) {
                if (ke != 0) {
                    var extraarr = COUNTRY_PREFERENCE[va.label];
                    if(extraarr!==undefined && extraarr.length>0){
                        angular.forEach(va.children,function(couval,coukey){
                            var dupindex = va.children.indexOf(couval);
                            var mainobj = _.findWhere(va.children, {id: couval.main_id});
                            if(mainobj!==undefined && mainobj.selected!==undefined && mainobj.selected!==null && mainobj.selected!=='' && mainobj.selected){
                                ivhTreeviewMgr.select($scope.countryRegionArr, $scope.countryRegionArr[ke].children[dupindex]);
                            }
                        });
                    }

                    angular.forEach(va.children, function (childval, childkey) {
                        if (childval.selected) {
                            this.push({ id: childval.country_id, name: childval.label });
                        }
                    }, $scope.selectedCountry);

                }
            });
        };

        $scope.deselectCountry = function (back) {
            ivhTreeviewMgr.deselect($scope.countryRegionArr, $scope.countryRegionArr[0]);
            back();
        };

        $scope.getBusinessModel();
        $scope.getLanguageList();
        $scope.getCountryRegionArr();
    }
]);

