'use strict';
App.factory('signupService', ['$http', '$q', function ($http, $q) {
    var signupServiceFactory = {};
    /**
    * @description
    * # user type detail
    */
    var _getUserTypes = function (language) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            url: 'api/general/get_usertypes',
            method: "GET",
            data: { language: language },
            ignoreLoadingBar: true
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (msg, code) {
                deferred.reject(msg);
                console.log(msg, code);
            });
        return deferred.promise;
    };
    /**
    * @description
    * # create new user
    */
    var _createUser = function (formdata) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            url: 'api/signup/register_user',
            method: "POST",
            data: formdata,
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (msg) {
                deferred.reject(msg);
                console.log(msg);
            });
        return deferred.promise;
    };
    /**
    * @description
    * # invite user signup
    */
    var _signupInviteUser = function (userData) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            url: 'api/user_profile/get_invited_user_details',
            method: "POST",
            data: userData,
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (msg) {
                deferred.reject(msg);
                console.log(msg);
            });
        return deferred.promise;
    };
    signupServiceFactory.getUserTypes = _getUserTypes;
    signupServiceFactory.createUser = _createUser;
    signupServiceFactory.signupInviteUser = _signupInviteUser;
    return signupServiceFactory;
}]);