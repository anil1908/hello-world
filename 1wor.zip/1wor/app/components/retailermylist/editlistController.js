'use strict';
angular.module('OneWorld').controller('editlistController', ['$scope', '$rootScope', 'listService', '$uibModal', '$location', '$sessionStorage', 'localStorageService','$filter',
    function ($scope, $rootScope, listService, $uibModal, $location, $sessionStorage, localStorageService,$filter) {
        var parameter = $location.search();
        var TokenData = localStorageService.get('authorizeTokenDetail');
        if (parameter.id != '' && parameter.id != undefined) {
            $scope.bookidArr = [];
            $scope.selectBookArr = [];
            $scope.booksList = [];
            $scope.state = false;
            $scope.totalBooks = 0;
            $scope.isEditSubmitted = false;
            $scope.bookListOption = {
                pagestart: 0,
                pagelimit: 10,
                book_title: '',
                author_name: '',
                book_publisher: ''
            };
            $scope.toggleState = function () {
                $scope.state = !$scope.state;
            };
            //Back redirection
            $scope.goBack = function () {
                $location.path('/retailermylist');
            };
            //Get Books Listing
            $scope.getListDetails = function () {
                var data = $scope.bookListOption;
                data.access_token = TokenData.access_token;
                data.language = $rootScope.language;
                data.list_id = parameter.id;
                $scope.bookDetailList(data, false);
            };
            //Pagination
            $scope.PagingList = function () {
                $scope.bookListOption.pagestart += 10;
                var data = $scope.bookListOption;
                data.access_token = TokenData.access_token;
                data.language = $rootScope.language;
                data.list_id = parameter.id;
                data.lazyLoading = true;
                $scope.bookDetailList(data, true);
            };
            //Clear filter
            $scope.cancelSearch = function () {
                if($scope.bookidArr.length>0 || $scope.bookListOption.book_title!==''
                    || $scope.bookListOption.author_name!=='' || $scope.bookListOption.book_publisher!==''){
                    $scope.bookidArr = [];
                    $scope.bookListOption = {
                        pagestart: 0,
                        pagelimit: 10,
                        book_title: '',
                        author_name: '',
                        book_publisher: ''
                    };
                    var data = $scope.bookListOption;
                    data.access_token = TokenData.access_token;
                    data.language = $rootScope.language;
                    data.list_id = parameter.id;
                    $scope.bookDetailList(data, false);
                }
            };
            //Search Books
            $scope.searchBooks = function () {
                $scope.bookListOption.pagestart = 0;
                $scope.bookListOption.pagelimit = 10;
                var data = $scope.bookListOption;
                data.access_token = TokenData.access_token;
                data.language = $rootScope.language;
                data.list_id = parameter.id;
                $scope.bookDetailList(data, false);
            };
            //Call service to get list and books data
            $scope.bookDetailList = function (data, isLoad) {
                listService.getListBooks(data)
                        .then(function (data) {
                            if (data.error <= 0) {
                                if(data.response.books.length > 0){
                                    var listarr = [];
                                    angular.forEach(data.response.books,function(bookval,bookkey){
                                        angular.forEach(bookval,function(bval,bkey){
                                            listarr.push(bval);
                                        });
                                    });
                                    data.response.books = listarr;
                                }
                                if (isLoad && data.response.books.length > 0) {
                                    angular.forEach(data.response.books, function (value, key) {
                                        $scope.booksList.books.push(value);
                                    });
                                }
                                if (!isLoad) {
                                    $scope.booksList = data.response;
                                }
                                $scope.totalBookLength = data.total_rows;

                                var listadd = localStorageService.get('list_add');
                                if(listadd!==undefined && listadd!==null && listadd!==''){
                                    $scope.isError = false;
                                    $scope.isMessage = true;
                                    $scope.message = $filter('translate')('LIST_ADD_SUCCESS');
                                    localStorageService.set('list_add','');
                                }
                                else{
                                    $scope.isError = false;
                                    $scope.isMessage = false;
                                    $scope.message = '';
                                }

                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                if (data.error == 3) {
                                    $location.search({});
                                    $location.path('/retailermylist');
                                    $rootScope.listsmessage = data.errorMsg;
                                    $rootScope.listsisError = true;
                                    $rootScope.listsisMessage = false;
                                }
                                else{
                                    $scope.isError = true;
                                    $scope.isMessage = false;
                                    $scope.message = data.errorMsg;
                                }
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = '';
                        });
            }
        }


        //Delete Selected Books from lists
        $scope.deleteSelected = function () {
            var bookIdArray = [];
            var bundleIdArray = [];
            angular.forEach($scope.bookidArr, function (value, key) {
                var isAva = _.where($scope.selectBookArr, {book_id: value.book_id});
                var isBundleAva = _.where($scope.selectBookArr, {bundle_id: value.bundle_id});
                if (value.book_id!==undefined && isAva.length <= 0) {
                    bookIdArray.push(value.book_id);
                }
                if (value.bundle_id!==undefined && isBundleAva.length <= 0) {
                    bundleIdArray.push(value.bundle_id);
                }
            });

            if (bookIdArray.length > 0 || bundleIdArray.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('CATALOG_REMOVE_CONFIRMATION_LABEL')};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.deleteListBookArr(bookIdArray,bundleIdArray);
                }, function () {
                    console.log('Closed');
                });
            }  else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL')};
                        }
                    }
                });
                modalInstance.result.then(function () {

                }, function () {
                    console.log('error');
                });
            }
        };

        $scope.deleteListBookArr = function (bookIdArr,bundleIdArray) {
            var listbookData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                list_bookArr: bookIdArr,
                list_bundleArr : bundleIdArray,
                list_id: parameter.id
            };
            listService.deleteListBooks(listbookData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.selectBookArr = [];
                            $scope.bookidArr = [];
                            $scope.bookListOption.pagestart = 0;
                            $scope.bookListOption.pagelimit = 10;
                            $scope.getListDetails();
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = '';
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.updateList = function () {
            if ($scope.editList.$valid) {
                var listData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    list_name: $scope.booksList.lists.name,
                    list_id: parameter.id
                };
                listService.editListDetail(listData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $location.search({});
                                $location.path('/retailermylist');
                                $rootScope.listsmessage = data.msg;
                                $rootScope.listsisError = false;
                                $rootScope.listsisMessage = true;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.message = '';
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            } else {
                $scope.isEditSubmitted = true;
            }
        };

        $scope.getListDetails();
}]);
angular.module('OneWorld').controller('listBookDeleteCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'deleteData', 'localStorageService',
    function ($scope, $rootScope, $uibModalInstance, deleteData, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.ModalTitle = 'Confirmation';
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
}]);