'use strict';
App.factory('listService', ['$http', '$q', function ($http, $q) {
        var listServiceFactory = {};
        /**
         * @description
         * # list data
         */
        var _getMyListData = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_list/get_my_lists',
                method: "POST",
                data: data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # create list
         */
        var _createMyList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_list/create_my_lists',
                method: "POST",
                data: data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };


        var _getMyList = function (listsData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_list/get_my_lists_list',
                method: "POST",
                data: listsData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _deleteList = function (listData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_list/delete_list',
                method: "POST",
                data: listData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _getListBooks = function (data) {
            data.loadTop = false;
            var deferred = $q.defer();
            $http({
                headers: {
                    'Content-Type': 'application/json'},
                url: 'api/my_list/lists_details',
                method: "POST",
                data: data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        /**
         * @description
         * # delete list book
         */
        var _deleteListBooks = function (listData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_list/delete_lists_books',
                method: "POST",
                data: listData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        /**
         * @description
         * # edit group
         */
        var _editListDetail = function (listData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_list/update_lists_name',
                method: "POST",
                data: listData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        /**
         * @description
         * # List row
         */
        var _getListRow = function (listData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/my_list/get_list_name_by_id',
                method: "POST",
                data: listData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        }

        listServiceFactory.getMyListData = _getMyListData;
        listServiceFactory.createMyList = _createMyList;
        listServiceFactory.getMyList = _getMyList;
        listServiceFactory.deleteList = _deleteList;
        listServiceFactory.getListBooks = _getListBooks;
        listServiceFactory.deleteListBooks = _deleteListBooks;
        listServiceFactory.editListDetail = _editListDetail;
        listServiceFactory.getListRow = _getListRow;
        return listServiceFactory;
    }]);