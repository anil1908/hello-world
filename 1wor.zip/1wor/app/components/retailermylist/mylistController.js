'use strict';
angular.module('OneWorld').controller('mylistController', ['$scope', '$rootScope', 'listService', '$uibModal', '$location', '$sessionStorage', 'localStorageService','$filter',
    function ($scope, $rootScope, listService, $uibModal, $location, $sessionStorage, localStorageService,$filter) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.myList = [];
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'created_on',
            sorttype: 'DESC',
            maxsize: 10
        };
        $scope.state = false;
        $scope.selectedList = [];
        $scope.myListData = {listArr: [], allchecked: false};
        $scope.showDeleteConfirmationModal = false;
        $scope.pageIds = [];
        $scope.showButtonBar = false;
        $scope.format = 'MM/dd/yyyy';
        $scope.dateOptions = {
            dateDisabled: false,
            formatYear: 'yy',
            maxDate: new Date(2020, 5, 22),
            minDate: null,
            startingDay: 1,
            showWeeks: false,
        };
        $scope.showbuttonbar = false;
        $scope.popup1 = {opened: false};
        $scope.popup2 = {opened: false};
        $scope.isError = ($rootScope.listsisError !== undefined) ? $rootScope.listsisError : false;
        $scope.isMessage = ($rootScope.listsisMessage !== undefined) ? $rootScope.listsisMessage : false;
        $scope.message = ($rootScope.listsmessage !== undefined) ? $rootScope.listsmessage : '';
        /**
         * @description
         * move to Dashboard page
        */
        $scope.goBack = function () {
            $location.path('retailerdashboard');
        };
        $scope.getLists = function () {
            var listsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getListsData(listsData);
        };

        $scope.getListsData = function (listsData) {
            listsData.dataLoader = true;
            listService.getMyList(listsData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.pageIds = data.ids.split(',');
                            $scope.myListData.allchecked = false;
                            $scope.myList = data.response;
                            $scope.gridOption.filteredItems = data.total_rows;
                            $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                            if ($scope.gridOption.maxsize > 5) {
                                $scope.gridOption.maxsize = 5;
                            }

                            $rootScope.listsmessage = '';
                            $rootScope.listsisError = false;
                            $rootScope.listsisMessage = false;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.listSearch = function () {
            var listsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_created_by: $scope.search_created_by
            };
            $scope.getListsData(listsData);
        };

        $scope.cancelSearch = function () {
            $scope.search_name = '';
            $scope.search_created_by = '';
            $scope.myListData = {listArr: [], allchecked: false};
            var listsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_created_by: $scope.search_created_by
            };
            $scope.getListsData(listsData);
        };

        $scope.$watch('currentPage', function (pageNo) {
            var listsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_created_by: $scope.search_created_by
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getListsData(listsData);
            //or any other code here
        });

        /*
        * @description
        Grid Option*/
        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var listsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_created_by: $scope.search_created_by
            };
            $scope.getListsData(listsData);
        };

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var listsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_created_by: $scope.search_created_by
            };
            $scope.getListsData(listsData);
            var pagesizeelm = angular.element( document.querySelectorAll( '#pagesize' ) );
            angular.forEach(pagesizeelm,function(val,key){
                pagesizeelm[key].blur();
            });
        };


        $scope.toggleState = function () {
            $scope.state = !$scope.state;
        };

        $scope.checkAll = function () {
            if ($scope.myListData.allchecked) {
                _.each($scope.myList, function (element) {
                    var isavl = true;
                    _.each($scope.myListData.listArr, function (obj) {
                        if (obj.id === element.id) {
                            isavl = false;
                        }
                    });
                    if (isavl) {
                        $scope.myListData.listArr.push(element);
                    }
                });
            } else {
                var arr = [];
                angular.forEach($scope.myListData.listArr, function (element) {
                    if ($scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.myListData.listArr = arr;
            }
        };

        $scope.uncheckMain = function () {
            $scope.myListData.allchecked = false;
        };


        $scope.addSelectedList = function () {
            if ($scope.myListData.listArr.length > 0) {
                angular.forEach($scope.myListData.listArr, function (element) {

                    var idCheck = _.find($scope.selectedList, function (value) {
                        return value.id == element.id;
                    });
                    if (idCheck === undefined) {
                        $scope.selectedList.push(element.id);
                    }
                });
                $scope.state = true;
            }
        };

        /*
        * @description
        Delete List */
        $scope.deleteSelectedList = function () {
            if ($scope.myListData.listArr.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/retailermylist/retailerListDelete.html',
                    controller: 'listDeleteCtrl',
                    resolve: {
                        ListData: function () {
                            return {listArr: $scope.myListData.listArr};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.deleteListArr(dataObj);
                }, function () {
                    console.log('error');
                });
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {ModalTitle: $filter('translate')('WARNING_LABEL'), msg: $filter('translate')('CATALOG_SELECT_ONE_LABEL')};
                        }
                    }
                });
                modalInstance.result.then(function () {

                }, function () {
                    console.log('cancle');
                });
            }
        };

        $scope.deleteListRow = function (listObj) {
            var arr = [];
            arr.push({id: listObj.id});
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function () {
                        return {ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('CATALOG_REMOVE_CONFIRMATION_LABEL')};
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                var dataObj = {listArr: arr};
                $scope.deleteListArr(dataObj);
            }, function () {
                console.log('error');
            });
        };

        $scope.deleteListArr = function (dataObj) {
            var listIdArr = [];
            angular.forEach(dataObj.listArr, function (value, key) {
                listIdArr.push(value.id);
            });
            var listData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                listArr: listIdArr
            };
            listService.deleteList(listData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.myListData.listArr = [];
                            $scope.getLists();
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        /*
        * @description
        End Delete List */
}]);

angular.module('OneWorld').controller('listDeleteCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'ListData', 'localStorageService',
    function ($scope, $rootScope, $uibModalInstance, ListData, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.ModalTitle = 'Confirmation';
        $scope.listDelete = function () {
            $uibModalInstance.close({listArr: ListData.listArr});
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.rowDelete = function () {
            $uibModalInstance.close({listArr: ListData.listObj});
        };
}]);