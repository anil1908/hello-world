'use strict';
angular.module('OneWorld').controller('usertypeController', ['$scope', '$rootScope', '$uibModal', '$location', 'usertypeService', '$sessionStorage', 'localStorageService', '$filter',
    function($scope, $rootScope, $uibModal, $location, usertypeService, $sessionStorage, localStorageService, $filter) {
        var authTokenData = localStorageService.get('authorizeTokenDetail');
        $scope.usertype = parseInt(authTokenData.usertype);
        var userData = cookies.get('authorizationData');
        $rootScope.userData = userData;

        /**
         * @description
         * Check User Type And Redirect
         */

        $scope.userLogins = function(usertype) {
            usertypeService.getUserLogins({
                    language: $rootScope.language,
                    usertype_id: parseInt(usertype),
                    access_token: authTokenData.access_token
                })
                .then(function(data) {
                        if (data.error <= 0) {
                            var userTypeData = cookies.get('authorizationData'); //localStorageService.get('authorizationData');$sessionStorage.authorizationData;
                            userTypeData.logins = data.logins;
                            cookies.get('authorizationData', userTypeData);
                            $scope.usertype = usertype;
                            authTokenData.usertype = usertype;
                            authTokenData.logins = data.logins;
                            authTokenData.module_rights = data.module_rights;
                            localStorageService.set('authorizeTokenDetail', authTokenData);
                            $sessionStorage.contentDisplay = {
                                signinMenu: false,
                                signupMenu: false,
                                userAccount: true,
                                menuTab: true,
                                purchaseTab: false,
                                usertype: authTokenData.usertype
                            };
                            $rootScope.contentDisplay = $sessionStorage.contentDisplay;
                            if (data.logins > 1 || authTokenData.invited_by > 0) {
                                if (usertype == 1)
                                    $location.path('/dashboard');
                                else
                                    $location.path('/retailerdashboard');
                            }
                        } else {
                            $scope.isError = true;
                            $scope.message = data.errorMsg;
                        }
                    },
                    function(err, status) {});
        };

        /**
         * Set up Later
         */
        $scope.setupLater = function() {
            var data = {
                access_token: authTokenData.access_token,
                language: $rootScope.language,
                businessmodel_id: ['1', '3'],
                country_id: ["1"],
                language_id: ["123"],
                main_country_id: "1",
                markup: 30
            };
            usertypeService.addpreferenceDetail(data)
                .then(function(data) {
                        $scope.message = data.msg;
                        $scope.isError = false;
                        $scope.isMessage = true;
                        $location.path('/retailercatalog');
                    },
                    function(err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    })
                .catch(function(err) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * choose APi
         */
        $scope.chooseApi = function() {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function() {
                        return { ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('API_COMING_SOON') };
                    }
                }
            });
            modalInstance.result.then(function(dataObj) {


            }, function() {
                console.log('error');
            });
        };

    }
]);