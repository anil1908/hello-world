/**
* @description
* # user type check
*/
'use strict';
App.factory('usertypeService', ['$http', '$q', 'localStorageService',
    function ($http, $q, localStorageService) {
        var usertypeServiceFactory = {};
        var _getUserLogins = function (userDetail) {
            var deferred = $q.defer();
            $http({
                headers: { 'Content-Type': 'application/json' },
                url: 'api/users/get_users_logins',
                method: "POST",
                data: userDetail
            })
                .success(function (response) {
                    deferred.resolve(response);
                }).error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        /**
         * add Preference
         */
        var _addpreferenceDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: { 'Content-Type': 'application/json' },
                url: 'api/preference/update_retailer_preference',
                method: "POST",
                data: data,
            })
                .success(function (data) {
                    deferred.resolve(data);
                })
                .error(function (err, code) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        usertypeServiceFactory.getUserLogins = _getUserLogins;
        usertypeServiceFactory.addpreferenceDetail = _addpreferenceDetail;
        return usertypeServiceFactory;
    }]);