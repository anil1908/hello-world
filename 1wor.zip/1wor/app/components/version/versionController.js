'use strict';
angular.module('OneWorld').controller('versionController', ['$scope', '$rootScope', '$uibModal', 'versionService', '$location', '$sessionStorage', 'localStorageService', '$filter',
    function ($scope, $rootScope, $uibModal, versionService, $location, $sessionStorage, localStorageService, $filter) {
        $rootScope.logo = 'home-logo.png';
        $scope.versionData = [];
        $scope.revisionFiles = [];
        $scope.lastVersion = false;
        $scope.created_on = '';
        $scope.updated_on = '';
        $scope.getVersionDetail = function () {
            versionService.getVersionDetail()
                .then(function (data) {
                    if (data.error <= 0) {
                        angular.forEach(data.response.version,function(val,key){
                           if(val.indexOf("version")>=0){
                               val = val.replace(/=/g," ");
                               val = '<label class="bold">'+val+'</label>'
                           }
                           else{
                                val = '<label class="simple">'+val+'</label>'
                           }
                           if(val!==''){
                            this.push(val);
                           }
                        },$scope.versionData);
                        $scope.lastVersion = (data.response.last_db_revision==data.response.last_dir_revision)?true:false;
                        $scope.revisionFiles = data.response.revision_files;
                        $scope.created_on = data.response.created_on;
                        $scope.updated_on = data.response.updated_on;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        $scope.getVersionDetail();

    }]);