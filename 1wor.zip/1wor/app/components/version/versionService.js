'use strict';
App.factory('versionService', ['$http', '$q', function ($http, $q) {
    var versionServiceFactory = {};

    /**
     * @description
     * # purchase authenticate email
    */
    var _getVersionDetail = function (data) {
        var deferred = $q.defer();
        $http({
            headers: { 'Content-Type': 'application/json' },
            url: 'api/version',
            method: "POST",
            data: data
        })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
        return deferred.promise;
    };


    versionServiceFactory.getVersionDetail = _getVersionDetail;
    return versionServiceFactory;
}]);