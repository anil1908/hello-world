'use strict';
angular.module('OneWorld').controller('publisherpreferenceController', ['$scope', '$rootScope', '$uibModal', 'publisherpreferenceService', '$location', '$sessionStorage', 'localStorageService', '$filter',
    function ($scope, $rootScope, $uibModal, publisherpreferenceService, $location, $sessionStorage, localStorageService, $filter) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.whiteListRetailer = [];
        $scope.blackListRetailer = [];
        $scope.retailerList = [];
        $scope.retailerArr = [];
        $scope.preference_detail = {
            trust_level: 1,
            old_trust_level: 1,
            group_type: '',
            whitelist_retailer_name: '',
            blcaklist_retailer_name: '',
            preference_id: ''
        };
        $scope.currencyList = [];
        $scope.preview_settings = {};
        $scope.whiteRetailerError = '';
        $scope.blackRetailerError = '';
        $scope.trustLevelId = '';
        $scope.isSubmitted = false;
        $scope.isMessage = false;
        $scope.isError = false;
        $scope.previewPercentageList = [5, 10, 15, 20, 25, 30, 35, 40, 45, 50];
        /**
         * @description
         * move to Dashboard page
        */
        $scope.goBack = function () {
            $location.path('dashboard');
        };
        /**
         * change Retailer Type
         */
        $scope.changeRetailerType = function () {
            $scope.preference_detail.whitelist_retailer_name = '';
            $scope.preference_detail.blcaklist_retailer_name = '';

            var length = 0;
            if ($scope.preference_detail.group_type == 1) {
                length = $scope.blackListRetailer.length;
            }
            if ($scope.preference_detail.group_type == 2) {
                length = $scope.whiteListRetailer.length;
            }
            if (length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {
                                ModalTitle: $filter('translate')('CONFIRMATION_LABEL'),
                                msg: $filter('translate')('REMOVE_OTHER_RETAILER')
                            };
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    var data = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language
                    };
                    $scope.whiteRetailerError = '';
                    $scope.blackRetailerError = '';
                    publisherpreferenceService.deletePublisherPreference(data)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.getRetaileTrustList();
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        })
                        .catch(function (error) {

                        });
                }, function () {
                    document.getElementById('blcaklist_retailer_name').blur();
                    document.getElementById('whitelist_retailer_name').blur();
                    $scope.preference_detail.group_type = '';
                });
            }
        };
        /**
         * add whitelist retailer
         */
        $scope.addWhiteListRetailer = function () {
            if ($scope.trustLevelId == $scope.preference_detail.trust_level || $scope.blackListRetailer.length <= 0) {
                $scope.addWhiteRetailer();
            }
            else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return { ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('REMOVE_OTHER_LEVEL_RETAILER') };
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.addWhiteRetailer();
                }, function () {
                    console.log('error');
                });
            }
        };

        $scope.addWhiteRetailer = function () {
            $scope.blackRetailerError = '';
            var retailerData = _.findWhere($scope.retailerArr, { name: $scope.preference_detail.whitelist_retailer_name });
            if ($scope.preference_detail.whitelist_retailer_name !== null && $scope.preference_detail.whitelist_retailer_name !== undefined && $scope.preference_detail.whitelist_retailer_name !== '') {
                if (retailerData !== undefined && retailerData !== null && retailerData !== '') {
                    $scope.whiteRetailerError = '';
                    var data = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language,
                        trust_level: $scope.preference_detail.trust_level,
                        retailers_list: $scope.preference_detail.group_type,
                        retailer_id: retailerData.id,
                        preference_id: $scope.preference_detail.preference_id,
                        group_type: $scope.preference_detail.group_type
                    };
                    publisherpreferenceService.addRetailer(data)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.preference_detail.whitelist_retailer_name = '';
                                $scope.preference_detail.blcaklist_retailer_name = '';
                                $scope.getRetaileTrustList();
                                $scope.getRetailer();
                                $scope.updateWhilteListRetailer();
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        })
                        .catch(function (error) {

                        });
                }
                else {
                    $scope.whiteRetailerError = $filter('translate')('VALID_RETAILER_NAME_REQUIRED');
                }
            }
            else {
                if ($scope.preference_detail.group_type !== undefined && $scope.preference_detail.group_type !== null && $scope.preference_detail.group_type !== '') {
                    $scope.whiteRetailerError = $filter('translate')('RETAILER_NAME_REQUIRED');
                }
            }
        };
        /**
         * add blacklist retailer
         */
        $scope.addBlackListRetailer = function () {
            if ($scope.trustLevelId == $scope.preference_detail.trust_level || $scope.whiteListRetailer.length <= 0) {
                $scope.addBlackRetaile();
            }
            else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return { ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('REMOVE_OTHER_LEVEL_RETAILER') };
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.addBlackRetaile();
                }, function () {
                    console.log('error');
                });
            }
        };

        $scope.addBlackRetaile = function () {
            $scope.whiteRetailerError = '';
            var retailerData = _.findWhere($scope.retailerArr, { name: $scope.preference_detail.blcaklist_retailer_name });
            if ($scope.preference_detail.blcaklist_retailer_name !== null && $scope.preference_detail.blcaklist_retailer_name !== undefined && $scope.preference_detail.blcaklist_retailer_name !== '') {
                if (retailerData !== undefined && retailerData !== null && retailerData !== '') {
                    $scope.blackRetailerError = '';
                    var data = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language,
                        trust_level: $scope.preference_detail.trust_level,
                        retailers_list: $scope.preference_detail.group_type,
                        retailer_id: retailerData.id,
                        preference_id: $scope.preference_detail.preference_id,
                        group_type: $scope.preference_detail.group_type
                    };
                    publisherpreferenceService.addRetailer(data)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.preference_detail.whitelist_retailer_name = '';
                                $scope.preference_detail.blcaklist_retailer_name = '';
                                $scope.getRetaileTrustList();
                                $scope.getRetailer();
                                $scope.updateBlackListRetailer();
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        })
                        .catch(function (error) {

                        });
                }
                else {
                    $scope.blackRetailerError = $filter('translate')('VALID_RETAILER_NAME_REQUIRED');
                }
            }
            else {
                if ($scope.preference_detail.group_type !== undefined && $scope.preference_detail.group_type !== null && $scope.preference_detail.group_type !== '') {
                    $scope.blackRetailerError = $filter('translate')('RETAILER_NAME_REQUIRED');
                }
            }
        };

        /**
         * Delete Retailer
         */
        $scope.deleteRetailer = function (rid, preference_id) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function () {
                        return { ModalTitle: $filter('translate')('CONFIRMATION_LABEL'), msg: $filter('translate')('REMOVE_RETAILER') };
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                $scope.whiteRetailerError = '';
                $scope.blackRetailerError = '';
                var is_last = true;
                if ($scope.whiteListRetailer.length > 1) {
                    var is_last = false;
                }
                if ($scope.blackListRetailer.length > 1) {
                    var is_last = false;
                }

                var data = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    prp_id: rid,
                    preference_id: preference_id,
                    is_last: is_last
                };
                publisherpreferenceService.deleteRetailerPreference(data)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.getRetaileTrustList();
                            $scope.getRetailer();
                            $scope.updateWhilteListRetailer();
                            $scope.updateBlackListRetailer();
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    })
                    .catch(function (error) {

                    });
            }, function () {
                console.log('error');
            });
        };
        /**
         * get Retailer List
         */
        $scope.getRetailer = function () {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                trust_level: $scope.preference_detail.trust_level,
                preference_id: $scope.preference_detail.preference_id
            };
            // if($scope.preference_detail.trust_level==3){
            //     data.trust_level = '1,2,3';
            // }
            // if($scope.preference_detail.trust_level==2){
            //     data.trust_level = '1,2';
            // }
            // if($scope.preference_detail.trust_level==1){
            //     data.trust_level = $scope.preference_detail.trust_level;
            // }
            publisherpreferenceService.getRetailerList(data)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.preference_detail.preference_id = data.preference_id
                        $scope.retailerArr = data.response;
                        $scope.retailerList = _.pluck(data.response, 'name');
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                })
                .catch(function (error) {

                });


        };
        /**
         * get Retailer trust list
         */
        $scope.getRetaileTrustList = function () {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            publisherpreferenceService.getRetailerTrustList(data)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.trustLevelId = data.trust_level;
                        $scope.preference_detail.trust_level = data.trust_level;
                        $scope.preference_detail.old_trust_level = data.trust_level;
                        $scope.preference_detail.group_type = ($scope.preference_detail.group_type == undefined || $scope.preference_detail.group_type == null || $scope.preference_detail.group_type == '') ? data.group_type : $scope.preference_detail.group_type;
                        $scope.preference_detail.preference_id = data.preference_id;
                        $scope.whiteListRetailer = data.Whitelist;
                        $scope.blackListRetailer = data.Blacklist;
                        $scope.preview_settings.currency_preference = data.currency_preference;
                        $scope.preview_settings.sellwithdrm = (data.sellwithdrm!==undefined && data.sellwithdrm!==null && data.sellwithdrm!=='')?data.sellwithdrm:false;
                        $scope.preview_settings.oldsellwithdrm = (data.sellwithdrm!==undefined && data.sellwithdrm!==null && data.sellwithdrm!=='')?data.sellwithdrm:false;
                        $scope.preview_settings.preview_percentage = parseInt(data.preview_percentage);
                        $scope.preview_settings.allow_preview = (data.allow_preview == 1) ? true : false;
                        $scope.getRetailer();
                    } else {
                        $scope.preview_settings = {
                            currency_preference: '',
                            preview_percentage: 15,
                            sellwithdrm: true,
                            oldsellwithdrm: true,
                            allow_preview: 1
                        };
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * update White list retaile
        */
        $scope.updateWhilteListRetailer = function () {
            var autocom = new autoComplete({
                selector: '#whitelist_retailer_name',
                source: function (term, suggest) {
                    term = term.toLowerCase();
                    var choices = $scope.publisherList;
                    var suggestions = [];
                    for (i = 0; i < choices.length; i++)
                        if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                    suggest(suggestions);
                },
                onSelect: function (e, term, item) {
                    // old and new value check
                    if ($scope.preference_detail.whitelist_retailer_name && $scope.preference_detail.whitelist_retailer_name !== term) {
                        $scope.$apply(function () {
                            $scope.preference_detail.whitelist_retailer_name = term;
                        });
                    }
                }
            });
        };
        /**
         * update black list retaile
        */
        $scope.updateBlackListRetailer = function () {
            var autocom = new autoComplete({
                selector: '#blcaklist_retailer_name',
                source: function (term, suggest) {
                    term = term.toLowerCase();
                    var choices = $scope.publisherList;
                    var suggestions = [];
                    for (i = 0; i < choices.length; i++)
                        if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                    suggest(suggestions);
                },
                onSelect: function (e, term, item) {
                    // old and new value check
                    if ($scope.preference_detail.blcaklist_retailer_name && $scope.preference_detail.blcaklist_retailer_name !== term) {
                        $scope.$apply(function () {
                            $scope.preference_detail.blcaklist_retailer_name = term;
                        });
                    }
                }
            });
        };
        /**
         * select Radio
         */
        $scope.selectRadio = function (type) {
            if ($scope.preference_detail.group_type !== type) {
                $scope.preference_detail.group_type = type;
                $scope.changeRetailerType();
            }
            else {
                $scope.preference_detail.group_type = type;
            }
        };
        /**
         * get Currency Data
        */
        $scope.getCurrencyList = function () {
            var currencyData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            publisherpreferenceService.getCurrencyList(currencyData)
                .then(function (data) {
                    $scope.currencyList = data.response;
                })
                .catch(function () {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.addPreviewSettings = function () {
            if ($scope.previewsettings.$valid) {
                if ($scope.preview_settings.oldsellwithdrm == $scope.preview_settings.sellwithdrm) {
                    $scope.savePreviewSettings();
                }
                else {
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                        controller: 'deleteConfirmationCtrl',
                        resolve: {
                            deleteData: function () {
                                return {
                                    ModalTitle: $filter('translate')('CONFIRMATION_LABEL'),
                                    msg: $filter('translate')('GLOABLLY_CHANGE_DRM_SETTING')
                                };
                            }
                        }
                    });
                    modalInstance.result.then(function (dataObj) {
                        $scope.savePreviewSettings();
                    }, function () {
                        $scope.preview_settings.sellwithdrm  = $scope.preview_settings.oldsellwithdrm;
                    });
                }
            }
            else {
                $scope.isSubmitted = true;
            }
        };

        $scope.savePreviewSettings = function(){
            $scope.preview_settings.preview_percentage = ($scope.preview_settings.allow_preview) ? parseInt($scope.preview_settings.preview_percentage) : 15;
            var previewData = $scope.preview_settings;
            previewData.access_token = TokenData.access_token;
            previewData.language = $rootScope.language;
            publisherpreferenceService.addPreviewSettings(previewData)
                .then(function (data) {
                    $scope.message = data.msg;
                    $scope.isError = false;
                    $scope.isMessage = true;
                    //$scope.getRetaileTrustList();
                    $scope.preview_settings.oldsellwithdrm  = $scope.preview_settings.sellwithdrm;
                })
                .catch(function () {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        }

        $scope.changeTrustLevel = function () {
            var whiteListLength = $scope.whiteListRetailer.length;
            var blackListLength = $scope.blackListRetailer.length;
            console.log($scope.preference_detail)
            if (blackListLength > 0 || whiteListLength > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/components/common/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {
                                ModalTitle: $filter('translate')('CONFIRMATION_LABEL'),
                                msg: $filter('translate')('REMOVE_OTHER_RETAILER')
                            };
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    var data = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language
                    };
                    publisherpreferenceService.deletePublisherPreference(data)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.getRetailer();
                                $scope.trustLevelId = $scope.preference_detail.trust_level;
                                $scope.preference_detail.trust_level = $scope.preference_detail.trust_level;
                                $scope.preference_detail.old_trust_level = $scope.preference_detail.trust_level;
                                $scope.whiteListRetailer = [];
                                $scope.blackListRetailer = [];
                                //$scope.changeTru();
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                        })
                        .catch(function (error) {

                        });
                }, function () {
                    $scope.preference_detail.trust_level = $scope.preference_detail.old_trust_level;
                });
            }
            else {
                $scope.getRetailer();
            }
            // $scope.getRetailer();
        };

        $scope.changeTru = function () {
            var data = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            publisherpreferenceService.getRetailerTrustList(data)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.trustLevelId = data.trust_level;
                        $scope.preference_detail.trust_level = data.trust_level;
                        $scope.preference_detail.old_trust_level = data.trust_level;
                        $scope.preference_detail.group_type = ($scope.preference_detail.group_type == undefined || $scope.preference_detail.group_type == null || $scope.preference_detail.group_type == '') ? data.group_type : $scope.preference_detail.group_type;
                        $scope.preference_detail.preference_id = data.preference_id;
                        $scope.whiteListRetailer = data.Whitelist;
                        $scope.blackListRetailer = data.Blacklist;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.getRetaileTrustList();
        $scope.getCurrencyList();


    }]);