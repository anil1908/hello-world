'use strict';
App.factory('publisherpreferenceService', ['$http', '$q', function ($http, $q) {
        var publisherpreferenceServiceFactory = {};
        /**
         * @description
         * delete retailer List
         */
        var _deletePublisherPreference = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/preference/delete_publisher_retailer_preference',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * @description
         * retailer List
         */
        var _getRetailerList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/preference/get_retailers_list',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * @description
         * Add Whitelist Retailer
         */
        var _addRetailer = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/preference/insert_publisher_retailer_preference',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * @description
         * Retailer trust list
         */
        var _getRetailerTrustList = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/preference/get_publisher_retailer_preference_list',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * @description
         * Delete Retailer Preference
         */
        var _deleteRetailerPreference = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/preference/delete_publisher_retailer_preference_by_id',
                method: "POST",
                data: data,
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };
        /**
         * @description
         * # currency  list
         */
        var _getCurrencyList = function (currecyData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_currency',
                method: "GET",
                data: currecyData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        /**
         * @description
         * # add preview setting
         */
        var _addPreviewSettings = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/preference/add_publisher_preference',
                method: "POST",
                data: data
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        publisherpreferenceServiceFactory.deletePublisherPreference = _deletePublisherPreference;
        publisherpreferenceServiceFactory.getRetailerList = _getRetailerList;
        publisherpreferenceServiceFactory.addRetailer = _addRetailer;
        publisherpreferenceServiceFactory.getRetailerTrustList = _getRetailerTrustList;
        publisherpreferenceServiceFactory.deleteRetailerPreference = _deleteRetailerPreference;
        publisherpreferenceServiceFactory.getCurrencyList = _getCurrencyList;
        publisherpreferenceServiceFactory.addPreviewSettings = _addPreviewSettings;
        return publisherpreferenceServiceFactory;
    }]);