'use strict';
App.factory('businessmodelService', ['$http', '$q', function ($http, $q) {
        var businessmodelServiceFactory = {};

        var _getBusinessModelCategoryList = function (categoryData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/business_model/get_business_model_category',
                method: "POST",
                data: categoryData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _getBusinessModelByCategoryList = function (categorymodelData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/business_model/get_business_model_category_list_by_id',
                method: "POST",
                data: categorymodelData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _setFavouriteModel = function (favData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/business_model/insert_business_model_category_list_to_favourite',
                method: "POST",
                data: favData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _removeFavouriteModel = function (favData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/business_model/delete_business_model_category_list_from_favourite',
                method: "POST",
                data: favData
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _getModelDetail = function (modelData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/business_model/get_model_associative_details_by_id',
                method: "POST",
                data: modelData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _getBusinessModelList = function (modelData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/business_model/get_business_model_list',
                method: "POST",
                data: modelData,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _addpreferenceDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/preference/update_retailer_preference',
                method: "POST",
                data: data,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        var _getPreferenceDetail = function (data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/preference/get_retailer_preference',
                method: "POST",
                data: data,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        /**
         * @description
         * # currency  list
         */
        var _getCurrencyList = function (currecyData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_currency',
                method: "GET",
                data: currecyData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        businessmodelServiceFactory.getBusinessModelCategoryList = _getBusinessModelCategoryList;
        businessmodelServiceFactory.getBusinessModelByCategoryList = _getBusinessModelByCategoryList;
        businessmodelServiceFactory.setFavouriteModel = _setFavouriteModel;
        businessmodelServiceFactory.removeFavouriteModel = _removeFavouriteModel;
        businessmodelServiceFactory.getModelDetail = _getModelDetail;
        businessmodelServiceFactory.getBusinessModelList = _getBusinessModelList;
        businessmodelServiceFactory.addpreferenceDetail = _addpreferenceDetail;
        businessmodelServiceFactory.getPreferenceDetail = _getPreferenceDetail;
        businessmodelServiceFactory.getCurrencyList = _getCurrencyList;
        return businessmodelServiceFactory;
    }]);