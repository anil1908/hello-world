'use strict';
angular.module('OneWorld').controller('retailerbusinessmodelController', ['$scope', '$rootScope', 'businessmodelService', '$uibModal', '$location', '$sessionStorage', 'localStorageService',
    function ($scope, $rootScope, businessmodelService, $uibModal, $location, $sessionStorage, localStorageService) {


    }]);