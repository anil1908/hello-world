'use strict';
angular.module('OneWorld').controller('businessmodelsController', ['$scope', '$rootScope', 'businessmodelService', '$uibModal', '$location', '$sessionStorage', 'localStorageService',
    function ($scope, $rootScope, businessmodelService, $uibModal, $location, $sessionStorage, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.categoryList = [];
        $scope.modelList = [];
        $scope.selectedIndex = 0;
        $scope.categoryid = 1;
        $scope.model_id = 0;
        $scope.gridOption = {
            filteredItems: 0,
            sortField: 'model_id',
            sorttype: 'ASC',
        };
        /**
         * @description
         * move to Dashboard page
        */
        $scope.goBack = function(){
            $location.path('dashboard');
        };
        /**
         * @description
         * move to Retailer Dashboard page
        */
        $scope.goBackRetailer = function () {
            $location.path('retailerdashboard');
        };
        $scope.getCategory = function () {
            var categoryData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                categoryid: $scope.categoryid
            };
            $scope.getCategoryData(categoryData);
        };

        $scope.getCategoryData = function (categoryData) {
            businessmodelService.getBusinessModelCategoryList(categoryData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.categoryList = data.response.category;
                            $scope.modelList = data.response.category[0].list;
                            $scope.isError = false;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.getModelByCategory = function () {
            var categorymodelData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                categoryid: $scope.categoryid
            };
            $scope.getCategoryModelData(categorymodelData);
        };

        $scope.getCategoryModelData = function (categorymodelData) {
            businessmodelService.getBusinessModelByCategoryList(categorymodelData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.modelList = data.response;
                            $scope.isError = false;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.sort_by = function (sortField, categoryid) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            $scope.categoryid = categoryid;
            $scope.getModelByCategory();
        };

        $scope.tabChange = function (index, categoryid) {
            $scope.selectedIndex = index;
            $scope.gridOption.sortField = 'id';
            $scope.gridOption.sorttype = 'ASC';
            $scope.categoryid = categoryid;
            $scope.getModelByCategory($scope.categoryid);
        };

        $scope.addtoFav = function (model_id, category_id) {
            var favData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                business_model_id: model_id
            };
            $scope.setFavModel(favData);
            $scope.categoryid = category_id;

        };

        $scope.setFavModel = function (favData) {
            businessmodelService.setFavouriteModel(favData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.isError = false;
                            $scope.getModelByCategory();
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.removeFav = function (model_id, category_id) {
            var favData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                business_model_id: model_id
            };
            $scope.removeFavModel(favData);
            $scope.categoryid = category_id;

        };

        $scope.removeFavModel = function (favData) {
            businessmodelService.removeFavouriteModel(favData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.isError = false;
                            $scope.getModelByCategory();
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        /*
         * @description
         * Business Model Details*/
        $scope.businessModelDetailsModal = function (modelid, modelname, modeldesc) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/components/businessmodels/businessmodelsDetail.html',
                controller: 'viewModelDetailCtrl',
                resolve: {
                    modelData: function () {
                        return {modelid: modelid, modelname: modelname, modeldesc: modeldesc};
                    }
                }
            });
            modalInstance.result.then(function () {

            }, function () {
                //console.log('error');
            });

        };

        $scope.getCategory();
    }]);

angular.module('OneWorld').controller('viewModelDetailCtrl', ['$scope', '$rootScope', 'businessmodelService', '$uibModalInstance', 'localStorageService', 'modelData',
    function ($scope, $rootScope, businessmodelService, $uibModalInstance, localStorageService, modelData) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        var modelLibData = {access_token: TokenData.access_token,
            language: $rootScope.language,
            modelid: modelData.modelid
        };
        businessmodelService.getModelDetail(modelLibData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.modelData = modelData;
                        $scope.modelDetailData = data.response;
                    } else {
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                        $scope.$parent.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.$parent.isError = true;
                    $scope.$parent.isMessage = false;
                });
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);