'use strict';
angular.module('OneWorld').controller('widgetCodeCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'localStorageService', 'userRightsService', 'widgetData','BASE_URL',
    function ($scope, $rootScope, $uibModalInstance, localStorageService, userRightsService, widgetData,BASE_URL) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        /**
        * @description
         * widgetCode Config
         */
        $scope.widgetData = widgetData;
        $scope.widgetCode =
                            '<div ng-app="widget">'+
                                '<div ng-controller="widgetCtrl">'+
                                    '<widget-detail widget="'+BASE_URL+'"></widget-detail>'+
                                '</div>'+
                            '</div>'+
                    '<link rel="stylesheet" type="text/css" href="'+BASE_URL+'/assets/css/widgets.css">'+
                    '<script type="text/javascript" src="'+BASE_URL+'/widget/book_widget.js"></script>'+
                    '<script charset="utf-8" type="text/javascript">'+
                        'init_widget('+$scope.widgetData.widget_id+');'+
                    '</script>';

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.copyCode = function(){
            $uibModalInstance.close({});
        }
        $scope.copyfail = function(err) {
            console.log(err);
        }
}]);