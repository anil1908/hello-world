 /**
 * @description
 * # module rights check
 */
'use strict';
App.factory('userRightsService', ['$http', '$q', 'localStorageService',
    function ($http, $q, localStorageService) {
        var userrightsServiceFactory = {};
        var _checkUserRights = function (moduleId) {
            var authorize = false;
            var TokenData = localStorageService.get('authorizeTokenDetail');
            if (TokenData !== null && (parseInt(TokenData.invited_by) === 0 || (TokenData.module_rights!==undefined && TokenData.module_rights.indexOf(parseInt(moduleId)) >= 0)) ) {
                authorize = true;
            }
            return authorize;
        };
        userrightsServiceFactory.checkUserRights = _checkUserRights;
        return userrightsServiceFactory;
    }]);