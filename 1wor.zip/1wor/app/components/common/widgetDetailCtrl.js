'use strict';
angular.module('OneWorld').controller('widgetDetailCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'localStorageService', 'userRightsService', 'widgetData','widgetsService','BASE_URL',
    function ($scope, $rootScope, $uibModalInstance, localStorageService, userRightsService, widgetData,widgetsService,BASE_URL) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        /**
        * @description
         * widgetCode Config
         */
        $scope.widgetData = widgetData;
        $scope.bookArr     = [];
        $scope.bookPriceArr     = [];
        $scope.gridOption ={
            pageStart : 0,
            pageLimit : 10
        }
        $scope.books = [];
        /**
        * @description
        *  Widget Detail
        */
        $scope.getWidgetDetailData = function(widgetData){
            widgetsService.getWidgetDetail(widgetData)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.widgetData = data.response.widgets;
                        $scope.widgetData.widgetiamge = data.widgetiamge;
                        if ($scope.widgetData.color == '#ffffff') {
                            $scope.widgetData.colortype = 'white';
                        }
                        else if ($scope.widgetData.color == '#000000') {
                            $scope.widgetData.colortype = 'black';
                        }
                        else{
                            $scope.widgetData.colortype = 'custom';
                        }
                        if(data.response.book.length>0){

                             angular.forEach(data.response.book,function(val,key) {
                                this.push(val);
                            }, $scope.books);
                            angular.forEach(data.response.book,function(bookval,bookkey){
                                var business_arr    = [];
                                var price_arr       = [];
                                var businessArrStatus = {};
                                if(bookval.business_model!==undefined &&  bookval.business_model.length>0){
                                    angular.forEach(bookval.business_model,function(businessvalue,businesskey){
                                        businessArrStatus[businessvalue.id] = businessvalue.is_visible;
                                        this.push(businessvalue);
                                    },business_arr);
                                }
                                if(bookval.price!==undefined && !_.isEmpty(bookval.price)){
                                    angular.forEach(bookval.price,function(priceval,pricekey){
                                        var isvisible =  ((bookval.bundle_id!==undefined && bookval.bundle_id!==null && bookval.bundle_id!=='') || (bookval.book_id!==undefined && bookval.book_id!==null && bookval.book_id!==''))?businessArrStatus[priceval.business_model_id]:true;
                                        $scope.books[bookkey+widgetData.pageStart]['price'][pricekey]['is_visible'] = isvisible;
                                        price_arr.push(priceval);
                                    });
                                }
                                if(bookval.book_id!==undefined && bookval.book_id!==null && bookval.book_id!==''){
                                    $scope.bookArr[bookval.book_id] = business_arr;
                                    $scope.bookPriceArr[bookval.book_id] = price_arr;
                                }
                                else{
                                    $scope.bookArr[bookval.bundle_id] = business_arr;
                                    $scope.bookPriceArr[bookval.bundle_id] = price_arr;
                                }


                            });
                        }
                    } else {
                        $scope.message = data.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        if($scope.widgetData.widget_id!==undefined && $scope.widgetData.widget_id!==null && $scope.widgetData.widget_id!==''){
            var widgetData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                widget_id: $scope.widgetData.widget_id,
                pageStart : $scope.gridOption.pageStart,
                pageLimit : $scope.gridOption.pageLimit
            };
            $scope.getWidgetDetailData(widgetData);
        }
        /**
        * @description
        *  Widget paging request
        */
        $scope.pagingList = function(){
            $scope.gridOption.pageStart = ($scope.gridOption.pageStart+$scope.gridOption.pageLimit);
            var widgetData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                widget_id: $scope.widgetData.widget_id,
                pageStart : $scope.gridOption.pageStart,
                pageLimit : $scope.gridOption.pageLimit
            };
            $scope.getWidgetDetailData(widgetData);
        };

        $scope.widgetCode =     '<div ng-app="widget">'+
                                    '<div ng-controller="widgetCtrl">'+
                                        '<widget-detail widget="'+BASE_URL+'"></widget-detail>'+
                                    '</div>'+
                                '</div>'+
                    '<link rel="stylesheet" type="text/css" href="'+BASE_URL+'/assets/css/widgets.css">'+
                    '<script type="text/javascript" src="'+BASE_URL+'/widget/book_widget.js"></script>'+
                    '<script charset="utf-8" type="text/javascript">'+
                        'init_widget('+$scope.widgetData.widget_id+');'+
                    '</script>';

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        /**
        * @description
        *  copy widget code
        */
        $scope.copyCode = function(){
            $uibModalInstance.close({});
        }
        $scope.copyfail = function(err) {
            console.log(err);
        }
}]);