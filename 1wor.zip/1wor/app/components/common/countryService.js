'use strict';
App.factory('countryService', ['$http', '$q', function ($http, $q) {
        var countryServiceFactory = {};
        /**
         * @description
         * # country list
         */
        var _getCountryList = function (countryData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_country',
                method: "POST",
                data: countryData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };

        /**
         * @description
         * # country-region list
         */
        var _getCountryRegionList = function (Data) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/catalog/get_region_with_country',
                method: "POST",
                data: Data
            })
            .success(function (data) {
                deferred.resolve(data);
            })
            .error(function (err, code) {
                deferred.reject(err);
            });
            return deferred.promise;
        };

        countryServiceFactory.getCountryList = _getCountryList;
        countryServiceFactory.getCountryRegionList = _getCountryRegionList;
        return countryServiceFactory;
    }]);