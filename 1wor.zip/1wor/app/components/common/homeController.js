angular.module('OneWorld').controller('homeController', ['$scope', '$rootScope', 'userRightsService', '$sessionStorage', '$translate', 'authService', '$location', 'localStorageService', 'Idle', 'SESSION_TIMEOUT', '$filter', '$sce', '$uibModal',
    function ($scope, $rootScope, userRightsService, $sessionStorage, $translate, authService, $location, localStorageService, Idle, SESSION_TIMEOUT, $filter, $sce, $uibModal) {
        /*
        * @description
        Login And Signup Menu display*/
        var authTokenData = localStorageService.get('authorizeTokenDetail');
        $scope.usertype = (authTokenData !== null) ? parseInt(authTokenData.usertype) : '';
        var userData = cookies.get('authorizationData');
        $rootScope.userData = userData;
        $scope.currentYear = new Date().getFullYear();
        if (userData != null && userData != undefined && userData.email !== '') {
            $rootScope.logo = 'main-logo.jpg';
        } else {
            $rootScope.logo = 'home-logo.png';
        }
        $scope.showMenu = function (viewLocation) {
            var active = (viewLocation === $location.path());
            return active;
        };
        $scope.goHome = function () {
            $location.path('/');
        }
        $scope.logOut = function () {
            authService.logOut()
                .then(function (data) {
                    if (data.error <= 0) {
                        $location.search({});
                        $rootScope.message = '';
                        $location.path('/');
                    } else {
                        $scope.isError = true;
                        $scope.message = data.errorMsg;
                    }
                },
                function (err, status) {
                });
        };
        $scope.checkRights = function (moduleId) {
            return userRightsService.checkUserRights(moduleId);
        };
        $scope.movePage = function (pageName) {
            $location.path(pageName);
        };
        /**
         * get Report Html
         */
        $scope.getReport = function () {
            authService.getReportHtml()
                .then(function (data) {                       
                    if (data.error <= 0) {                        
                        var modalInstance = $uibModal.open({
                            animation: true,
                            templateUrl: 'app/components/common/reports.html',
                            controller: 'reportsCtrl',
                            resolve: {
                                reportData: function () {
                                    return { location: data.location };
                                }
                            }
                        });
                        modalInstance.result.then(function (dataObj) {

                        }, function () {
                            console.log('cancle');
                        });
                    } else {

                    }
                }, function (err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };
        /**
         * Close Ifrmae
         */
        $scope.closeIframe = function () {
            $scope.location = '';
        };
        /*End Login And Signup Menu display*/
        /**
         * session Timeout
         */
        $rootScope.idle = SESSION_TIMEOUT;
        $rootScope.timeout = 5;
        $rootScope.$on('IdleTimeout', function () {
            if ($rootScope.error_no != 2) {
                authService.logOut()
                    .then(function (data) {
                        if (data.error <= 0) {
                            localStorageService.set('sessionTimeoutError', 2);
                            window.location = 'login';
                        } else {
                            $scope.isError = true;
                            $scope.message = data.errorMsg;
                        }
                    },
                    function (err, status) {
                    });
            }
            else {
                document.title = $filter('translate')('PAGE_TITLE') + ' - ' + $filter('translate')('HOME_HEADER_TITLE');
                window.location = 'login';
            }
        });

        $rootScope.$watch('idle', function (value) {
            if (value !== null) Idle.setIdle(value);
        });

        $rootScope.$watch('timeout', function (value) {
            if (value !== null) Idle.setTimeout(value);
        });

        /**
         * End session Timeout
         */
    }
]);

angular.module('OneWorld').controller('reportsCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'localStorageService', 'authService','reportData', '$sce',
    function ($scope, $rootScope, $uibModalInstance, localStorageService, authService,reportData, $sce) {
        $scope.location = $sce.trustAsResourceUrl(reportData.location);
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);