angular.module('OneWorld').controller('bundleDetailCtrl', ['$scope', '$rootScope', 'catalogService', '$uibModalInstance', 'localStorageService', 'userRightsService', 'bundleData',
    function ($scope, $rootScope, catalogService, $uibModalInstance, localStorageService, userRightsService, bundleData) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.bundleData = bundleData.bundleDataObj;
        $scope.bundleDetailData = [];
        $scope.isPriceUpdate = true;
        $scope.wholesalemodel = [3, 9];

        angular.forEach($scope.bundleData.bussinessArr,function(bval,bkey){
            if($scope.wholesalemodel.indexOf(parseInt(bval.id))>=0 && !bval.is_visible){
                $scope.isPriceUpdate = false;
            }
        });

        /**
         * @description
         * retailer bundle books detail
         */
        $scope.getBundleDetail = function(){
            var bodata = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                bundle_id: $scope.bundleData.bundle_id
            };
            catalogService.getRetailerBundleDetail(bodata)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.bundleDetailData = data.response;
                        } else {
                            $scope.$parent.isError = true;
                            $scope.$parent.isMessage = false;
                            $scope.$parent.message = data.errorMsg;
                        }
                    })
                    .catch(function(err){
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
            });
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

        $scope.ok = function(){
             $uibModalInstance.close();
        };

        /**
         * @description
         * reset price
        */
        $scope.resetSellingPrice = function(parentindex,index,priceobj){
            var orignalprice = parseFloat($scope.bundleData.bookpriceArr[parentindex].price[index]['original_digital_list']);
            var sellingprice = ((orignalprice * parseFloat($scope.bundleData.default_markup))/100)+orignalprice;
            sellingprice = sellingprice.toFixed(2);
            $scope.bundleData.bookpriceArr[parentindex].price[index]['selling_price'] = parseFloat(sellingprice);
        };
        /**
         * @description
         * invisible business model
         */
        $scope.invisibleModel = function(business){
            if(business.id==9){
                $scope.isPriceUpdate = false;
            }
            var index = $scope.bundleData.bussinessArr.indexOf(business);
            $scope.bundleData.bussinessArr[index]['is_visible'] = false;
        };
        /**
         * @description
         * visible business model
         */
        $scope.visibleModel = function(business){
            if(business.id==9){
                $scope.isPriceUpdate = true;
            }
            var index = $scope.bundleData.bussinessArr.indexOf(business);
            $scope.bundleData.bussinessArr[index]['is_visible'] = true;
        };
        /**
         * @description
         * cancel Widget
         */
        $scope.changeWidgetDone = function(){
            if($scope.widgetsalesbundle.$valid){
                $uibModalInstance.close({bundleData: $scope.bundleData,saveWidget:true,isPriceUpdate:$scope.isPriceUpdate,validWidget:$scope.widgetsalesbundle.$valid});
            }
        };
        $scope.cancelWidget = function(){
             $uibModalInstance.close({bundleData: $scope.bundleData,saveWidget:false,isPriceUpdate:$scope.isPriceUpdate,validWidget:$scope.widgetsalesbundle.$valid});
        }

        $scope.getBundleDetail();
}]);