/*
 * @description
 *  App Confirmation Modal*/
angular.module('OneWorld').controller('businessinstructionCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'businessData', 'localStorageService', 'businessmodelService',
    function($scope, $rootScope, $uibModalInstance, businessData, localStorageService, businessmodelService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.categoryList = [];
        $scope.modelList = [];
        $scope.categoryid = 1;
        $scope.isbusinessload = false;
        $scope.model_id = 0;
        $scope.selectedIndex = 0;
        $scope.gridOption = {
            filteredItems: 0,
            sortField: 'model_id',
            sorttype: 'ASC',
        };

        $scope.tabChange = function(index, categoryid) {
            $scope.selectedIndex = index;
            $scope.gridOption.sortField = 'id';
            $scope.gridOption.sorttype = 'ASC';
            $scope.categoryid = categoryid;
            var categorymodelData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                categoryid: $scope.categoryid
            };
            $scope.getCategoryModelData(categorymodelData);
        };

        $scope.getCategoryModelData = function(categorymodelData) {
            businessmodelService.getBusinessModelByCategoryList(categorymodelData)
                .then(function(data) {
                    if (data.error <= 0) {
                        $scope.modelList = data.response;
                        $scope.isError = false;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };


        $scope.getCategoryData = function() {
            var categoryData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                categoryid: $scope.categoryid
            };

            businessmodelService.getBusinessModelCategoryList(categoryData)
                .then(function(data) {
                    $scope.isbusinessload = true;
                    if (data.error <= 0) {
                        $scope.categoryList = data.response.category;
                        $scope.modelList = data.response.category[0].list;
                        $scope.isError = false;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                }, function(err, status) {
                    $scope.isbusinessload = true;
                    $scope.isError = true;
                    $scope.isMessage = false;
                });
        };

        $scope.ok = function() {
            $uibModalInstance.close();
        }
        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.getCategoryData();
    }
]);