angular.module('OneWorld').controller('bookDetailCtrl', ['$scope', '$rootScope', 'catalogService', '$uibModalInstance', 'localStorageService', 'userRightsService', 'bookData',
    function ($scope, $rootScope, catalogService, $uibModalInstance, localStorageService, userRightsService, bookData) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.isPriceUpdate = true;
        $scope.wholesalemodel = [3, 9];
        $scope.visibleTab = {
            'sale' : true,
            'subscription' : false,
            'book' : false
        };
        $scope.bookData = bookData;
        $scope.channelData = [];
        $scope.groupData = [];
        /**
         * @description
         * retailer book detail data
         */
        if (bookData.type == 'retailer') {
            var bodata = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                catalog_id: bookData.bookId
            };
            catalogService.getRetailerBooksDetail(bodata)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.bookDetailData = data.response;
                            if(data.response.catalog.age_range!==undefined && data.response.catalog.age_range!==null && data.response.catalog.age_range!==''){
                                var ageRangeArr = data.response.catalog.age_range.split('-');
                                if(ageRangeArr!==undefined && ageRangeArr[0]<=0 && ageRangeArr[1]<=0){
                                    $scope.bookDetailData.catalog.age_range = '';
                                }
                            }
                            else{
                                $scope.bookDetailData.catalog.age_range = '';
                            }

                            if(data.response.catalog.us_grade_range!==undefined && data.response.catalog.us_grade_range!==null && data.response.catalog.us_grade_range!==''){

                                var usgradeRangeArr = data.response.catalog.us_grade_range.split('-');
                                if(usgradeRangeArr!==undefined && usgradeRangeArr[0]<=0 && usgradeRangeArr[1]<=0){
                                    $scope.bookDetailData.catalog.us_grade_range = '';
                                }
                            }
                            else{
                                $scope.bookDetailData.catalog.us_grade_range = '';
                            }

                            if (data.response.catalog.contributor.length > 0) {
                                var str = '';
                                _.each(data.response.catalog.contributor, function (contributorArr) {
                                    str += contributorArr.contributorname + ' - ' + contributorArr.contributorrolename + '<br>';
                                })
                                $scope.bookDetailData.catalog.contributor_role = str.slice(0, -2);
                            }
                            ;
                            if (data.response.catalog.subject_id.length > 0) {
                                var str = '';
                                _.each(data.response.catalog.subject_id, function (subArr) {
                                    str += subArr.name + ', ';
                                })
                                $scope.bookDetailData.catalog.subject = str.slice(0, -2);
                            }
                            ;
                            if (data.response.catalog.identifier.length > 0) {
                                var str = '';
                                _.each(data.response.catalog.identifier, function (identifierArr) {
                                     str += identifierArr.identifiertypename + ' - ' + identifierArr.identifiername + '<br>';
                                })
                                $scope.bookDetailData.catalog.identifier = str.slice(0, -2);
                            }
                            else{
                                $scope.bookDetailData.catalog.identifier = '';
                            }
                            if (data.response.catalog.country_id.length > 0) {
                                var str = '';
                                _.each(data.response.catalog.country_id, function (countryArr) {
                                    var arr = countryArr.split('_');
                                    str += ((arr[1] !== undefined) ? arr[1] : '') + ', ';
                                })
                                $scope.bookDetailData.catalog.country_id = str.slice(0, -2);
                            } else {
                                $scope.bookDetailData.catalog.country_id = '';
                            }


                            if (data.response.catalog.region_name.length > 0) {
                                var str = '';
                                _.each(data.response.catalog.region_name, function (regionArr) {
                                    str += ((regionArr !== undefined) ? regionArr : '') + ', ';
                                })
                                $scope.bookDetailData.catalog.region_name = str.slice(0, -2);
                            } else {
                                $scope.bookDetailData.catalog.region_name = '';
                            }

                           // $scope.bookDetailData.catalog.region_name = data.response.catalog.region_name.toString();
                        } else {
                            $scope.$parent.isError = true;
                            $scope.$parent.isMessage = false;
                            $scope.$parent.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                    });
        }
        /**
         * @description
         * retailer book detail data
         */
        else if(bookData.type == 'widget'){
            var bodata = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                catalog_id: bookData.bookDetail.book_id
            };
            $scope.form = {};
            $scope.bookDetailObj = bookData.bookDetail;
            angular.forEach($scope.bookDetailObj.bussinessArr,function(bval,bkey){
                if($scope.wholesalemodel.indexOf(parseInt(bval.id))>=0 && !bval.is_visible){
                    $scope.isPriceUpdate = false;
                }
            });

            catalogService.getRetailerBooksDetail(bodata)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.bookDetailData = data.response;
                            if(data.response.catalog.age_range!==undefined && data.response.catalog.age_range!==null && data.response.catalog.age_range!==''){
                                var ageRangeArr = data.response.catalog.age_range.split('-');
                                if(ageRangeArr!==undefined && ageRangeArr[0]<=0 && ageRangeArr[1]<=0){
                                    $scope.bookDetailData.catalog.age_range = '';
                                }
                            }
                            else{
                                $scope.bookDetailData.catalog.age_range = '';
                            }

                            if(data.response.catalog.us_grade_range!==undefined && data.response.catalog.us_grade_range!==null && data.response.catalog.us_grade_range!==''){

                                var usgradeRangeArr = data.response.catalog.us_grade_range.split('-');
                                if(usgradeRangeArr!==undefined && usgradeRangeArr[0]<=0 && usgradeRangeArr[1]<=0){
                                    $scope.bookDetailData.catalog.us_grade_range = '';
                                }
                            }
                            else{
                                $scope.bookDetailData.catalog.us_grade_range = '';
                            }

                            if (data.response.catalog.contributor.length > 0) {
                                var str = '';
                                _.each(data.response.catalog.contributor, function (contributorArr) {
                                    str += contributorArr.contributorname + ' - ' + contributorArr.contributorrolename + '<br>';
                                })
                                $scope.bookDetailData.catalog.contributor_role = str.slice(0, -2);
                            }
                            ;
                            if (data.response.catalog.subject_id.length > 0) {
                                var str = '';
                                _.each(data.response.catalog.subject_id, function (subArr) {
                                    str += subArr.name + ', ';
                                })
                                $scope.bookDetailData.catalog.subject = str.slice(0, -2);
                            }
                            ;
                            if (data.response.catalog.identifier.length > 0) {
                                var str = '';
                                _.each(data.response.catalog.identifier, function (identifierArr) {
                                     str += identifierArr.identifiertypename + ' - ' + identifierArr.identifiername + '<br>';
                                })
                                $scope.bookDetailData.catalog.identifier = str.slice(0, -2);
                            }
                            else{
                                $scope.bookDetailData.catalog.identifier = '';
                            }
                            if (data.response.catalog.country_id.length > 0) {
                                var str = '';
                                _.each(data.response.catalog.country_id, function (countryArr) {
                                    var arr = countryArr.split('_');
                                    str += ((arr[1] !== undefined) ? arr[1] : '') + ', ';
                                })
                                $scope.bookDetailData.catalog.country_id = str.slice(0, -2);
                            } else {
                                $scope.bookDetailData.catalog.country_id = '';
                            }


                            if (data.response.catalog.region_name.length > 0) {
                                var str = '';
                                _.each(data.response.catalog.region_name, function (regionArr) {
                                    str += ((regionArr !== undefined) ? regionArr : '') + ', ';
                                })
                                $scope.bookDetailData.catalog.region_name = str.slice(0, -2);
                            } else {
                                $scope.bookDetailData.catalog.region_name = '';
                            }
                        } else {
                            $scope.$parent.isError = true;
                            $scope.$parent.isMessage = false;
                            $scope.$parent.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                    });
        }
        /**
         * @description
         * publisher book detail data
         */
        else {
            var bodata = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                catalog_id: bookData.bookId
            };
            catalogService.getBooksDetail(bodata)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.bookDetailData = data.response;
                        if(data.response.catalog.age_range!==undefined && data.response.catalog.age_range!==null && data.response.catalog.age_range!==''){
                            var ageRangeArr = data.response.catalog.age_range.split('-');
                            if(ageRangeArr!==undefined && ageRangeArr[0]<=0 && ageRangeArr[1]<=0){
                                $scope.bookDetailData.catalog.age_range = '';
                            }
                        }
                        else{
                            $scope.bookDetailData.catalog.age_range = '';
                        }

                        if(data.response.catalog.us_grade_range!==undefined && data.response.catalog.us_grade_range!==null && data.response.catalog.us_grade_range!==''){

                            var usgradeRangeArr = data.response.catalog.us_grade_range.split('-');
                            if(usgradeRangeArr!==undefined && usgradeRangeArr[0]<=0 && usgradeRangeArr[1]<=0){
                                $scope.bookDetailData.catalog.us_grade_range = '';
                            }
                        }
                        else{
                            $scope.bookDetailData.catalog.us_grade_range = '';
                        }

                        if (data.response.catalog.contributor.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.contributor, function (contributorArr) {
                                str += contributorArr.contributorname + ' - ' + contributorArr.contributorrolename + '<br>';
                            })
                            $scope.bookDetailData.catalog.contributor_role = str.slice(0, -2);
                        }
                        ;

                        if (data.response.catalog.subject_id.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.subject_id, function (subArr) {
                                str += subArr.name + ', ';
                            })
                            $scope.bookDetailData.catalog.subject = str.slice(0, -2);
                        }

                        if (data.response.catalog.identifier.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.identifier, function (identifierArr) {
                                str += identifierArr.identifiertypename + ' - ' + identifierArr.identifiername + '<br>';
                            })
                            $scope.bookDetailData.catalog.identifier = str.slice(0, -2);
                        }
                        else{
                            $scope.bookDetailData.catalog.identifier = '';
                        }
                        if (data.response.catalog.country_id.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.country_id, function (countryArr) {
                                var arr = countryArr.split('_');
                                str += ((arr[1] !== undefined) ? arr[1] : '') + ', ';
                            })
                            $scope.bookDetailData.catalog.country_id = str.slice(0, -2);
                        } else {
                            $scope.bookDetailData.catalog.country_id = '';
                        }

                        if (data.response.catalog.priceArr.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.priceArr, function (prices) {
                                str += prices.symbol + ' ' + prices.price + ' ('+prices.code+')' + ', ';
                            })
                            $scope.bookDetailData.catalog.price = str.slice(0, -2);
                        };

                        if (data.response.catalog.region_name.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.region_name, function (regionArr) {
                                str += ((regionArr !== undefined) ? regionArr : '') + ', ';
                            })
                            $scope.bookDetailData.catalog.region_name = str.slice(0, -2);
                        } else {
                            $scope.bookDetailData.catalog.region_name = '';
                        }
                    } else {
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                        $scope.$parent.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.$parent.isError = true;
                    $scope.$parent.isMessage = false;
            });

            var catalogData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                catalog_id : bookData.bookId
            };
            catalogService.getCatalogAssociatedDetails(catalogData)
                .then(function (data) {
                    $scope.channelData = (data.response.channel_data!==undefined && data.response.channel_data!==null && data.response.channel_data!=='')?data.response.channel_data:[];
                    $scope.groupData = (data.response.group_data!==undefined && data.response.group_data!==null && data.response.group_data!=='')?data.response.group_data:[];
                }, function (err) {

                });
        }

        /**
         * visible tab
         */
        $scope.visibleTab = function(tabname){
            $scope.visibleTab = {
                'sale' : false,
                'subscription' : false,
                'book' : false
            };
            $scope.visibleTab[tabname] = true;
        };
        /**
         * @description
         * Edit Book
         */
        $scope.editBook = function () {
            $uibModalInstance.close({id: $scope.bookDetailData.catalog.id});
        };
        /**
         * @description
         * invisible business model
         */
        $scope.invisibleModel = function(business){
            if(business.id==3){
                $scope.isPriceUpdate = false;
            }
            var index = $scope.bookDetailObj.bussinessArr.indexOf(business);
            $scope.bookDetailObj.bussinessArr[index]['is_visible'] = false;
        };
        /**
         * @description
         * visible business model
         */
        $scope.visibleModel = function(business){
            if(business.id==3){
                $scope.isPriceUpdate = true;
            }
            var index = $scope.bookDetailObj.bussinessArr.indexOf(business);
            $scope.bookDetailObj.bussinessArr[index]['is_visible'] = true;
        };
        /**
         * @description
         * reset price
        */
        $scope.resetSellingPrice = function(parentindex,index,priceobj){
            var orignalprice = parseFloat($scope.bookDetailObj.bookpriceArr[parentindex].price[index]['original_digital_list']);
            var sellingprice = ((orignalprice * parseFloat($scope.bookDetailObj.default_markup))/100)+orignalprice;
            sellingprice = sellingprice.toFixed(2);
            $scope.bookDetailObj.bookpriceArr[parentindex].price[index]['selling_price'] = parseFloat(sellingprice);
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        /**
         * @description
         *check Rights
        */
        $scope.checkModifyRights = function (moduleid) {
            return userRightsService.checkUserRights(moduleid);
        };

        $scope.changeWidgetDone = function(){
            if($scope.widgetsalesbundle.$valid){
                $uibModalInstance.close({bookObj: $scope.bookDetailObj,saveWidget:true,isPriceUpdate:$scope.isPriceUpdate,validWidget:$scope.widgetsalesbundle.$valid});
            }
        };

        $scope.cancelWidget = function(){
             $uibModalInstance.close({bookObj: $scope.bookDetailObj,saveWidget:false,isPriceUpdate:$scope.isPriceUpdate,validWidget:$scope.widgetsalesbundle.$valid});
        };
        /**
         * Tab Change
         */
        $scope.catalogtabChange = function(tabid){
            var removeEl = angular.element( document.querySelectorAll( '.tab-pane' ) );
            removeEl.removeClass('in active');
            var addEl = angular.element( document.querySelector( '#'+tabid ) );
            addEl.addClass('in active');
        };

    }]);
