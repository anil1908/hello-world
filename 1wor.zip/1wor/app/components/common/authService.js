'use strict';
App.factory('authService', ['$http', '$q', '$rootScope', '$sessionStorage', 'localStorageService',
    function($http, $q, $rootScope, $sessionStorage, localStorageService) {
        var serviceBase = 'http://180.211.99.238:8092/1world/';
        var authServiceFactory = {};
        var _authentication = {
            isAuth: false,
            email: ""
        };
        var userDetail = {
            logins: "",
            first_name: "",
            last_name: ""
        };
        var loginDetail = {
            keepsignin: false,
            access_token: ''
        };
        var _saveRegistration = function(registration) {
            _logOut();
            return $http.post(serviceBase + 'api/account/register', registration).then(function(response) {
                return response;
            });
        };
        /**
         * @description
         * # login request
         */
        var _login = function(loginData) {
            var deferred = $q.defer();
            $http({
                    headers: { 'Content-Type': 'application/json' },
                    url: 'api/users/login',
                    method: "POST",
                    data: loginData
                })
                .success(function(response) {
                    if (response.error <= 0) {
                        userDetail.user_id = response.user_id;
                        userDetail.logins = response.logins;
                        userDetail.first_name = response.first_name;
                        userDetail.last_name = response.last_name;
                        userDetail.email = response.email;
                        userDetail.photo = response.photo;
                        cookies.set('authorizationData', userDetail);
                        _authentication.isAuth = true;
                        _authentication.email = loginData.email;
                        loginDetail.invited_by = response.invited_by;
                        loginDetail.module_rights = response.module_rights;
                        loginDetail.keepsignin = loginData.keepsignin;
                        loginDetail.access_token = response.access_token;
                        loginDetail.usertype = response.usertype;
                        loginDetail.account_no = response.account_no;
                        localStorageService.set('authorizeTokenDetail', loginDetail);
                        $rootScope.logo = 'main-logo.jpg';
                        $rootScope.userData = {
                            first_name: response.first_name,
                            last_name: response.last_name,
                            photo: response.photo
                        };
                        deferred.resolve(response);
                    } else {
                        deferred.resolve(response);
                    }
                }).error(function(err, status) {
                    _logOut();
                    deferred.reject(err);
                });
            return deferred.promise;
        };
        /**
         * @description
         * # logout request
         */
        var _logOut = function() {
            var deferred = $q.defer();
            $http({
                    headers: { 'Content-Type': 'application/json' },
                    url: 'api/users/logout',
                    method: "POST"
                })
                .success(function(response) {
                    $rootScope.logo = 'home-logo.png';
                    cookies.del('authorizationData');
                    localStorageService.remove('authorizeTokenDetail');
                    _authentication.isAuth = false;
                    _authentication.email = "";
                    deferred.resolve(response);
                }).error(function(err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var _fillAuthData = function(language) {
            var authData = cookies.get('authorizationData');
            if (authData) {
                _authentication.isAuth = true;
                _authentication.email = authData.email;
            }
        };
        /**
         * @description
         * # check  login
         */
        var _isLoggedIn = function(language, callback) {
            var authenticationObj = {};
            var authTokenData = localStorageService.get('authorizeTokenDetail');
            var authData = cookies.get('authorizationData');

            if (authTokenData !== null && authTokenData !== '' && authTokenData.keepsignin && (authData === null || authData === undefined || authData === '')) {
                var deferred = $q.defer();
                $http({
                        headers: { 'Content-Type': 'application/json' },
                        url: 'api/users/validate_token',
                        method: "POST",
                        data: { language: language, access_token: authTokenData.access_token }
                    })
                    .success(function(response) {
                        if (response.error <= 0) {
                            userDetail.user_id = response.user_id;
                            userDetail.logins = response.logins;
                            userDetail.first_name = response.first_name;
                            userDetail.last_name = response.last_name;
                            userDetail.email = response.email;
                            userDetail.photo = response.photo;
                            $rootScope.userData = userDetail;
                            $rootScope.$watch($rootScope.userData);
                            cookies.set('authorizationData', userDetail);
                            var TokenDetail = localStorageService.get('authorizeTokenDetail');
                            TokenDetail.access_token = response.access_token;
                            TokenDetail.logins = response.logins;
                            TokenDetail.usertype = response.usertype;
                            TokenDetail.module_rights = response.module_rights;
                            TokenDetail.account_no = response.account_no;
                            localStorageService.set('authorizeTokenDetail', TokenDetail);
                            authenticationObj.isAuth = true;
                            authenticationObj.email = response.email;
                            callback(authenticationObj);
                        } else {
                            callback(false);
                        }
                    }).error(function(err, status) {
                        _logOut();
                        callback(false);
                    });
            } else if (authTokenData !== null && authTokenData !== '' && authData !== null && authData !== '' && authData !== undefined) {
                authenticationObj.isAuth = true;
                authenticationObj.email = authData.email;
                callback(authenticationObj);
            } else {
                cookies.del('authorizationData');
                callback(false);
            }
        };
        /**
         * @description
         * # forget password request
         */
        var _forgetPassword = function(forgetData) {
            var deferred = $q.defer();
            $http({
                    headers: { 'Content-Type': 'application/json' },
                    method: 'POST',
                    url: 'api/users/forgot_password',
                    data: forgetData
                })
                .success(function(response) {
                    deferred.resolve(response);
                })
                .error(function(err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };
        /**
         * @description
         * # reset password request
         */
        var _checkResetPassword = function(resetUserData) {
            var deferred = $q.defer();
            $http({
                    headers: { 'Content-Type': 'application/json' },
                    method: 'POST',
                    url: 'api/users/check_reset_password_url',
                    data: resetUserData
                })
                .success(function(response) {
                    localStorageService.set('resetId', resetUserData.user_id);
                    deferred.resolve(response);
                })
                .error(function(err, status) {
                    localStorageService.set('resetId', '');
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var _resetPassword = function(resetData) {
            var deferred = $q.defer();
            resetData.user_id = localStorageService.get('resetId');
            $http({
                    headers: { 'Content-Type': 'application/json' },
                    method: 'POST',
                    url: 'api/users/reset_password',
                    data: resetData
                })
                .success(function(response) {
                    if (response.error <= 0) {
                        localStorageService.set('resetId', '');
                        deferred.resolve(response);
                    } else {
                        deferred.reject(err);
                    }
                })
                .error(function(err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };
        /**
         * @description
         * # user keep login
         */
        var _keepLogin = function() {
            var deferred = $q.defer();
            var signData = localStorageService.get('authorizeTokenDetail');
            if (signData !== null && signData !== '' && signData.keepsignin) {
                $http({
                        headers: { 'Content-Type': 'application/json' },
                        url: 'api/users/validate_token',
                        method: "POST",
                        data: signData
                    })
                    .success(function(response) {
                        if (response.error <= 0) {
                            userDetail.logins = response.user_id;
                            userDetail.logins = response.logins;
                            userDetail.first_name = response.first_name;
                            userDetail.last_name = response.last_name;
                            userDetail.email = response.email;
                            userDetail.photo = response.photo;
                            cookies.set('authorizationData', userDetail);
                            //$sessionStorage.authorizationData = userDetail;
                            //localStorageService.set('authorizationData', userDetail);
                            _authentication.isAuth = true;
                            _authentication.email = loginData.email;

                            loginDetail.invited_by = response.invited_by;
                            loginDetail.module_rights = response.module_rights;
                            loginDetail.keepsignin = true;
                            loginDetail.access_token = response.access_token;
                            loginDetail.usertype = response.usertype;
                            loginDetail.account_no = response.account_no;
                            localStorageService.set('authorizeTokenDetail', loginDetail);
                            deferred.resolve(response);
                        } else {
                            deferred.resolve(response);
                        }
                    }).error(function(err, status) {
                        _logOut();
                        deferred.reject(err);
                    });
                return deferred.promise;
            } else {

            }
        }

        /**
         * @description
         * # user keep login
         */
        var _getReportHtml = function() {
            var deferred = $q.defer();
            $http({
                    headers: { 'Content-Type': 'application/json' },
                    method: 'GET',
                    url: 'api/dashboard/auth_reporttab',
                    cache: false,
                })
                .success(function(response) {
                    deferred.resolve(response);
                })
                .error(function(err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        }


        authServiceFactory.saveRegistration = _saveRegistration;
        authServiceFactory.login = _login;
        authServiceFactory.logOut = _logOut;
        authServiceFactory.fillAuthData = _fillAuthData;
        authServiceFactory.authentication = _authentication;
        authServiceFactory.isLoggedIn = _isLoggedIn;
        authServiceFactory.forgetPassword = _forgetPassword;
        authServiceFactory.checkResetPassword = _checkResetPassword;
        authServiceFactory.resetPassword = _resetPassword;
        authServiceFactory.keepLogin = _keepLogin;
        authServiceFactory.getReportHtml = _getReportHtml;
        return authServiceFactory;
    }
]);