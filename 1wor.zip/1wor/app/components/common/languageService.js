'use strict';
App.factory('languageService', ['$http', '$q', function ($http, $q) {
        var languageServiceFactory = {};
        /**
         * @description
         * # language list
         */
        var _getLanguageList = function (languageData) {
            var deferred = $q.defer();
            $http({
                headers: {'Content-Type': 'application/json'},
                url: 'api/general/get_language_iso1',
                method: "GET",
                data: languageData,
                cache: true,
            })
                    .success(function (data) {
                        deferred.resolve(data);
                    })
                    .error(function (err, code) {
                        deferred.reject(err);
                    });
            return deferred.promise;
        };
        languageServiceFactory.getLanguageList = _getLanguageList;
        return languageServiceFactory;
    }]);