angular.module('OneWorld').controller('resetpasswordchkController', ['$scope', '$rootScope', '$location', 'authService',
    function ($scope, $rootScope, $location, authService) {
        if ($location.search().u != '' && $location.search().u != undefined &&
                $location.search().t != '' && $location.search().t != undefined &&
                $location.search().h != '' && $location.search().h != undefined) {
            var userData = {};
            userData.language = $rootScope.language;
            userData.user_id = $location.search().u;
            userData.time = $location.search().t;
            userData.hash = $location.search().h;
            /*
            * @description
            Check Reset Password Link Is Expire or not*/
            authService.checkResetPassword(userData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $location.$$search = {};
                            $location.path('/resetpassword');
                        } else {
                            $location.$$search = {};
                            $rootScope.errmessage = data.errorMsg;
                            $location.path('/');
                        }
                    },
                            function (err) {
                                $location.path('/');
                            })
        } else {
            $location.path('/');
        }
    }]);

angular.module('OneWorld').controller('resetpasswordController', ['$scope', '$rootScope', '$location', 'authService',
    function ($scope, $rootScope, $location, authService) {
        $scope.resetPasswordData = {password: '', confirmpassword: ''};
        $scope.isSubmitted = false;
        $scope.formname = 'resetpassword';
        /**
        * @description
         * Reset Password Config
         */
        $scope.resetPassword = function () {
            if ($scope.resetpassword.$valid) {
                var resetData = {};
                resetData.language = $rootScope.language;
                resetData.new_password = $scope.resetPasswordData.password;
                authService.resetPassword(resetData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $rootScope.message = data.msg;
                                $location.path('/');
                            } else {
                                $scope.resetPasswordData = {password: '', confirmpassword: ''};
                                $scope.isError = true;
                                $scope.message = data.errorMsg;
                            }
                        },
                                function (err) {
                                    $scope.resetPasswordData = {password: '', confirmpassword: ''};
                                    $scope.isError = true;
                                });
            } else {
                $scope.isSubmitted = true;
            }
        };
        $scope.goBack = function () {
            $location.path('/');
        }
    }]);

