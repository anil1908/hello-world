var App = angular.module('OneWorld', [
        'ui.router',
        'ui.bootstrap',
        'ngAnimate',
        'ngCookies',
        'ngResource',
        'ngSanitize',
        'pascalprecht.translate',
        'tmh.dynamicLocale',
        'remoteValidation',
        'LocalStorageModule',
        'ngStorage',
        'checklist-model',
        'xeditable',
        'ngTagsInput',
        'angular-cache',
        'ui.select2',
        'ivh.treeview',
        'colorpicker.module',
        'wu.masonry',
        'angular-clipboard',
        'angular-toArrayFilter',
        'ngIdle',
        'wysiwyg.module',
        'ngEditor',
        'ui.sortable',
        'oc.lazyLoad',
        'rzModule'
    ])
    .constant('DEBUG_MODE', true)
    .constant('CURRENCY_ARRAY', ['BIF', 'CLP', 'DJF', 'GNF', 'JPY', 'KRW', 'MGA', 'PYG', 'RWF', 'VND', 'VUV', 'XAF', 'XOF', 'XPF'])
    .constant('DATE_FORMAT', 'MM/dd/yyyy')
    .constant('SESSION_TIMEOUT', 1800)
    .constant('COUNTRY_PREFERENCE', (function() {
        return {
            'North America': [
                { country_id: "2", id: "2_duplicate1Canada", main_id: "2_Canada", label: "Canada" },
                { country_id: "1", id: "1_duplicate1United States", main_id: "1_United States", label: "United States" }
            ],
            'Central America': [{ country_id: "33", id: "33_duplicate1Mexico", main_id: "33_Mexico", label: "Mexico" }],
            'South America': [
                { country_id: "43", id: "43_duplicate1Venezuela", main_id: "43_Venezuela", label: "Venezuela" },
                { country_id: "42", id: "42_duplicate1Argentina", main_id: "42_Argentina", label: "Argentina" },
                { country_id: "41", id: "41_duplicate1Brazil", main_id: "41_Brazil", label: "Brazil" }
            ],
            'Europe (EU)': [
                { country_id: "59", id: "59_duplicate1Spain", main_id: "59_Spain", label: "Spain" },
                { country_id: "58", id: "58_duplicate1Italy", main_id: "58_Italy", label: "Italy" },
                { country_id: "57", id: "57_duplicate1France", main_id: "57_France", label: "France" },
                { country_id: "55", id: "55_duplicate1Germany", main_id: "55_Germany", label: "Germany" },
                { country_id: "56", id: "56_duplicate1United Kingdom", main_id: "56_United Kingdom", label: "United Kingdom" }
            ],
            'Europe (Non-EU)': [
                { country_id: "90", id: "90_duplicate1Switzerland", main_id: "90_Switzerland", label: "Switzerland" },
                { country_id: "89", id: "89_duplicate1Russia", main_id: "89_Russia", label: "Russia" }
            ],
            'South Asia': [{ country_id: "180", id: "180_duplicate1India", main_id: "180_India", label: "India" }],
            'South East Asia': [
                { country_id: "193", id: "193_duplicate1Philippines", main_id: "193_Philippines", label: "Philippines" },
                { country_id: "192", id: "192_duplicate1Singapore", main_id: "192_Singapore", label: "Singapore" }
            ],
            'Middle East': [
                { country_id: "200", id: "200_duplicate1Turkey", main_id: "200_Turkey", label: "Turkey" },
                { country_id: "201", id: "201_duplicate1Saudi Arabia", main_id: "201_Saudi Arabia", label: "Saudi Arabia" },
                { country_id: "203", id: "203_duplicate1United Arab Emirates", main_id: "203_United Arab Emirates", label: "United Arab Emirates" },
                { country_id: "204", id: "204_duplicate1Israel", main_id: "204_Israel", label: "Israel" }
            ],
            'Australia-Oceania': [
                { country_id: "216", id: "216_duplicate1New Zealand", main_id: "216_New Zealand", label: "New Zealand" },
                { country_id: "215", id: "215_duplicate1Australia", main_id: "215_Australia", label: "Australia" }
            ]
        };
    })())
    .constant('BASE_URL', (function() {
        if ('baseURI' in document) {
            var str = document.baseURI;
            var lastStr = str.substring(str.lastIndexOf('/') + 1);
            str = str.replace(lastStr, '');
        } else {
            var baseTags = document.getElementsByTagName("base");
            if (baseTags.length > 0) {
                var str = baseTags[0].href;
                var lastStr = str.substring(str.lastIndexOf('/') + 1);
                str = str.replace(lastStr, ' ');
            } else {
                var str = window.location.href;
                var lastStr = str.substring(str.lastIndexOf('/') + 1);
                str = str.replace(lastStr, ' ');
            }
        }
        str = str.substring(0, str.length - 1);
        return str;
    })())
    .constant('LOCALES', {
        'locales': {
            'ru_RU': 'Русский',
            'en_US': 'English'
        },
        'preferredLocale': 'en_US',
    })
    .constant('PUBLISHERARR', ['dashboard', 'userselection', 'profile', 'myaccount', 'groups', 'editgroup', 'businessmodels', 'catalog', 'maintainbooks', 'addbook', 'editbook', 'channels', 'createchannel', 'editchannel'])
    .constant('RETAILERARR', ['retailerdashboard', 'userselection', 'retailerprofile', 'retailermyaccount', 'aboutbusinessmodel', 'retailercatalog', 'retailermylist', 'editlist', 'retailerwidgets', 'createretailerwidgets', 'editretailerwidgets', 'retailerreports'])
    .constant('PURCHASEARR', ['purchasehistory', 'purchaseauth', 'version'])
    .config(['$stateProvider', '$urlRouterProvider', '$locationProvider', '$translateProvider', 'tmhDynamicLocaleProvider', '$ocLazyLoadProvider', function($stateProvider, $urlRouterProvider, $locationProvider, $translateProvider, tmhDynamicLocaleProvider, $ocLazyLoadProvider) {
        $locationProvider.html5Mode(true);
        $urlRouterProvider.otherwise('/');
        // Now setup the states
        $stateProvider
            .state('home', {
                title: 'HOME_HEADER_TITLE',
                url: '/',
                templateUrl: 'app/components/login/login.html',
                controller: 'loginController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/login/loginController.js'
                            ]
                        })
                    }
                }
            })
            .state('signup', {
                title: 'SIGNUP_HEADER_TITLE',
                url: '/signup',
                templateUrl: 'app/components/signup/signup.html',
                controller: 'signupController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/signup/signupController.js',
                                'app/components/signup/signupService.js'
                            ]
                        })
                    }
                }
            })
            .state('verify', {
                title: 'Verify',
                url: '/verify?u',
                controller: 'verifyController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/verify/verifyController.js'
                            ]
                        })
                    }
                }
            })
            .state('userselection', {
                title: 'SELECT_USERTYPE',
                url: '/userselection',
                templateUrl: 'app/components/userselection/usertype.html',
                controller: 'usertypeController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/userselection/usertypeController.js',
                                'app/components/userselection/usertypeService.js'
                            ]
                        })
                    }
                }
            })
            .state('resetpasswordchk', {
                title: 'SIGNUP_HEADER_TITLE',
                url: '/resetpasswordchk',
                controller: 'resetpasswordchkController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/resetpassword/resetpasswordController.js'
                            ]
                        })
                    }
                }
            })
            .state('resetpassword', {
                title: 'SIGNUP_HEADER_TITLE',
                url: '/resetpassword',
                templateUrl: 'app/components/resetpassword/resetpassword.html',
                controller: 'resetpasswordController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/resetpassword/resetpasswordController.js'
                            ]
                        })
                    }
                }
            })
            .state('dashboard', {
                title: 'DASHBOARD_TITLE',
                url: '/dashboard',
                templateUrl: 'app/components/dashboard/dashboard.html',
                controller: 'dashboardController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/dashboard/dashboardController.js',
                                'app/components/dashboard/dashboardService.js'
                            ]
                        })
                    }
                }
            })
            .state('profile', {
                title: 'PUBLISHER_COMPANY_PROFILE_TITLE',
                url: '/profile',
                templateUrl: 'app/components/profile/profile.html',
                controller: 'profileController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/profile/profileController.js',
                                'app/components/profile/profileService.js',
                                'app/components/businessmodels/businessmodelService.js',
                                'app/components/common/languageService.js',
                                'app/components/common/countryService.js',
                                'app/components/publisherpreference/publisherpreferenceService.js'
                            ]
                        })
                    }
                }
            })
            .state('myaccount', {
                title: 'SIGNUP_HEADER_TITLE',
                url: '/myaccount',
                templateUrl: 'app/components/myaccount/myaccount.html',
                controller: 'myaccountController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/myaccount/myaccountController.js',
                                'app/components/profile/profileService.js'
                            ]
                        })
                    }
                }
            })
            .state('retailermyaccount', {
                title: 'SIGNUP_HEADER_TITLE',
                url: '/retailermyaccount',
                templateUrl: 'app/components/myaccount/retailermyaccount.html',
                controller: 'myaccountController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/myaccount/myaccountController.js',
                                'app/components/profile/profileService.js'
                            ]
                        })
                    }
                }
            })
            .state('groups', {
                title: 'GROUPS_HEADER_TITLE',
                url: '/groups',
                templateUrl: 'app/components/groups/groups.html',
                controller: 'groupsController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/groups/groupsController.js',
                                'app/components/groups/groupService.js'
                            ]
                        })
                    }
                }
            })
            .state('editgroup', {
                title: 'EDIT_GROUPS_HEADER_TITLE',
                url: '/editgroup',
                templateUrl: 'app/components/groups/publishereditgroup.html',
                controller: 'editgroupController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/groups/editgroupController.js',
                                'app/components/groups/groupService.js'
                            ]
                        })
                    }
                }
            })
            .state('businessmodels', {
                title: 'BUSINESS_MODELS_HEADER_TITLE',
                url: '/businessmodels',
                templateUrl: 'app/components/businessmodels/businessmodels.html',
                controller: 'businessmodelsController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/businessmodels/businessmodelsController.js',
                                'app/components/businessmodels/businessmodelService.js'
                            ]
                        })
                    }
                }
            })
            .state('aboutbusinessmodel', {
                title: 'ABOUT_BUSINESS_MODELS_LABEL',
                url: '/aboutbusinessmodel',
                templateUrl: 'app/components/businessmodels/retailerbusinessmodel.html',
                controller: 'businessmodelsController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/businessmodels/businessmodelsController.js',
                                'app/components/businessmodels/businessmodelService.js'
                            ]
                        })
                    }
                }
            })
            .state('catalog', {
                title: 'CATALOG',
                url: '/catalog',
                templateUrl: 'app/components/catalog/publishercatalog.html',
                controller: 'catalogController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/catalog/catalogController.js',
                                'app/components/catalog/catalogService.js',
                                'app/components/groups/groupService.js'
                            ]
                        })
                    }
                }
            })
            .state('maintainbooks', {
                title: 'MAINTAIN_BOOKS_LABEL',
                url: '/maintainbooks',
                templateUrl: 'app/components/maintainbooks/publishermaintainbooks.html',
                controller: 'booksController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/maintainbooks/booksController.js',
                                'app/components/catalog/catalogService.js'
                            ]
                        })
                    }
                }
            })
            .state('addbook', {
                title: 'MAINTAIN_BOOKS_LABEL',
                url: '/addbook',
                templateUrl: 'app/components/maintainbooks/publisheraddbook.html',
                controller: 'addBooksController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/maintainbooks/addBooksController.js',
                                'app/components/maintainbooks/bookService.js'
                            ]
                        })
                    }
                }
            })
            .state('editbook', {
                title: 'MAINTAIN_BOOKS_LABEL',
                url: '/editbook',
                templateUrl: 'app/components/maintainbooks/publisheraddbook.html',
                controller: 'addBooksController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/maintainbooks/addBooksController.js',
                                'app/components/maintainbooks/bookService.js'
                            ]
                        })
                    }
                }
            })
            .state('channels', {
                title: 'CHANNELS_LABEL',
                url: '/channels',
                templateUrl: 'app/components/channels/channels.html',
                controller: 'channelsController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/channels/channelsController.js',
                                'app/components/businessmodels/businessmodelService.js',
                                'app/components/channels/channelService.js'
                            ]
                        })
                    }
                }
            })
            .state('createchannel', {
                title: 'CHANNELS_LABEL',
                url: '/createchannel',
                templateUrl: 'app/components/channels/createchannel.html',
                controller: 'createChannelsController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/channels/addChannelsController.js',
                                'app/components/channels/channelService.js'
                            ]
                        })
                    }
                }
            })
            .state('editchannel', {
                title: 'CHANNELS_LABEL',
                url: '/editchannel',
                templateUrl: 'app/components/channels/createchannel.html',
                controller: 'createChannelsController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/channels/addChannelsController.js',
                                'app/components/channels/channelService.js'
                            ]
                        })
                    }
                }
            })
            .state('retailerdashboard', {
                title: 'DASHBOARD_TITLE',
                url: '/retailerdashboard',
                templateUrl: 'app/components/dashboard/retailerdashboard.html',
                controller: 'dashboardController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/dashboard/dashboardController.js',
                                'app/components/dashboard/dashboardService.js'
                            ]
                        })
                    }
                }
            })
            .state('retailerprofile', {
                title: 'PUBLISHER_COMPANY_PROFILE_TITLE',
                url: '/retailerprofile',
                templateUrl: 'app/components/profile/retailerprofile.html',
                controller: 'profileController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/profile/profileController.js',
                                'app/components/profile/profileService.js',
                                'app/components/businessmodels/businessmodelService.js',
                                'app/components/common/languageService.js',
                                'app/components/common/countryService.js',
                                'app/components/publisherpreference/publisherpreferenceService.js'
                            ]
                        })
                    }
                }
            })
            .state('retailercatalog', {
                title: 'CATALOG',
                url: '/retailercatalog',
                templateUrl: 'app/components/catalog/retailercatalog.html',
                controller: 'retailercatalogController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/catalog/retailercatalogController.js',
                                'app/components/catalog/catalogService.js',
                                'app/components/retailermylist/listService.js',
                                'app/components/businessmodels/businessmodelService.js'
                            ]
                        })
                    }
                }
            })
            .state('retailerwidgets', {
                title: 'CATALOG',
                url: '/retailerwidgets',
                templateUrl: 'app/components/retailerwidgets/retailerwidgets.html',
                controller: 'retailerwidgetsController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/retailerwidgets/retailerwidgetsController.js',
                                'app/components/retailerwidgets/widgetsService.js'
                            ]
                        })
                    }
                }
            })
            .state('createretailerwidgets', {
                title: 'CATALOG',
                url: '/createretailerwidgets',
                templateUrl: 'app/components/retailerwidgets/createretailerwidgets.html',
                controller: 'createretailerwidgetsController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/retailerwidgets/createretailerwidgetsController.js',
                                'app/components/retailerwidgets/widgetsService.js',
                                'app/components/catalog/catalogService.js'
                            ]
                        })
                    }
                }
            })
            .state('editretailerwidgets', {
                title: 'CATALOG',
                url: '/editretailerwidgets',
                templateUrl: 'app/components/retailerwidgets/createretailerwidgets.html',
                controller: 'createretailerwidgetsController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/retailerwidgets/createretailerwidgetsController.js',
                                'app/components/retailerwidgets/widgetsService.js',
                                'app/components/catalog/catalogService.js'
                            ]
                        })
                    }
                }
            })
            .state('preference', {
                title: 'RETAILER_PREFERENCE',
                url: '/preference',
                templateUrl: 'app/components/preference/retailerpreference.html',
                controller: 'preferenceController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/preference/preferenceController.js',
                                'app/components/businessmodels/businessmodelService.js',
                                'app/components/common/languageService.js',
                                'app/components/common/countryService.js'
                            ]
                        })
                    }
                }
            })
            .state('retailermylist', {
                title: 'RETAILER_MYLISTS_LABEL',
                url: '/retailermylist',
                templateUrl: 'app/components/retailermylist/retailermylist.html',
                controller: 'mylistController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/retailermylist/mylistController.js',
                                'app/components/retailermylist/listService.js'
                            ]
                        })
                    }
                }
            })
            .state('editlist', {
                title: 'RETAILER_MYLISTS_LABEL',
                url: '/editlist',
                templateUrl: 'app/components/retailermylist/editlist.html',
                controller: 'editlistController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/retailermylist/editlistController.js',
                                'app/components/retailermylist/listService.js'
                            ]
                        })
                    }
                }
            })
            .state('publisherpreference', {
                title: 'MY_PREFERENCE_LABEL',
                url: '/publisherpreference',
                templateUrl: 'app/components/publisherpreference/publisherpreference.html',
                controller: 'publisherpreferenceController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/publisherpreference/publisherpreferenceController.js',
                                'app/components/publisherpreference/publisherpreferenceService.js'
                            ]
                        })
                    }
                }
            })
            .state('purchasehistory', {
                title: 'PURCHASE_HISTORY',
                url: '/purchasehistory',
                templateUrl: 'app/components/purchasehistory/purchasehistory.html',
                controller: 'purchasehistoryController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/purchasehistory/purchasehistoryController.js',
                                'app/components/purchasehistory/purchasehistoryService.js'
                            ]
                        })
                    }
                }
            })
            .state('purchaseauth', {
                title: 'PURCHASE_AUTHENTICATION',
                url: '/purchaseauth',
                templateUrl: 'app/components/purchaseauth/purchaseauth.html',
                controller: 'purchaseauthController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/purchaseauth/purchaseauthController.js',
                                'app/components/purchaseauth/purchaseauthService.js'
                            ]
                        })
                    }
                }
            })
            .state('version', {
                title: 'VERSION_TITLE',
                url: '/version',
                templateUrl: 'app/components/version/version.html',
                controller: 'versionController',
                resolve: {
                    loadMyFiles: function($ocLazyLoad) {
                        return $ocLazyLoad.load({
                            name: '1world',
                            files: [
                                'app/components/version/versionController.js',
                                'app/components/version/versionService.js'
                            ]
                        })
                    }
                }
            });
    }])
    .config(function($compileProvider, DEBUG_MODE) {
        if (!DEBUG_MODE) {
            $compileProvider.debugInfoEnabled(false); // disables AngularJS debug info
        }
    })
    .config(function($translateProvider, DEBUG_MODE, LOCALES) {
        if (DEBUG_MODE) {
            $translateProvider.useMissingTranslationHandlerLog(); // warns about missing translates
        }
        $translateProvider.useStaticFilesLoader({
            files: [{
                    prefix: 'assets/resources/locale-', // path to translations files
                    suffix: '.json' // suffix, currently- extension of the translations
                },
                {
                    prefix: 'assets/resources/validate/locale-validate-', // path to translations files
                    suffix: '.json' // suffix, currently- extension of the translations
                }
            ]
        });
        $translateProvider.preferredLanguage(LOCALES.preferredLocale);
        // Enable escaping of HTML
        $translateProvider.useSanitizeValueStrategy('escape');
        $translateProvider.useLocalStorage();
    })
    .config(function(tmhDynamicLocaleProvider) {
        tmhDynamicLocaleProvider.localeLocationPattern('bower_components/angular-i18n/angular-locale_{{locale}}.js');
    })
    .config(function($httpProvider) {
        $httpProvider.interceptors.push('authInterceptorService');
    })
    .run(function($http, CacheFactory) {
        $http.defaults.cache = CacheFactory('defaultCache', {
            maxAge: 20 * 60 * 1000,
            cacheFlushInterval: 120 * 60 * 1000,
            deleteOnExpire: 'aggressive'
        });
    })
    .config(function(IdleProvider, KeepaliveProvider) {
        KeepaliveProvider.interval(10);
        IdleProvider.windowInterrupt('focus');
    })
    .run(function($rootScope, Idle, $log, Keepalive, localStorageService) {
        var userTokenData = localStorageService.get('authorizeTokenDetail');
        if (userTokenData !== undefined && userTokenData !== null && userTokenData !== '' && userTokenData.access_token !== undefined && userTokenData.access_token !== null && userTokenData.access_token !== '') {
            Idle.watch();
        }
    })
    .run(['authService', 'LOCALES', '$rootScope', function(authService, LOCALES, $rootScope) {
        $rootScope.language = LOCALES.preferredLocale;
        authService.fillAuthData($rootScope.language);
    }])
    .run(function($rootScope, $state, $window, beforeUnload, $cookieStore, $sessionStorage, $location, authService, LOCALES, localStorageService, Idle, PUBLISHERARR, RETAILERARR, PURCHASEARR) {
        $rootScope.$on("$stateChangeStart", function(event, toState, toParams, fromState) {
            $window.scrollTo(0, 0);
            $rootScope.title = toState.title;
            $rootScope.selectedMenu = toState.name;
            $rootScope.$watch($rootScope.error_no);
            var authArr = ['home', 'verify', 'signup', 'resetpassword', 'resetpasswordchk', 'purchaseauth', 'purchasehistory'];
            var publisherRights = {
                //  profile: '1,2',
                createchannel: '3',
                editchannel: '3',
                maintainbooks: '4',
                publisherpreference: '10'
            };
            var retailerRights = {
                //    retailerprofile: '6',
                createretailerwidgets: '7',
                editretailerwidgets: '7',
                preference: '9',
                editlist: '8'
            };
            var userTokenData = localStorageService.get('authorizeTokenDetail');
            var userData = cookies.get('authorizationData');
            $rootScope.userData = userData;
            if (PURCHASEARR.indexOf(toState.name) >= 0) {
                $rootScope.contentDisplay = {
                    signinMenu: false,
                    signupMenu: false,
                    userAccount: false,
                    menuTab: false,
                    purchaseTab: true,
                    usertype: ''
                };
                $location.path('/' + toState.name);
            } else {
                if (authArr.indexOf(toState.name) < 0 || (userTokenData !== null && userTokenData.keepsignin)) {
                    authService.isLoggedIn($rootScope.language, function(authToken) {
                        if (!authToken) {
                            $location.path('/');
                        } else {
                            if (userTokenData) {
                                if (parseInt(userTokenData.usertype) === 3) {
                                    $sessionStorage.contentDisplay = {
                                        signinMenu: false,
                                        signupMenu: false,
                                        userAccount: true,
                                        menuTab: false,
                                        purchaseTab: false,
                                        usertype: userTokenData.usertype
                                    };
                                    $rootScope.contentDisplay = $sessionStorage.contentDisplay;
                                    $location.path('/userselection');
                                } else {
                                    $sessionStorage.contentDisplay = {
                                        signinMenu: false,
                                        signupMenu: false,
                                        userAccount: true,
                                        menuTab: true,
                                        purchaseTab: false,
                                        usertype: userTokenData.usertype
                                    };
                                    $rootScope.contentDisplay = $sessionStorage.contentDisplay;
                                    if (authArr.indexOf(toState.name) < 0) {
                                        if (userTokenData.usertype == 1) {
                                            var rightno = (publisherRights[toState.name] !== undefined && publisherRights[toState.name] !== null && publisherRights[toState.name] !== '') ? publisherRights[toState.name] : '';
                                            var isAccess = false;
                                            var rigarr = (publisherRights[toState.name] !== undefined && publisherRights[toState.name] !== null && publisherRights[toState.name] !== '') ? publisherRights[toState.name].split(',') : [];
                                            angular.forEach(rigarr, function(rval, rkey) {
                                                if (userTokenData.module_rights !== undefined && userTokenData.module_rights.indexOf(parseInt(rval)) >= 0) {
                                                    isAccess = true;
                                                }
                                            });
                                            if (rightno == '' || parseInt(userTokenData.invited_by) === 0) {
                                                isAccess = true;
                                            }
                                            if (PUBLISHERARR.indexOf(toState.name) >= 0 && isAccess) {
                                                $location.path('/' + toState.name);
                                            } else {
                                                $location.search({});
                                                $location.path('/dashboard');
                                            }
                                        } else {
                                            var rightno = (retailerRights[toState.name] !== undefined && retailerRights[toState.name] !== null && retailerRights[toState.name] !== '') ? retailerRights[toState.name] : '';
                                            var isAccess = false;
                                            var rigarr = (retailerRights[toState.name] !== undefined && retailerRights[toState.name] !== null && retailerRights[toState.name] !== '') ? retailerRights[toState.name].split(',') : [];
                                            angular.forEach(rigarr, function(rval, rkey) {
                                                if (userTokenData.module_rights !== undefined && userTokenData.module_rights.indexOf(parseInt(rval)) >= 0) {
                                                    isAccess = true;
                                                }
                                            });
                                            if (rightno == '' || parseInt(userTokenData.invited_by) === 0) {
                                                isAccess = true;
                                            }

                                            if (RETAILERARR.indexOf(toState.name) >= 0 && isAccess) {
                                                $location.path('/' + toState.name);
                                            } else {
                                                $location.search({});
                                                $location.path('/retailerdashboard');
                                            }
                                        }
                                    } else {
                                        if (parseInt(userTokenData.usertype) === 3) {
                                            $location.path('/userselection');
                                        } else {
                                            if (parseInt(userTokenData.logins) > 1) {
                                                $location.path('/dashboard');
                                            } else {
                                                $location.path('/userselection');
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    });
                } else {
                    if ($location.search().u === '' || $location.search().u === undefined) {
                        if (userData) {
                            if (userTokenData !== null && parseInt(userTokenData.usertype) === 3) {
                                $location.path('/userselection');
                            } else {
                                if (parseInt(userData.logins) > 1) {
                                    $location.path('/dashboard');
                                } else {
                                    $location.path('/userselection');
                                }
                            }
                        }
                    }
                }
            }

        });
    });