App.directive('confirmField', function () {
    return {
        require: 'ngModel',
        link: function (scope, elm, attrs, ctrl) {
            var matchfield = attrs.matchfield;
            var formname = attrs.formname;
            ctrl.$parsers.unshift(function (viewValue, $scope) {
                /**
                * field confirmation check
                */
                var noMatch = viewValue != scope[formname][matchfield].$viewValue;
                ctrl.$setValidity('noMatch', !noMatch);
                return viewValue;
            })
        }
    }
})