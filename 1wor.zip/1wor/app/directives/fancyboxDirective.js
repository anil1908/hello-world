/**
 * @description
 * # fancybox Directive
 */
App.directive('fancybox', function ($compile) {
    return {
        restrict: 'A',
        controller: function ($scope) {
            $scope.openFancybox = function (imgpath) {
                /**
                 * image Fancybox
                */
                var fancy = $.fancybox;
                var template = angular.element('<img src="' + imgpath + '"  alt=""/>');
                var compiledTem = $compile(template)($scope);
                fancy.open({content: template, type: 'html'});
            };
        }
    }
});