App.directive('autoSearch', function ($timeout) {
    return {
        restrict: "A",
        require: "?ngModel",
        link: function (scope, element, attrs, ngModel) {
            $timeout(function () {
                var subject = new autoComplete({
                    selector: '#'+attrs.id,
                    minChars: 1,
                    source: function(term, suggest){
                        term = term.toLowerCase();
                        var choices = scope[attrs.uiItems];
                        var suggestions = [];
                        for (i=0;i<choices.length;i++)
                            if (~choices[i].toLowerCase().indexOf(term)) suggestions.push(choices[i]);
                        suggest(suggestions);
                    },
                    onSelect: function(e, term, item){
                        if (ngModel.$viewValue && ngModel.$viewValue !== element.val()) {
                            scope.$apply(function () {
                                var subject = _.where(scope.subjectList, {name: element.val()});
                                var index = _.where(scope.bookDetail.subject_id, subject[0]);
                                if (index.length <= 0) {
                                    scope.bookDetail.subject_id.push(subject[0]);
                                }
                                ngModel.$setViewValue('');
                                document.getElementById("subjectId").value ='';
                            });
                        }
                    }
                });
            }, 1000);
        }
    };
});