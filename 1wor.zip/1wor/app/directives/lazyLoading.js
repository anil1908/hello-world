/**
 * @ngdoc function
 * @description
 * # lazyLoading Directive
 */
App.directive("lazyLoading", [function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs, $window) {
                $window = angular.element(window);
                $window.bind('scroll', function (event) {
                    if($(window).scrollTop() + $(window).height() == $(document).height()) {
                        $(window).scrollTop($(window).scrollTop()-1)
                        scope.$apply(attrs.scrollLoadEvent);
                    }
                });
            }
        };
}]);

App.directive("customlazyLoading", [function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs, $window) {
                $window = angular.element(window);
                var div = document.getElementById(attrs.scrollLoadId);
                element.on('scroll', function (event) {
                        if(div.offsetHeight + div.scrollTop >= div.scrollHeight) {
                            scope.$apply(attrs.scrollLoadEvent);
                        }
                });
            }
        };
}]);