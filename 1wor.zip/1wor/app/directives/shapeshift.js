/**
 * @description
 * # shapeshift Directive
 */
App.directive('shapeshift', function(){
        return {
            restrict: 'A',
            link: function(scope, element, attrs) {
                $(element).shapeshift(scope.$eval(attrs.shapeshift));
            }
        };
    }
);

