/**
 * @description
 * # text managment Directive
 */
App.directive('txtMaxlength', function() {
  return {
    require: 'ngModel',
    link: function (scope, element, attrs, ngModelCtrl) {
      var maxlength = Number(attrs.txtMaxlength);
      function fromUser(text) {
        if(text!==null && text!==undefined && text!==''){
          text = text.replace(/<\/?[^>]+(>|$)/g, "");
          if (text.length > maxlength) {
            var transformedInput = text.substring(0, (maxlength-1));
            ngModelCtrl.$setViewValue(transformedInput);
            ngModelCtrl.$render();
            return transformedInput;
          }
          return text;
        }
        else{
          return text;
        }
      }
      ngModelCtrl.$parsers.push(fromUser);
    }
  };
});