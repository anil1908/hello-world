'use strict';
App.filter('numberDecimal', ['numberFilter', '$locale',
  function(number, $locale) {
    var formats = $locale.NUMBER_FORMATS;
    return function(input, fractionSize) {
      if(input!==undefined && input!==null){
        var decimalval = 0.00;
        var formattedValue = number(input, fractionSize);
        var decimalIdx = formattedValue.indexOf(formats.DECIMAL_SEP);
        if (decimalIdx == -1) return formattedValue;
        var whole = formattedValue.substring(0, decimalIdx);
        var decimal = (Number(formattedValue.substring(decimalIdx)) || "").toString();
        return whole +  decimal.substring(1);
      }
    };
  }
]);