'use strict';
App.filter('dateFormat', function($filter)
{
    return function(input)
    {
        if(input == null || input == '' || input == undefined){ return ""; }
        var _date = $filter('date')(new Date(input), 'MM/dd/yyyy');
        return _date.toUpperCase();
    };
});