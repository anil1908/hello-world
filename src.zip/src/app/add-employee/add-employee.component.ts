import { Component, Input, OnInit } from '@angular/core';
import { EmployeeService } from '../employee/employee.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbModal, NgbActiveModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {
  @Input() id: any;

  createEmployeeForm: FormGroup;
  submitted: boolean = false;
  constructor(
    public modalService: NgbModal,
    public activeModal: NgbActiveModal,
    public fb: FormBuilder,
    public employeeService: EmployeeService) { }

  ngOnInit() {
    if (this.id !== undefined && this.id !== null && this.id !== '') {
      this.createEmployeeForm = this.fb.group({
          'emp_id': ['', Validators.compose([Validators.required])],
          'firstname': ['', Validators.compose([Validators.required])],
          'lastname': ['', Validators.compose([Validators.required])],
          'location': ['', Validators.compose([Validators.required])],
          'position': ['', Validators.compose([Validators.required])],
          'gender': ['', Validators.compose([Validators.required])]
        });
      this.employeeService.getById(this.id).subscribe(data => {
        this.createEmployeeForm.controls['emp_id'].setValue(data['emp_id']);
        this.createEmployeeForm.controls['firstname'].setValue(data['firstname']);
        this.createEmployeeForm.controls['lastname'].setValue(data['lastname']);
        this.createEmployeeForm.controls['location'].setValue(data['location']);
        this.createEmployeeForm.controls['position'].setValue(data['position']);
        this.createEmployeeForm.controls['gender'].setValue(data['gender']);
      });
    }
    else {
      this.createEmployeeForm = this.fb.group({
        'emp_id': ['', Validators.compose([Validators.required])],
        'firstname': ['', Validators.compose([Validators.required])],
        'lastname': ['', Validators.compose([Validators.required])],
        'location': ['', Validators.compose([Validators.required])],
        'position': ['', Validators.compose([Validators.required])],
        'gender': ['male', Validators.compose([Validators.required])]
      });
    }
  }

  submitEmployee() {
    if (this.createEmployeeForm.valid) {
      var empdata = this.createEmployeeForm.value;
      empdata['id'] = this.id;
      this.employeeService.create(empdata).subscribe(data => {
        if (data == null || data == undefined || data == '') {
          alert('Employee Id ' + empdata.emp_id + ' already exists')
        }
        else {
          this.activeModal.close();
        }
      });

    }
    else {
      this.submitted = true;
    }
  }

  capitaltext(field){
    let val = this.createEmployeeForm.controls[field].value;
    val =  val.charAt(0).toUpperCase() + val.slice(1);
    this.createEmployeeForm.controls[field].setValue(val);
  }

}
