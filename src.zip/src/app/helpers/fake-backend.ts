import {Http,BaseRequestOptions,Response,ResponseOptions,RequestMethod } from '@angular/http';
import {MockBackend,MockConnection} from '@angular/http/testing';

export let fakeBackendProvider = {
    provide : Http,
    useFactory : (backend:MockBackend,options:BaseRequestOptions) => {
        let employees: any[] = JSON.parse(localStorage.getItem('employees')) || [];
        backend.connections.subscribe((connection:MockConnection) => {
            setTimeout(() => {
        
                // get employees
                if (connection.request.url.endsWith('/api/employees') && connection.request.method === RequestMethod.Get) {
                    if (connection.request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
                        connection.mockRespond(new Response(new ResponseOptions({ status: 200, body: employees })));
                    } else {
                        // return 401 not authorised if token is null or invalid
                        connection.mockRespond(new Response(new ResponseOptions({ status: 401 })));
                    }
                }

                 // create & update employees
                if (connection.request.url.endsWith('/api/create_employees') && connection.request.method === RequestMethod.Post) {
                   // get new user object from post body
                    let newUser = JSON.parse(connection.request.getBody());
                    
                    if(newUser['id']!==undefined && newUser['id']!==null && newUser['id']!==''){
                        if(newUser['id']!=newUser['emp_id']){
                            // validation
                            let duplicateUser = false;
                            employees.filter(user => { 
                                if(user.emp_id === newUser.emp_id){
                                    duplicateUser = true;
                                }
                            });
                            if (duplicateUser) {
                                return connection.mockRespond(new Response(new ResponseOptions({ status: 401 })));
                            }
                        }
                        for (let i = 0; i < employees.length; i++) {
                            if ( employees[i]['emp_id'] == newUser['id']) {
                                employees[i]['firstname'] = newUser['firstname'];
                                employees[i]['lastname'] = newUser['lastname'];
                                employees[i]['location'] = newUser['location'];
                                employees[i]['position'] = newUser['position'];
                                employees[i]['gender'] = newUser['gender'];
                                localStorage.setItem('employees', JSON.stringify(employees));
                            }
                        }
                        connection.mockRespond(new Response(new ResponseOptions({ status: 200 , body: newUser})));
                    }
                    else{
                        // validation
                        let duplicateUser = false;
                        employees.filter(user => { 
                            if(user.emp_id === newUser.emp_id){
                                duplicateUser = true;
                            }
                        });
                        if (duplicateUser) {
                            return connection.mockRespond(new Response(new ResponseOptions({ status: 401 })));
                        }
                        newUser.id = employees.length + 1;
                        employees.push(newUser);
                        localStorage.setItem('employees', JSON.stringify(employees));
                        // respond 200 OK
                        connection.mockRespond(new Response(new ResponseOptions({ status: 200 , body: newUser})));
                    }
                   
                }

                 // delete employees
                if (connection.request.url.match(/\/api\/employee\/\d+$/) && connection.request.method === RequestMethod.Delete) {
                    // check for fake auth token in header and return user if valid, this security is implemented server side in a real application
                    if (connection.request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
                        // find user by id in users array
                        let urlParts = connection.request.url.split('/');
                        let id = parseInt(urlParts[urlParts.length - 1]);
                        for (let i = 0; i < employees.length; i++) {
                            if ( employees[i]['emp_id'] == id) {
                                // delete user
                                employees.splice(i, 1);
                                localStorage.setItem('employees', JSON.stringify(employees));
                                break;
                            }
                        }
                        // respond 200 OK
                        connection.mockRespond(new Response(new ResponseOptions({ status: 200 })));
                    } else {
                        // return 401 not authorised if token is null or invalid
                        connection.mockRespond(new Response(new ResponseOptions({ status: 401 })));
                    }
                }
                // get user by id
                if (connection.request.url.match(/\/api\/employee\/\d+$/) && connection.request.method === RequestMethod.Get) {
                    // check for fake auth token in header and return user if valid, this security is implemented server side in a real application
                    if (connection.request.headers.get('Authorization') === 'Bearer fake-jwt-token') {
                      
                        // find user by id in users array
                        let urlParts = connection.request.url.split('/');
                        let id = parseInt(urlParts[urlParts.length - 1]);
                        let matchedUsers = employees.filter(user => { return user.emp_id == id; });
                        let user = matchedUsers.length ? matchedUsers[0] : null;
                        // respond 200 OK with user
                        connection.mockRespond(new Response(new ResponseOptions({ status: 200, body: user })));
                    } else {
                        // return 401 not authorised if token is null or invalid
                        connection.mockRespond(new Response(new ResponseOptions({ status: 401 })));
                    }
                }

            },500);
        });
        return new Http(backend,options);
    },
    deps : [MockBackend,BaseRequestOptions]
}
