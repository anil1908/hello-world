import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee/employee.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { AddEmployeeComponent } from '../add-employee/add-employee.component';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  public filterText: string = '';
  public filterInput = new FormControl();
  employeedata: Array<any> = [];
  iscardview: boolean = true;
  constructor(
    public modalService: NgbModal,
    public employeeService: EmployeeService) { }

  ngOnInit() {
    this.getEmployeeData();
    this.filterInput
      .valueChanges
      .debounceTime(200)
      .subscribe(term => {
        this.filterText = term;
        console.log(term);
      });
  }

  cardView(val) {
    this.iscardview = val;
  }

  getEmployeeData() {
    this.employeeService.getAll().subscribe(data => {
      this.employeedata = data;
    });
  }

  addnew() {
    const modalRef = this.modalService.open(AddEmployeeComponent);
    modalRef.componentInstance.id = '';
    modalRef.result.then((result) => {
      this.getEmployeeData();
    }, (reason) => {
      this.getEmployeeData();
    });
  }

  deleteEmployee(id) {
    this.employeeService.delete(id).subscribe(data => {
      this.getEmployeeData();
    });
  }

  editEmployee(id) {
    const modalRef = this.modalService.open(AddEmployeeComponent);
    modalRef.componentInstance.id = id;
    modalRef.result.then((result) => {
      this.getEmployeeData();
    }, (reason) => {
      this.getEmployeeData();
    });
  }

}
