import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';

@Injectable()
export class AucService {
  data : string;
  aucdata : string;
  constructor(public http: Http) {
    console.log('Hello AucService Provider');
  }

  autoLogin() {
    var url = 'user.json';
    var response = this.http.get(url).map(res => res.json());
    return response;
  }

  regionLoad(data){
    var url = 'http://192.168.1.8/1world_dev/api/general/get_regions';
    var response = this.http.post(url,data).map(res => res.json());
    return response;
  }

}
