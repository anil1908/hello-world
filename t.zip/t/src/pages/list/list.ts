import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import {AucService} from '../../providers/auc-service';


@Component({
  selector: 'list-page',
  templateUrl: 'list.html',
  providers: [AucService]
})
export class ListPage {
  selectedItem: any;
  icons: string[];
  pet : string;
  country: Array<{id: string,  name: string}>;
  constructor(public AucService:AucService,public navCtrl: NavController, public navParams: NavParams) {
    this.loadPeople();
    this.pet = 'kittens';
  }

  loadPeople(){
    this.AucService.autoLogin().subscribe(
        data => {
          this.getRegions({access_token:data.access_token,language:data.language});
        },
        err => {
            console.log(err);
        }
    );
  }

  getRegions(aucdata){
    this.AucService.regionLoad(aucdata).subscribe(
      data => {
        this.country = data.response;
      },
      err => {
          console.log(err);
      }
    );
  }


}
