<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$lang = array();
$lang['signup_title'] = 'S\'inscrire';
$lang['signup_instruction'] = 'Entrez vos données personnelles ci-dessous:';
$lang['signup_first_name'] = 'Prénom';
$lang['signup_last_name'] = 'Nom de famille';
$lang['signup_company_name'] = 'Nom de la compagnie';
$lang['signup_email'] = 'Email';
$lang['signup_password'] = 'Mot de passe';
$lang['signup_policy'] = 'je suis d\'accord avec le <a href="">Conditions d\'utilisation</a> et <a href="">Politique de confidentialité</a>';
$lang['signup_back'] = 'Arrière';
$lang['signup_button'] = 'S\'inscrire';
