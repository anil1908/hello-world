<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
$lang = array();
$lang['email_exists'] = 'Email already exists.';
$lang['group_name_exists'] = 'Group name already exists.';
$lang['book_title_exists'] = 'Book Title already exists.';
$lang['account_confirmed'] = 'Account confirmed successfully.';
$lang['account_already_confirmed'] = 'Your account is already confirmed.';
$lang['technical_error'] = 'Please try after some time.';
$lang['invalid_login'] = 'The credentials you entered did not match any account.  Please try again.';
$lang['forgot_email'] = 'Either account is inactive or email not exists.';
$lang['forgot_email_success'] = 'Instructions to reset your password have been sent to your email address.';
$lang['link_expired'] = 'Your link is expired.';
$lang['reset_password_success'] = 'Password reset successfully.';
$lang['update_user_profile'] = 'User detail updated successfully.';
$lang['update_user_status'] = 'User status updated successfully.';
$lang['update_channel_status'] = 'Channel status updated successfully.';
$lang['update_company_profile'] = 'Company information updated successfully.';
$lang['session_expired'] = 'Session has expired';
$lang['account_inactive'] = 'Your account is inactive.';
$lang['invalid_user'] = 'Invalid User.';
$lang['invite_user'] = 'Invitation send successfully.';
$lang['available_tag'] = 'Tag already available.';
$lang['applied_tag'] = 'Tag applied successfully.';
$lang['favourite_business_model'] = 'Model added to favourite list.';
$lang['unfavourite_business_model'] = 'Model removed from favourite list.';
$lang['group_create_success'] = 'Group created successfully.';
$lang['group_delete_success'] = 'Group Deleted successfully.';
$lang['group_exists_in_channel'] = 'Group(s) already exists in channel. Please delete it first.';
$lang['book_exists_in_group'] = 'Book(s) already exists in group. Please delete it first.';
$lang['tag_update_success'] = 'Tag(s) updated successfully';
$lang['book_delete_success'] = 'Book(s) deleted successfully';
$lang['group_book_delete_success'] = 'Book(s) deleted successfully';
$lang['group_name_update_success'] = 'Group name updated successfully';
$lang['select_book'] = 'Select book for delete.';
$lang['insufficient_book_detail'] = 'Provide Book details';
$lang['delete_channel_success'] = 'Channel deleted successfully.';
$lang['book_insert_success'] = 'Book Inserted successfully.';

