<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Channel extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('channel_model');
        $this->load->model('general_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * Channel list
     *
     * @access	public
     * @param	access_token,language,search_name,search_from_date,search_to_date,search_model,pageStart,pageLimit,sortField,sorttype
     * @return	JSON Array
     */
    public function get_channel_list() {
        $retarray = array();
        $result = array();
        $id_array = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        $this->form_validation->set_rules('search_name', 'Group Name', 'trim|xss_clean');
        $this->form_validation->set_rules('search_from_date', 'From Date', 'trim|xss_clean');
        $this->form_validation->set_rules('search_to_date', 'To Date', 'trim|xss_clean');
        $this->form_validation->set_rules('search_model', 'Business Model', 'trim|xss_clean');


        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            $search_business_model = 0;
            $search_status = -1;
            if ($common_result['error'] == 0) {
                $search_name = addslashes(strtolower($this->input->post('search_name')));
                $search_from_date = $this->input->post('search_from_date');
                $search_to_date = $this->input->post('search_to_date');
                $modelarr = $this->input->post('search_model');

                if (count($modelarr) > 0) {
                    $search_business_model = (!empty($modelarr['id']) ? $modelarr['id'] : 0);
                }
                $search_status = $this->input->post('search_status');
                $pageStart = (!empty($this->input->post('pageStart'))) ? $this->input->post('pageStart') : 0;
                $pageLimit = (!empty($this->input->post('pageLimit'))) ? $this->input->post('pageLimit') : 10;
                $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'c.created_on';
                $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'DESC';

                $retarray['response'] = array();
                //Get channel list
                $result = $this->channel_model->get_channel_list_by_company_id($common_result['company_id'], $pageStart, $pageLimit, $sortField, $sortType, $search_name, $search_from_date, $search_to_date, $search_business_model, $search_status);
                $retarray['found_rows'] = $this->general_model->found_rows();
                $wherearr = array('company_id' => $common_result['company_id']);
                $retarray['total_rows'] = $this->channel_model->get_channel_list_count($common_result['company_id'], $search_name, $search_from_date, $search_to_date, $search_business_model, $search_status);
                $i = 0;
                if (is_array($result) && count($result) > 0) {
                    $retarray['error'] = 0;
                    foreach ($result as $key => $val) {
                        array_push($id_array, $result[$key]['id']);
                        //Channel list
                        $retarray['response'][$i] = array('id' => $result[$key]['id'],
                            'name' => $result[$key]['name'],
                            'created_on' => date('m/d/Y', strtotime($result[$key]['created_on'])),
                            'business_model' => $result[$key]['business_model'],
                            'group_name' => $result[$key]['group_name'],
                            'window' => date('m/d/Y', strtotime($result[$key]['start_date'])) . " To " . date('m/d/Y', strtotime($result[$key]['end_date'])),
                            'region' => $result[$key]['region'],
                            'status' => $result[$key]['status'],
                        );
                        $i++;
                    }
                    //ids
                    $retarray['ids'] = implode(',', $id_array);
                } else {
                    $retarray = array("error" => 0,
                        "found_rows" => 0,
                        "total_rows" => 0,
                        "response" => array(),
                        "ids" => '');
                }
            } else {
                $retarray = $common_result;
            }
        }
        echo json_encode($retarray);
    }

    /**
     * Change channel status
     *
     * @access	public
     * @param	access_token,language,channel_id,status
     * @return	JSON Array
     */
    public function update_channel_status() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $channel_id = $this->input->post('channel_id');
            $status = $this->input->post('status');
            $modified_on = date('Y-m-d H:i:s');

            if (!empty($channel_id)) {
                //update channel data
                $channel_data = array('modified_on' => $modified_on,
                    'modified_by' => $common_result['user_id']);
                $this->channel_model->update_channel_data_by_id($channel_data, $channel_id);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('update_channel_status');
                $retarray['response'] = array();
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Delete channel
     *
     * @access	public
     * @param	access_token,language,channelArr
     * @return	JSON Array
     */
    public function delete_channel() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $channel_id = $this->input->post('channelArr');
            $deleted_on = date('Y-m-d H:i:s');
            if (is_array($channel_id) && count($channel_id) > 0) {
                //Delete channel data
                $channel_data = array('deleted_on' => $deleted_on,
                    'deleted_by' => $common_result['user_id']);
                $this->channel_model->delete_channel_data($channel_data, $channel_id);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('delete_channel_success');
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Channel Price
     *
     * @access	public
     * @param	access_token,language,channel_id
     * @return	JSON Array
     */
    public function get_channel_price() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $channel_id = $this->input->post('channel_id');
            if (!empty($channel_id)) {
                //Get channel book price
                $retarray['response'] = $this->channel_model->get_channel_books_price_by_channel_id($channel_id);
                $retarray['error'] = 0;
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Regions and countries
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_region_with_country() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Create Channel 
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function create_channel() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $channel_array = $this->input->post("channelArr");
            if (is_object($channel_array) && count($channel_array) > 0) {
                $created_on = date('Y-m-d H:i:s');
                foreach ($channel_array as $ca) {
                    $channel_data = array("company_id" => $common_result['company_id'],
                        "name" => $ca->name,
                        "start_date" => date('Y-m-d', strtotime($ca->start_date)),
                        "end_date" => date('Y-m-d', strtotime($ca->end_date)),
                        "group_id" => $ca->group_id,
                        "business_model_id" => $ca->business_model_id,
                        "global_discount" => $ca->global_discount,
                        "publisher_payout" => $ca->publisher_payout,
                        "retailers_list" => $ca->retailers_list,
                        "status" => 1,
                        "created_on" => $created_on,
                        "created_by" => $common_result['user_id']);
                    $channel_id = $this->channel_model->insert_channel($channel_data);
                    if ($channel_id > 0) {
                        $result = $this->channel_model->get_group_books_by_group_id($ca->group_id);
                    }
                }
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

}
