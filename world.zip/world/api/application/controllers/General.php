<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class General extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('users_model');
        $this->load->model('general_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * Get Usertypes
     *
     * @access	public
     * @param	NA
     * @return	JSON Array
     */
    public function get_usertypes() {
        $result = array();
        $retarray = array();
        $result = $this->users_model->get_usertypes();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }

    /**
     * Get modules
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_modules() {
        $retarray = array();
        $retarray = $this->general_model->get_modules();
        return $retarray;
    }
    /**
     * Get contributor role
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_contributors_role() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_contributors_role();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get contributor people
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_contributors_people() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_contributors_people();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get language
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_language() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_language();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get subject
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_subject() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_subject();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get identifier type
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_identifier_types() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_identifier_types();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get region
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_regions() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_regions();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get country
     *
     * @access	public
     * @param	region_array
     * @return	Json Array
     */
    public function get_country() {
        $result = array();
        $retarray = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        $region_array = $this->input->post("region_array");
        if(is_array($region_array) && count($region_array)>0){
            $result = $this->general_model->get_country_by_region($region_array);
            $retarray['error'] = 0;
            if (is_array($result) && count($result) > 0) {
                $retarray['response'] = $result;
            }
        }
        echo json_encode($retarray);
    }
    
    /**
     * Get review type
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_review_type() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_review_type();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get review source
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_review_source() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_review_source();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get review date role
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_review_date_role() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_review_date_role();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get awards
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_awards() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_awards();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get awards code
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_awards_code() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_awards_code();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get audience
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_audience() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_audience();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get relation code
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_relation_code() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_relation_code();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }
    /**
     * Get currency
     *
     * @access	public
     * @param	NA
     * @return	Json Array
     */
    public function get_currency() {
        $result = array();
        $retarray = array();
        $result = $this->general_model->get_currency();
        $retarray['error'] = 0;
        if (is_array($result) && count($result) > 0) {
            $retarray['response'] = $result;
        }
        echo json_encode($retarray);
    }

}
