<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Preference extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('user_profile_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }
    
    /**
     * Get Retailer Preference 
     *
     * @access	public
     * @param	access_token,language,post data
     * @return	JSON Array
     */
    public function get_retailer_preference() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $modelarr = array();
        $langarr = array();
        $main_country_id = 0;
        $markup = 0;
        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if($common_result['error']==0){                                              
            $retarray['response'] = $this->user_profile_model->get_retailer_preferences($common_result['user_id']);
            $retarray['error'] = 0;            
        
        }else{
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }
    
    /**
     * Update Retailer Preference 
     *
     * @access	public
     * @param	access_token,language,post data
     * @return	JSON Array
     */
    public function update_retailer_preference() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $modelarr = array();
        $langarr = array();
        $main_country_id = 0;
        $markup = 0;
        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if($common_result['error']==0){
           
            $modelarr = $this->input->post('businessmodel_id');  
            $countryarr = $this->input->post('country_id');  
            $langarr = $this->input->post('language_id');  
            $main_country_id = $this->input->post('main_country_id');  
            $markup = $this->input->post('markup');             
            //Get category of business model
            $this->user_profile_model->update_retailer_preferences($modelarr,$countryarr,$langarr,$main_country_id,$markup,$common_result['user_id']);
            $retarray['error'] = 0;
            $retarray['msg'] = $this->lang->line("preference_update_success");
        
        }else{
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }
    
    
    
}
