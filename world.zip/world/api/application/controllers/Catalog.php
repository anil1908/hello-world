<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Catalog extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code

        $this->load->model('catalog_model');
        $this->load->model('general_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {

    }

    /**
     * Catalog list
     *
     * @access	public
     * @param	access_token,language,
     *          pageStart,pageLimit,
     *          sortField,sorttype,globalText,tagText
     * @return	JSON Array
     */
    public function get_catalog_list() {
        $retarray = array();
        $result = array();
        $id_array = array();
        $common_result = array();
        $namearray = array();

        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        $_POST = json_decode(file_get_contents('php://input'), true);
        $pageStart = (!empty($this->input->post('pageStart'))) ? $this->input->post('pageStart') : 0;
        $pageLimit = (!empty($this->input->post('pageLimit'))) ? $this->input->post('pageLimit') : 10;
        $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'b.publication_date';
        $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'DESC';

        $this->form_validation->set_rules('globalText', 'Search value', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $search = addslashes(strtolower($this->input->post('globalText')));
            $tag_search = $this->input->post('tagText');
            if (!empty($tag_search)) {
                foreach ($tag_search as $word) {
                    $namearray[] = '(LOWER(t.name) = "' . addslashes(strtolower($word)) . '")';
                }
            }
            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                $retarray['error'] = 0;
                //Get catalog list
                $result = $this->catalog_model->get_book_list_by_company_id($common_result['company_id'], $pageStart, $pageLimit, $sortField, $sortType, $search, $namearray);
                $retarray['found_rows'] = $this->general_model->found_rows();
                $wherearr = array('company_id' => $common_result['company_id']);
                $retarray['total_rows'] = $this->catalog_model->get_book_list_count($common_result['company_id'], $search, $namearray);

                $i = 0;
                if (is_array($result) && count($result) > 0) {
                    $retarray['error'] = 0;
                    foreach ($result as $key => $val) {
                        array_push($id_array, $result[$key]['id']);
                        //Catalog list
                        $retarray['response'][$i] = array('id' => $result[$key]['id'],
                            'title' => strip_slashes($result[$key]['title']),
                           // 'author' => (strlen($result[$key]['author']) > 20) ? substr($result[$key]['author'], 0, 20) . ".." : $result[$key]['author'],
                            'author' => (!empty($result[$key]['author'])) ? $result[$key]['author'] : NULL,
                            'publication_date' => (!empty($result[$key]['publication_date']))?date('m/d/Y', strtotime($result[$key]['publication_date'])):NULL,
                            'imprint' => $result[$key]['imprint'],
                            'identifier_no' => (strlen($result[$key]['identifier_no']) > 20) ? substr($result[$key]['identifier_no'], 0, 20) . ".." : $result[$key]['identifier_no'],
                            'publisher' => strip_slashes($result[$key]['publisher']),
                            'tag' => $result[$key]['tag']
                        );
                        $retarray['response'][$i]['image'][0]['thumb'] = (!empty($result[$key]['image']) && file_exists($path . '/' . $result[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $result[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                        $retarray['response'][$i]['image'][0]['img'] = (!empty($result[$key]['image']) && file_exists($path . '/' . $result[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $result[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                        $retarray['response'][$i]['image'][0]['description'] = "";
                        $i++;
                    }
                    //ids
                    $retarray['ids'] = implode(',', $id_array);
                } else {
                    $retarray = array("error" => 0,
                        "found_rows" => 0,
                        "total_rows" => 0,
                        "response" => array(),
                        "ids" => '');
                }
            } else {
                $retarray = $common_result;
            }
        }
       // echo "<pre>";print_r($retarray);exit;
        echo json_encode($retarray);
    }

    /**
     * Regions and countries
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_region_with_country() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            //Get region with country
            $retarray['response'] = $this->catalog_model->get_region_with_country();
            $retarray['error']=0;
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Book list
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_catalog_list_by_selection() {
        $retarray = array();
        $result = array();
        $common_result = array();

        $path = realpath(PUBPATH . '../assets/images/bookcovers');

        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            //Get book list
            $result = $this->catalog_model->get_book_list_by_selection($common_result['company_id']);
            $i = 0;
            if (is_array($result) && count($result) > 0) {
                $retarray['error'] = 0;
                foreach ($result as $key => $val) {
                    //Book list
                    $retarray['response'][$i] = array('id' => $result[$key]['id'],
                        'title' => $result[$key]['title']
                    );
                    $retarray['response'][$i]['image'][0]['thumb'] = (!empty($result[$key]['image']) && file_exists($path . '/' . $result[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $result[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                    $retarray['response'][$i]['image'][0]['img'] = (!empty($result[$key]['image']) && file_exists($path . '/' . $result[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $result[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                    $retarray['response'][$i]['image'][0]['description'] = "";
                    $i++;
                }
            } else {
                $retarray['error'] = 0;
                $retarray['response'] = array();
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Book list
     *
     * @access	public
     * @param	access_token,language,catalog_id
     * @return	JSON Array
     */
    public function get_catalog_details_by_id() {
        $retarray = array();
        $result = array();
        $result_contributor = array();
        $result_price = array();
        $result_subject = array();
        $identifier_array = array();
        $error_array = array();
        $result_identifier = array();
        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        $_POST = json_decode(file_get_contents('php://input'), true);
        if (!$this->custom_function->check_access_token()) {
            $retarray['error'] = 2;
            $retarray['errorMsg'] = $this->lang->line('session_expired');
            echo json_encode($retarray);
            exit;
        }

        $book_id = $this->input->post('catalog_id');
        if (!empty($book_id)) {
            //Get catalog details
            $result = $this->catalog_model->get_book_details_by_id($book_id);
            if (is_object($result) && count($result) > 0) {
                $retarray['error'] = 0;
                //Catalog Details
                $result_contributor = $this->catalog_model->get_book_contributor_detail_by_id($book_id);
                $result_price = $this->catalog_model->get_book_price_detail_by_id($book_id);
                $result_subject = $this->catalog_model->get_book_subject_detail_by_id($book_id);
                $identifier_array= $this->catalog_model->get_book_identifier_detail_by_id($book_id);
                $error_array = array("error"=>false,"identifiermessage"=>'');
                foreach ($identifier_array as $key=>$val){
                    $result_identifier[]=array_merge($identifier_array[$key],$error_array);
                }
                $retarray['response']['catalog'] = array('id' => $result->id,
                    'title' => stripslashes($result->title),
                    'image' => (!empty($result->image) && file_exists($path . '/' . $result->image)) ? base_url() . 'assets/images/bookcovers/' . $result->image : base_url() . 'assets/images/bookcovers/img-cover.png',
                    'sub_title' => $result->sub_title,
                    'volume' => $result->volume,
                    'edition' => $result->edition,
                    'contributor' => (!empty($result_contributor)) ? $result_contributor : array(),
                    'identifier' => (!empty($result_identifier)) ? $result_identifier : array(),
                    'publisher' => $result->publisher,
                    'imprint' => $result->imprint,
                    'publication_date' =>(!empty($result->publication_date)) ?date('m/d/Y',strtotime($result->publication_date)):NULL,
                    'priceArr' => (!empty($result_price)) ?$result_price : array(),
                    'language' => $result->language,
                    'language_id' => $result->language_id,
                    'subject_id' => (!empty($result_subject)) ? $result_subject : array(),
                    'main_subject_id' => $result->main_subject_id,
                    'description' => strip_tags($result->description),
                    'short_description' => (strlen($result->description) > 50) ? substr($result->description, 0, 50) . ".." : $result->description,
                    'keywords' => $result->keywords,
                    'age_range' => $result->age_range,
                    'us_grade_range' => $result->us_grade_range,
                    'region_id' => (!empty($result->region_id)) ? explode(',', $result->region_id) : array(),
                    'region_name' => (!empty($result->region_name)) ? explode(',', $result->region_name) : array(),
                    'country_id' => (!empty($result->country_name)) ? explode(',', $result->country_name) : array(),
                    'audience_id' => $result->audience_id,
                    'copyright_year' => (!empty($result->copyright_year) || $result->copyright_year!=0000)?$result->copyright_year:NULL,
                    'copyright_owner' => $result->copyright_owner,
                    'supplier_details' => $result->supplier_details,
                    'supply_date' => (!empty($result->supply_date)) ? date('m/d/Y',strtotime($result->supply_date)):NULL,
                    'title_availability' =>(!empty($result->title_availability)) ?date('m/d/Y',strtotime($result->title_availability)):NULL,
                    'countries_included' => $result->countries_included,
                    'cover_image' =>(!empty($result->cover_image) && file_exists($path . '/' . $result->cover_image)) ? base_url() . 'assets/images/bookcovers/' . $result->cover_image : base_url() . 'assets/images/bookcovers/img-cover.png',
                    'original_image' =>(!empty($result->cover_image) && file_exists($path . '/' . $result->cover_image)) ?$result->cover_image :''
                );
                //Catalog reviews
                $retarray['response']['catalog_reviews'] = $this->catalog_model->get_book_reviews_by_id($book_id);
                //Catalog awards
                $retarray['response']['catalog_awards'] = $this->catalog_model->get_book_awards_by_id($book_id);
                //Catalog related product
                $retarray['response']['catalog_related_products'] = $this->catalog_model->get_book_related_product_by_id($book_id);
            } else {
                $retarray['error'] = 0;
                $retarray['response'] = array();
            }
        } else {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = $this->lang->line('technical_error');
        }
        echo json_encode($retarray);
    }

    /**
     * Tag list
     *
     * @access	public
     * @param   access_token,language
     * @return	JSON Array
     */
    public function get_tag_list() {
        $retarray = array();
        $common_result = array();

        //Get user_id and company_id
        $common_result = $this->custom_function->_common();
        if ($common_result['error'] == 0) {
            $retarray['error'] = 0;
            //Catalog tag list
            $retarray['response'] = $this->catalog_model->get_tag_list($common_result['company_id']);
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Tag list by search
     *
     * @access	public
     * @param   access_token,language,tagText
     * @return	JSON Array
     */
    public function get_tag_list_by_search() {
        $retarray = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common();
        if ($common_result['error'] == 0) {
            $search = addslashes(strtolower($this->input->post('tagText')));
            $retarray['error'] = 0;
            //Get tag list by search
            $result = $this->catalog_model->get_tag_list_by_search($common_result['company_id'], $search);

            if (is_array($result) && count($result) > 0) {
                $i = 0;
                foreach ($result as $key => $val) {
                    //Tag name
                    $retarray['response'][] = $result[$key]['name'];
                    $i++;
                }
            } else {
                $retarray['error'] = 0;
                $retarray['response'] = array();
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Insert tag data
     *
     * @access	public
     * @param   access_token,language,tag_name
     * @return	JSON Array
     */
    public function add_tag() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        $this->form_validation->set_rules('tag_name', 'Tag name', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $tag_name = addslashes(strtoupper($this->input->post('tag_name')));
            $created_on = date('Y-m-d H:i:s');

            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                //Insert tag data
                $tag_data = array("name" => $tag_name,
                    "publisher_id" => $common_result['company_id'],
                    "created_on" => $created_on,
                    "created_by" => $common_result['user_id']);
                //Get tag
                $result = $this->catalog_model->get_tag_by_company_id($common_result['company_id'], $tag_name);
                if (!$result) {
                    $retarray['error'] = 0;
                    $this->catalog_model->insert_tag($tag_data);
                    //Tag list
                    $retarray['response'] = $this->catalog_model->get_tag_list($common_result['company_id']);
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('available_tag');
                }
            } else {
                $retarray = $common_result;
            }
        }
        echo json_encode($retarray);
    }

    /**
     * Update tag data
     *
     * @access	public
     * @param	access_token,language,tag_name,original_tag_name
     * @return	JSON Array
     */
    public function update_tag() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //server side validations
        $this->form_validation->set_rules('original_tag_name', 'Original tag name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('tag_name', 'Tag name', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $modified_on = date('Y-m-d H:i:s');
            $tag_name = addslashes($this->input->post('tag_name'));
            $original_tag_name = $this->input->post('original_tag_name');
            $tag_id = $this->input->post('tag_id');

            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                if (strtolower($original_tag_name) != strtolower($tag_name)) {
                    //Update tag data
                    $tag_data = array("name" => strtoupper($tag_name),
                        "modified_on" => $modified_on,
                        "modified_by" => $common_result['user_id']);
                    //Get tag
                    $result = $this->catalog_model->get_tag_by_company_id($common_result['company_id'], $tag_name);
                    if ($result == 0) {
                        $retarray['error'] = 0;
                        $this->catalog_model->update_tag($tag_data, $common_result['company_id'], $tag_id);
                        //Tag list
                        $retarray['response'] = $this->catalog_model->get_tag_list($common_result['company_id']);
                    } else {
                        $retarray['error'] = 1;
                        $retarray['errorMsg'] = $this->lang->line('available_tag');
                    }
                } else {
                    $retarray['error'] = 0;
                }
            } else {
                $retarray = $common_result;
            }
        }
        echo json_encode($retarray);
    }

    /**
     * Delete tag data
     *
     * @access	public
     * @param	access_token,language,tag_id
     * @return	JSON Array
     */
    public function delete_tag() {
        $retarray = array();
        $common_result = array();
        $deleted_on = date('Y-m-d H:i:s');
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $tag_id = $this->input->post("tag_id");
            //Delete tag data
            $tag_data = array("deleted_on" => $deleted_on,
                "deleted_by" => $common_result['user_id']);
            $this->catalog_model->update_tag($tag_data, $common_result['company_id'], $tag_id);
            $this->catalog_model->update_book_tag($tag_data, $tag_id);
            $retarray['error'] = 0;
            //Tag list
            $retarray['response'] = $this->catalog_model->get_tag_list($common_result['company_id']);
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Insert tag by selection
     *
     * @access	public
     * @param	access_token,language,bookListArr,tagListArr
     * @return	JSON Array
     */
    public function insert_catalog_tag_by_selection() {
        $retarray = array();
        $result = array();
        $book_tag_data = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        $created_on = date('Y-m-d H:i:s');
        $catalog_array = $this->input->post("bookListArr");
        $tag_array = $this->input->post("tagListArr");

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {

            if (!empty($tag_array)) {
                //Tag Selected
                $update_book_tag_data = array("deleted_on"=>NULL,
                                                          "deleted_by"=>0);
                if (is_array($catalog_array) && count($catalog_array) > 0) {
                    foreach ($catalog_array as $key => $val) {
                        $this->catalog_model->update_book_tag_by_book_id($update_book_tag_data,$val['id'],$tag_array);
                        foreach ($tag_array as $ta) {
                            //Insert book tag data
                            $book_tag_data[] = array("book_id" => $val['id'],
                                "tag_id" => $ta,
                                "created_on" => $created_on,
                                "created_by" => $common_result['user_id']);
                        }
                    }
                    $this->catalog_model->insert_book_tag($book_tag_data);
                    $retarray['error'] = 0;
                    $retarray['msg'] = $this->lang->line('applied_tag');
                } else if (is_array($catalog_array) && empty($catalog_array)) {
                    //Tag All
                    $result = $this->catalog_model->get_book_id($common_result['company_id']);
                    if (is_array($result) && count($result) > 0) {
                        foreach ($result as $key => $val) {
                            $this->catalog_model->update_book_tag_by_book_id($update_book_tag_data,$val['id'],$tag_array);
                            foreach ($tag_array as $ta) {
                                //Insert book tag data
                                $book_tag_data[] = array("book_id" => $val['id'],
                                    "tag_id" => $ta,
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }
                        }
                        $this->catalog_model->insert_book_tag($book_tag_data);
                        $retarray['error'] = 0;
                        $retarray['msg'] = $this->lang->line('applied_tag');
                    }
                }
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Insert tag for one book
     *
     * @access	public
     * @param	access_token,language,book_id,tagArr
     * @return	JSON Array
     */
    public function insert_individual_catalog_tag() {
        $retarray = array();
        $result = array();
        $book_tag_data = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        $created_on = date('Y-m-d H:i:s');

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $book_id = $this->input->post("book_id");
            $tag_array = array_map('strtolower', $this->input->post("tagArr"));
            if (!empty($tag_array)) {
                //Check book tag
                $result = $this->catalog_model->check_book_tag($tag_array, $common_result['company_id']);
                if (is_object($result) && !empty($result->tag_names)) {
                    $existing_tag_array = array_map('strtolower', explode(',', $result->tag_names));
                    $this->catalog_model->delete_all_book_tags_by_id($book_id);
                    $tag_ids = explode(',', $result->tag_ids);
                    foreach ($tag_ids as $ti) {
                        //Insert book tag data
                        $book_tag_data[] = array("book_id" => $book_id,
                            "tag_id" => $ti,
                            "created_on" => $created_on,
                            "created_by" => $common_result['user_id']);
                    }
                    $this->catalog_model->insert_book_tag_for_individual_book($book_tag_data);
                    $remaining_tag_array = array_diff($tag_array, $existing_tag_array);
                } else {
                    $remaining_tag_array = $tag_array;
                }
                if (is_array($remaining_tag_array) && count($remaining_tag_array) > 0) {
                    foreach ($remaining_tag_array as $rta) {
                        //Insert tag data
                        $tag_data[] = array("name" => addslashes(strtoupper($rta)),
                            "publisher_id" => $common_result['company_id'],
                            "created_on" => $created_on,
                            "created_by" => $common_result['user_id']);
                    }
                    $this->catalog_model->insert_tag_for_individual_book($tag_data, $book_id, $common_result['user_id']);
                }
            } else {
                //delete book tag data
                $deleted_on = date('Y-m-d H:i:s');
                $book_tag_data = array("deleted_on" => $deleted_on,
                    "deleted_by" => $common_result['user_id']);
                $this->catalog_model->delete_book_tags_by_id($book_id, $book_tag_data);
            }
            $retarray['error'] = 0;
            $retarray['msg'] = $this->lang->line("tag_update_success");
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Add book
     *
     * @access	public
     * @param	access_token,language,bookDetail,bookReview,bookAward,relatedProduct
     * @return	JSON Array
     */
    public function add_catalog() {
        $retarray = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $book_detail = $this->input->post("bookDetail");
            $cover_image = $_POST['bookDetail']['cover_image'];
            $book_review_array = $this->input->post("bookReview");
            $book_award_array = $this->input->post("bookAward");
            $book_related_array = $this->input->post("relatedProduct");
            if (is_array($book_detail) && count($book_detail) > 0) {
                $result = $this->catalog_model->check_book_title(addslashes($book_detail['title']), $common_result['company_id']);
                if ($result) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line("book_title_exists");
                    echo json_encode($retarray);
                    exit;
                }
                if (!empty($book_detail['identifier'])) {
                    $identifier_array = array();
                    foreach ($book_detail['identifier'] as $key=>$val){
                        array_push($identifier_array,$book_detail['identifier'][$key]['identifiername']);
                    }
                    $result_identifier = $this->catalog_model->check_identifier($identifier_array,$common_result['company_id']);
                    if($result_identifier){
                        $retarray['error'] = 1;
                        $retarray['errorMsg'] = $this->lang->line("identifier_no_exists");
                        echo json_encode($retarray);
                        exit;
                    }
                }
                $created_on = date('Y-m-d H:i:s');
                //Server side validation
                foreach ($book_detail as $key=>$val){
                    $this->form_validation->set_rules("bookDetail[".$key."]", $key, 'trim|xss_clean');
                    if(is_array($book_detail[$key])){
                        ($key=="contributor")?$this->form_validation->set_rules("bookDetail[".$key."]", "Contributor", 'trim|required|xss_clean'):"";
                        ($key=="priceArr")?$this->form_validation->set_rules("bookDetail[".$key."]", "Price", 'trim|required|xss_clean'):"";
                        ($key=="subject_id")?$this->form_validation->set_rules("bookDetail[".$key."]", "Subject", 'trim|required|xss_clean'):"";
                    }else{
                        ($key=="title")? $this->form_validation->set_rules("bookDetail[".$key."]", "Title", 'trim|required|xss_clean'):'';
                        ($key=="copyright_year")? $this->form_validation->set_rules("bookDetail[".$key."]", "Copyright Year", 'trim|required|xss_clean'):'';
                        ($key=="copyright_owner")? $this->form_validation->set_rules("bookDetail[".$key."]", "Copyright Owner", 'trim|required|xss_clean'):'';
                    }
                }

                if ($this->form_validation->run() == FALSE) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = validation_errors();
                } else {
                    $res = $this->_book_cover($cover_image, $common_result['company_id']);
                    if($res==1){
                        $retarray['error']=1;
                        $retarray['errorMsg']="The image you are attempting to upload doesn't fit into the allowed dimensions.(400*325)";
                        echo json_encode($retarray);
                        exit;
                    }
                    //Insert book data
                    $book_data = array("company_id" => $common_result['company_id'],
                        "title" => addslashes($book_detail['title']),
                        "sub_title" => $book_detail['sub_title'],
                        "description" => addslashes($book_detail['description']),
                        "volume" => addslashes($book_detail['volume']),
                        "edition" => addslashes($book_detail['edition']),
                        "keywords" => addslashes($book_detail['keywords']),
                        "min_age_range" => $book_detail['min_age_range'],
                        "max_age_range" => $book_detail['max_age_range'],
                        "min_us_grade_range" => $book_detail['min_us_grade_range'],
                        "max_us_grade_range" => $book_detail['max_us_grade_range'],
                        "imprint" => $book_detail['imprint'],
                        "language_id" => $book_detail['language_id'],
                        "main_subject_id" => $book_detail['main_subject_id'],
                        "publication_date" => (!empty($book_detail['publication_date'])) ? date('Y-m-d', strtotime($book_detail['publication_date'])) : NULL,
                        "audience_id" => $book_detail['audience_id'],
                        "copyright_year" =>(!empty($book_detail['copyright_year']))?$book_detail['copyright_year']:0000,
                        "copyright_owner" => addslashes($book_detail['copyright_owner']),
                        "supplier_details" => addslashes($book_detail['supplier_details']),
                        "supply_date" => (!empty($book_detail['supply_date'])) ? date('Y-m-d', strtotime($book_detail['supply_date'])) : NULL,
                        "title_availability" => (!empty($book_detail['title_availability'])) ? date('Y-m-d', strtotime($book_detail['title_availability'])) : NULL,
                        "cover_image" => $res,
                        "created_on" => $created_on,
                        "created_by" => $common_result['user_id']);
//                    echo "<pre>";print_r($book_data);exit;
                    $book_id = $this->catalog_model->insert_book($book_data);
                    unset($book_data);
                    if ($book_id > 0) {
                        if (!empty($book_detail['contributor'])) {
                            foreach ($book_detail['contributor'] as $key => $val) {
                                $person_id = $this->catalog_model->check_contributor_people(stripslashes(strtolower($book_detail['contributor'][$key]['contributorname'])));
                                //Insert book contributor
                                $book_contributor_data[] = array("book_id" => $book_id,
                                    "role_id" => $book_detail['contributor'][$key]['contributorrole'],
                                    "person_id" => $person_id,
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }
                            $this->catalog_model->insert_book_contributor($book_contributor_data);
                            unset($book_contributor_data);
                        }
                        if (!empty($book_detail['identifier'])) {
                            foreach ($book_detail['identifier'] as $key => $val) {
                                //Insert book identifier
                                $book_identifier_data[] = array("book_id" => $book_id,
                                    "identifier_type_id" => $book_detail['identifier'][$key]['identifiertype'],
                                    "identifier_no" => $book_detail['identifier'][$key]['identifiername'],
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }
                            $this->catalog_model->insert_book_identifier($book_identifier_data);
                            unset($book_identifier_data);
                        }
                        if (!empty($book_detail['priceArr'])) {
                            foreach ($book_detail['priceArr'] as $key => $val) {
                                //Insert book price
                                $book_price_data[] = array("book_id" => $book_id,
                                    "price" => $book_detail['priceArr'][$key]['price'],
                                    "currency_id" => $book_detail['priceArr'][$key]['currency_id'],
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }
                            $this->catalog_model->insert_book_price($book_price_data);
                            unset($book_price_data);
                        }
                        if (!empty($book_detail['subject_id'])) {
                            foreach ($book_detail['subject_id'] as $key => $val) {
                                //Insert subject data
                                $book_subject_data[] = array("book_id" => $book_id,
                                    "subject_id" => $book_detail['subject_id'][$key]['id'],
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }
                            $this->catalog_model->insert_book_subject($book_subject_data);
                            unset($book_subject_data);
                        }
                        if (!empty($book_detail['region_id'])) {
                            if(in_array(1,$book_detail['region_id']) && empty($book_detail['country_id'])){
                                //Insert book region
                                $book_region_data[] = array("book_id" => $book_id,
                                    "region_id" => 1,
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                                $proceed =0;
                            }else if(!empty($book_detail['country_id'])){
                                if(in_array(1,$book_detail['region_id'])){
                                    $result = $this->catalog_model->get_region_by_country($book_detail['country_id']);
                                    if(is_object($result) && !empty($result->region_ids)){
                                        $region = explode(',', $result->region_ids);
                                        foreach ($region as $r) {
                                            //insert book region
                                            $book_region_data[] = array("book_id" => $book_id,
                                                "region_id" => $r,
                                                "created_on" => $created_on,
                                                "created_by" => $common_result['user_id']);
                                        }
                                        $proceed =1;
                                    }
                                }else{
                                    foreach ($book_detail['region_id'] as $br) {
                                        //Insert book region
                                        $book_region_data[] = array("book_id" => $book_id,
                                            "region_id" => $br,
                                            "created_on" => $created_on,
                                            "created_by" => $common_result['user_id']);
                                    }
                                    $proceed =1;
                                }
                            }
                            $this->catalog_model->insert_book_region($book_region_data);
                            unset($book_region_data);

                            if($proceed ==1){
                                foreach ($book_detail['country_id'] as $bc) {
                                    //Insert book country
                                    $book_country_data[] = array("book_id" => $book_id,
                                        "country_id" => $bc,
                                        "created_on" => $created_on,
                                        "created_by" => $common_result['user_id']);
                                }
                                $this->catalog_model->insert_book_country($book_country_data);
                                unset($book_country_data);
                            }
                        }
                        if (is_array($book_review_array) && count($book_review_array) > 0) {
                            foreach ($book_review_array as $key => $val) {
                                //Insert book review
                                $book_review_data[] = array("book_id" => $book_id,
                                    "source_id" => $book_review_array[$key]['reviewsource']['id'],
                                    "type_id" => $book_review_array[$key]['reviewtype']['id'],
                                    "title" => addslashes($book_review_array[$key]['reviewtitle']),
                                    "review_text" => addslashes($book_review_array[$key]['reviewtext']),
                                    "url" => $book_review_array[$key]['reviewurl'],
                                    "review_date" =>(!empty($book_review_array[$key]['reviewdate']))? date('Y-m-d', strtotime($book_review_array[$key]['reviewdate'])):NULL,
                                    "review_date_role_id" => $book_review_array[$key]['reviewrole']['id'],
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id'],
                                );
                            }
                            $this->catalog_model->insert_book_review($book_review_data);
                            unset($book_review_data);
                        }
                        if (is_array($book_award_array) && count($book_award_array) > 0) {
                            foreach ($book_award_array as $key => $val) {
                                $award_id = $this->catalog_model->check_award_name(stripslashes(strtolower($book_award_array[$key]['awardname'])));
                                //Insert award data
                                $book_award_data[] = array("book_id" => $book_id,
                                    "award_id" => $award_id,
                                    "award_code_id" => $book_award_array[$key]['awardcode']['id'],
                                    "year" => $book_award_array[$key]['awardyear'],
                                    "country_id" => $book_award_array[$key]['awardcountry']['id'],
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id'],
                                );
                            }
                            $this->catalog_model->insert_book_award($book_award_data);
                            unset($book_award_data);
                        }
                        if (is_array($book_related_array) && count($book_related_array) > 0) {
                            foreach ($book_related_array as $key => $val) {
                                //Insert book related data
                                $book_related_data[] = array("book_id" => $book_id,
                                    "relation_code_id" => $book_related_array[$key]['relatedcode']['id'],
                                    "identifier_type_id" => $book_related_array[$key]['identifiertype']['id'],
                                    "identifier" => $book_related_array[$key]['identifiername'],
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id'],
                                );
                            }
                            $this->catalog_model->insert_book_related($book_related_data);
                            unset($book_related_data);
                        }
                        $retarray['error'] = 0;
                        $retarray['msg'] = $this->lang->line("book_insert_success");
                    }
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("insufficient_book_detail");
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * update book
     *
     * @access	public
     * @param	access_token,language,bookDetail,bookReview,bookAward,relatedProduct
     * @return	JSON Array
     */
    public function update_catalog() {
        $retarray = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {

            $book_id = $this->input->post("book_id");
            $book_detail = $this->input->post("bookDetail");
            $cover_image = $_POST['bookDetail']['cover_image'];
            $book_review_array = $this->input->post("bookReview");
            $book_award_array = $this->input->post("bookAward");
            $book_related_array = $this->input->post("relatedProduct");
            if (is_array($book_detail) && count($book_detail) > 0) {
                $result = $this->catalog_model->check_book_title_by_id(addslashes($book_detail['title']), $common_result['company_id'], $book_id);
                if ($result) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line("book_title_exists");
                    echo json_encode($retarray);
                    exit;
                }
                if (!empty($book_detail['identifier'])) {
                    $identifier_array = array();
                    foreach ($book_detail['identifier'] as $key=>$val){
                        array_push($identifier_array,$book_detail['identifier'][$key]['identifiername']);
                    }
                    $result_identifier = $this->catalog_model->check_identifier($identifier_array,$common_result['company_id'],$book_id);
                    if($result_identifier){
                        $retarray['error'] = 1;
                        $retarray['errorMsg'] = $this->lang->line("identifier_no_exists");
                        echo json_encode($retarray);
                        exit;
                    }
                }
                $modified_on = date('Y-m-d H:i:s');
                foreach ($book_detail as $key=>$val){
                    $this->form_validation->set_rules("bookDetail[".$key."]", $key, 'trim|xss_clean');
                    if(is_array($book_detail[$key])){
                        ($key=="contributor")?$this->form_validation->set_rules("bookDetail[".$key."]", "Contributor", 'trim|required|xss_clean'):"";
                        ($key=="priceArr")?$this->form_validation->set_rules("bookDetail[".$key."]", "Price", 'trim|required|xss_clean'):"";
                        ($key=="subject_id")?$this->form_validation->set_rules("bookDetail[".$key."]", "Subject", 'trim|required|xss_clean'):"";
                    }else{
                        ($key=="title")? $this->form_validation->set_rules("bookDetail[".$key."]", "Title", 'trim|required|xss_clean'):'';
                        ($key=="copyright_year")? $this->form_validation->set_rules("bookDetail[".$key."]", "Copyright Year", 'trim|required|xss_clean'):'';
                        ($key=="copyright_owner")? $this->form_validation->set_rules("bookDetail[".$key."]", "Copyright Owner", 'trim|required|xss_clean'):'';
                    }
                }

                if ($this->form_validation->run() == FALSE) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = validation_errors();
                } else {
                    $res = $this->_book_cover($cover_image, $common_result['company_id'], $book_id, $book_detail['original_image']);
                    if($res==1){
                        $retarray['error']=1;
                        $retarray['errorMsg']="The image you are attempting to upload doesn't fit into the allowed dimensions.(400*325)";
                        echo json_encode($retarray);
                        exit;
                    }
                    //Update book data
                    $book_data = array("company_id" => $common_result['company_id'],
                        "title" => addslashes($book_detail['title']),
                        "sub_title" => $book_detail['sub_title'],
                        "description" => addslashes($book_detail['description']),
                        "volume" => addslashes($book_detail['volume']),
                        "edition" => addslashes($book_detail['edition']),
                        "keywords" => addslashes($book_detail['keywords']),
                        "min_age_range" => $book_detail['min_age_range'],
                        "max_age_range" => $book_detail['max_age_range'],
                        "min_us_grade_range" => $book_detail['min_us_grade_range'],
                        "max_us_grade_range" => $book_detail['max_us_grade_range'],
                        "imprint" => $book_detail['imprint'],
                        "language_id" => $book_detail['language_id'],
                        "main_subject_id" => $book_detail['main_subject_id'],
                        "publication_date" =>(!empty($book_detail['publication_date']))? date('Y-m-d', strtotime($book_detail['publication_date'])):NULL,
                        "audience_id" => $book_detail['audience_id'],
                        "copyright_year" =>(!empty($book_detail['copyright_year']))?$book_detail['copyright_year']:0000,
                        "copyright_owner" => addslashes($book_detail['copyright_owner']),
                        "supplier_details" => addslashes($book_detail['supplier_details']),
                        "supply_date" => (!empty($book_detail['supply_date']))? date('Y-m-d', strtotime($book_detail['supply_date'])):NULL,
                        "title_availability" =>(!empty($book_detail['title_availability']))? date('Y-m-d', strtotime($book_detail['title_availability'])):NULL,
                        "cover_image" => $res,
                        "modified_on" => $modified_on,
                        "modified_by" => $common_result['user_id']);
                        $this->catalog_model->update_book($book_data, $book_id);
                        unset($book_data);
                        if ($book_id > 0) {
                            $created_on = date('Y-m-d H:i:s');
                            $deleted_on = date('Y-m-d H:i:s');
                            $delete_book_data = array("deleted_on"=>$deleted_on,
                                                      "deleted_by"=>$common_result['user_id']);
                            $book_array = array($book_id);
                            $this->catalog_model->delete_books_data($delete_book_data,$book_array,1);

                            if(!empty($book_detail['contributor'])){
                                foreach ($book_detail['contributor'] as $key=>$val){
                                    $person_id = $this->catalog_model->check_contributor_people(stripslashes(strtolower($book_detail['contributor'][$key]['contributorname'])));
                                    //Insert book contributor data
                                    $book_contributor_data[] = array("book_id"=>$book_id,
                                                                   "role_id"=>$book_detail['contributor'][$key]['contributorrole'],
                                                                   "person_id"=>$person_id,
                                                                   "created_on"=>$created_on,
                                                                   "created_by"=>$common_result['user_id']);
                                }
                                $this->catalog_model->insert_book_contributor($book_contributor_data);
                                unset($book_contributor_data);
                            }
                            if(!empty($book_detail['identifier'])){
                                foreach ($book_detail['identifier'] as $key=>$val){
                                    //Insert book identifier data
                                    $book_identifier_data[] = array("book_id"=>$book_id,
                                                                   "identifier_type_id"=>$book_detail['identifier'][$key]['identifiertype'],
                                                                   "identifier_no"=>$book_detail['identifier'][$key]['identifiername'],
                                                                   "created_on"=>$created_on,
                                                                   "created_by"=>$common_result['user_id']);
                                }
                                $this->catalog_model->insert_book_identifier($book_identifier_data);
                                unset($book_identifier_data);
                            }
                            if(!empty($book_detail['priceArr'])){
                                foreach ($book_detail['priceArr'] as $key=>$val){
                                    //Insert book price data
                                    $book_price_data[] = array("book_id"=>$book_id,
                                                                   "price"=>$book_detail['priceArr'][$key]['price'],
                                                                   "currency_id"=>$book_detail['priceArr'][$key]['currency_id'],
                                                                   "created_on"=>$created_on,
                                                                   "created_by"=>$common_result['user_id']);
                                }
                                $this->catalog_model->insert_book_price($book_price_data);
                                unset($book_price_data);
                            }
                            if(!empty($book_detail['subject_id'])){
                                foreach ($book_detail['subject_id'] as $key=>$val){
                                    //Insert book subject data
                                    $book_subject_data[] = array("book_id"=>$book_id,
                                                                   "subject_id"=>$book_detail['subject_id'][$key]['id'],
                                                                   "created_on"=>$created_on,
                                                                   "created_by"=>$common_result['user_id']);
                                }
                                $this->catalog_model->insert_book_subject($book_subject_data);
                                unset($book_subject_data);
                            }
                            if (!empty($book_detail['region_id'])) {
                                if(in_array(1,$book_detail['region_id']) && empty($book_detail['country_id'])){
                                    //Insert book region data
                                    $book_region_data[] = array("book_id" => $book_id,
                                        "region_id" => 1,
                                        "created_on" => $created_on,
                                        "created_by" => $common_result['user_id']);
                                    $proceed =0;
                                }else if(!empty($book_detail['country_id'])){
                                    if(in_array(1,$book_detail['region_id'])){
                                        $result = $this->catalog_model->get_region_by_country($book_detail['country_id']);
                                        if(is_object($result) && !empty($result->region_ids)){
                                            $region = explode(',', $result->region_ids);
                                            foreach ($region as $r) {
                                                //Insert book region data
                                                $book_region_data[] = array("book_id" => $book_id,
                                                    "region_id" => $r,
                                                    "created_on" => $created_on,
                                                    "created_by" => $common_result['user_id']);
                                            }
                                            $proceed =1;
                                        }
                                    }else{
                                        foreach ($book_detail['region_id'] as $br) {
                                            //Insert book region data
                                            $book_region_data[] = array("book_id" => $book_id,
                                                "region_id" => $br,
                                                "created_on" => $created_on,
                                                "created_by" => $common_result['user_id']);
                                        }
                                        $proceed =1;
                                    }
                                }
                                $this->catalog_model->insert_book_region($book_region_data);
                                unset($book_region_data);

                                if($proceed ==1){
                                    foreach ($book_detail['country_id'] as $bc) {
                                        //Insert book country data
                                        $book_country_data[] = array("book_id" => $book_id,
                                            "country_id" => $bc,
                                            "created_on" => $created_on,
                                            "created_by" => $common_result['user_id']);
                                    }
                                    $this->catalog_model->insert_book_country($book_country_data);
                                    unset($book_country_data);
                                }
                            }

                            if (is_array($book_review_array) && count($book_review_array) > 0) {
                                foreach ($book_review_array as $key => $val) {
                                    //Insert book review data
                                    $book_review_data[] = array("book_id" => $book_id,
                                        "source_id" => $book_review_array[$key]['reviewsource']['id'],
                                        "type_id" =>$book_review_array[$key]['reviewtype']['id'],
                                        "title" => addslashes($book_review_array[$key]['reviewtitle']),
                                        "review_text" => addslashes($book_review_array[$key]['reviewtext']),
                                        "url" => $book_review_array[$key]['reviewurl'],
                                        "review_date" =>(!empty($book_review_array[$key]['reviewdate']))? date('Y-m-d', strtotime($book_review_array[$key]['reviewdate'])):NULL,
                                        "review_date_role_id" => $book_review_array[$key]['reviewrole']['id'],
                                        "created_on" => $created_on,
                                        "created_by" => $common_result['user_id'],
                                    );
                                }
                                $this->catalog_model->insert_book_review($book_review_data);
                                unset($book_review_data);
                            }
                            if (is_array($book_award_array) && count($book_award_array) > 0) {
                                foreach ($book_award_array as $key => $val) {
                                    $award_id = $this->catalog_model->check_award_name(stripslashes(strtolower($book_award_array[$key]['awardname'])));
                                    //Insert book award data
                                    $book_award_data[] = array("book_id" => $book_id,
                                        "award_id" => $award_id,
                                        "award_code_id" => $book_award_array[$key]['awardcode']['id'],
                                        "year" => $book_award_array[$key]['awardyear'],
                                        "country_id" => $book_award_array[$key]['awardcountry']['id'],
                                        "created_on" => $created_on,
                                        "created_by" => $common_result['user_id'],
                                    );
                                }
                                $this->catalog_model->insert_book_award($book_award_data);
                                unset($book_award_data);
                            }
                            if (is_array($book_related_array) && count($book_related_array) > 0) {
                                foreach ($book_related_array as $key => $val) {
                                    //Insert book related data
                                    $book_related_data[] = array("book_id" => $book_id,
                                        "relation_code_id" => $book_related_array[$key]['relatedcode']['id'],
                                        "identifier_type_id" => $book_related_array[$key]['identifiertype']['id'],
                                        "identifier" => $book_related_array[$key]['identifiername'],
                                        "created_on" => $created_on,
                                        "created_by" => $common_result['user_id'],
                                    );
                                }
                                $this->catalog_model->insert_book_related($book_related_data);
                                unset($book_related_data);
                            }
                    $retarray['error'] = 0;
                    $retarray['msg'] = $this->lang->line("book_update_success");
                        }
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("insufficient_book_detail");
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Profile image upload
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function _book_cover($cover_image, $company_id, $book_id=0, $original_image='') {
        $retarray = array();
        if($book_id > 0){
                if ($original_image!='') {
                    if(strpos($cover_image,$original_image) !== false){
                        return $filename = $original_image;
                    }
                }
                $path = realpath(PUBPATH . '../assets/images/bookcovers');
                if (($original_image!='') && file_exists($path . '/' .$original_image)) {
                    $result_file = pathinfo($path . '/' . $original_image);
                    //unlinking images
                    unlink($path . '/' . $original_image);
                }
        }
        $retarray = explode(",", $cover_image);
        if (!empty($retarray[1])) {
            $data = base64_decode($retarray[1]);
            list($width, $height) = getimagesize($cover_image);
            if($width < "400" || $height < "325") {
                return 1;
                exit;
            }

            $filename = "book" . "_" . $company_id . "_" . time(). ".jpeg";
            $path = '../assets/images/bookcovers/' . $filename;


            $success = file_put_contents($path, $data);

            return $filename;
        }
    }

    //Create Thumbnail function
    public function _createThumbnail($filename) {
        $config['image_library'] = "gd2";
        $config['source_image'] = "../assets/images/bookcovers/" . $filename;
        $config['create_thumb'] = TRUE;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = BOOK_THUMB_WIDTH;
        $config['height'] = BOOK_THUMB_HEIGHT;
        $config['overwrite'] = TRUE;

        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
    }

    /**
     * Delete book
     *
     * @access	public
     * @param	access_token,language,bookListArr
     * @return	JSON Array
     */
    public function delete_catalog() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $book_array = $this->input->post("bookListArr");
            $created_on = date('Y-m-d H;i:s');
            $deleted_on = date('Y-m-d H:i:s');
            if (is_array($book_array) && count($book_array) > 0) {
                $result = $this->catalog_model->check_group_books($book_array);
                if (is_object($result) && !empty($result->book_ids)) {
                    $existing_book_array = explode(',', $result->book_ids);
                    $remaining_book_array = array_diff($book_array, $existing_book_array);
                    if (empty($remaining_book_array)) {
                        $retarray['error'] = 1;
                        $retarray['errorMsg'] = $this->lang->line("book_exists_in_group");
                        echo json_encode($retarray);
                        exit;
                    }
                } else {
                    $remaining_book_array = $book_array;
                }
                $result = $this->catalog_model->get_book_price_by_id($remaining_book_array);
                if (is_array($result) && count($result) > 0) {
                    foreach ($result as $key => $val) {
                        //Insert book price history data
                        $book_price_data[] = array("book_id" => $result[$key]['book_id'],
                            "price" => $result[$key]['price'],
                            "currency_id" => $result[$key]['currency_id'],
                            "created_on" => $created_on,
                            "created_by" => $common_result['user_id']
                        );
                    }
                    $this->catalog_model->insert_book_price_history($book_price_data);
                }
                $this->catalog_model->delete_book_prices_by_id($remaining_book_array);
                //Delete book data
                $book_data = array("deleted_on" => $deleted_on,
                    "deleted_by" => $common_result['user_id']);
                $this->catalog_model->delete_books_data($book_data, $remaining_book_array);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line("book_delete_success");
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("select_book");
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Maintain Books list
     *
     * @access	public
     * @param	access_token,language,
     *          pageStart,pageLimit,
     *          sortField,sorttype,search_title,search_author,search_imprint,search_publisher
     * @return	JSON Array
     */
    public function get_maintain_books_list() {
        $retarray = array();
        $result = array();
        $id_array = array();
        $common_result = array();

        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        $_POST = json_decode(file_get_contents('php://input'), true);
        $pageStart = (!empty($this->input->post('pageStart'))) ? $this->input->post('pageStart') : 0;
        $pageLimit = (!empty($this->input->post('pageLimit'))) ? $this->input->post('pageLimit') : 10;
        $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'b.publication_date';
        $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'DESC';

        $this->form_validation->set_rules('search_title', 'Search value', 'trim|xss_clean');
        $this->form_validation->set_rules('search_author', 'Search tag value', 'trim|xss_clean');
        $this->form_validation->set_rules('search_imprint', 'Search tag value', 'trim|xss_clean');
        $this->form_validation->set_rules('search_publisher', 'Search tag value', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $search_title = addslashes(strtolower($this->input->post('search_title')));
            $search_author = addslashes(strtolower($this->input->post('search_author')));
            $search_imprint = addslashes(strtolower($this->input->post('search_imprint')));
            $search_publisher = addslashes(strtolower($this->input->post('search_publisher')));

            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                $retarray['error'] = 0;
                //Get book list
                $result = $this->catalog_model->get_maintain_books_list($common_result['company_id'], $pageStart, $pageLimit, $sortField, $sortType, $search_title, $search_author, $search_imprint, $search_publisher);
                $retarray['found_rows'] = $this->general_model->found_rows();
                $wherearr = array('company_id' => $common_result['company_id']);
                $retarray['total_rows'] = $this->catalog_model->get_maintain_books_list_count($common_result['company_id'], $search_title, $search_author, $search_imprint, $search_publisher);

                $i = 0;
                if (is_array($result) && count($result) > 0) {
                    $retarray['error'] = 0;
                    foreach ($result as $key => $val) {
                        array_push($id_array, $result[$key]['id']);
                        //Book list
                        $retarray['response'][$i] = array('id' => $result[$key]['id'],
                            'title' => stripslashes($result[$key]['title']),
                            'image' => (!empty($result[$key]['image']) && file_exists($path . '/' . $result[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $result[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png',
                            'author' => (strlen($result[$key]['author']) > 20) ? substr($result[$key]['author'], 0, 20) . ".." : $result[$key]['author'],
                            'publication_date' =>(!empty($result[$key]['publication_date']))?date('m/d/Y', strtotime($result[$key]['publication_date'])):NULL,
                            'imprint' => $result[$key]['imprint'],
                            'identifier_no' => (strlen($result[$key]['identifier_no']) > 20) ? substr($result[$key]['identifier_no'], 0, 20) . ".." : $result[$key]['identifier_no'],
                            'publisher' => stripslashes($result[$key]['publisher']),
                        );
                        $i++;
                    }
                    $retarray['ids'] = implode(',', $id_array);
                } else {
                    $retarray = array("error" => 0,
                        "found_rows" => 0,
                        "total_rows" => 0,
                        "response" => array(),
                        "ids" => '');
                }
            } else {
                $retarray = $common_result;
            }
        }
        echo json_encode($retarray);
    }

}
