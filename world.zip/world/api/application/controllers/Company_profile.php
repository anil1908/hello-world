<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Company_profile extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('company_profile_model');
        $this->load->model('users_model');
        $this->load->model('general_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * Company profile details
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_company_profile() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $company_id = 0;

        $path = realpath(PUBPATH . '../assets/images/companyprofile');
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            //Get company details
            $result = $this->company_profile_model->get_company_details_by_id($common_result['company_id']);
            if (is_object($result) && count($result) > 0) {
                //Company data
                $retarray['response']['company'] = array('name' => $result->name,
                    'address' => $result->address,
                    'contact_no' => $result->contact_no,
                    'contact_person' => $result->contact_person);
                $retarray['response']['financial'] = array('bank_name' => $result->bank_name,
                    'bank_address' => $result->bank_address,
                    'routing_number' => $result->routing_number,
                    'account_number' => $result->account_number,
                    'dwolla_account_number' => $result->dwolla_account_number);
                $retarray['response']['logo'] = (!empty($result->logo) && file_exists($path . '/' . $result->logo)) ? base_url() . 'assets/images/companyprofile/' . $result->logo : base_url() . 'assets/images/companyprofile/profilepicture.jpg';
                $retarray['response']['is_image'] = (!empty($result->logo) && file_exists($path . '/' . $result->logo)) ? 1 : 0;
                $retarray['error'] = 0;
            } else {
                $retarray['error'] = 0;
                $retarray['response'] = array();
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Change company profile Information
     *
     * @access	public
     * @param	name,address,contact_no,contact_person,access_token,language
     * @return	JSON Array
     */
    public function update_company_profile() {
        $retarray = array();
        $common_result = array();
        $company_id = 0;

        $_POST = json_decode(file_get_contents('php://input'), true);

        //server side validation
        $this->form_validation->set_rules('name', 'Company Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('address', 'Address', 'trim|required|xss_clean');
        $this->form_validation->set_rules('contact_no', 'Contact Number', 'trim|required|xss_clean');
        $this->form_validation->set_rules('contact_person', 'Contact Person', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $name = $this->input->post('name');
            $address = $this->input->post('address');
            $contact_no = $this->input->post('contact_no');
            $contact_person = $this->input->post('contact_person');

            //Get user_id and company_id
            $common_result = $this->custom_function->_common();
            if ($common_result['error'] == 0) {
                //Update company data
                $company_data = array('name' => $name,
                    'address' => $address,
                    'contact_no' => $contact_no,
                    'contact_person' => $contact_person);

                $this->company_profile_model->update_company_data_by_id($company_data, $common_result['company_id']);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('update_company_profile');
            } else {
                $retarray = $common_result;
            }
            echo json_encode($retarray);
        }
    }

    /**
     * Change company profile financial Information
     *
     * @access	public
     * @param	bank_name,bank_address,routing_number,account_number,dwolla_account_number,access_token,language
     * @return	JSON Array
     */
    public function update_company_financial_info() {
        $retarray = array();
        $common_result = array();
        $company_id = 0;

        $_POST = json_decode(file_get_contents('php://input'), true);

        //server side validation
        $this->form_validation->set_rules('bank_name', 'Bank Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('bank_address', 'Bank Address', 'trim|required|xss_clean');
        $this->form_validation->set_rules('routing_number', 'Routing Number', 'trim|required|xss_clean');
        $this->form_validation->set_rules('account_number', 'Account Number', 'trim|required|xss_clean');
        $this->form_validation->set_rules('dwolla_account_number', 'Dwolla Account Number', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $bank_name = $this->input->post('bank_name');
            $bank_address = $this->input->post('bank_address');
            $routing_number = $this->input->post('routing_number');
            $account_number = $this->input->post('account_number');
            $dwolla_account_number = $this->input->post('dwolla_account_number');

            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                //Update company data
                $company_data = array('bank_name' => $bank_name,
                    'bank_address' => $bank_address,
                    'routing_number' => $routing_number,
                    'account_number' => $account_number,
                    'dwolla_account_number' => $dwolla_account_number);

                $this->company_profile_model->update_company_data_by_id($company_data, $common_result['company_id']);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('update_company_profile');
            }
            echo ($common_result['error'] == 1) ? json_encode($common_result) : json_encode($retarray);
        }
    }

    /**
     * Profile image upload
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function update_company_profile_image() {
        $retarray = array();
        $company_id = 0;
        if (!$this->custom_function->check_access_token(1)) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = $this->lang->line('session_expired');
            echo json_encode($retarray);
            exit;
        }

        $user_id = $this->custom_function->get_user_id_from_access_token(1);
        if (!empty($user_id)) {
            if ($user_id == $this->session->userdata('user_id')) {
                $company_id = $this->session->userdata('company_id');
            }

            $config['upload_path'] = COMPANY_PROFILE_UPLOAD_PATH;
            $config['allowed_types'] = ALLOWED_FILE_TYPE;
            $config['max_size'] = MAX_FILE_SIZE;
            $config['max_width'] = COMPANY_PROFILE_MAX_WIDTH;
            $config['max_height'] = COMPANY_PROFILE_MAX_HEIGHT;
            $config['file_name'] = "profile" . "_" . $company_id . "_" . time();

            $this->load->library('upload', $config);

            if (!$this->upload->do_upload('file')) {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->upload->display_errors();
                $retarray['thumbnail_name'] = base_url() . 'assets/images/companyprofile/profilepicture.jpg';
            } else {
                $finfo = $this->upload->data();
                if (!empty($company_id)) {
                    //Get company details
                    $result = $this->company_profile_model->get_company_details_by_id($company_id);
                    if (is_object($result) && count($result) > 0) {
                        $path = realpath(PUBPATH . '../assets/images/companyprofile');
                        if (!empty($result->logo) && file_exists($path . '/' . $result->logo)) {
                            $result_file = pathinfo($path . '/' . $result->logo);
                            //unlinking images
                            unlink($path . '/' . $result_file['filename'] . '_thumb.' . $result_file['extension']);
                            unlink($path . '/' . $result->logo);
                        }
                        $company_data = array("logo" => '');
                        $this->company_profile_model->update_company_data_by_id($company_data, $company_id);
                        $retarray['image'] = base_url() . 'assets/images/companyprofile/profilepicture.jpg';
                    }
                    $this->_createThumbnail($config['file_name'] . $finfo['file_ext']);
                    $company_data = array('logo' => $config['file_name'] . $finfo['file_ext']);
                    $this->company_profile_model->update_company_data_by_id($company_data, $company_id);
                    $retarray['thumbnail_name'] = base_url() . 'assets/images/companyprofile/' . $config['file_name'] . $finfo['file_ext'];
                    $retarray['error'] = 0;
                    $retarray['msg'] = $this->lang->line('update_company_profile');
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('technical_error');
                }
            }
        } else {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = $this->lang->line('technical_error');
        }
        echo json_encode($retarray);
    }

    //Create Thumbnail function
    public function _createThumbnail($filename) {
        $config['image_library'] = "gd2";
        $config['source_image'] = "../assets/images/companyprofile/" . $filename;
        $config['create_thumb'] = TRUE;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = COMPANY_PROFILE_THUMB_WIDTH;
        $config['height'] = COMPANY_PROFILE_THUMB_HEIGHT;
        $config['overwrite'] = TRUE;

        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
    }

    /**
     * Profile image remove
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function remove_company_profile_image() {
        $retarray = array();
        $result = array();
        $common_result = array();

        //Get user_id and company_id
        $common_result = $this->custom_function->_common();
        if ($common_result['error'] == 0) {
            //Get company details
            $result = $this->company_profile_model->get_company_details_by_id($common_result['company_id']);
            if (is_object($result) && count($result) > 0) {
                $path = realpath(PUBPATH . '../assets/images/companyprofile');
                if (!empty($result->logo) && file_exists($path . '/' . $result->logo)) {
                    $result_file = pathinfo($path . '/' . $result->logo);
                    //unlinking images
                    unlink($path . '/' . $result->logo);
                    unlink($path . '/' . $result_file['filename'] . '_thumb.' . $result_file['extension']);
                }
                $company_data = array("logo" => '');
                $this->company_profile_model->update_company_data_by_id($company_data, $common_result['company_id']);
                $retarray['error'] = 0;
                $retarray['image'] = base_url() . 'assets/images/companyprofile/profilepicture.jpg';
                $retarray['msg'] = $this->lang->line('update_company_profile');
            } else {
                $retarray['error'] = 1;
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Company users list
     *
     * @access	public
     * @param	access_token,language,pageStart,pageLimit,sortField,sorttype
     * @return	JSON Array
     */
    public function get_company_users() {
        $retarray = array();
        $result = array();
        $common_result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        $pageStart = (!empty($this->input->post('pageStart'))) ? $this->input->post('pageStart') : 0;
        $pageLimit = (!empty($this->input->post('pageLimit'))) ? $this->input->post('pageLimit') : 10;
        $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'u.created_on';
        $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'DESC';

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            //Get user details
            $result = $this->company_profile_model->get_users_data_by_company_id($common_result['company_id'], $pageStart, $pageLimit, $sortField, $sortType);
            $retarray['found_rows'] = $this->general_model->found_rows();
            $wherearr = array('company_id' => $common_result['company_id']);
            $retarray['total_rows'] = $this->general_model->total_rows($wherearr, 'users');
            $i = 0;
            if (is_array($result) && count($result) > 0) {
                $retarray['error'] = 0;
                foreach ($result as $key => $val) {
                    //Company users data
                    $retarray['response'][$i] = array('id' => $result[$key]['id'],
                        'email' => $result[$key]['email'],
                        'first_name' => $result[$key]['first_name'],
                        'last_name' => $result[$key]['last_name'],
                        'username' => $result[$key]['first_name'] . ' ' . $result[$key]['last_name'],
                        'created_on' => date('F d, Y', strtotime($result[$key]['created_on'])),
                        'created_by' => (!empty($result[$key]['created_by'])) ? $result[$key]['created_by'] : 'SELF',
                        'active' => ($result[$key]['status'] == 0) ? 'No' : 'Yes',
                        'action' => ($result[$key]['status'] == 0) ? 'Activate' : 'Deactivate',
                        'status' => $result[$key]['status'],
                        'is_confirm' => (int) $result[$key]['is_confirm'],
                    );
                    $i++;
                }
            } else {
                $retarray['error'] = 1;
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Invite user
     *
     * @access	public
     * @param	access_token,language,email_ids,rights_array,usertype
     * @return	JSON Array
     */
    public function send_invitation() {
        $retarray = array();
        $result = array();
        $users_data = array();
        $exist_email_ids = array();
        $common_result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);

        $this->form_validation->set_rules('email_ids', 'Email', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $email_ids = $this->input->post('email_ids');
            if (!empty($this->input->post('rights_array'))) {
                $modulearray = join(',', $this->input->post('rights_array'));
            } else {
                $modulearray = '';
            }
            $usertype = $this->input->post('usertype');
            $invited_date = date('Y-m-d H:i:s');

            //Get user_id and company_id
            $common_result = $this->custom_function->_common();
            if ($common_result['error'] == 0) {
                $email = explode(';', $email_ids);
                //Check email exist
                $result = $this->company_profile_model->email_exists($email);

                if (is_object($result) && !empty($result->email_exist)) {
                    $exist_email_ids = explode(',', $result->email_exist);
                    $errorMsg = "Below email(s) already exists.<br/>";
                    $errorMsg .= str_replace(',', '<br/>', $result->email_exist);
                    $retarray['errorMsg'] = $errorMsg;
                    $retarray['error'] = 1;
                    echo json_encode($retarray);
                    exit;
                }
                foreach ($email as $e) {
                    if (!in_array($e, $exist_email_ids)) {
                        //Insert user data
                        $users_data[] = array('email' => $e,
                            'company_id' => $common_result['company_id'],
                            'is_confirm' => 0,
                            'status' => 0,
                            'invited_by' => $common_result['user_id'],
                            'invited_date' => $invited_date,
                            'created_on' => $invited_date,
                            'created_by' => $common_result['user_id']);
                    }
                }

                $result_user = $this->company_profile_model->insert_user_details($users_data, $modulearray, $usertype);
                if (is_array($result_user) && count($result_user) > 0) {
                    $final_result = array_combine($result_user, $email);
                    foreach ($final_result as $key => $val) {
                        $data = array(
                            'signupurl' => base_url() . 'signup?u=' . $this->encrypt->encode($key, $this->config->item('encryption_key')),
                        );

                        $template = 'emails/invite_user.php';
                        $subject = '1World Content User Invitation';
                        //Send mail
                        $this->custom_function->send_mail($data, $val, $template, $subject);
                    }
                    $retarray['error'] = 0;
                    $retarray['msg'] = $this->lang->line('invite_user');
                } else {
                    $retarray['error'] = 1;
                }
            } else {
                $retarray = $common_result;
            }
        }
        echo json_encode($retarray);
    }

    /**
     * Re send invitation
     *
     * @access	public
     * @param	access_token,language,email,company_user_id
     * @return	JSON Array
     */
    public function resend_invitation() {
        $retarray = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        if (!$this->custom_function->check_access_token()) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = $this->lang->line('session_expired');
            echo json_encode($retarray);
            exit;
        }

        $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $company_user_id = $this->input->post('company_user_id');
            $email = $this->input->post('email');
            if (!empty($company_user_id)) {
                $data = array(
                    'signupurl' => base_url() . 'signup?u=' . $this->encrypt->encode($company_user_id, $this->config->item('encryption_key')),
                );

                $template = 'emails/invite_user.php';
                $subject = '1World Content User Invitation';
                //Send mail
                $this->custom_function->send_mail($data, $email, $template, $subject);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('invite_user');
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        }
        echo json_encode($retarray);
    }

}
