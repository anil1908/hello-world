<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('products_model');
    }

    public function index() {
        $this->load->view('products/products_list');
    }

    public function productlist() {

        $retarray = array();
        $retarray = $this->products_model->get_products_list();
        echo json_encode($retarray);
    }

    public function product_list_datatable() {
        $this->load->view('products/products_list_datatables');
    }

    public function product_list_datatable_ajax() {
        $this->load->view('products/products_list_datatables_ajax');
    }

    public function product_list_datatable_ajax_result() {

        $draw = $this->input->get_post('draw', true);
        $start = $this->input->get_post('start', true);
        $length = $this->input->get_post('length', true);
        $sortColumnarr = $this->input->get_post('columns', true);
        $orderarr = $this->input->get_post('order', true);
        $sortColumn = $sortColumnarr[$orderarr[0]['column']]['name'];
        $sortColumnDir = $orderarr[0]['dir'];
        $searcharr = $this->input->get_post('search', true);
        $searchValue = $searcharr['value'];
        $pageSize = $length != '' ? $length : 0;
        $skip = $start != '' ? $start : 0;
        $recordsTotal = 0;
        if (is_array($sortColumnarr) && count($sortColumnarr) > 0) {
            for ($c = 0; $c < count($sortColumnarr); $c++) {
                if (!empty($sortColumnarr[$c]['name']) && $sortColumnarr[$c]['name'] != 'select_all')
                    $column_names[] = $sortColumnarr[$c]['name'];
            }
        }
        // DB table to use
        $sTable = 'products';

        // Paging
        if (isset($start) && $length != '-1') {
            $this->db->limit($this->db->escape_str($length), $this->db->escape_str($start));
        }

        // Ordering
        if (!empty($sortColumn) && !empty($sortColumnDir)) {
            $this->db->order_by($this->db->escape_str($sortColumn), $this->db->escape_str($sortColumnDir));
        }

        /*
         * Filtering
         * NOTE this does not match the built-in DataTables filtering which does it
         * word by word on any field. It's possible to do here, but concerned about efficiency
         * on very large tables, and MySQL's regex functionality is very limited
         */
        if (!empty($searchValue)) {
            for ($i = 0; $i < count($sortColumnarr); $i++) {

                $bSearchable = $sortColumnarr[$i]['searchable'];

                // Individual column filtering
                if (isset($bSearchable) && $bSearchable == 'true' && !empty($sortColumnarr[$i]['name'])) {
                    if ($sortColumnarr[$i]['name'] == 'production_date' || $sortColumnarr[$i]['name'] == 'expiry_date')
                        $searchValue = date('Y-m-d', strtotime($searchValue));
                    $this->db->or_like($sortColumnarr[$i]['name'], $this->db->escape_like_str($searchValue));
                }
            }
        }

        // Select Data
        $this->db->select('SQL_CALC_FOUND_ROWS ' . str_replace(' , ', ' ', implode(', ', $column_names)), false);
        $rResult = $this->db->get($sTable);

        // Data set length after filtering
        $this->db->select('FOUND_ROWS() AS found_rows');
        $iFilteredTotal = $this->db->get()->row()->found_rows;

        // Total data set length
        $iTotal = $this->db->count_all($sTable);

        // Output       
        $retarray['draw'] = $draw;
        $retarray['recordsFiltered'] = $iFilteredTotal;
        $retarray['recordsTotal'] = $iTotal;
        $retarray['data'] = array();

        foreach ($rResult->result_array() as $aRow) {

            $retarray['data'][] = array("id" => $aRow["id"],
                "name" => $aRow["name"],
                "description" => $aRow["description"],
                "price" => $aRow["price"],
                "production_date" => date('d-m-Y', strtotime($aRow["production_date"])),
                "expiry_date" => date('d-m-Y', strtotime($aRow["expiry_date"])));
        }

        echo json_encode($retarray);
        exit;
    }

}
