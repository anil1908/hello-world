<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Group extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('group_model');
        $this->load->model('general_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * Group 
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_group() {
        $retarray = array();
        $common_result = array();

        //Get user_id and company_id
        $common_result = $this->custom_function->_common();
        if ($common_result['error'] == 0) {
            $retarray['error'] = 0;
            //Get group
            $retarray['response'] = $this->group_model->get_group_by_company_id($common_result['company_id']);
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Group list
     *
     * @access	public
     * @param	access_token,language,pageStart,pageLimit,sortField,sorttype,search_name,search_from_date,search_to_date,search_created_by
     * @return	JSON Array
     */
    public function get_group_list() {
        $retarray = array();
        $result = array();
        $id_array = array();
        $common_result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);

        $this->form_validation->set_rules('search_name', 'Group Name', 'trim|xss_clean');
        $this->form_validation->set_rules('search_from_date', 'From Date', 'trim|xss_clean');
        $this->form_validation->set_rules('search_to_date', 'To Date', 'trim|xss_clean');
        $this->form_validation->set_rules('search_created_by', 'Created By', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $search_name = addslashes(strtolower($this->input->post('search_name')));
            $search_from_date = $this->input->post('search_from_date');
            $search_to_date = $this->input->post('search_to_date');
            $search_created_by = addslashes(strtolower($this->input->post('search_created_by')));
            $pageStart = (!empty($this->input->post('pageStart'))) ? $this->input->post('pageStart') : 0;
            $pageLimit = (!empty($this->input->post('pageLimit'))) ? $this->input->post('pageLimit') : 10;
            $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'g.created_on';
            $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'DESC';

            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                $retarray['error'] = 0;
                //Get group list
                $result = $this->group_model->get_group_list_by_company_id($common_result['company_id'], $pageStart, $pageLimit, $sortField, $sortType, $search_name, $search_from_date, $search_to_date, $search_created_by);
                $retarray['found_rows'] = $this->general_model->found_rows();
                $wherearr = array('company_id' => $common_result['company_id']);
                $retarray['total_rows'] = $this->group_model->get_group_list_count($common_result['company_id'], $search_name, $search_from_date, $search_to_date, $search_created_by);
                $i = 0;
                if (is_array($result) && count($result) > 0) {
                    $retarray['error'] = 0;
                    foreach ($result as $key => $val) {
                        array_push($id_array, $result[$key]['id']);
                        //Group list
                        $retarray['response'][$i] = array('id' => $result[$key]['id'],
                            'name' => strip_slashes($result[$key]['name']),
                            'created_on' => date('m/d/Y', strtotime($result[$key]['created_on'])),
                            'created_by' => $result[$key]['created_by'],
                            'no_of_books' => $result[$key]['no_of_books']
                        );
                        $i++;
                    }
                    //Group ids 
                    $retarray['ids'] = implode(',', $id_array);
                } else {
                    $retarray = array("error" => 0,
                        "found_rows" => 0,
                        "total_rows" => 0,
                        "response" => array(),
                        "ids" => '');
                }
            } else {
                $retarray = $common_result;
            }
        }
        echo json_encode($retarray);
    }

    /**
     * Create group
     *
     * @access	public
     * @param	groupOptions,bookArr,group_name,group_id
     * @return	JSON Array
     */
    public function create_group() {
        $retarray = array();
        $common_result = array();
        $book_array = array();
        $group_book_data = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $selection = $this->input->post('groupOptions');
            $book_array = $this->input->post("bookArr");
            $created_on = date("Y-m-d H:i:s");
            //New group
            if ($selection == 1) {
                $group_name = addslashes($this->input->post("group_name"));

                $this->form_validation->set_rules('group_name', 'Group Name', 'trim|required|xss_clean');

                if ($this->form_validation->run() == FALSE) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = validation_errors();
                } else {
                    //Check group name
                    $result = $this->group_model->check_group_name($group_name, $common_result['company_id']);
                    if ($result) {
                        $retarray['error'] = 1;
                        $retarray['errorMsg'] = $this->lang->line("group_name_exists");
                        echo json_encode($retarray);
                        exit;
                    }
                    //Insert group data
                    $group_data = array("name" => $group_name,
                        "company_id" => $common_result['company_id'],
                        "created_on" => $created_on,
                        "created_by" => $common_result['user_id']);
                    $group_id = $this->group_model->insert_group($group_data);
                }
            }
            //Existing group
            else if ($selection == 2) {
                $group_id = $this->input->post('group_id');
            }
            if (!empty($group_id) && $group_id > 0) {
                if (is_array($book_array) && count($book_array) > 0) {
                    foreach ($book_array as $b) {
                        //Insert group book data
                        $group_book_data[] = array("group_id" => $group_id,
                            "book_id" => $b,
                            "created_on" => $created_on,
                            "created_by" => $common_result['user_id']);
                    }
                    $this->group_model->insert_group_books($group_book_data);
                    $retarray['error'] = 0;
                    $retarray['msg'] = $this->lang->line("group_create_success");
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('technical_error');
                }
            } else {
                $retarray['error'] = 0;
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * group details
     *
     * @access	public
     * @param	group_id,book_title,author_name,imprint,book_publisher,pageStart,pageLimit,sortField,sorttype
     * @return	JSON Array
     */
    public function group_details() {
        $retarray = array();
        $result = array();
        $id_array = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        $this->form_validation->set_rules('book_title', 'Title', 'trim|xss_clean');
        $this->form_validation->set_rules('author_name', 'Author', 'trim|xss_clean');
        $this->form_validation->set_rules('imprint', 'Imprint', 'trim|xss_clean');
        $this->form_validation->set_rules('book_publisher', 'Publisher', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $group_id = $this->input->post("group_id");

            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                $retarray['error'] = 0;
                $pageStart = (!empty($this->input->post('pageStart'))) ? $this->input->post('pageStart') : 0;
                $pageLimit = (!empty($this->input->post('pageLimit'))) ? $this->input->post('pageLimit') : 10;
                $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'gb.id';
                $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'DESC';
                $search_title = addslashes(strtolower($this->input->post('book_title')));
                $search_author = addslashes(strtolower($this->input->post('author_name')));
                $search_imprint = addslashes(strtolower($this->input->post('imprint')));
                $search_publisher = addslashes(strtolower($this->input->post('book_publisher')));

                if (!empty($group_id)) {
                    //Group details
                    $result_group = $this->group_model->get_group_details_by_id($group_id);
                    if (is_object($result_group) && count($result_group) > 0) {
                        $retarray['response']['group'] = array("id" => $result_group->id,
                            "name" => stripslashes($result_group->name),
                            "created_on" => $result_group->created_on,
                            "first_name" => $result_group->first_name);
                    }

                    $retarray['response']['found_rows'] = $this->general_model->found_rows();
                    $retarray['response']['total_rows'] = $this->group_model->get_book_details_count($group_id, $search_title, $search_author, $search_imprint, $search_publisher);
                    //Group books details
                    $result = $this->group_model->get_book_details_by_group_id($group_id, $sortField, $sortType, $pageStart, $pageLimit, $search_title, $search_author, $search_imprint, $search_publisher);
                    $i = 0;
                    if (is_array($result) && count($result) > 0) {
                        $retarray['error'] = 0;
                        foreach ($result as $key => $val) {
                            array_push($id_array, $result[$key]['id']);
                            //Group book list
                            $retarray['response']['group_books'][$i] = array('id' => $result[$key]['id'],
                                'title' => strip_slashes($result[$key]['title']),
                                'author' => (strlen($result[$key]['author']) > 20) ? substr($result[$key]['author'], 0, 20) . ".." : $result[$key]['author'],
                                'publication_date' => date('m/d/Y', strtotime($result[$key]['publication_date'])),
                                'imprint' => $result[$key]['imprint'],
                                'identifier_no' => (strlen($result[$key]['identifier_no']) > 20) ? substr($result[$key]['identifier_no'], 0, 20) . ".." : $result[$key]['identifier_no'],
                                'publisher' => $result[$key]['publisher']
                            );
                            $i++;
                        }
                        //ids 
                        $retarray['ids'] = implode(',', $id_array);
                    } else {
                        $retarray['error'] = 0;
                        $retarray['found_rows'] = 0;
                        $retarray['total_rows'] = 0;
                        $retarray['ids'] = '';
                        $retarray['response']['group_books'] = array();
                    }
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('technical_error');
                }
            } else {
                $retarray = $common_result;
            }
        }
        echo json_encode($retarray);
    }

    /**
     * Update group name
     *
     * @access	public
     * @param   access_token,language,group_name,group_id
     * @return	JSON Array
     */
    public function update_group_name() {
        $retarray = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {

            $this->form_validation->set_rules('group_name', 'Group Name', 'trim|required|xss_clean');

            if ($this->form_validation->run() == FALSE) {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = validation_errors();
            } else {
                $group_name = $this->input->post('group_name');
                $group_id = $this->input->post('group_id');
                if (!empty($group_id)) {
                    //Check group name
                    $result = $this->group_model->check_group_name_by_id($group_name, $group_id);
                    if (!$result) {
                        $modified_on = date('Y-m-d H:i:s');
                        //Update group data
                        $group_data = array("name" => $group_name,
                            "modified_on" => $modified_on,
                            "modified_by" => $common_result['user_id']);
                        $this->group_model->update_group_name($group_data, $group_id);
                        $retarray['error'] = 0;
                        $retarray['msg'] = $this->lang->line("group_name_update_success");
                    } else {
                        $retarray['error'] = 1;
                        $retarray['errorMsg'] = $this->lang->line("group_name_exists");
                    }
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('technical_error');
                }
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Delete group books
     *
     * @access	public
     * @param	group_bookArr,group_id
     * @return	JSON Array
     */
    public function delete_group_books() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $group_book_array = array();
        $group_book_data = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $created_on = date('Y-m-d H:i:s');
            $group_book_array = $this->input->post("group_bookArr");
            $group_id = $this->input->post('group_id');

            if (is_array($group_book_array) && count($group_book_array) > 0) {
                //Get group books
                $result = $this->group_model->get_group_books($group_book_array, $group_id);
                if (is_array($result) && count($result) > 0) {
                    foreach ($result as $r) {
                        //Insert group book history data
                        $group_book_data[] = array("group_id" => $r['group_id'],
                            "book_id" => $r['book_id'],
                            "created_on" => $created_on,
                            "created_by" => $common_result['user_id']);
                    }
                    $this->group_model->insert_history_group_books($group_book_data);
                    $this->group_model->delete_group_books($group_book_array);
                    $retarray['error'] = 0;
                    $retarray['msg'] = $this->lang->line("group_book_delete_success");
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("select_book");
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Delete group 
     *
     * @access	public
     * @param	groupArr
     * @return	JSON Array
     */
    public function delete_group() {
        $retarray = array();
        $common_result = array();
        $group_array = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $group_array = $this->input->post("groupArr");
            $created_on = date('Y-m-d H:i:s');
            if (is_array($group_array) && count($group_array) > 0) {
                //Get group related with channel    
                $result = $this->group_model->get_group_related_with_channel($group_array);
                if (is_object($result) && !empty($result->ids)) {
                    $existing_group_array = explode(',', $result->ids);
                    $delete_group_array = array_diff($group_array, $existing_group_array);
                    if (is_array($delete_group_array) && count($delete_group_array) > 0) {
                        //Get group books
                        $result = $this->group_model->get_group_books_by_group_id($delete_group_array);
                        //Group having books
                        if (is_array($result) && count($result) > 0) {
                            foreach ($result as $r) {
                                //Insert group book history data
                                $group_book_data[] = array("group_id" => $r['group_id'],
                                    "book_id" => $r['book_id'],
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }
                            $this->group_model->insert_history_group_books($group_book_data);
                            $this->group_model->delete_group_books_by_group_id($delete_group_array);
                        }
                        $result = $this->group_model->get_group_name($delete_group_array);
                        if (is_object($result) && !empty($result->group_names)) {
                            $group_names = explode(',', $result->group_names);
                            $main_group_array = array_combine($delete_group_array, $group_names);
                            foreach ($main_group_array as $id => $name) {
                                //Insert group history data
                                $group_data[] = array("company_id" => $common_result['company_id'],
                                    "group_id" => $id,
                                    "name" => $name,
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }
                            $this->group_model->insert_history_groups($group_data);
                            $this->group_model->delete_group_by_id($delete_group_array);
                        }

                        $retarray['error'] = 0;
                        $retarray['msg'] = $this->lang->line("group_delete_success");
                    } else {
                        $retarray['error'] = 1;
                        $retarray['errorMsg'] = $this->lang->line("group_exists_in_channel");
                    }
                } else {
                    $retarray['error'] = 0;
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

}
