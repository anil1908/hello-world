<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Retailer_catalog extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('retailer_catalog_model');
        $this->load->model('general_model');
        $this->load->model('catalog_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * Curation list
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_curation_list() {
        $retarray = array();
        $result = array();
        $common_result = array();
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common();
        if($common_result['error']==0){
            //Get company details
            $retarray['response'] = $this->retailer_catalog_model->get_curation_list();
            $retarray['error']=0;
        }else{
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }
    
    /**
     * Retailer catalog
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_retailer_catalog_by_id() {
        $retarray = array();
        $result = array();
        $common_result = array();
        
        $_POST = json_decode(file_get_contents('php://input'), true);
        $pageStart = (!empty($this->input->post('pagestart'))) ? $this->input->post('pagestart') : 0;
        $pageLimit = (!empty($this->input->post('pagelimit'))) ? $this->input->post('pagelimit') : 10;
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if($common_result['error']==0){
            $curation_id = $this->input->post("curation_id");
            $business_model_id= $this->input->post("business_id");
            $search = $this->input->post("searchtext");
            //Get company details
            $retarray['response'] = $this->retailer_catalog_model->get_retailer_catalog_by_id($common_result['user_id'],$pageStart,$pageLimit,$curation_id,$search,$business_model_id);
            $retarray['error']=0;
        }else{
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }
    
    /**
     * Curation book list
     *
     * @access	public
     * @param	access_token,language,curation_id
     * @return	JSON Array
     */
    public function get_curation_book_by_list_id() {
        $retarray = array();
        $result = array();
        $common_result = array();
        
        $_POST = json_decode(file_get_contents('php://input'), true);
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if($common_result['error']==0){
            //Get company details
            $curation_id = $this->input->post("curation_id");
//            $common_result['user_id']  =16;
//            $curation_id = 1;
            $retarray['response'] = $this->retailer_catalog_model->get_curation_book_by_list_id($common_result['user_id'],$curation_id);
            $retarray['error']=0;
        }else{
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }
     /**
     * Retailer catalog list by selection
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_retailer_catalog_by_selection() {
        $retarray = array();
        $result = array();
        $common_result = array();

        $path = realpath(PUBPATH . '../assets/images/bookcovers');

        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $curation_id = $this->input->post("curation_id");
            $business_model_id= $this->input->post("business_id");
            $search = $this->input->post("searchtext");
            //Get book list
            $retarray['error']=0;
            $retarray['response'] = $this->retailer_catalog_model->get_catalog_list_by_selection($common_result['user_id'],$curation_id,$search,$business_model_id);
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }
    
    /**
     * Book Details
     *
     * @access	public
     * @param	access_token,language,catalog_id
     * @return	JSON Array
     */
    public function get_catalog_details_by_id() {
        $retarray = array();
        $result = array();
        $result_contributor = array();
        $result_price = array();
        $result_subject = array();
        $identifier_array = array();
        $error_array = array();
        $result_identifier = array();
        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        $_POST = json_decode(file_get_contents('php://input'), true);
        if (!$this->custom_function->check_access_token()) {
            $retarray['error'] = 2;
            $retarray['errorMsg'] = $this->lang->line('session_expired');
            echo json_encode($retarray);
            exit;
        }

        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $book_id = $this->input->post('catalog_id');
            if (!empty($book_id)) {
                //Get catalog details
                $result = $this->retailer_catalog_model->get_book_details_by_id($book_id);
                if (is_object($result) && count($result) > 0) {
                    $retarray['error'] = 0;
                    //Catalog Details
                    $result_contributor = $this->catalog_model->get_book_contributor_detail_by_id($book_id);
                    $result_subject = $this->catalog_model->get_book_subject_detail_by_id($book_id);
                    $identifier_array= $this->catalog_model->get_book_identifier_detail_by_id($book_id);
                    $error_array = array("error"=>false,"identifiermessage"=>'');
                    foreach ($identifier_array as $key=>$val){
                        $result_identifier[]=array_merge($identifier_array[$key],$error_array);
                    }
                    $retarray['response']['catalog'] = array('id' => $result->id,
                        'title' => stripslashes($result->title),
                        'image' => (!empty($result->image) && file_exists($path . '/' . $result->image)) ? base_url() . 'assets/images/bookcovers/' . $result->image : base_url() . 'assets/images/bookcovers/img-cover.png',
                        'sub_title' => $result->sub_title,
                        'volume' => $result->volume,
                        'edition' => $result->edition,
                        'contributor' => (!empty($result_contributor)) ? $result_contributor : array(),
                        'identifier' => (!empty($result_identifier)) ? $result_identifier : array(),
                        'publisher' => $result->publisher,
                        'imprint' => $result->imprint,
                        'publication_date' => date('m/d/Y',strtotime($result->publication_date)),
                        'language' => $result->language,
                        'language_id' => $result->language_id,
                        'subject_id' => (!empty($result_subject)) ? $result_subject : array(),
                        'main_subject_id' => $result->main_subject_id,
                        'description' => (strlen($result->description) > 50) ? substr($result->description, 0, 50) . ".." : $result->description,
                        'keywords' => $result->keywords,
                        'age_range' => $result->age_range,
                        'us_grade_range' => $result->us_grade_range,
                        'region_id' => (!empty($result->region_id)) ? explode(',', $result->region_id) : array(),
                        'region_name' => (!empty($result->region_name)) ? explode(',', $result->region_name) : array(),
                        'country_id' => (!empty($result->country_name)) ? explode(',', $result->country_name) : array(),
                        'audience_id' => $result->audience_id,
                        'copyright_year' => $result->copyright_year,
                        'copyright_owner' => $result->copyright_owner,
                        'supplier_details' => $result->supplier_details,
                        'supply_date' => date('m/d/Y',strtotime($result->supply_date)),
                        'title_availability' => date('m/d/Y',strtotime($result->title_availability)),
                        'countries_included' => $result->countries_included,
                        'cover_image' =>(!empty($result->cover_image) && file_exists($path . '/' . $result->cover_image)) ? base_url() . 'assets/images/bookcovers/' . $result->cover_image : base_url() . 'assets/images/bookcovers/img-cover.png',
                        'original_image' =>(!empty($result->cover_image) && file_exists($path . '/' . $result->cover_image)) ?$result->cover_image :''
                    );
                    //Catalog reviews
                    $retarray['response']['catalog_prices'] = (array)$this->retailer_catalog_model->get_retailer_catalog_price_by_id($book_id,$common_result['user_id'],NULL,1);
                    //Catalog reviews
                    $retarray['response']['catalog_reviews'] = $this->catalog_model->get_book_reviews_by_id($book_id);
                    //Catalog awards
                    $retarray['response']['catalog_awards'] = $this->catalog_model->get_book_awards_by_id($book_id);
                    //Catalog related product
                    $retarray['response']['catalog_related_products'] = $this->catalog_model->get_book_related_product_by_id($book_id);
                } else {
                    $retarray['error'] = 0;
                    $retarray['response'] = array();
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }
}
