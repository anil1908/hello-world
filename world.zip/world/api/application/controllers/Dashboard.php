<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('dashboard_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * Dashboard
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_dashboard() {
        $retarray = array();
        $result = array();
        $common_result = array();
        
        $path = realpath(PUBPATH . '../assets/images/companyprofile');
        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if($common_result['error']==0){
            //Get company details
            $result = $this->dashboard_model->get_company_details_by_id($common_result['company_id']);

            if (is_object($result) && count($result) > 0) {
                //Company details
                $retarray['response'] = array('name' => $result->name,
                    'usertype' => $result->usertype,
                    'logo' => (!empty($result->logo) && file_exists($path . '/' . $result->logo)) ? base_url() . 'assets/images/companyprofile/' . $result->logo : base_url() . 'assets/images/companyprofile/profilepicture.jpg',
                    'is_image' => (!empty($result->logo) && file_exists($path . '/' . $result->logo)) ? 1 : 0);
                $retarray['error'] = 0;
            } else {
                $retarray['error'] = 0;
                $retarray['response']=array();
            }
        }else{
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }
}
