<html ng-app="prodata">
    <head><title>Angular + Codeigniter Combo Pack</title>
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" />
        <link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css" />
    </head>
    <body ng-controller="productctrl">

        <h1>Depression - Medicine Lists</h1>
        <table  datatable="ng" dt-options="dtOptions" class="row-border hover">
            <thead>
                <tr>
                    <th>Sr. No.</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Production Date</th>
                    <th>Expiry Date</th>
                </tr>
            </thead>
            <tbody>
                <tr ng-repeat="products in productslist">
                    <td>{{products.id}}</td>
                    <td>{{products.name}}</td>
                    <td>{{products.description}}</td>
                    <td>{{products.price}}</td>
                    <td>{{products.production_date|date:'MM/dd/yyyy'}}</td>
                    <td>{{products.expiry_date|date:'MM/dd/yyyy'}}</td>
                </tr>
            </tbody>
        </table>
    </body>

    <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
    <script src="http://code.angularjs.org/1.1.5/angular.min.js"></script>
    <script src="<?= base_url(); ?>assets/js/angular-datatables.min.js"></script>
    <script type="text/javascript">
  var baseurl = "<?=base_url(); ?>";
</script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/js/products_datatable.js"></script>
</html>
