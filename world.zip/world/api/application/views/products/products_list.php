<html ng-app="Products">
<head><title>Angular + Codeigniter Combo Pack</title>

</head>
<body>
<h1>Depression - Medicine Lists</h1>
<table border="1" ng-controller="ListCtrl">
	<thead>
    	<th>Sr. No.</th>
        <th>Name</th>
        <th>Description</th>
        <th>Price</th>
        <th>Production Date</th>
        <th>Expiry Date</th>
    </thead>
    <tbody>
    	<tr ng-repeat="products in productslist">
        	<td>{{products.id}}</td>
            <td>{{products.name}}</td>
            <td>{{products.description}}</td>
            <td>{{products.price}}</td>
            <td>{{products.production_date|date:'MM/dd/yyyy'}}</td>
            <td>{{products.expiry_date|date:'MM/dd/yyyy'}}</td>
        </tr>
    </tbody>
</table>



</body>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.3/angular.min.js"></script>
<script type="text/javascript" src="assets/js/products.js"></script>
</html>
