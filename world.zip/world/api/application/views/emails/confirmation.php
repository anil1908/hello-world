<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Confirm your 1World Content Exchange account</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    </head>
    <body>
        <table border="0" cellpadding="0" cellspacing="0" width="600" align="center" style="border:solid 1px #ededed;">
            <tbody>
                <tr>
                    <td><table border="0" cellpadding="0" cellspacing="0">
                            <tbody>
                                <tr>
                                    <td><table border="0" cellpadding="0" cellspacing="0" style="width:640px">
                                            <tbody>
                                                <tr>
                                                    <td align="center">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td align="left"><a href="#" style="border:0px;" target="_blank"><img alt="1World Content" src="<?php echo base_url() . EMAILLOGO; ?>" /></a></td>
                                                </tr>
                                            </tbody>
                                        </table></td>
                                </tr>
                                <tr>
                                    <td><table width="100%" border="0" cellpadding="20" cellspacing="0">
                                            <tbody>
                                                <tr>
                                                    <td style="font:normal 14px/24px 'Open Sans', sans-serif; color:#5a6168;"><p style="font-size:16px; color:#1980C5; margin-top:0px;">Dear <?php echo $username; ?>,</p>
                                                        <p style="font-size:14px; color:#030303; line-height:20px; padding:0 0 6px; margin:0;">Thank you for registration.</p>
                                                        <p style="font-size:14px; color:#030303; line-height:20px; padding:0 0 12px; margin:0;">Your account is currently inactive, please click on the confirmation link below to active your account.</p>
                                                        <p> 
                                                            <a title="Activate Account" href="<?php echo $confirmurl; ?>" target="_blank">Click here to activate your account</a></p>
                                                        <table style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; line-height: 20px; padding-top:17px;" border="0" width="100%" cellspacing="0" cellpadding="0">
                                                            <tbody>
                                                                <tr>
                                                                    <td style="color: #292929;" width="80"><strong>Username : </strong></td>
                                                                    <td width="600"><?php echo $useremail; ?></td>
                                                                </tr>

                                                            </tbody>
                                                        </table>
                                                        <p style="color:#1980C5;"><strong>Best Regards,</strong><br />
                                                            <span style="color:#030303;">1World Content Exchange</span></p>
                                                        <div style="min-height:10px; font-size:12px; color:#5a6168; font-family:'Open Sans', sans-serif;">
                                                            <p>Note : This is an auto generated response. Please do not respond to this mail.</p>
                                                        </div></td>
                                                </tr>
                                            </tbody>
                                        </table></td>
                                </tr>

                            </tbody>
                        </table></td>
                </tr>
            </tbody>
        </table>
    </body>
</html>