<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Group_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }


    /**
         * Group list
         *
         * @access	public
         * @param	company_id
         * @return	Array
    */
    public function get_group_by_company_id($compnay_id){
        $retarray = array();
        if(!empty($compnay_id)){
            $this->db->select("id,name");
            $this->db->where("company_id",$compnay_id);
            $query = $this->db->get("groups");
            if($query->num_rows()>0){
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }
    /**
         * Group list
         *
         * @access	public
         * @param	company_id,pageStart, pageLimit, sortField, sortType, search_name,search_from_date,search_to_date, search_created_by
         * @return	Array
    */
    public function get_group_list_by_company_id($company_id, $pageStart, $pageLimit, $sortField, $sortType, $search_name,$search_from_date,$search_to_date, $search_created_by){
            $retarray = array();
            if(!empty($company_id)){
                $this->db->select("g.id,g.name,g.created_on,CONCAT(u.first_name,' ',u.last_name)as created_by,COUNT(gb.book_id)as no_of_books");
                $this->db->from("groups g");
                $this->db->join("groups_books gb","g.id=gb.group_id","LEFT");
                $this->db->join("users u","u.id=g.created_by");
                if(!empty($search_name)){
                    $this->db->where("(LOWER(g.name) LIKE '%$search_name%')");
                }
                if(!empty($search_from_date) && !empty($search_to_date)){
                    $search_from_date = date('Y-m-d', strtotime($search_from_date));
                    $search_to_date = date('Y-m-d', strtotime($search_to_date));
                    $this->db->where("(g.created_on > '$search_from_date' AND g.created_on < '$search_to_date')");
                }
                if(!empty($search_created_by)){
                    $this->db->where("(LOWER(CONCAT_WS(' ',u.first_name,u.last_name)) LIKE '%$search_created_by%')");
                }

                $this->db->where("g.company_id='".$company_id."'");
                $this->db->group_by('g.id');
                $this->db->order_by($sortField,$sortType);
                $this->db->limit($pageLimit,$pageStart);
                $query = $this->db->get();
                if ($query->num_rows() > 0) {
                    $retarray = $query->result_array();
                }
        }
            return $retarray;
    }
    /**
         * Count group list
         *
         * @access	public
         * @param	company_id,name_search,search_from_date,search_to_date,created_by_search
         * @return	count of rows
    */
    public function get_group_list_count($company_id, $name_search,$search_from_date,$search_to_date,$created_by_search){
            $iTotal = 0;
            $result = array();
            if(!empty($company_id)){
                $this->db->select("COUNT(g.id) as num_rows");
                $this->db->from("groups g");
                $this->db->join("users u","u.id=g.created_by","LEFT");
                 if(!empty($name_search)){
                    $this->db->where("(LOWER(g.name) LIKE '%$name_search%')");
                }
                if(!empty($search_from_date) && !empty($search_to_date)){

                    $search_from_date = date('Y-m-d', strtotime($search_from_date));
                    $search_to_date = date('Y-m-d', strtotime($search_to_date));
                    $this->db->where("(g.created_on > '$search_from_date' AND g.created_on < '$search_to_date')");
                }
                if(!empty($search_created_by)){
                    $this->db->where("(LOWER(CONCAT_WS(' ',u.first_name,u.last_name)) LIKE '%$created_by_search%')");
                }
                $this->db->where("g.company_id='".$company_id."'");
                $query = $this->db->get();
                if ($query->num_rows() > 0) {
                   $result = $query->row();
                   $iTotal = $result->num_rows;
                }
            }
            return $iTotal;
    }
    /**
         * Group Detail
         *
         * @access	public
         * @param	group_id
         * @return	Array
    */
    public function get_group_details_by_id($group_id){
            $retarray = array();
            if(!empty($group_id)){
                $this->db->select("g.id,g.name,DATE_FORMAT(g.created_on,'%m/%d/%Y') as created_on,u.first_name");
                $this->db->from("groups g");
                $this->db->join("groups_books gb","g.id=gb.group_id","LEFT");
                $this->db->join("users u","u.id=g.created_by");
                $this->db->where("g.id='".$group_id."'");
                $this->db->group_by('g.id');
                $query = $this->db->get();
                if ($query->num_rows() > 0) {
                    $retarray = $query->row();
                }
            }
            return $retarray;
    }
    /**
         * Check group name
         *
         * @access	public
         * @param	group_name,group_id
         * @return	boolean
    */
    public function check_group_name_by_id($group_name,$group_id){
            $retarray = array();
            if(!empty($group_id) && !empty($group_name)){
                $this->db->where("id<>",$group_id);
                $this->db->where("LOWER(name)",  strtolower($group_name));
                $query = $this->db->get("groups");
                if ($query->num_rows() > 0) {
                    return TRUE;
                }else{
                    return FALSE;
                }
            }
    }
    /**
         * Update group name
         *
         * @access	public
         * @param	group_data,group_id
         * @return	NA
    */
    public function update_group_name($group_data,$group_id){
        if(!empty($group_id) && (is_array($group_data) && count($group_data)>0)){
            $this->db->where("id",$group_id);
            $this->db->update("groups",$group_data);
        }
    }
    /**
         * Book Details of group
         *
         * @access	public
         * @param	group_id,sortField,sortType,pageStart,pageLimit,search_title, search_author, search_imprint, search_publisher
         * @return	Array
    */
    public function get_book_details_by_group_id($group_id,$sortField,$sortType,$pageStart,$pageLimit,$search_title, $search_author, $search_imprint, $search_publisher){
            $retarray = array();
            if(!empty($group_id)){
                $this->db->select("b.id,b.title,GROUP_CONCAT(DISTINCT cp.name) as author,b.publication_date,b.imprint,GROUP_CONCAT(DISTINCT bi.identifier_no) as identifier_no,c.name as publisher");
                $this->db->from("groups_books gb");
                $this->db->join("books b","b.id=gb.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
                $this->db->join("book_identifiers bi","b.id=bi.book_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)","LEFT");
                $this->db->join("identifier_types it","it.id=bi.identifier_type_id","LEFT");
                $this->db->join("company c","c.id=b.company_id","LEFT");
                $this->db->join("book_contributors bc","bc.role_id=1 AND gb.book_id = bc.book_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)","LEFT");
                $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
                $this->db->where("gb.group_id='".$group_id."'");
                if(!empty($search_title)){
                    $this->db->where("LOWER(b.title) LIKE '%$search_title%'");
                }
                if(!empty($search_author)){
                    $this->db->where("LOWER(cp.name) LIKE '%$search_author%'");
                }
                if(!empty($search_imprint)){
                     $this->db->where("LOWER(b.imprint) LIKE '%$search_imprint%'");
                }
                if(!empty($search_publisher)){
                     $this->db->where("LOWER(c.name) LIKE '%$search_publisher%'");
                }
                $this->db->group_by("gb.id");
                $this->db->order_by($sortField,$sortType);
                $this->db->limit($pageLimit,$pageStart);
                $query = $this->db->get();
                if($query->num_rows()>0){
                    $retarray = $query->result_array();
                }
            }
            return $retarray;
    }
    /**
         * Count of Book Details
         *
         * @access	public
         * @param	group_id,search_title, search_author, search_imprint, search_publisher
         * @return	count of rows
    */
    public function get_book_details_count($group_id,$search_title, $search_author, $search_imprint, $search_publisher){
            $iTotal = 0;
            $result = array();
            if(!empty($group_id)){
                $this->db->select("COUNT(gb.id) as num_rows");
                $this->db->from("groups_books gb");
                $this->db->join("books b","b.id=gb.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
                $this->db->join("company c","c.id=b.company_id","LEFT");
                $this->db->join("book_contributors bc","bc.role_id=1 AND gb.book_id = bc.book_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)","LEFT");
                $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
                $this->db->where("gb.group_id='".$group_id."'");
                if(!empty($search_title)){
                    $this->db->where("LOWER(b.title) LIKE '%$search_title%'");
                }
                if(!empty($search_author)){
                    $this->db->where("LOWER(cp.name) LIKE '%$search_author%'");
                }
                if(!empty($search_imprint)){
                     $this->db->where("LOWER(b.imprint) LIKE '%$search_imprint%'");
                }
                if(!empty($search_publisher)){
                     $this->db->where("LOWER(c.name) LIKE '%$search_publisher%'");
                }
                $query = $this->db->get();
                if ($query->num_rows() > 0) {
                   $result = $query->row();
                   $iTotal = $result->num_rows;
                }
            }
            return $iTotal;
    }
    /**
         * Group name
         *
         * @access	public
         * @param	group_array
         * @return	Array
    */
    public function get_group_name($group_array){
            $retarray = array();
            if(is_array($group_array) && count($group_array) > 0){
                $this->db->select("GROUP_CONCAT(name) as group_names");
                $this->db->where_in("id",$group_array);
                $query = $this->db->get('groups');
                if($query->num_rows()>0){
                    $retarray = $query->row();
                }
            }
            return $retarray;
    }
    /**
         * Check Group name
         *
         * @access	public
         * @param	group name,company_id
         * @return	boolean
    */
    public function check_group_name($group_name,$company_id){
            if(!empty($company_id)){
                $this->db->where("name ='$group_name' AND company_id=$company_id");
                $query = $this->db->get('groups');
                if($query->num_rows()>0){
                   return TRUE;
                }else{
                   return FALSE;
                }
            }
    }
    /**
         *Insert group
         *
         * @access	public
         * @param	group data
         * @return	group_id
    */
    public function insert_group($group_data){
        $group_id=0;
        if(is_array($group_data) && count($group_data)>0){
            $this->db->insert("groups",$group_data);
            $group_id = $this->db->insert_id();
        }
        return $group_id;
    }
    /**
         *Insert group books
         *
         * @access	public
         * @param	group_book_data
         * @return	NA
    */
    public function insert_group_books($group_book_data){
        if(is_array($group_book_data) && count($group_book_data)>0){
            $this->db->custom_insert_batch("groups_books",$group_book_data);
        }
    }
    /**
         * Group books
         *
         * @access	public
         * @param	group_book_array,group_id
         * @return	Array
    */
    public function get_group_books($group_book_array,$group_id){
            $retarray = array();
            if((is_array($group_book_array) && count($group_book_array)>0) && !empty($group_id)){
                $this->db->where_in('book_id',$group_book_array);
                $this->db->where('group_id',$group_id);
                $query = $this->db->get("groups_books");
                if($query->num_rows()>0){
                    $retarray = $query->result_array();
                }
            }
            return $retarray;
    }
    /**
         * Group books by group id
         *
         * @access	public
         * @param	group_array
         * @return	Array
    */
    public function get_group_books_by_group_id($group_array){
            $retarray = array();
            if(is_array($group_array) && count($group_array)>0){
                $this->db->where_in('group_id',$group_array);
                $query = $this->db->get("groups_books");
                if($query->num_rows()>0){
                    $retarray = $query->result_array();
                }
            }
            return $retarray;
    }
    /**
         * Insert group book history
         *
         * @access	public
         * @param	group book data
         * @return	NA
    */
    public function insert_history_group_books($group_book_data){
            if(is_array($group_book_data) && count($group_book_data) >0){
                $this->db->custom_insert_batch("history_groups_books",$group_book_data);
            }
    }
    /**
         * Insert group history
         *
         * @access	public
         * @param	group data
         * @return	NA
    */
    public function insert_history_groups($group_data){
            if(is_array($group_data) && count($group_data) >0){
                $this->db->insert_batch("history_groups",$group_data);
            }
    }
    /**
         * Delete group book
         *
         * @access	public
         * @param	group_book_array
         * @return	NA
    */
    public function delete_group_books($group_book_array,$group_id){
            if((is_array($group_book_array) && count($group_book_array) >0) && !empty($group_id)) {
                $this->db->where("group_id",$group_id);
                $this->db->where_in("book_id",$group_book_array);
                $this->db->delete("groups_books");
            }
    }
    /**
         * Group related with channel
         *
         * @access	public
         * @param	group_array
         * @return	Array
    */
    public function get_group_related_with_channel($group_array){
            $retarray = array();
            if(is_array($group_array) && count($group_array) >0){
                $this->db->select("group_concat(DISTINCT group_id) as ids");
                $this->db->where_in("group_id",$group_array);
                //$this->db->where("deleted_by < 1 or deleted_by = 0");
                $query = $this->db->get("channels");
                if($query->num_rows()>0){
                    $retarray = $query->row();
                }
            }
            return $retarray;
    }
    /**
         * Delete group book by group id
         *
         * @access	public
         * @param	delete_group_array
         * @return	NA
    */
    public function delete_group_books_by_group_id($delete_group_array){
            if(is_array($delete_group_array) && count($delete_group_array)>0){
                $this->db->where_in("group_id",$delete_group_array);
                $this->db->delete('groups_books');
            }
    }
    /**
         * Delete group
         *
         * @access	public
         * @param	delete_group_array
         * @return	NA
    */
    public function delete_group_by_id($delete_group_array){
            if(is_array($delete_group_array) && count($delete_group_array)>0){
                $this->db->where_in("id",$delete_group_array);
                $this->db->delete('groups');
            }
    }

}
