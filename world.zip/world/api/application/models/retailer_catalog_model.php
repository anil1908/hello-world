<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Retailer_catalog_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Curation list
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
     public function get_curation_list() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("retailer_curation");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Retailer Catalog
     *
     * @access	public
     * @param	retailer_id,pageStart,pageLimit,curation_id,search
     * @return	Array
     */
     public function get_retailer_catalog_by_id1($retailer_id,$pageStart,$pageLimit,$curation_id,$search) {
        $retarray = array();
        $namearray = array();
        $channelarray = array();
        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        if(!empty($curation_id)){
            //        $this->db->select("SQL_CALC_FOUND_ROWS DISTINCT u.id as user_id,b.id as book_id,b.title,cb.new_standard_price,cb.currency_id,(CASE WHEN cu.symbol IS NOT NULL THEN cu.symbol else cu.code end)as symbol");
            $this->db->select("u.id as user_id,b.id as book_id,cb.channel_id,c.retailers_list,cr.retailer_id,b.title,b.cover_image as image,cb.standard_price,cb.new_standard_price,cb.currency_id,(CASE WHEN cu.symbol IS NOT NULL THEN cu.symbol else cu.code end)as symbol,cu.code,bm.name as bm_name");
            $this->db->from("channels_books as cb");
            $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("retailer_curation_books as rcb","rcb.retailer_curation_id= $curation_id AND b.id=rcb.book_id AND (rcb.deleted_by < 1 OR rcb.deleted_by =0)");
            $this->db->join("retailer_curation as rc","rc.id=rcb.retailer_curation_id AND (rc.deleted_by < 1 OR rc.deleted_by =0)");
            $this->db->join("channels as c","cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->join("channels_retailers as cr","c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)","LEFT");
            $this->db->join("users as u","u.id=$retailer_id AND u.status = 1");
            $this->db->join("currency as cu","cb.currency_id = cu. id");
            $this->db->join("retailer_preference_country as rpc","rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id","LEFT");
            $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id","LEFT");
            $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
            $this->db->join("business_models bm", "bm.id = c.business_model_id");
            $this->db->where("c.status = 1 AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            $this->db->order_by("c.id,b.id,rpc.country_id", "DESC");
            $this->db->order_by("cu.seq_no,cu.code", "ASC");
//            $this->db->limit($pageLimit,$pageStart);
            $query = $this->db->get();
        }else{
    //        $this->db->select("SQL_CALC_FOUND_ROWS DISTINCT u.id as user_id,b.id as book_id,b.title,cb.new_standard_price,cb.currency_id,(CASE WHEN cu.symbol IS NOT NULL THEN cu.symbol else cu.code end)as symbol");
            $this->db->select("u.id as user_id,b.id as book_id,cb.channel_id,c.retailers_list,cr.retailer_id,b.title,b.cover_image as image,cb.standard_price,cb.new_standard_price,cb.currency_id,(CASE WHEN cu.symbol IS NOT NULL THEN cu.symbol else cu.code end)as symbol,cu.code,bm.name as bm_name");
            $this->db->from("channels_books as cb");
            $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("channels as c","cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->join("channels_retailers as cr","c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)","LEFT");
            $this->db->join("users as u","u.id=$retailer_id AND u.status = 1");
            $this->db->join("currency as cu","cb.currency_id = cu. id");
            $this->db->join("retailer_preference_country as rpc","rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id","LEFT");
            $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id","LEFT");
            $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
            $this->db->join("business_models bm", "bm.id = c.business_model_id");
            $this->db->where("c.status = 1 AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            $this->db->order_by("c.id,b.id,rpc.country_id", "DESC");
            $this->db->order_by("cu.seq_no,cu.code", "ASC");
//            $this->db->limit($pageLimit,$pageStart);
            $query = $this->db->get();
        }
//        echo $this->db->last_query();exit;
        if ($query->num_rows() > 0) {
            $bookarr = $query->result_array();
            if (is_array($bookarr) && count($bookarr) > 0) {
                $c = 0;
                $d = 0;
                foreach ($bookarr as $key => $val) {
                    if($bookarr[$key]['retailers_list']=="Blacklist" && $bookarr[$key]['retailer_id'] == $retailer_id){
                    }else{
                        $book_title = stripslashes($bookarr[$key]['title']);
                        $channel_id = stripslashes($bookarr[$key]['channel_id']);
                        if (!in_array($book_title, $namearray)) {
                            $c = 0;
                            array_push($namearray, $book_title);
                        }
                        if (!in_array($channel_id, $channelarray)) {
                            $c = 0;
                            array_push($channelarray, $channel_id);
                        }
                        $retarray[$book_title]['book_id'] = $bookarr[$key]['book_id'];
                        $retarray[$book_title]['title'] = $bookarr[$key]['title'];
                        $retarray[$book_title]['image'] = (!empty($bookarr[$key]['image']) && file_exists($path . '/' . $bookarr[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $bookarr[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                        if(empty($retarray[$book_title]['price'][$channel_id]['main_price'])){
                            $retarray[$book_title]['price'][$channel_id]['main_price'] = $bookarr[$key]['symbol']." ".$bookarr[$key]['new_standard_price']." ".$bookarr[$key]['bm_name'];
                        }
                        $retarray[$book_title]['price'][$channel_id]['price'][$c]['code'] = $bookarr[$key]['code'];
                        $retarray[$book_title]['price'][$channel_id]['price'][$c]['original_digital_list'] = $bookarr[$key]['standard_price'];
                        $c++;
                    }

                }
            }
        }
        echo "<pre>";
        print_r($retarray);
        exit;
        return $retarray;
    }
    /**
     * Retailer Catalog
     *
     * @access	public
     * @param	retailer_id,pageStart,pageLimit,curation_id,search
     * @return	Array
     */
     public function get_retailer_catalog_by_id($retailer_id,$pageStart,$pageLimit,$curation_id,$search,$business_model_id) {
        $retarray = array();
        $namearray = array();
        $bookarr = array();
        $bookidarray = array();
        $pricearr = array();
        $channelarray = array();
        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        if(!empty($curation_id)){
            $this->db->select("b.id as book_id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,c.retailers_list,cr.retailer_id");
            $this->db->from("channels_books as cb");
            $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("retailer_curation_books as rcb","rcb.retailer_curation_id= $curation_id AND b.id=rcb.book_id AND (rcb.deleted_by < 1 OR rcb.deleted_by =0)");
            $this->db->join("retailer_curation as rc","rc.id=rcb.retailer_curation_id AND (rc.deleted_by < 1 OR rc.deleted_by =0)");
            $this->db->join("book_contributors bc","b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)","LEFT");
            $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
            $this->db->join("channels as c","cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->join("channels_retailers as cr","c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)","LEFT");
            $this->db->join("users as u","u.id=$retailer_id AND u.status = 1");
            $this->db->join("currency as cu","cb.currency_id = cu. id");
            $this->db->join("retailer_preference_country as rpc","rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id","LEFT");
            $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id","LEFT");
            $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
            $this->db->join("business_models bm", "bm.id = c.business_model_id");
            $this->db->where("c.status = 1 AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            if(!empty($search)){
                $this->db->where("((LOWER(b.title) LIKE '%$search%') OR (LOWER(cp.name) LIKE '%$search%'))");
            }
            if(!empty($business_model_id)){
                $this->db->where_in("c.business_model_id",$business_model_id);
            }
            $this->db->order_by("c.id,b.id,rpc.country_id", "DESC");
            $this->db->order_by("cu.seq_no,cu.code", "ASC");
            $this->db->group_by("b.id,c.retailers_list");
            $this->db->limit($pageLimit,$pageStart);
            $query = $this->db->get();
        }else{
    //        $this->db->select("SQL_CALC_FOUND_ROWS DISTINCT u.id as user_id,b.id as book_id,b.title,cb.new_standard_price,cb.currency_id,(CASE WHEN cu.symbol IS NOT NULL THEN cu.symbol else cu.code end)as symbol");
            $this->db->select("b.id as book_id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,c.retailers_list,cr.retailer_id");
            $this->db->from("channels_books as cb");
            $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("book_contributors bc","b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)","LEFT");
            $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
            $this->db->join("channels as c","cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->join("channels_retailers as cr","c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)","LEFT");
            $this->db->join("users as u","u.id=$retailer_id AND u.status = 1");
            $this->db->join("currency as cu","cb.currency_id = cu. id");
            $this->db->join("retailer_preference_country as rpc","rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id","LEFT");
            $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id","LEFT");
            $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
            $this->db->join("business_models bm", "bm.id = c.business_model_id");
            $this->db->where("c.status = 1 AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            if(!empty($search)){
                $this->db->where("((LOWER(b.title) LIKE '%$search%') OR (LOWER(cp.name) LIKE '%$search%'))");
            }
            if(!empty($business_model_id)){
                $this->db->where_in("c.business_model_id",$business_model_id);
            }
            $this->db->order_by("b.id,rpc.country_id", "DESC");
            $this->db->order_by("cu.seq_no,cu.code", "ASC");
            $this->db->group_by("b.id,c.retailers_list");
            $this->db->limit($pageLimit,$pageStart);
            $query = $this->db->get();
        }
//        echo $this->db->last_query();exit;
        if ($query->num_rows() > 0) {
            $bookarr = $query->result_array();
            if (is_array($bookarr) && count($bookarr) > 0) {
                $c = 0;
                $d = 0;
                $cnt=0;
                foreach ($bookarr as $key => $val) {
                    
//                    echo $bookarr[$key]['book_id']."<br/>";
                    if(($bookarr[$key]['retailers_list']=='Blacklist' && $bookarr[$key]['retailer_id']==$retailer_id)||($bookarr[$key]['retailers_list']=='Whitelist' && $bookarr[$key]['retailer_id']!=$retailer_id)){
                    }
                    else{
                            if (in_array($bookarr[$key]['book_id'], $bookidarray)) {
                                continue;
                            }else{
                                array_push($bookidarray, $bookarr[$key]['book_id']);
                                $retarray[$c]['book_id'] = $bookarr[$key]['book_id'];
                                $retarray[$c]['title'] = stripslashes($bookarr[$key]['title']);
                                $retarray[$c]['author'] = $bookarr[$key]['author'];
                                $retarray[$c]['image'] = (!empty($bookarr[$key]['image']) && file_exists($path . '/' . $bookarr[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $bookarr[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                                $retarray[$c]['price'] = $this->get_retailer_catalog_price_by_id($bookarr[$key]['book_id'],$retailer_id,$business_model_id);
                                $c++;
                            }
//                        $this->db->select("cb.channel_id,c.retailers_list,cr.retailer_id,cb.new_standard_price,cb.currency_id,(CASE WHEN cu.symbol IS NOT NULL THEN cu.symbol else cu.code end)as symbol,cu.code,bm.name as bm_name");
//                        $this->db->from("channels_books as cb");
//                        $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
//                        $this->db->join("channels as c","cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
//                        $this->db->join("channels_retailers as cr","c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)","LEFT");
//                        $this->db->join("currency as cu","cb.currency_id = cu. id");
//                        $this->db->join("business_models bm", "bm.id = c.business_model_id");
//                        $this->db->where("c.status = 1 AND cb.book_id=".$bookarr[$key]['book_id']." AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
//                        if(!empty($business_model_id)){
//                            $this->db->where_in("c.business_model_id",$business_model_id);
//                        }
//                        $this->db->order_by("c.id,b.id", "DESC");
//                        $this->db->order_by("cu.seq_no,cu.code", "ASC");
//                        $query_price = $this->db->get();
//                        echo $this->db->last_query()."<br/>";
//                        if($query_price->num_rows()>0){
//                            $pricearr = $query_price->result_array();
//                            if(is_array($pricearr) && count($pricearr) > 0){
//                                foreach ($pricearr as $key=>$val){
//                                    if($pricearr[$key]['retailers_list']=='Blacklist' && $pricearr[$key]['retailer_id']==$retailer_id){
//                                    }else{
//                                        $channel_id =  $pricearr[$key]['channel_id'];
//                                        if (!in_array($channel_id, $channelarray)) {
//                                                $d = 0;
//                                                array_push($channelarray, $channel_id);
//                                        }
//                                        if(empty($retarray[$c]['price'][$channel_id]['main_price'])){
//                                            $retarray[$c]['price'][$channel_id]['main_price'] = $pricearr[$key]['symbol']." ".$pricearr[$key]['new_standard_price']." ".$pricearr[$key]['bm_name'];
//                                        }
//                                        else{
//                                            $retarray[$c]['price'][$channel_id]['price'][$d]['currency'] = $pricearr[$key]['code'];
//                                            $retarray[$c]['price'][$channel_id]['price'][$d]['original_digital_list'] = $pricearr[$key]['new_standard_price'];
//                                        }
//                                        $d++;
//                                    }
//
//                                }
//                            }
//                        }
//                        $c++;
                    }
                }
            }
        }
//        echo "<pre>";
//        print_r($retarray);
//        exit;
        return $retarray;
    }
    /**
     * Retailer Catalog
     *
     * @access	public
     * @param	retailer_id,pageStart,pageLimit,curation_id,search
     * @return	Array
     */
     public function get_catalog_list_by_selection($retailer_id,$curation_id,$search,$business_model_id) {
        $retarray = array();
        $namearray = array();
        $bookarr = array();
        $pricearr = array();
        $channelarray = array();
        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        if(!empty($curation_id)){
            $this->db->select("b.id as book_id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,c.retailers_list,cr.retailer_id");
            $this->db->from("channels_books as cb");
            $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("retailer_curation_books as rcb","rcb.retailer_curation_id= $curation_id AND b.id=rcb.book_id AND (rcb.deleted_by < 1 OR rcb.deleted_by =0)");
            $this->db->join("retailer_curation as rc","rc.id=rcb.retailer_curation_id AND (rc.deleted_by < 1 OR rc.deleted_by =0)");
            $this->db->join("book_contributors bc","b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)","LEFT");
            $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
            $this->db->join("channels as c","cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->join("channels_retailers as cr","c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)","LEFT");
            $this->db->join("users as u","u.id=$retailer_id AND u.status = 1");
            $this->db->join("currency as cu","cb.currency_id = cu. id");
            $this->db->join("retailer_preference_country as rpc","rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id","LEFT");
            $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id","LEFT");
            $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
            $this->db->join("business_models bm", "bm.id = c.business_model_id");
            $this->db->where("c.status = 1 AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            if(!empty($search)){
                $this->db->where("((LOWER(b.title) LIKE '%$search%') OR (LOWER(cp.name) LIKE '%$search%'))");
            }
            if(!empty($business_model_id)){
               $this->db->where_in("c.business_model_id",$business_model_id);
            }
            $this->db->order_by("c.id,b.id,rpc.country_id", "DESC");
            $this->db->order_by("cu.seq_no,cu.code", "ASC");
            $this->db->group_by("b.id");
            $query = $this->db->get();
        }else{
    //        $this->db->select("SQL_CALC_FOUND_ROWS DISTINCT u.id as user_id,b.id as book_id,b.title,cb.new_standard_price,cb.currency_id,(CASE WHEN cu.symbol IS NOT NULL THEN cu.symbol else cu.code end)as symbol");
            $this->db->select("b.id as book_id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,c.retailers_list,cr.retailer_id");
            $this->db->from("channels_books as cb");
            $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("book_contributors bc","b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)","LEFT");
            $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
            $this->db->join("channels as c","cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->join("channels_retailers as cr","c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)","LEFT");
            $this->db->join("users as u","u.id=$retailer_id AND u.status = 1");
            $this->db->join("currency as cu","cb.currency_id = cu. id");
            $this->db->join("retailer_preference_country as rpc","rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id","LEFT");
            $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id","LEFT");
            $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
            $this->db->join("business_models bm", "bm.id = c.business_model_id");
            $this->db->where("c.status = 1 AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            if(!empty($search)){
                $this->db->where("((LOWER(b.title) LIKE '%$search%') OR (LOWER(cp.name) LIKE '%$search%'))");
            }
            if(!empty($business_model_id)){
                $this->db->where_in("c.business_model_id",$business_model_id);
            }
            $this->db->order_by("c.id,b.id,rpc.country_id", "DESC");
            $this->db->order_by("cu.seq_no,cu.code", "ASC");
            $this->db->group_by("b.id");
            $query = $this->db->get();
        }
//        echo $this->db->last_query();exit;
        if ($query->num_rows() > 0) {
            $bookarr = $query->result_array();
            if (is_array($bookarr) && count($bookarr) > 0) {
                $c = 0;
                foreach ($bookarr as $key => $val) {
                    if(($bookarr[$key]['retailers_list']=='Blacklist' && $bookarr[$key]['retailer_id']==$retailer_id)||($bookarr[$key]['retailers_list']=='Whitelist' && $bookarr[$key]['retailer_id']!=$retailer_id)){
                    }else{
                        $retarray[$c]['book_id'] = $bookarr[$key]['book_id'];
                        $retarray[$c]['title'] = stripslashes($bookarr[$key]['title']);
                        $retarray[$c]['author'] = $bookarr[$key]['author'];
                        $retarray[$c]['image'] = (!empty($bookarr[$key]['image']) && file_exists($path . '/' . $bookarr[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $bookarr[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                        $c++;
                    }
                }
            }
        }
        return $retarray;
    }

    /**
     * Retailer Catalog
     *
     * @access	public
     * @param	book_id
     * @return	Array
     */
     public function get_retailer_catalog_price_by_id($book_id,$retailer_id,$business_model_id=null,$flag=0) {
        $retarray = array();
        $namearray = array();
        $bookarr = array();
        $pricearr = array();
        $channelarray = array();

        $this->db->select("cb.new_standard_price,c.retailers_list,cr.retailer_id,c.id as channel_id,(CASE WHEN cu.symbol IS NOT NULL THEN cu.symbol else cu.code end)as symbol,cu.code,bm.name as bm_name,bm.short_description as short_desc");
        $this->db->from("channels_books as cb");
        $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
        $this->db->join("channels as c","cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
        $this->db->join("channels_retailers as cr","c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)","LEFT");
        $this->db->join("users as u","u.id=$retailer_id AND u.status = 1");
        $this->db->join("currency as cu","cb.currency_id = cu. id");
        $this->db->join("retailer_preference_country as rpc","rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id","LEFT");
        $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id","LEFT");
        $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
        $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
        $this->db->join("business_models bm", "bm.id = c.business_model_id");
        $this->db->where("c.status = 1 AND cb.book_id=$book_id AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
        if(!empty($business_model_id)){
               $this->db->where_in("c.business_model_id",$business_model_id);
        }
        $this->db->order_by("c.id,b.id,rpc.country_id", "DESC");
        $this->db->order_by("cu.seq_no,cu.code", "ASC");
//        $this->db->group_by("c.id"); 
       $query_price = $this->db->get();
//       echo $this->db->last_query();exit;
//        if ($query->num_rows() > 0) {
//            $retarray = $query->result_array();
//        }
        if($query_price->num_rows()>0){
                            $pricearr = $query_price->result_array();
//                            echo "<pre>";print_r($pricearr);exit;
                            if(is_array($pricearr) && count($pricearr) > 0){
                                foreach ($pricearr as $key=>$val){
                                    if(($pricearr[$key]['retailers_list']=='Blacklist' && $pricearr[$key]['retailer_id']==$retailer_id) ||($pricearr[$key]['retailers_list']=='Whitelist' && $pricearr[$key]['retailer_id']!=$retailer_id)){ 
                                    }else{
                                        $channel_id =  $pricearr[$key]['channel_id'];
                                        if (!in_array($channel_id, $channelarray)) {
                                                $d = 0;
                                                array_push($channelarray, $channel_id);
                                        }
                                        if(empty($retarray[$channel_id]['main_price'])){
                                            $retarray[$channel_id]['main_price'] = $pricearr[$key]['symbol']." ".$pricearr[$key]['new_standard_price']." ".$pricearr[$key]['bm_name'];
                                            $retarray[$channel_id]['price_list'] = $pricearr[$key]['symbol']." ".$pricearr[$key]['new_standard_price'];
                                            $retarray[$channel_id]['business_model'] = $pricearr[$key]['bm_name']."-".$pricearr[$key]['short_desc'];
                                        }
                                        else{
                                            $retarray[$channel_id]['price'][$d]['currency'] = $pricearr[$key]['code'];
                                            $retarray[$channel_id]['price'][$d]['original_digital_list'] = $pricearr[$key]['new_standard_price'];
                                        }
                                        $d++;
                                    }
                                }
                            }
                        }
        return $retarray;
    }
    /**
     * Curation book list
     *
     * @access	public
     * @param	retailer_id,curation_id
     * @return	Array
     */
     public function get_curation_book_by_list_id($retailer_id,$curation_id) {
        $retarray = array();
        $namearray = array();

        $path = realpath(PUBPATH . '../assets/images/bookcovers');

        if ($query->num_rows() > 0) {
            $bookarr = $query->result_array();
            if (is_array($bookarr) && count($bookarr) > 0) {
                $c = 0;
                foreach ($bookarr as $key => $val) {
                    $book_title = stripslashes($bookarr[$key]['title']);
                    if (!in_array($book_title, $namearray)) {
                        $c = 0;
                        array_push($namearray, $book_title);
                    }
                    $retarray['book_id'] = $bookarr[$key]['book_id'];
                    $retarray['title'] = $bookarr[$key]['title'];
                    $retarray['image'] = (!empty($bookarr[$key]['image']) && file_exists($path . '/' . $bookarr[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $bookarr[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                    $retarray['price'][$c]['price_list'] = $bookarr[$key]['symbol']." ".$bookarr[$key]['new_standard_price']." ".$bookarr[$key]['bm_name'];
                    $c++;
                }
            }
        }
//        echo "<pre>";
//        print_r($retarray);
//        exit;
        return $retarray;
    }

    /**
         * Book Details
         *
         * @access	public
         * @param	book_id
         * @return	Array
    */
    public function get_book_details_by_id($book_id){
            $retarray = array();
            if(!empty($book_id)){
                $this->db->select("b.id,b.title,b.cover_image as image,b.sub_title,b.volume,b.edition,b.audience_id,b.copyright_year,"
                        . "b.copyright_owner,b.supplier_details,b.supply_date,b.publication_date,b.cover_image,b.title_availability,"
                        ."b.main_subject_id,"
                        . "b.description,b.keywords,CONCAT(b.min_age_range,'-',b.max_age_range) as age_range,CONCAT(b.min_us_grade_range,'-',b.max_us_grade_range)as us_grade_range,"
                        ."GROUP_CONCAT(DISTINCT CONCAT(r.id))as region_id,"
                        ."GROUP_CONCAT(DISTINCT CONCAT(r.name))as region_name,"
                        ."GROUP_CONCAT(DISTINCT CONCAT(con.id,'_',con.name))as country_name,"
                        . "c.name as publisher,b.imprint,l.name as language,l.id as language_id,"
                        . "GROUP_CONCAT(DISTINCT con.name)as countries_included");
                $this->db->from("books b");
                $this->db->join("company c","c.id=b.company_id","LEFT");
                $this->db->join("language l","l.id=b.language_id","LEFT");
                $this->db->join("book_countries bcon","b.id=bcon.book_id AND (bcon.deleted_by < 1 OR bcon.deleted_by = 0)","LEFT");
                $this->db->join("country con","con.id=bcon.country_id","LEFT");
                $this->db->join("book_regions br","b.id=br.book_id AND (br.deleted_by < 1 OR br.deleted_by = 0)","LEFT");
                $this->db->join("regions r","r.id=br.region_id","LEFT");
                $this->db->where("b.id='".$book_id."' AND (b.deleted_by < 1 OR b.deleted_by = 0)");
                $query = $this->db->get();

                if ($query->num_rows() > 0) {
                    $retarray = $query->row();
                }
            }
            return $retarray;
    }

}
