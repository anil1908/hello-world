<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Users_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Validate User
     *
     * @access	public
     * @param	users_data
     * @return	Array
     */
    public function validate_user($users_data) {
        $retarray = array();
        $this->db->select("u.id as user_id,u.first_name,u.last_name,u.photo,c.id as company_id,c.usertype_id as usertype,COUNT(a.id) as logins,u.invited_by,GROUP_CONCAT(DISTINCT umr.module_id) as rights");
        $this->db->from("users u");
        $this->db->join("company c", "c.id=u.company_id", "LEFT");
        $this->db->join("audit_log a", "u.id=a.user_id AND c.usertype_id=a.usertype_id", "LEFT");
        $this->db->join("users_module_rights umr","u.id=umr.user_id AND (umr.deleted_by < 1 OR umr.deleted_by =0)","LEFT");
        $this->db->where($users_data);
        $query = $this->db->get();
        
        if ($query->num_rows() > 0) {
            $retarray = $query->row();
            //Insert audit log data
            if (!empty($retarray->user_id) && $retarray->usertype != 3) {
                $dataarr = array("user_id" => $retarray->user_id, "user_ip" => $_SERVER['REMOTE_ADDR'], "usertype_id" => $retarray->usertype, "log_date" => date("Y-m-d H:i:s"));
                $this->add_audit_log($dataarr);
            }
        }
        return $retarray;
    }

    /**
     * Insert audit log(User login) 
     *
     * @access	public
     * @param	auditlog_data
     * @return	NA
     */
    public function add_audit_log($auditlog_data) {
        if (is_array($auditlog_data) && count($auditlog_data) > 0) {
            $this->db->insert("audit_log", $auditlog_data);
        }
    }

    /**
     * User login count
     *
     * @access	public
     * @param	user_id,usertype_id
     * @return  number of rows
     */
    public function get_user_login_count($user_id, $usertype_id) {
        $retarray = array();
        if(!empty($user_id) && !empty($usertype_id)){
            $this->db->where("user_id", $user_id);
            $this->db->where("usertype_id", $usertype_id);
            $query = $this->db->get("audit_log");
            
            if ($query->num_rows() > 0) {
                $retarray = $query->num_rows();
            }
        }
        return $retarray;
    }

    /**
     * Insert company details
     *
     * @access	public
     * @param	company_data
     * @return	company_id
     */
    public function add_company_details($company_data) {
        $company_id = 0;
        if((is_array($company_data) && count($company_data)>0)){
            $this->db->insert('company', $company_data);
            $company_id = $this->db->insert_id();
        }
        return $company_id;
    }

    /**
     * Insert user details
     *
     * @access	public
     * @param	users_data,usertype
     * @return	user_id
     */
    public function add_user_details($users_data,$usertype) {
        $user_id = 0;
        $data = array();
        if(!empty($usertype) && (is_array($users_data) && count($users_data)>0)){
            $this->db->insert('users', $users_data);
            $user_id = $this->db->insert_id();
            if($usertype!=3){
                $usertype = "and m.usertype_id='.$usertype.'";
            }else{
                $usertype='';
            }
            $this->db->query("INSERT users_module_rights (user_id, module_id, created_on, created_by)
                               SELECT u.id, m.id, now(), u.id
                               FROM users u ,modules m
                               WHERE u.id=$user_id $usertype");
        }
        return $user_id;
    }

    /**
     * Confirm user
     *
     * @access	public
     * @param	user_id,users_data
     * @return	NA
     */
    public function update_user_confirmation($user_id, $users_data) {
        if (!empty($user_id) && (is_array($users_data) && count($users_data)>0)) {
            $this->db->where('id', $user_id);
            $this->db->update('users', $users_data);
        }
    }

    /**
     * User confirmation status
     *
     * @access	public
     * @param	user_id
     * @return	Array
     */
    public function get_user_confirm_status_by_id($user_id) {
        $retarray = array();
        if (!empty($user_id)) {
            $this->db->where('id', $user_id);
            $this->db->select('is_confirm,status');
            $query = $this->db->get('users');
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Check email
     *
     * @access	public
     * @param	email
     * @return	boolean
     */
    public function email_exists($email) {
        if(!empty($email)){
            $this->db->where('email', $email);
            $query = $this->db->get('users');
            if ($query->num_rows() <= 0) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }
    
    /**
     * Check email
     *
     * @access	public
     * @param	email,user_id
     * @return	boolean
     */
    public function email_exists_invite($email,$user_id) {
        if(!empty($user_id) && !empty($email)){
            $this->db->where('id <>', $user_id);
        }
        $this->db->where('email', $email);
        $query = $this->db->get('users');
        if ($query->num_rows() <= 0) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    /**
     * Validate token
     *
     * @access	public
     * @param	user_id
     * @return	Array
     */
    public function validate_token($user_id) {
        $retarray = array();
        if(!empty($user_id)){
            $this->db->select('u.id,u.email,u.first_name,u.last_name,c.usertype_id as usertype,COUNT(a.id) as logins');
            $this->db->from('users u');
            $this->db->join("company c", "c.id=u.company_id");
            $this->db->join("audit_log a", "u.id=a.user_id AND c.usertype_id=a.usertype_id", "LEFT");
            $this->db->where(array('u.id'=>$user_id,'u.status'=>1));
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * User details by email
     *
     * @access	public
     * @param	email
     * @return	Array
     */
    public function get_user_detail_by_email($email) {
        $retarray = array();
        if (!empty($email)) {
            $this->db->where('email', $email);
            $this->db->where('status', 1);
            $query = $this->db->get('users');
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * User details
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_users_data() {
        $retarray = array();
        $query = $this->db->get('users');
        if($query->num_rows()>0){
            $retarray = $query->result();
        }
        return $retarray;
    }

    /**
     * Usertypes
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_usertypes() {
        $retarray = array();
        $this->db->select('id,usertype');
        $this->db->where("LOWER(usertype)<>", "admin");
        $query = $this->db->get('usertypes');
        if($query->num_rows()>0){
            $retarray = $query->result();
        }
        return $retarray;
    }

    /**
     * Reset Password
     *
     * @access	public
     * @param	user_id, users_data
     * @return	NA
     */
    public function update_user_details($users_data, $user_id) {
        if (!empty($user_id) && (is_array($users_data) && count($users_data) > 0)) {
            $this->db->where("id", $user_id);
            $this->db->update("users", $users_data);
        }
    }

}
