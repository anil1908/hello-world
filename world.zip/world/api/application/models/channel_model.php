<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Channel_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Channel list by company id
     *
     * @access	public
     * @param	company_id, pageStart, pageLimit, sortField, sortType, search_name, search_from_date, search_to_date, search_business_model, search_status
     * @return	Array
     */
    public function get_channel_list_by_company_id($company_id, $pageStart, $pageLimit, $sortField, $sortType, $search_name, $search_from_date, $search_to_date, $search_business_model, $search_status) {
        $retarray = array();
        if (!empty($company_id)) {
            $this->db->select("c.id,c.name,c.created_on,CONCAT(bm.name,'-',bm.short_description)as business_model,"
                    . "g.name as group_name,c.start_date,c.end_date,GROUP_CONCAT(DISTINCT r.name)as region,c.status");
            $this->db->from("channels c");
            $this->db->join("business_models bm", "bm.id=c.business_model_id", "LEFT");
            $this->db->join("groups g", "g.id=c.group_id", "LEFT");
            $this->db->join("channels_countries cc", "c.id= cc.channel_id AND (cc.deleted_by < 1 OR cc.deleted_by = 0)", "LEFT");
            $this->db->join("country con", "con.id=cc.country_id", "LEFT");
            $this->db->join("regions r", "r.id=con.region_id", "LEFT");
            $this->db->where("c.company_id='" . $company_id . "' AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            if (!empty($search_name)) {
                $this->db->where("(LOWER(c.name) LIKE '%$search_name%')");
            }
            if (!empty($search_from_date) && !empty($search_to_date)) {
                $search_from_date = date('Y-m-d', strtotime($search_from_date));
                $search_to_date = date('Y-m-d', strtotime($search_to_date));
                $this->db->where("('" . $search_from_date . "' BETWEEN c.start_date AND c.end_date OR '" . $search_to_date . "' BETWEEN c.start_date AND c.end_date)");
            }
            if (!empty($search_business_model)) {
                $this->db->where("(c.business_model_id = '$search_business_model')");
            }
            if ($search_status != -1 && $search_status != '') {
                $this->db->where("(c.status = '$search_status')");
            }
            $this->db->group_by("c.id");
            $this->db->order_by($sortField, $sortType);
            $this->db->limit($pageLimit, $pageStart);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Count channel list
     *
     * @access	public
     * @param	company_id, search_name, search_from_date, search_to_date, search_business_model, search_status
     * @return	Count of rows
     */
    public function get_channel_list_count($company_id, $search_name, $search_from_date, $search_to_date, $search_business_model, $search_status) {
        $iTotal = 0;
        $result = array();
        if (!empty($company_id)) {
            $this->db->select("COUNT(c.id) as num_rows");
            $this->db->from("channels c");
            $this->db->where("c.company_id='" . $company_id . "'");
            if (!empty($search_name)) {
                $this->db->where("(LOWER(c.name) LIKE '%$search_name%')");
            }
            if (!empty($search_from_date) && !empty($search_to_date)) {
                $search_from_date = date('Y-m-d', strtotime($search_from_date));
                $search_to_date = date('Y-m-d', strtotime($search_to_date));
                $this->db->where("('" . $search_from_date . "' BETWEEN c.start_date AND c.end_date OR '" . $search_to_date . "' BETWEEN c.start_date AND c.end_date)");
            }
            if (!empty($search_business_model)) {
                $this->db->where("(c.business_model_id = '$search_business_model')");
            }
            if ($search_status != -1 && $search_status != '') {
                $this->db->where("(c.status = '$search_status')");
            }
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $result = $query->row();
                $iTotal = $result->num_rows;
            }
        }
        return $iTotal;
    }
    /**
     * Channel books by channel id
     *
     * @access	public
     * @param	channel_id
     * @return	Array
     */
    public function get_channel_books_by_channel_id($channel_id) {
        $retarray = array();
        if (!empty($channel_id)) {
            $this->db->select("b.id,b.name");
            $this->db->from("channels c");
            $this->db->join("books b", "b.id=c.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Update channel status
     *
     * @access	public
     * @param	channel_data,channel_id
     * @return	NA
     */
    public function update_channel_data_by_id($channel_data, $channel_id) {
        if (!empty($channel_id) && (is_array($channel_data) && count($channel_data) > 0)) {
            $this->db->where("id", $channel_id);
            $this->db->set('status', 'NOT status', FALSE);
            $this->db->update("channels", $channel_data);
        }
    }
    /**
     * Insert channel
     *
     * @access	public
     * @param	channel_data
     * @return	NA
     */
    public function insert_channel($channel_data) {
        if (is_array($channel_data) && count($channel_data) > 0) {
            $this->db->insert("channels",$channel_data);
        }
    }
    /**
     * Group book by group id
     *
     * @access	public
     * @param	group_id
     * @return	Array
     */
    public function get_group_books_by_group_id($group_id) {
        if (!empty($group_id)) {
            $this->db->where("group_id",$group_id);
            $query = $this->db->get("group_books");
            if($query->num_rows()>0){
                $retarray = $query->result_array();
            }
        }
    }
    /**
     * Channel book price
     *
     * @access	public
     * @param	channel_id
     * @return	Array
     */
    public function get_channel_books_price_by_channel_id($channel_id) {
        $retarray = array();
        $idarray = array();
        if (!empty($channel_id)) {
            $this->db->select("b.title,cb.book_id,cb.currency_id,cu.code,cb.standard_price,cb.new_standard_price,cb.publisher_share");
            $this->db->from("channels_books cb");
            $this->db->join("currency cu", "cu.id=cb.currency_id", "LEFT");
            $this->db->join("books b", "b.id=cb.book_id AND (b.deleted_by < 1 OR b.deleted_by =0)", "LEFT");
            $this->db->join("channels c", "c.id=cb.channel_id AND (c.deleted_by < 1 OR c.deleted_by =0)", "LEFT");
            $this->db->where("c.id = $channel_id AND (cb.deleted_by < 1 OR cb.deleted_by =0)");
            $this->db->order_by("b.id","ASC");
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $result = $query->result_array();
                if (is_array($result) && count($result) > 0) {
                    $i=0;
                    foreach ($result as $key=>$val) {
                        if(!in_array($result[$key]['book_id'], $idarray)){
                            $i=0;
                            array_push($idarray, $result[$key]['book_id']);
                        }
                        $retarray[$result[$key]['title']][$i]['code'] = $result[$key]['code'];
                        $retarray[$result[$key]['title']][$i]['standard_price'] = $result[$key]['standard_price'];
                        $retarray[$result[$key]['title']][$i]['new_standard_price'] = $result[$key]['new_standard_price'];
                        $retarray[$result[$key]['title']][$i]['publisher_share'] = $result[$key]['publisher_share'];
                        $i++;
                    }
                }
            }
        }
        return $retarray;
    }

    /**
     * Delete channel data
     *
     * @access	public
     * @param	channel_data,channel_id
     * @return	NA
     */
    public function delete_channel_data($channel_data, $channel_id) {
        if (!empty($channel_id) && (is_array($channel_data) && count($channel_data) > 0)) {
            $this->db->where_in("channel_id", $channel_id);
            $this->db->update("channels_retailers", $channel_data);

            $this->db->where_in("channel_id", $channel_id);
            $this->db->update("channels_countries", $channel_data);

            $this->db->where_in("channel_id", $channel_id);
            $this->db->update("channels_books", $channel_data);

            $this->db->where_in("id", $channel_id);
            $this->db->update("channels", $channel_data);
        }
    }

}
