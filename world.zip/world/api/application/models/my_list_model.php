<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class My_list_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
    
    /**
         * My list
         *
         * @access	public
         * @param	company_id
         * @return	Array
    */
    public function get_my_list_company_id($compnay_id){
        $retarray = array();
        if(!empty($compnay_id)){
            $this->db->select("id,name");
            $this->db->where("company_id",$compnay_id);
            $query = $this->db->get("my_lists");
            if($query->num_rows()>0){
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }
    /**
         * My list
         *
         * @access	public
         * @param	company_id,pageStart, pageLimit, sortField, sortType, search_name,search_from_date,search_to_date, search_created_by
         * @return	Array
    */
    public function get_my_list_by_company_id($company_id, $pageStart, $pageLimit, $sortField, $sortType, $search_name,$search_from_date,$search_to_date, $search_created_by){
            $retarray = array();
            if(!empty($company_id)){
                $this->db->select("l.id,l.name,l.created_on,CONCAT(u.first_name,' ',u.last_name)as created_by,COUNT(lb.book_id)as no_of_books");
                $this->db->from("my_lists l");
                $this->db->join("my_lists_books lb","l.id=lb.list_id","LEFT");
                $this->db->join("users u","u.id=l.created_by");
                if(!empty($search_name)){
                    $this->db->where("(LOWER(l.name) LIKE '%$search_name%')");
                }
                if(!empty($search_from_date) && !empty($search_to_date)){                                        
                    $search_from_date = date('Y-m-d', strtotime($search_from_date));                    
                    $search_to_date = date('Y-m-d', strtotime($search_to_date));
                    $this->db->where("(l.created_on > '$search_from_date' AND l.created_on < '$search_to_date')");
                }
                if(!empty($search_created_by)){
                    $this->db->where("(LOWER(CONCAT_WS(' ',u.first_name,u.last_name)) LIKE '%$search_created_by%')");
                }
                
                $this->db->where("l.company_id='".$company_id."'");
                $this->db->group_by('l.id');
                $this->db->order_by($sortField,$sortType);
                $this->db->limit($pageLimit,$pageStart);               
                $query = $this->db->get();                  
                if ($query->num_rows() > 0) {
                    $retarray = $query->result_array();
                }
        }
            return $retarray;
    }
    /**
         * Count my list
         *
         * @access	public
         * @param	company_id,name_search,search_from_date,search_to_date,created_by_search
         * @return	count of rows
    */
    public function get_my_list_count($company_id, $name_search,$search_from_date,$search_to_date,$created_by_search){
            $iTotal = 0;
            $result = array();
            if(!empty($company_id)){
                $this->db->select("COUNT(l.id) as num_rows");
                $this->db->from("my_lists l");                
                $this->db->join("users u","u.id=l.created_by","LEFT");
                 if(!empty($name_search)){
                    $this->db->where("(LOWER(l.name) LIKE '%$name_search%')");
                }
                if(!empty($search_from_date) && !empty($search_to_date)){
                    
                    $search_from_date = date('Y-m-d', strtotime($search_from_date));
                    $search_to_date = date('Y-m-d', strtotime($search_to_date));
                    $this->db->where("(l.created_on > '$search_from_date' AND l.created_on < '$search_to_date')");
                }
                if(!empty($search_created_by)){
                    $this->db->where("(LOWER(CONCAT_WS(' ',u.first_name,u.last_name)) LIKE '%$created_by_search%')");
                }
                $this->db->where("l.company_id='".$company_id."'");                
                $query = $this->db->get();
                if ($query->num_rows() > 0) {
                   $result = $query->row(); 
                   $iTotal = $result->num_rows;
                }
            }
            return $iTotal;
    }
    /**
         * My List Detail
         *
         * @access	public
         * @param	group_id
         * @return	Array
    */
    public function get_my_list_details_by_id($list_id){
            $retarray = array();
            if(!empty($group_id)){
                $this->db->select("l.id,l.name,DATE_FORMAT(l.created_on,'%m/%d/%Y') as created_on,u.first_name");
                $this->db->from("my_lists l");
                $this->db->join("my_lists_books lb","l.id=lb.list_id","LEFT");
                $this->db->join("users u","u.id=l.created_by");
                $this->db->where("l.id='".$list_id."'");
                $this->db->group_by('l.id');
                $query = $this->db->get();
                if ($query->num_rows() > 0) {
                    $retarray = $query->row();
                }
            }
            return $retarray;
    }
    /**
         * Check list name
         *
         * @access	public
         * @param	list_name,list_id
         * @return	boolean
    */
    public function check_list_name_by_id($list_name,$list_id){
            $retarray = array();
            if(!empty($list_id) && !empty($list_name)){
                $this->db->where("id<>",$list_id);
                $this->db->where("LOWER(name)",  strtolower($list_name));
                $query = $this->db->get("my_lists");
                if ($query->num_rows() > 0) {
                    return TRUE;
                }else{
                    return FALSE;
                }
            }
    }
    /**
         * Update list name
         *
         * @access	public
         * @param	list_data,list_id
         * @return	NA
    */
    public function update_list_name($list_data,$list_id){
        if(!empty($list_id) && (is_array($list_data) && count($list_data)>0)){
            $this->db->where("id",$list_id);
            $this->db->update("my_lists",$list_data);
        }
    }
    /**
         * Book Details of my lists
         *
         * @access	public
         * @param	list_id,sortField,sortType,pageStart,pageLimit,search_title, search_author, search_imprint, search_publisher
         * @return	Array
    */
    public function get_book_details_by_list_id($list_id,$sortField,$sortType,$pageStart,$pageLimit,$search_title, $search_author, $search_imprint, $search_publisher){
            $retarray = array();
            if(!empty($list_id)){
                $this->db->select("b.id,b.title,GROUP_CONCAT(DISTINCT cp.name) as author,b.publication_date,b.imprint,GROUP_CONCAT(DISTINCT bi.identifier_no) as identifier_no,c.name as publisher");
                $this->db->from("my_lists_books lb");
                $this->db->join("books b","b.id=lb.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
                $this->db->join("book_identifiers bi","b.id=bi.book_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)","LEFT");
                $this->db->join("identifier_types it","it.id=bi.identifier_type_id","LEFT");
                $this->db->join("company c","c.id=b.company_id","LEFT");
                $this->db->join("book_contributors bc","bc.role_id=1 AND lb.book_id = bc.book_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)","LEFT");
                $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
                $this->db->where("lb.list_id='".$list_id."'");
                if(!empty($search_title)){
                    $this->db->where("LOWER(b.title) LIKE '%$search_title%'");
                }
                if(!empty($search_author)){
                    $this->db->where("LOWER(cp.name) LIKE '%$search_author%'");
                }
                if(!empty($search_imprint)){
                     $this->db->where("LOWER(b.imprint) LIKE '%$search_imprint%'");
                }
                if(!empty($search_publisher)){
                     $this->db->where("LOWER(c.name) LIKE '%$search_publisher%'");
                }
                $this->db->group_by("lb.id");
                $this->db->order_by($sortField,$sortType);
                $this->db->limit($pageLimit,$pageStart);   
                $query = $this->db->get();
                if($query->num_rows()>0){
                    $retarray = $query->result_array();
                }
            }
            return $retarray;
    }
    /**
         * Count of Book Details 
         *
         * @access	public
         * @param	list_id,search_title, search_author, search_imprint, search_publisher
         * @return	count of rows
    */
    public function get_book_details_count($list_id,$search_title, $search_author, $search_imprint, $search_publisher){
            $iTotal = 0;
            $result = array();
            if(!empty($list_id)){
                $this->db->select("COUNT(gb.id) as num_rows");
                $this->db->from("my_lists_books lb");
                $this->db->join("books b","b.id=lb.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
                $this->db->join("company c","c.id=b.company_id","LEFT");
                $this->db->join("book_contributors bc","bc.role_id=1 AND lb.book_id = bc.book_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)","LEFT");
                $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
                $this->db->where("lb.list_id='".$list_id."'");
                if(!empty($search_title)){
                    $this->db->where("LOWER(b.title) LIKE '%$search_title%'");
                }
                if(!empty($search_author)){
                    $this->db->where("LOWER(cp.name) LIKE '%$search_author%'");
                }
                if(!empty($search_imprint)){
                     $this->db->where("LOWER(b.imprint) LIKE '%$search_imprint%'");
                }
                if(!empty($search_publisher)){
                     $this->db->where("LOWER(c.name) LIKE '%$search_publisher%'");
                }
                $query = $this->db->get();
                if ($query->num_rows() > 0) {
                   $result = $query->row(); 
                   $iTotal = $result->num_rows;
                }
            }
            return $iTotal;
    }
    /**
         * list name
         *
         * @access	public
         * @param	group_array
         * @return	Array
    */
    public function get_list_name($list_array){
            $retarray = array();
            if(is_array($list_array) && count($list_array) > 0){
                $this->db->select("GROUP_CONCAT(name) as lists_names");
                $this->db->where_in("id",$list_array);
                $query = $this->db->get('my_lists');
                if($query->num_rows()>0){
                    $retarray = $query->row();
                }
            }
            return $retarray;
    }
    /**
         * Check My List name
         *
         * @access	public
         * @param	list name,company_id
         * @return	boolean
    */
    public function check_list_name($list_name,$company_id){
            if(!empty($company_id)){
                $this->db->where("name ='$list_name' AND company_id=$company_id");
                $query = $this->db->get('my_lists');
                if($query->num_rows()>0){
                   return TRUE;
                }else{
                   return FALSE;
                }
            }
    }
    /**
         *Insert list
         *
         * @access	public
         * @param	list data
         * @return	list_id
    */
    public function insert_lists($list_data){
        $list_id=0;
        if(is_array($list_data) && count($list_data)>0){
            $this->db->insert("my_lists",$list_data);
            $list_id = $this->db->insert_id();
        } 
        return $list_id;
    }
    /**
         *Insert lists books
         *
         * @access	public
         * @param	list_book_data
         * @return	NA
    */
    public function insert_lists_books($list_book_data){
        if(is_array($list_book_data) && count($list_book_data)>0){
            $this->db->custom_insert_batch("my_lists_books",$list_book_data);
        }
    }
    /**
         * My Lists books
         *
         * @access	public
         * @param	lists_book_array,list_id
         * @return	Array
    */
    public function get_lists_books($lists_book_array,$list_id){
            $retarray = array();
            if((is_array($lists_book_array) && count($lists_book_array)>0) && !empty($list_id)){
                $this->db->where_in('book_id',$lists_book_array);
                $this->db->where('list_id',$list_id);
                $query = $this->db->get("my_lists_books");
                if($query->num_rows()>0){
                    $retarray = $query->result_array();
                }
            }
            return $retarray;
    }
    /**
         * My List books by group id
         *
         * @access	public
         * @param	group_array
         * @return	Array
    */
    public function get_lists_books_by_list_id($list_array){
            $retarray = array();
            if(is_array($list_array) && count($list_array)>0){
                $this->db->where_in('list_id',$list_array);
                $query = $this->db->get("my_lists_books");
                if($query->num_rows()>0){
                    $retarray = $query->result_array();
                }
            }
            return $retarray;
    }
    /**
         * Insert my lists book history
         *
         * @access	public
         * @param	list book data
         * @return	NA
    */
    public function insert_history_lists_books($lists_book_data){
            if(is_array($lists_book_data) && count($lists_book_data) >0){
                $this->db->custom_insert_batch("history_my_lists_books",$lists_book_data);
            }
    }
    /**
         * Insert my list history
         *
         * @access	public
         * @param	group data
         * @return	NA
    */
    public function insert_history_my_lists($lists_data){
            if(is_array($lists_data) && count($lists_data) >0){
                $this->db->insert_batch("history_my_lists",$lists_data);
            }
    }
    /**
         * Delete lists book 
         *
         * @access	public
         * @param	lists_book_array
         * @return	NA
    */
    public function delete_lists_books($lists_book_array){
            if(is_array($lists_book_array) && count($lists_book_array) >0){
                $this->db->where_in("list_id",$lists_book_array);
                $this->db->delete("my_lists_books");
            }
    }
     /**
         * Delete lists book by lists id
         *
         * @access	public
         * @param	delete_lists_array
         * @return	NA
    */
    public function delete_lists_books_by_lists_id($delete_lists_array){
            if(is_array($delete_lists_array) && count($delete_lists_array)>0){
                $this->db->where_in("list_id",$delete_lists_array);
                $this->db->delete('my_lists_books');
            }
    }
    /**
         * Delete lists
         *
         * @access	public
         * @param	delete_group_array
         * @return	NA
    */
    public function delete_lists_by_id($delete_lists_array){
            if(is_array($delete_lists_array) && count($delete_lists_array)>0){
                $this->db->where_in("id",$delete_lists_array);
                $this->db->delete('my_lists');
            }
    }

}
