App.directive('autoComplete', function($timeout) {
 	return {
        restrict: "A",
        require	: "?ngModel",
        link 	: function(scope, element, attrs, ngModel) {
            $timeout(function() {
            	$('#'+attrs.id).autocomplete({
	                source: scope[attrs.uiItems],
	                select: function() {
	                    $timeout(function() {
	                      	if (ngModel.$viewValue && ngModel.$viewValue !== element.val()) {
			                    scope.$apply(function() {
			                        ngModel.$setViewValue(element.val());
			                    });
			                }
	                    }, 0);
	                }
	            });
            }, 1000);
        }
    };
});