'use strict';
App.controller('booksController', ['$scope', '$rootScope', 'catalogService', '$uibModal', '$location', '$sessionStorage', 'localStorageService',
    function ($scope, $rootScope, catalogService, $uibModal, $location, $sessionStorage, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.booksList = [];
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'title',
            sorttype: 'ASC',
            maxsize: 10
        };
        $scope.state = false;
        $scope.selectedBookList = [];
        $scope.pageIds = [];
        $scope.booksListData = {bookArr: [], allchecked: false};
        $scope.isError = ($rootScope.maintainbooksisError !== undefined) ? $rootScope.maintainbooksisError : false;
        $scope.isMessage = ($rootScope.maintainbooksisMessage !== undefined) ? $rootScope.maintainbooksisMessage : false;
        $scope.message = ($rootScope.maintainbooksmessage !== undefined) ? $rootScope.maintainbooksmessage : '';


        $scope.toggleState = function () {
            $scope.state = !$scope.state;
        };

        $scope.checkAll = function () {

            if ($scope.booksListData.allchecked) {
                _.each($scope.booksList, function (element) {
                    var isavl = true;
                    _.each($scope.booksListData.bookArr, function (obj) {
                        if (obj.id === element.id) {
                            isavl = false;
                        }
                    });
                    if (isavl) {
                        $scope.booksListData.bookArr.push(element);
                    }
                });
            } else {
                var arr = [];
                angular.forEach($scope.booksListData.bookArr, function (element) {
                    if ($scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.booksListData.bookArr = arr;
            }
        };


        $scope.uncheckMain = function () {
            $scope.booksListData.allchecked = false;
        };

        $scope.getBooks = function () {
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getBooksData(booksData);
        };
        /*Grid Option*/

        $scope.$watch('currentPage', function (pageNo) {
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getBooksData(booksData);
            //or any other code here
        });

        $scope.$watch('currentPage', function (pageNo) {

            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getBooksData(booksData);
            //or any other code here
        });

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            $scope.getBooksData(booksData);
        };

        $scope.bookSearch = function () {
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            $scope.getBooksData(booksData);
        };

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            $scope.getBooksData(booksData);
        };
        $scope.cancelSearch = function () {
            $scope.search_title = '';
            $scope.search_author = '';
            $scope.search_imprint = '';
            $scope.search_publisher = '';
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_title: $scope.search_title,
                search_author: $scope.search_author,
                search_imprint: $scope.search_imprint,
                search_publisher: $scope.search_publisher
            };
            $scope.getBooksData(booksData);
        };
        /*End Grid Option*/
        $scope.getBooksData = function (booksData) {
            catalogService.getMaintainBooksList(booksData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.pageIds = data.ids.split(',');
                            $scope.booksListData.allchecked = false;
                            $scope.booksList = data.response;
                            $scope.gridOption.filteredItems = data.total_rows;
                            $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                            if ($scope.gridOption.maxsize > 5) {
                                $scope.gridOption.maxsize = 5;
                            }

                            $rootScope.maintainbooksisError = false;
                            $rootScope.maintainbooksisMessage = false;
                            $rootScope.maintainbooksmessage = '';
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.deleteSelectedBook = function () {

            if ($scope.booksListData.bookArr.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/views/publisherBookDelete.html',
                    controller: 'bookDeleteCtrl',
                    resolve: {
                        BookData: function () {
                            return {bookArr: $scope.booksListData.bookArr};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    console.log(dataObj)
                    $scope.deleteBookArr(dataObj);
                }, function () {
                    console.log('error');
                });
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/views/selectone.html',
                    controller: 'bookDeleteCtrl',
                    resolve: {
                        BookData: function () {

                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {

                }, function () {
                    console.log('Closed');
                });
            }
        };


        $scope.deleteBookRow = function (bookObj) {
            var arr = [];
            arr.push({id: bookObj.id});
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function () {
                        return {ModalTitle: "Confirmation", msg: "Are you sure you want to delete the record(s)?"};
                    }
                }
            });
            modalInstance.result.then(function () {
                debugger;
                $scope.deleteBookArr(arr);
            }, function () {
                console.log('error');
            });

        };
        $scope.deleteBookArr = function (dataObj) {
            var bookIdArr = [];

            angular.forEach(dataObj, function (value, key) {
                bookIdArr.push(value.id);

            });

            var bookData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                bookListArr: bookIdArr
            };
            catalogService.deleteBook(bookData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.getBooks();
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        /*Book Details*/
        $scope.bookDetailsModal = function (bookId) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/publisherBookDetail.html',
                controller: 'bookDetailCtrl',
                resolve: {
                    bookData: function () {
                        return {bookId: bookId,type:'publisher'};
                    }
                }
            });
            modalInstance.result.then(function (bookObj) {
                $location.path('/editbook?id=' + bookObj.id);
            }, function () {
                console.log('Closed');
            });
        };

    }]);

App.controller('bookDeleteCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'BookData', 'localStorageService',
    function ($scope, $rootScope, $uibModalInstance, BookData, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.ModalTitle = 'Confirmation';
        $scope.bookDelete = function () {
            $uibModalInstance.close({bookArr: BookData.bookArr});
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
        /*$scope.rowDelete = function () {
         $uibModalInstance.close({bookArr: BookData.bookObj});
         };*/
    }]);