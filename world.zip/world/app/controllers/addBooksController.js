'use strict';
App.controller('addBooksController', ['$scope', '$rootScope', 'bookService', '$uibModal', '$location', '$sessionStorage', 'localStorageService',
    function ($scope, $rootScope, bookService, $uibModal, $location, $sessionStorage, localStorageService) {
        var TokenData                   = localStorageService.get('authorizeTokenDetail');
        var parameter                   = $location.search();

        if(parameter.id!==undefined){
            var bookData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    catalog_id  : parameter.id
            };
            bookService.getBookDetail(bookData)
                .then(function(data){
                    if(data.error<=0){
                        var bookObject  = data.response.catalog;
                        var ageArr      = (bookObject.age_range!==undefined && bookObject.age_range!=='')?bookObject.age_range.split('-'):[];
                        var gradeArr    = (bookObject.us_grade_range!==undefined && bookObject.us_grade_range!=='')?bookObject.us_grade_range.split('-'):[]; 
                        $scope.bookDetail = {bookid:parameter.id,title:bookObject.title,sub_title:bookObject.sub_title,
                                            volume:bookObject.volume,edition:bookObject.edition,
                                            contributor:[],identifier:[],priceArr:[],
                                            publisher:bookObject.publisher,imprint:bookObject.imprint,publication_date:bookObject.publication_date,
                                            language_id:bookObject.language_id,subject_id:bookObject.subject_id,
                                            main_subject_id:bookObject.main_subject_id,description:bookObject.description,
                                            keywords:bookObject.keywords,
                                            min_age_range:(ageArr[0]!==undefined)?ageArr[0]:'',max_age_range:(ageArr[1]!==undefined)?ageArr[1]:'',
                                            min_us_grade_range:(gradeArr[0]!==undefined)?gradeArr[0]:'',max_us_grade_range:(gradeArr[1]!==undefined)?gradeArr[1]:'',
                                            region_id:(bookObject.region_id!==undefined)?bookObject.region_id.split(","):[],
                                            country_id:(bookObject.countries_included!==undefined)?bookObject.countries_included.split(","):[],
                                            audience_id:bookObject.audience_id,
                                            copyright_year:bookObject.copyright_year,copyright_owner:bookObject.copyright_owner,
                                            supplier_details:bookObject.supplier_details,supply_date:bookObject.supply_date,
                                            title_availability:bookObject.title_availability,cover_image:bookObject.cover_image};
                        if(bookObject.contributor_role.length>0){
                            _.each(bookObject.contributor_role, function(contributorArr) {
                                var arr = contributorArr.split('-');
                                $scope.bookDetail.contributor.push({contributorrole:(arr[0]!==undefined)?arr[0]:'',
                                                                    contributorname:(arr[1]!==undefined)?arr[1]:''});
                            })
                        };
                        if(bookObject.identifier.length>0){
                            _.each(bookObject.identifier, function(identifierArr) {
                                var arr = identifierArr.split('=');
                                $scope.bookDetail.identifier.push({identifiertype:(arr[0]!==undefined)?arr[0]:'',
                                                                   identifiername:(arr[1]!==undefined)?arr[1]:''});
                            });
                        };
                        if(bookObject.price.length>0){
                            _.each(bookObject.price, function(priceval) {
                                var arr = priceval.split('-');
                                $scope.bookDetail.priceArr.push({currency_id:(arr[0]!==undefined)?arr[0]:'',
                                                                 price:(arr[1]!==undefined)?arr[1]:''});
                            })
                        };
                        $scope.bookReviewList           = [];
                        $scope.bookAwardList            = [];
                        $scope.bookRelatedProductsList  = [];
                        if(data.response.catalog_reviews.length>0){
                            _.each(data.response.catalog_reviews, function(reviewsArr) {
                                $scope.bookReviewList.push({reviewtype:{name:reviewsArr.reviewtype_name,id:reviewsArr.reviewtype_id},
                                                           reviewsource:{name:reviewsArr.reviewsource_name,id:reviewsArr.reviewsource_id},
                                                           reviewtitle:reviewsArr.title,
                                                           reviewtext:reviewsArr.review,
                                                           reviewurl:reviewsArr.url,
                                                           reviewdate:reviewsArr.created_on,
                                                           reviewrole:{name:reviewsArr.reviewrole_name,id:reviewsArr.reviewrole_id}});
                            })
                        }
                        if(data.response.catalog_awards.length>0){
                            _.each(data.response.catalog_awards, function(awardsArr) {
                                $scope.bookAwardList.push({awardcountry:{name:awardsArr.awardcountry_name,id:awardsArr.awardcountry_id},
                                                           awardcode:{name:awardsArr.awardcode_name,id:awardsArr.awardcode_id},
                                                           awardname:awardsArr.award_name,
                                                           awardyear:awardsArr.year});
                            })
                        }
                        if(data.response.catalog_related_products.length>0){
                            _.each(data.response.catalog_related_products, function(productArr) {
                                $scope.bookRelatedProductsList.push({relatedcode:{name:productArr.relatedcode_name,id:productArr.relatedcode_id},
                                                           identifiertype:{name:productArr.identifiertype_name,id:productArr.identifiertype_id},
                                                           identifiername:productArr.title});
                            })
                        }
                    }
                    else{
                        $scope.message      = err.errorMsg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;    
                    }
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        }
        else{
            $scope.bookDetail               = {bookid:'',title:'',sub_title:'',volume:'',edition:'',
            contributor:[{contributorrole:'',contributorname:''}],
            identifier:[{identifiertype:'',identifiername:''}],publisher:'',imprint:'',publication_date:'',
            priceArr:[{currency_id:'',price:''}],language_id:'',subject_id:[],main_subject_id:'',
            description:'',keywords:'',min_age_range:'',max_age_range:'',min_us_grade_range:'',
            max_us_grade_range:'',region_id:[],country_id:[],
            audience_id:'',
            copyright_year:'',copyright_owner:'',supplier_details:'',supply_date:'',
            title_availability:'',cover_image:''};

            $scope.bookReviewList           = [];
            $scope.bookAwardList            = [];
            $scope.bookRelatedProductsList  = [];
        }
        
        $scope.bookReviewDetail         = {reviewtype:{id:'',name:''},reviewsource:{id:'',name:''},
                                            reviewtitle:'',reviewtext:'',reviewurl:'',reviewdate:'',
                                            reviewrole:{id:'',name:''}};
        $scope.bookAwardDetail          = {awardname:'',awardyear:'',
                                            awardcountry:{id:'',name:''},awardcode:{id:'',name:''}};
        $scope.bookRelatedProductDetail = {relatedcode:{id:'',name:''},identifiertype:{id:'',name:''}
                                            ,identifiername:''};                                            
        $scope.bookReviewEdit           = false;
        $scope.bookAwardEdit            = false;
        $scope.bookRelatedProductEdit   = false;
        $scope.editBookReviewObject     = {};
        $scope.editBookAwardObject      = {};
        $scope.editBookRelatedProductObject = {};
        $scope.bookAward                = {};
        $scope.AwardList                = [];
        $scope.bookRelatedProducts      = {};
        $scope.contributorList          = [];
        $scope.identifierList           = [];
        $scope.currencyList             = [];
        $scope.languageList             = [];
        $scope.subjectList              = [];
        $scope.regionList               = [];
        $scope.countryList              = [];
        $scope.audienceList             = [];
        $scope.ageRange                 = ['1','2','3','4','5'];
        $scope.yearList                 = ['2016','2017','2018','2019'];
        $scope.reviewTypeList           = [];
        $scope.reviewSourceList         = [];
        $scope.reviewRoleList           = [];
        $scope.awardCountryList         = [];
        $scope.awardCodeList            = [];
        $scope.RelatedCodeList          = [];
        $scope.message                  = '';
        $scope.isError                  = false;
        $scope.isMessage                = false;
        $scope.bookReviewFormSubmit     = false;
        $scope.isSubmitted              = false;
        $scope.bookAwardFormSubmit      = false;
        $scope.bookProductFormSubmit    = false;
        $scope.bookRelatedProductFormSubmit = false;
        $scope.validage     = false;
      
        $scope.bookView                 = function(){
            $location.search({});
            $location.path('/maintainbooks');
        }
        $scope.addContributor           = function(){
            $scope.bookDetail.contributor.push({contributorrole:'',contributorname:''});
        };
        $scope.removeContributor        = function(contributorDetail){
            $scope.bookDetail.contributor.splice($scope.bookDetail.contributor.indexOf(contributorDetail),1);
        };
        $scope.getContributorsRole      = function(){
            var contributorData = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getContributorsRoleList(contributorData)
                .then(function(data){
                    $scope.contributorList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });   
        };
        $scope.addIdentifier            = function(){
            $scope.bookDetail.identifier.push({identifiertype:'',identifiername:''});  
        };
        $scope.removeIdentifier         = function(identifierDetail){
            $scope.bookDetail.identifier.splice($scope.bookDetail.identifier.indexOf(identifierDetail),1);
        };
        $scope.getIdentifierType        = function(){
            var identifierData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getIdentifierTypeList(identifierData)
                .then(function(data){
                    $scope.identifierList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.addPrice                 = function(){
            $scope.bookDetail.priceArr.push({currency_id:'',price:''});     
        };
        $scope.removePrice              = function(priceDetail){
            $scope.bookDetail.priceArr.splice($scope.bookDetail.priceArr.indexOf(priceDetail),1);
        };
        $scope.getCurrencyList          = function(){
            var currencyData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getCurrencyList(currencyData)
                .then(function(data){
                    $scope.currencyList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        }
        $scope.getLanguageList          = function(){
            var languageData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getLanguageList(languageData)
                .then(function(data){
                    $scope.languageList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getSubjectList           = function(){
            var subjectData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getSubjectList(subjectData)
                .then(function(data){
                    $scope.subjectList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getRegionList            = function(){
            var regionData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getRegionList(regionData)
                .then(function(data){
                    $scope.regionList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getAudienceList          = function(){
            var audienceData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getAudienceList(audienceData)
                .then(function(data){
                    $scope.audienceList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.updateCountry            = function(){
            var countryData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    region_array: $scope.bookDetail.region_id
            };
            bookService.getCountryList(countryData)
                .then(function(data){
                    $scope.countryList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getAllCountry            = function(){
            var countryData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    region_array: [1]
            };
            bookService.getCountryList(countryData)
                .then(function(data){
                    $scope.awardCountryList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getReviewTypeList        = function(){
            var reviewData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getReviewTypeList(reviewData)
                .then(function(data){
                    $scope.reviewTypeList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getReviewSourceList      = function(){
            var reviewData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getReviewSourceList(reviewData)
                .then(function(data){
                    $scope.reviewSourceList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getReviewRoleList        = function(){
            var reviewData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getReviewRoleList(reviewData)
                .then(function(data){
                    $scope.reviewRoleList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }); 
        };
        $scope.getAwardList             = function(){
            var awardData  = {
                        access_token: TokenData.access_token,
                        language        : $rootScope.language
                };
            bookService.getAwardList(awardData)
            .then(function(data){
                $scope.AwardList   = _.pluck(data.response,'name');
            },
            function(err,status){
                $scope.message      = err.errorMsg;
                $scope.isError      = true;
                $scope.isMessage    = false;
            }); 
        };
        $scope.getAwardCodeList         = function(){
            var reviewData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getAwardCodeList(reviewData)
                .then(function(data){
                    $scope.awardCodeList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }); 
        };
        $scope.getRelatedCodeList       = function(){
            var reviewData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getRelatedCode(reviewData)
                .then(function(data){
                    $scope.RelatedCodeList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }); 
        };
        $scope.addBookReview            = function(){
            if($scope.addbookreviewform.$valid){
                $scope.bookReviewList.push($scope.bookReviewDetail);
                $scope.bookReviewDetail = {reviewtype:{id:'',name:''},reviewsource:{id:'',name:''},
                                            reviewtitle:'',reviewtext:'',reviewurl:'',reviewdate:'',
                                            reviewrole:{id:'',name:''}};
                $scope.bookReviewFormSubmit     = false;
            }
            else{
                $scope.bookReviewFormSubmit     = true;
            }
        };
        $scope.deleteBookReview         = function(bookReview){
            $scope.bookReviewList.splice($scope.bookReviewList.indexOf(bookReview),1);
        };
        $scope.editBookReview           = function(bookReview){
            var reviewsourceval = _.where($scope.reviewSourceList, {id: bookReview.reviewsource.id, name: bookReview.reviewsource.name});
            var reviewtypeval   = _.where($scope.reviewTypeList, {id: bookReview.reviewtype.id, name: bookReview.reviewtype.name});
            var reviewroleval = _.where($scope.reviewRoleList, {id: bookReview.reviewrole.id, name: bookReview.reviewrole.name});
            $scope.bookReviewEdit       = true;
            $scope.editBookReviewObject       = bookReview;
            $scope.bookReviewDetail = {reviewtype:(reviewtypeval[0]!==undefined)?reviewtypeval[0]:{},
                                        reviewsource:(reviewsourceval[0]!==undefined)?reviewsourceval[0]:{},
                                        reviewtitle:bookReview.reviewtitle,reviewtext:bookReview.reviewtext,
                                        reviewurl:bookReview.reviewurl,reviewdate:bookReview.reviewdate,
                                        reviewrole:(reviewroleval[0]!==undefined)?reviewroleval[0]:{}};
        };
        $scope.updateBookReview         = function(){
            if($scope.addbookreviewform.$valid){
                $scope.bookReviewList.splice($scope.bookReviewList.indexOf($scope.editBookReviewObject),1);
                $scope.bookReviewList.push($scope.bookReviewDetail);
                $scope.bookReviewDetail     = {reviewtype:{id:'',name:''},reviewsource:{id:'',name:''},
                                                reviewtitle:'',reviewtext:'',reviewurl:'',reviewdate:'',
                                                reviewrole:{id:'',name:''}};
                $scope.bookReviewEdit       = false;
                $scope.editBookReviewObject = {};
            }
            else{
                $scope.bookReviewFormSubmit     = true;
            }
        };
        $scope.addBookAward             = function(){
            if($scope.addbookawardform.$valid){
                $scope.bookAwardList.push($scope.bookAwardDetail);
                $scope.bookAwardDetail          = {awardname:'',awardyear:'',
                                                    awardcountry:{id:'',name:''},awardcode:{id:'',name:''}};
                $scope.bookAwardFormSubmit     = false;
            }
            else{
                $scope.bookAwardFormSubmit     = true;
            }
        };
        $scope.deleteBookAward          = function(bookAward){
            $scope.bookAwardList.splice($scope.bookAwardList.indexOf(bookAward),1);
        };
        $scope.editBookAward            = function(bookAward){
            var awardcountryval = _.where($scope.awardCountryList, {id: bookAward.awardcountry.id, name: bookAward.awardcountry.name});
            var awardcodeval    = _.where($scope.awardCodeList, {id: bookAward.awardcode.id, name: bookAward.awardcode.name});
            $scope.bookAwardEdit        = true;
            $scope.editBookAwardObject  = bookAward;
            $scope.bookAwardDetail      = {awardname:bookAward.awardname,awardyear:bookAward.awardyear,
                                            awardcountry:(awardcountryval[0]!==undefined)?awardcountryval[0]:{},
                                            awardcode:(awardcodeval[0]!==undefined)?awardcodeval[0]:{}};
        };
        $scope.updateBookAward          = function(){
            if($scope.addbookawardform.$valid){
                $scope.bookAwardList.splice($scope.bookAwardList.indexOf($scope.editBookAwardObject),1);
                $scope.bookAwardList.push($scope.bookAwardDetail);
                $scope.bookAwardDetail          = {awardname:'',awardyear:'',
                                                    awardcountry:{id:'',name:''},awardcode:{id:'',name:''}};
                $scope.bookAwardEdit        = false;
                $scope.editBookAwardObject  = {};
            }
            else{
                $scope.bookReviewFormSubmit     = true;
            }
        };
        $scope.addBookRelatedProduct    = function(){
            if($scope.addbookproductform.$valid){
                $scope.bookRelatedProductsList.push($scope.bookRelatedProductDetail);
                $scope.bookRelatedProductDetail = {relatedcode:{id:'',name:''},identifiertype:{id:'',name:''}
                                            ,identifiername:''};
                $scope.bookProductFormSubmit    = false;
            }
            else{
                $scope.bookProductFormSubmit    = true;
            }
        };
        $scope.deleteBookRelatedProduct = function(bookProduct){
            $scope.bookRelatedProductsList.splice($scope.bookRelatedProductsList.indexOf(bookProduct),1);
        };
        $scope.editBookRelatedProduct   = function(bookProduct){
            var identifiertypeval = _.where($scope.identifierList, {id: bookProduct.identifiertype.id, name: bookProduct.identifiertype.name});
            var relatedcodeval    = _.where($scope.RelatedCodeList, {id: bookProduct.relatedcode.id, name: bookProduct.relatedcode.name});
            $scope.bookRelatedProductEdit        = true;
            $scope.editBookRelatedProductObject  = bookProduct;
            $scope.bookRelatedProductDetail      = {relatedcode     :(relatedcodeval[0]!==undefined)?relatedcodeval[0]:{},
                                                    identifiertype  :(identifiertypeval[0]!==undefined)?identifiertypeval[0]:{},
                                                    identifiername  :bookProduct.identifiername};
        };
        $scope.updateBookRelatedProduct = function(){
            if($scope.addbookproductform.$valid){
                $scope.bookRelatedProductsList.splice($scope.bookRelatedProductsList.indexOf($scope.editBookRelatedProductObject),1);
                $scope.bookRelatedProductsList.push($scope.bookRelatedProductDetail);
                $scope.bookRelatedProductDetail = {relatedcode:{id:'',name:''},identifiertype:{id:'',name:''}
                                            ,identifiername:''};
                $scope.bookRelatedProductEdit        = false;
                $scope.editBookRelatedProductObject  = {};
                $scope.bookRelatedProductFormSubmit  = false;
            }
            else{
                $scope.bookRelatedProductFormSubmit     = true;
            }
        };
        $scope.setFile = function(element) {
            $scope.currentFile  = element.files[0];
            var reader          = new FileReader();
            reader.onload       = function(event){
                $scope.bookDetail.cover_image   = event.target.result;
                $scope.$apply();
            }
            reader.readAsDataURL(element.files[0]);
        };

        $scope.addBookDetail            = function(){
            if($scope.addbook.$valid){
                var bookData  = {
                        access_token: TokenData.access_token,
                        language        : $rootScope.language,
                        bookDetail      : $scope.bookDetail,
                        bookReview      : $scope.bookReviewList,
                        bookAward       : $scope.bookAwardList,
                        relatedProduct  : $scope.bookRelatedProductsList,
                };
                bookService.insertBookDetail(bookData)
                .then(function(data){
                    if(data.error<=0){
                        $location.search({});
                        $location.path('/maintainbooks');
                        $scope.message                  = err.msg;
                        $scope.isError                  = false;
                        $scope.isMessage                = true;
                    }
                    else{
                        $scope.message      = err.msg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;
                    }
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }); 
            }
            else{
                $scope.isSubmitted    = true;
            }
        };

        $scope.editBookDetail           = function(){
            if($scope.addbook.$valid){
                var bookData  = {
                        access_token: TokenData.access_token,
                        language        : $rootScope.language,
                        bookDetail      : $scope.bookDetail,
                        bookReview      : $scope.bookReviewList,
                        bookAward       : $scope.bookAwardList,
                        relatedProduct  : $scope.bookRelatedProductsList,
                };
                bookService.insertBookDetail(bookData)
                .then(function(data){
                    if(data.error<=0){
                        $location.search({});
                        $location.path('/maintainbooks');
                        $scope.message                  = err.msg;
                        $scope.isError                  = false;
                        $scope.isMessage                = true;
                    }
                    else{
                        $scope.message      = err.msg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;
                    }
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }); 
            }
            else{
                $scope.isSubmitted    = true;
            }
        };

        $scope.getContributorsRole();
        $scope.getIdentifierType();
        $scope.getCurrencyList();
        $scope.getSubjectList();
        $scope.getLanguageList();
        $scope.getRegionList();
        $scope.getAudienceList();
        $scope.getReviewTypeList();
        $scope.getReviewSourceList();
        $scope.getReviewRoleList();
        $scope.getAllCountry();
        $scope.getAwardCodeList();
        $scope.getRelatedCodeList();
        $scope.getAwardList();
}]);
