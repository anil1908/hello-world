'use strict';
App.controller('myaccountController', ['$scope', '$rootScope','$uibModal', 'profileService', '$location', '$sessionStorage', 'localStorageService',
    function ($scope, $rootScope,$uibModal,profileService, $location, $sessionStorage, localStorageService) {
        $scope.userData = {
            first_name: '',
            last_name: '',
            email: '',
            password: '',
            reenter_password: '',
            photo: ''
        };
        $scope.message = '';
        $scope.showConfirmationModal = false;
        $scope.showAccountInfoEditModal = false;
        $scope.isImage = false;
        $scope.isSubmitted = false;
        $scope.formname = 'edituserprofile';
        var tokenData = localStorageService.get('authorizeTokenDetail');

        $scope.userAccountDetail = function () {
            var TokenData = localStorageService.get('authorizeTokenDetail');
            var userDetail = {access_token: TokenData.access_token, language: $rootScope.language}
            profileService.getuserAccountDetail(userDetail)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.userData         = data.response;
                            $scope.isImage          = data.response.is_image;
                            $rootScope.userData.photo= data.response.photo;
                            var userData            = cookies.get('authorizationData');
                            userData.photo          = data.response.photo;
                            cookies.set('authorizationData',userData);
                            $scope.isError          = false;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.toggleAccountInfoEditModal = function () {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/publishermyaccountedit.html',
                controller: 'accountEditCtrl',
                resolve: {
                    accountDetail: function () {
                        return {userData:$scope.userData};
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                if (dataObj.data.error <= 0) {
                    $scope.isError  = false;
                    $scope.isMessage= true;
                    $scope.message  = dataObj.data.msg;
                    $scope.userData.first_name  = dataObj.userDetail.first_name;
                    $scope.userData.last_name   = dataObj.userDetail.last_name;
                    var userDataList            = cookies.get('authorizationData');
                    userDataList.first_name     = dataObj.userDetail.first_name;
                    userDataList.last_name      = dataObj.userDetail.last_name;
                    cookies.set('authorizationData',userDataList);
                    $rootScope.userData.first_name = dataObj.userDetail.first_name;
                    $rootScope.userData.last_name = dataObj.userDetail.last_name;
                } else {
                    $scope.isError  = true;
                    $scope.isMessage= false;
                    $scope.message  = dataObj.data.errorMsg;
                }
            }, function () {
              console.log('error');
            });
        };

        $scope.uploadFile = function (event) {
            var fileData = event.target.files;
            profileService.editUserPhoto(fileData, {access_token: tokenData.access_token, language: $rootScope.language})
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.$emit('updateFile', {filePath: data.thumbnail_name, isImage: true});
                            $('#file').val('');
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $('#file').val('');
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = err.errorMsg;
                    });
        };

        $scope.toggleConfirmationModal = function () {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/publisherDeleteConfirmation.html',
                controller: 'accountPhotoDeleteCtrl',
                resolve: {
                    accountDetail: function () {
                        return {};
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                profileService.deleteUserPhoto({access_token: tokenData.access_token, 
                                                language: $rootScope.language})
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.$emit('updateFile', {filePath: data.image, isImage: data.is_image});
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
            }, function () {
              console.log('error');
            });
        };

        $scope.$on('updateFile', function (event, data) {
            $rootScope.userData.photo= data.filePath;
            var userData            = cookies.get('authorizationData');
            userData.photo          = data.filePath;
            cookies.set('authorizationData',userData);
            $scope.userData.photo = data.filePath;
            $scope.isImage = data.isImage;
        });
        $scope.userAccountDetail();
}]);


App.controller('accountEditCtrl', ['$scope','$rootScope','$uibModalInstance', 'profileService', '$location', '$sessionStorage', 'localStorageService','accountDetail',
    function ($scope, $rootScope,$uibModalInstance, profileService, $location, $sessionStorage, localStorageService,accountDetail) {
    
    $scope.ModalTitle   = "Account Information"
    var TokenData       = localStorageService.get('authorizeTokenDetail');
    $scope.form         = {};
    $scope.userData     = accountDetail.userData;

    $scope.editUser     = function () {
        if ($scope.form.edituserprofile.$valid) {
            if ($scope.userData.password === '' || $scope.userData.password === $scope.userData.reenter_password)
            {
                $scope.userData.language    = $rootScope.language;
                $scope.userData.access_token= TokenData.access_token;
                profileService.editUser($scope.userData)
                        .then(function (data) {
                            $uibModalInstance.close({data:data,userDetail:$scope.userData});
                        }, function (err, status) {
                            $scope.isError  = true;
                            $scope.isMessage= false;
                            $scope.message  = err.errorMsg;
                        });
            } else {
                $scope.edituserprofile.reenter_password.$error.required = true;
                $scope.isSubmitted = true;
            }
        } else {
            $scope.isSubmitted = true;
        }
    };

    $scope.cancel       = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);

App.controller('accountPhotoDeleteCtrl', ['$scope','$rootScope','$uibModalInstance', 'profileService', '$location', '$sessionStorage', 'localStorageService','accountDetail',
    function ($scope, $rootScope,$uibModalInstance, profileService, $location, $sessionStorage, localStorageService,accountDetail) {
    
    $scope.ModalTitle   = "Confirmation"
    var TokenData       = localStorageService.get('authorizeTokenDetail');
    $scope.rowDelete    = function(){
        $uibModalInstance.close({});
    };
    $scope.cancel       = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);
