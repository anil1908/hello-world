'use strict';
App.controller('createretailerwidgetsController', ['$scope', '$rootScope', '$uibModal', '$location', 'localStorageService',
    function ($scope, $rootScope, $uibModal, $location, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');


}]);