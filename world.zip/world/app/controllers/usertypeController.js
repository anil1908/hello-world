'use strict';
App.controller('usertypeController',['$scope','$rootScope','$location','usertypeService','$sessionStorage','localStorageService',
	function($scope,$rootScope,$location,usertypeService,$sessionStorage,localStorageService){
        /*$sessionStorage.contentDisplay = {signinMenu:false,signupMenu:false,userAccount:true,menuTab:false};
        $rootScope.contentDisplay   = $sessionStorage.contentDisplay;*/
        
        var authTokenData       = localStorageService.get('authorizeTokenDetail');
        $scope.usertype         = parseInt(authTokenData.usertype);
        var userData 			= cookies.get('authorizationData');//localStorageService.get('authorizationData');$sessionStorage.authorizationData;
		$rootScope.userData	    = userData;

		$scope.userLogins		= function(usertype){
			usertypeService.getUserLogins({language:$rootScope.language,
                                            usertype_id:parseInt(usertype),
                                            access_token:authTokenData.access_token})
                .then(function (data) {
                    if (data.error <= 0) {
                    	var userTypeData 		= cookies.get('authorizationData');//localStorageService.get('authorizationData');$sessionStorage.authorizationData;
                        userTypeData.logins     = data.logins;                        
                        cookies.get('authorizationData',userTypeData);                        
                        $scope.usertype         = usertype;
                        authTokenData.usertype   = usertype;
                        localStorageService.set('authorizeTokenDetail',authTokenData);
                        $sessionStorage.contentDisplay = {signinMenu: false,
                                signupMenu: false,
                                userAccount: true,
                                menuTab: true};
                        $rootScope.contentDisplay = $sessionStorage.contentDisplay;
                                                
                        if(data.logins>1){                            
                            if(usertype == 1)
                                $location.path('/dashboard');
                            else
                                $location.path('/retailerdashboard');
                        }
                    }
                    else{
                        $scope.isError = true;
                        $scope.message = data.errorMsg;
                    }
                },
                function (err,status) {
                    $scope.message = err.errorMsg;
                });
		}
}]);