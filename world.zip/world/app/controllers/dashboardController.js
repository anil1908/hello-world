'use strict';
App.controller('dashboardController', ['$scope', '$rootScope', 'dashboardService','$location', '$sessionStorage', 'localStorageService',
    function ($scope, $rootScope, dashboardService, $location, $sessionStorage, localStorageService) {
        
        $scope.dashboardData = {
            name: '',            
            usertype: '',
            photo: ''
        };               
        $scope.companyAccountDetail = function () {             
            var TokenData = localStorageService.get('authorizeTokenDetail');
            $scope.usertype         = (TokenData!==null)? parseInt(TokenData.usertype) : '';            
            var companyDetail = {access_token: TokenData.access_token, language: $rootScope.language, usertype: $scope.usertype}
            dashboardService.getcompanyDetail(companyDetail)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.dashboardData = data.response;                    
                            $scope.isImage = data.is_image;
                            $scope.isError = false;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;                            
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        $scope.companyAccountDetail();
    }]);