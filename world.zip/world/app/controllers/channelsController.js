'use strict';
App.controller('channelsController', ['$scope', '$rootScope', 'channelService', 'businessmodelService', '$uibModal', '$location', '$sessionStorage', 'localStorageService',
    function ($scope, $rootScope, channelService, businessmodelService, $uibModal, $location, $sessionStorage, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.channelsList = [];
        $scope.modelList = [];
        $scope.priceList = [];
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'created_on',
            sorttype: 'DESC',
            maxsize: 10
        };
        $scope.state = false;
        $scope.selectedChannelList = [];
        $scope.channelListData = {channelArr: [], allchecked: false};
        $scope.pageIds = [];
        $scope.showButtonBar = false;
        $scope.format = 'MM/dd/yyyy';
        $scope.dateOptions = {
            dateDisabled: false,
            formatYear: 'yy',
            maxDate: new Date(2020, 5, 22),
            minDate: null,
            startingDay: 1,
            showWeeks: false,
        };
        $scope.showbuttonbar = false;
        $scope.popup1 = {opened: false};
        $scope.popup2 = {opened: false};
        $scope.showSelectGroupModal = false;
        $scope.isError = ($rootScope.channelisError !== undefined) ? $rootScope.channelisError : false;
        $scope.isMessage = ($rootScope.channelisMessage !== undefined) ? $rootScope.channelisMessage : false;
        $scope.message = ($rootScope.channelmessage !== undefined) ? $rootScope.channelmessage : '';


        $scope.getChannels = function () {
            var channelsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype
            };
            $scope.getChannelsData(channelsData);
        };

        $scope.getChannelsData = function (channelsData) {
            channelService.getChannelsList(channelsData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.pageIds = data.ids.split(',');
                            $scope.channelListData.allchecked = false;
                            $scope.channelsList = data.response;
                            $scope.gridOption.filteredItems = data.total_rows;
                            $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                            if ($scope.gridOption.maxsize > 5) {
                                $scope.gridOption.maxsize = 5;
                            }
                            $rootScope.channelmessage = '';
                            $rootScope.channelisError = false;
                            $rootScope.channelisMessage = false;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.channelSearch = function () {
            if ($scope.search_from_date != '' && $scope.search_from_date != undefined) {
                var from_date = new Date($scope.search_from_date);
                from_date = from_date.toLocaleDateString();
            }
            if ($scope.search_to_date != '' && $scope.search_to_date != undefined) {
                var to_date = new Date($scope.search_to_date);
                to_date = to_date.toLocaleDateString();
            }
            var channelsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_from_date: from_date,
                search_to_date: to_date,
                search_model: $scope.search_model,
                search_status: $scope.search_status
            };
            $scope.getChannelsData(channelsData);
        };

        $scope.cancelSearch = function () {
            $scope.search_name = '';
            $scope.search_from_date = '';
            $scope.search_to_date = '';
            $scope.search_status = '';
            $scope.search_model = '';
            var channelsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_from_date: $scope.search_from_date,
                search_to_date: $scope.search_to_date,
                search_model: $scope.search_model,
                search_status: $scope.search_status
            };
            $scope.getChannelsData(channelsData);
        };

        $scope.$watch('currentPage', function (pageNo) {
            if ($scope.search_from_date != '' && $scope.search_from_date != undefined) {
                var from_date = new Date($scope.search_from_date);
                from_date = from_date.toLocaleDateString();
            }
            if ($scope.search_to_date != '' && $scope.search_to_date != undefined) {
                var to_date = new Date($scope.search_to_date);
                to_date = to_date.toLocaleDateString();
            }
            var channelsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_from_date: from_date,
                search_to_date: to_date,
                search_model: $scope.search_model,
                search_status: $scope.search_status
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getChannelsData(channelsData);
            //or any other code here
        });

        /*Grid Option*/
        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';

            if ($scope.search_from_date != '' && $scope.search_from_date != undefined) {
                var from_date = new Date($scope.search_from_date);
                from_date = from_date.toLocaleDateString();
            }
            if ($scope.search_to_date != '' && $scope.search_to_date != undefined) {
                var to_date = new Date($scope.search_to_date);
                to_date = to_date.toLocaleDateString();
            }

            var channelsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_from_date: from_date,
                search_to_date: to_date,
                search_model: $scope.search_model,
                search_status: $scope.search_status
            };
            $scope.getChannelsData(channelsData);
        };

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;

            if ($scope.search_from_date != '' && $scope.search_from_date != undefined) {
                var from_date = new Date($scope.search_from_date);
                from_date = from_date.toLocaleDateString();
            }
            if ($scope.search_to_date != '' && $scope.search_to_date != undefined) {
                var to_date = new Date($scope.search_to_date);
                to_date = to_date.toLocaleDateString();
            }

            var channelsData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                search_name: $scope.search_name,
                search_from_date: from_date,
                search_to_date: to_date,
                search_model: $scope.search_model,
                search_status: $scope.search_status
            };
            $scope.getChannelsData(channelsData);
        };

        $scope.toggleState = function () {
            $scope.state = !$scope.state;
        };

        $scope.checkAll = function () {
            if ($scope.channelListData.allchecked) {
                angular.forEach($scope.channelsList, function (element) {
                    $scope.channelListData.channelArr.push(element);
                });
            } else {
                var arr = [];
                angular.forEach($scope.channelListData.channelArr, function (element) {
                    if ($scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.channelListData.channelArr = arr;
            }
        };

        $scope.uncheckMain = function () {
            $scope.channelListData.allchecked = false;
        };

        $scope.getBusinessModelList = function () {
            var TokenData = localStorageService.get('authorizeTokenDetail');
            var channelData = {
                access_token: TokenData.access_token,
                language: $rootScope.language
            };
            businessmodelService.getBusinessModelList(channelData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.modelList = data.response;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        $scope.getBusinessModelList();

        /* Delete Channel */
        $scope.deleteSelectedChannel = function () {
            if ($scope.channelListData.channelArr.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/views/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData: function () {
                            return {ModalTitle: "Confirmation", msg: "Are you sure you want to delete the record(s)?"};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.deleteChannelArr({channelArr: $scope.channelListData.channelArr});
                }, function () {
                    console.log('Closed');
                });
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/views/selectone.html',
                    controller: 'channelDeleteCtrl',
                    resolve: {
                        ChannelData: function () {

                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {

                }, function () {
                    console.log('Closed');
                });
            }
        };

        $scope.deleteChannelRow = function (channelObj) {
            var arr = [];
            arr.push({id: channelObj.id});
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function () {
                        return {ModalTitle: "Confirmation", msg: "Are you sure you want to delete the record(s)?"};
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                $scope.deleteChannelArr({channelArr: arr});
            }, function () {
                console.log('Closed');
            });
        };

        $scope.deleteChannelArr = function (dataObj) {
            var channelIdArr = [];
            angular.forEach(dataObj.channelArr, function (value, key) {
                channelIdArr.push(value.id);
            });
            var channelData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                channelArr: channelIdArr
            };
            channelService.deleteChannel(channelData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.getChannels();
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };
        /* End Delete Group */

        $scope.updateStatus = function (channelid) {
            var TokenData = localStorageService.get('authorizeTokenDetail');
            var channelData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                channel_id: channelid
            };
            channelService.updateChannelStatus(channelData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        }

        $scope.channelBookPrice = function (channelid) {
            var TokenData = localStorageService.get('authorizeTokenDetail');
            var channelData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                channel_id: channelid
            };
            channelService.getChannelBookPrice(channelData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            var modalInstance = $uibModal.open({
                                animation: true,
                                templateUrl: 'app/views/channelbookprice.html',
                                controller: 'channelPriceCtrl',
                                resolve: {
                                    ChannelPrice: function () {
                                        return {ChannelPrice: data};
                                    }
                                }
                            });
                            modalInstance.result.then(function (dataObj) {

                            }, function () {
                                console.log('Closed');
                            });

                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        }

    }]);

App.controller('channelPriceCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'ChannelPrice', 'localStorageService',
    function ($scope, $rootScope, $uibModalInstance, ChannelData, localStorageService) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        $scope.ModalTitle = 'Confirmation';
        $scope.ChannelPrice = ChannelData.ChannelPrice.response;
        $scope.business_id = ChannelData.ChannelPrice.business_id;
        $scope.status = {
            isCustomHeaderOpen: false,
            isFirstOpen: false,
            isFirstDisabled: false
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };

    }]);