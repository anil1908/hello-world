'use strict';
App.controller('profileController', ['$scope','$rootScope','$uibModal', 'profileService', '$location', '$sessionStorage', 'localStorageService',
    function ($scope, $rootScope,$uibModal, profileService, $location, $sessionStorage, localStorageService) {
        $scope.companyData              = {address: '', contact_no: '', contact_person: '', name: ''};
        $scope.financialData            = {account_number: '', bank_address: '', bank_name: '', dwolla_account_number: '', routing_number: ''};
        $scope.logo                     = '';
        $scope.isCompanyFinancialSubmitted = false;
        $scope.showPublisherConfirmationModal = false;
        $scope.isImage                  = false;
        $scope.companyInfoActive        = true;
        $scope.showInviteActionModal    = false;
        $scope.isUserSubmitted          = false;
        $scope.inviteNewUserSubmitted   = false;
        $scope.permissionArr            = [];
        $scope.pageSizeArr              = [1, 5, 10, 20, 50, 100];
        $scope.currentPage              = 1;
        $scope.pageLimit                = 10;
        $scope.list                     = [];
        $scope.sortField                = 'created_on';
        $scope.sorttype                 = 'DESC';
        var TokenData = localStorageService.get('authorizeTokenDetail');

        $scope.profileDetail = function () {
            if ($scope.companyInfoActive) {
                var profileDetail = {access_token: TokenData.access_token,
                    language: $rootScope.language};
                profileService.getProfileDetail(profileDetail)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.logo = data.response.logo;
                                $scope.companyData = data.response.company;
                                $scope.financialData = data.response.financial;
                                $scope.isImage = data.response.is_image;
                                $scope.isError = false;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.message = err.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            } else {
                var userDetail = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.currentPage - 1) * $scope.pageLimit,
                    pageLimit: $scope.pageLimit,
                    sortField: $scope.sortField,
                    sorttype: $scope.sorttype,
                };
                $scope.getUserData(userDetail);
            }
        };

        /*user information*/
        $scope.getUserData = function (userDetail) {
            var permissionDetail = {access_token: TokenData.access_token,
                                    language    : $rootScope.language,
                                    usertype    : TokenData.usertype};
            profileService.getPermissionList(permissionDetail)
                .then(function(data){
                    if (data.error <= 0) {
                        $scope.permissionArr = data.response;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                },function(err, status){
                    $scope.message = err.errorMsg;
                    $scope.isError = true;
                    $scope.isMessage = false;
            });
                             
            profileService.getCompanyUser(userDetail)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.currentUser      = cookies.get('authorizationData').user_id;//localStorageService.get('authorizationData').user_id;//$sessionStorage.authorizationData.user_id;
                            $scope.list             = data.response;
                            $scope.filteredItems    = data.total_rows;
                            $scope.totalItems       = data.total_rows;
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.setPage = function (pageNo) {
            var userDetail = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.pageLimit,
                pageLimit: $scope.pageLimit,
                sortField: $scope.sortField,
                sorttype: $scope.sorttype,
            };
            $scope.currentPage = pageNo;
            $scope.getUserData(userDetail);
        };

        $scope.sort_by = function (sortField) {
            $scope.sortField = sortField;
            $scope.sorttype = ($scope.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var userDetail = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.currentPage - 1) * $scope.pageLimit,
                pageLimit: $scope.pageLimit,
                sortField: sortField,
                sorttype: $scope.sorttype,
            };
            $scope.getUserData(userDetail);
        };

        $scope.changePageSize = function () {
            $scope.currentPage = 1;
            var userDetail = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.currentPage - 1) * $scope.pageLimit,
                pageLimit: $scope.pageLimit,
                sortField: $scope.sortField,
                sorttype: $scope.sorttype,
            };
            $scope.getUserData(userDetail);
        };

        $scope.toggleEditInviteUserModal = function (index,id) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/publishereditinviteuser.html',
                controller: 'editInviteUserCtrl',
                resolve: {
                    userData :  function (){
                        return {index:index,id:id,permissionArr:$scope.permissionArr};
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                if (dataObj.data.error <= 0) {
                    $scope.message  = dataObj.data.msg;
                    $scope.isError  = false;
                    $scope.isMessage= true;
                } else {
                    $scope.isError  = true;
                    $scope.isMessage= false;
                    $scope.message  = dataObj.data.errorMsg;
                }
                var userDetail = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.currentPage - 1) * $scope.pageLimit,
                    pageLimit: $scope.pageLimit,
                    sortField: $scope.sortField,
                    sorttype: $scope.sorttype,
                };
                $scope.getUserData(userDetail);

            }, function () {
              console.log('error');
            });
        }

        $scope.toggleInviteActionModal = function (index, id, status) {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'actionuser.tpl',
                controller: 'userActionCtrl',
                resolve: {
                    userDataDetail: function () {
                        return {ModalTitle:'Confirmation',index: index, id: id, status: status};
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                //debugger;
                if (dataObj.data.error <= 0) {
                    $scope.list[dataObj.index].action = dataObj.data.response.action;
                    $scope.list[dataObj.index].active = dataObj.data.response.active;
                    $scope.list[dataObj.index].status = dataObj.data.response.status;
                    $scope.isError                    = false;
                    $scope.isMessage                  = true;
                    $scope.message                    = dataObj.data.msg;
                } else {
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = dataObj.data.errorMsg;
                }
            }, function () {
              console.log('error');
            });
        };

        $scope.resendConfirmation   = function(id,email){
            var resendData ={
                                access_token    : TokenData.access_token,
                                language        : $rootScope.language,
                                email           : email,
                                company_user_id : id
                            };
                profileService.resendConfirmation(resendData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.$parent.isError  = false;
                                $scope.$parent.isMessage= true;
                                $scope.$parent.message  = data.msg;
                            } else {
                                $scope.$parent.isError  = true;
                                $scope.$parent.isMessage= false;
                                $scope.$parent.message  = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.$parent.message      = err.errorMsg;
                            $scope.$parent.isError      = true;
                            $scope.$parent.isMessage    = false;
                        });
        };

        $scope.toggleInviteNewUserModal = function(){
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/publisherInviteNewUser.html',
                controller: 'inviteNewUserCtrl',
                resolve: {
                    userData :  function (){
                        return {permissionArr:$scope.permissionArr};
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                //debugger;
                if(dataObj.data.error <= 0) {
                    $scope.isError  = false;
                    $scope.isMessage= true;
                    $scope.message  = dataObj.data.msg;
                } else {
                    $scope.isError  = true;
                    $scope.isMessage= false;
                    $scope.message  = dataObj.data.errorMsg;
                }
            }, function () {
              console.log('error');
            });
        };

        /*end user information*/
        $scope.togglePublisherAccountInfoEditModal = function () {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/publisheraccountinfoedit.html',
                controller: 'CompanyContactCtrl',
                resolve: {
                    companyDataDetail: function () {
                        return $scope.companyData;
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                if (dataObj.data.error <= 0) {
                    $scope.isError  = false;
                    $scope.isMessage= true;
                    $scope.message  = dataObj.data.msg;
                } else {
                    $scope.isError  = true;
                    $scope.isMessage= false;
                    $scope.message  = dataObj.data.errorMsg;
                }
            }, function () {
              console.log('error');
            });
        };

        $scope.togglePublisherEditFinancialModal = function () {
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/publisherfinancialinfoedit.html',
                controller: 'CompanyFinancialCtrl',
                resolve: {
                    financialDataDetail: function () {
                        return $scope.financialData;
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                if (dataObj.data.error <= 0) {
                    $scope.isError  = false;
                    $scope.isMessage= true;
                    $scope.message  = dataObj.data.msg;
                } else {
                    $scope.isError  = true;
                    $scope.isMessage= false;
                    $scope.message  = dataObj.data.errorMsg;
                }
            }, function () {
              console.log('error');
            });
        };

        $scope.uploadFile = function (event) {
            var fileData = event.target.files;
            profileService.editCompanyPhoto(fileData, {access_token: TokenData.access_token, language: $rootScope.language})
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.$emit('updateCompanyFile', {filePath: data.thumbnail_name, isImage: true});
                            $('#file').val('');
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                        } else {
                            $('#file').val('');
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = err.errorMsg;
                    });
        };

        $scope.togglePublisherConfirmationModal = function () {
            $scope.ModalTitle = "Confirmation";
            $scope.showPublisherConfirmationModal = !$scope.showModal;
        };

        $scope.deleteCompanyPhoto = function () {
            profileService.deleteCompanyPhoto({access_token: TokenData.access_token, language: $rootScope.language})
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.$emit('updateCompanyFile', {filePath: data.image, isImage: data.is_image});
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                            $('.companyphotocancle').trigger('click');
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                            $('.companyphotocancle').trigger('click');
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.tabChange = function (status) {
            $scope.companyInfoActive = status;
            $scope.profileDetail();
        };

        $scope.$on('updateCompanyContact', function (event, data) {
            $scope.companyData = {address: data.address, contact_no: data.contact_no, contact_person: data.contact_person, name: data.name};
        });
        $scope.$on('updateCompanyFinancial', function (event, data) {
            $scope.financialData = {account_number: data.account_number, bank_address: data.bank_address, bank_name: data.bank_name, dwolla_account_number: data.dwolla_account_number, routing_number: data.routing_number};
        });
        $scope.$on('updateCompanyFile', function (event, data) {
            $scope.logo = data.filePath;
            $scope.isImage = data.isImage;
        });
        $scope.profileDetail();
}]);

App.controller('editInviteUserCtrl', ['$scope','$rootScope','$uibModalInstance', 'profileService', '$location', '$sessionStorage', 'localStorageService','userData',
    function ($scope, $rootScope,$uibModalInstance, profileService, $location, $sessionStorage, localStorageService,userData) {
    
    $scope.permissionArr     = userData.permissionArr;    
    var TokenData            = localStorageService.get('authorizeTokenDetail');
    $scope.form              = {};
    $scope.userDetail        = {};
    var userDetailData       = {access_token    : TokenData.access_token,
                                language        : $rootScope.language,
                                company_user_id : userData.id};

    profileService.getUserDetail(userDetailData)
        .then(function(data){
            if (data.error <= 0) {
                $scope.userDetail = data.response;
            } else {
                $scope.$parent.isError = true;
                $scope.$parent.isMessage = false;
                $scope.$parent.message = data.errorMsg;
            }
        },function(err,status){
            $scope.$parent.message = err.errorMsg;
            $scope.$parent.isError = true;
            $scope.$parent.isMessage = false;
        });

    $scope.editUserDetail = function(){
        if($scope.form.edituser.$valid){
            var rights = [];
            angular.forEach($scope.userDetail.rights, function(value, key) {
              this.push(value.id);
            }, rights);
            var userRightsArr ={
                                access_token    : TokenData.access_token,
                                language        : $rootScope.language, 
                                first_name      : $scope.userDetail.first_name, 
                                last_name       : $scope.userDetail.last_name, 
                                company_user_id : $scope.userDetail.id, 
                                rights_array    : rights  
                                };

            profileService.updateUserDetail(userRightsArr)
            .then(function(data){
                $uibModalInstance.close({data:data});
            },function(err,status){
                $scope.$parent.message = err.errorMsg;
                $scope.$parent.isError = true;
                $scope.$parent.isMessage = false;
                $uibModalInstance.dismiss('cancel');
            });
        }
        else{
            $scope.isUserSubmitted = true;
        }
    }

    $scope.checkAll = function() {
        if($scope.userDetail.allchecked){
            $scope.userDetail.rights = angular.copy($scope.permissionArr);  
        }
        else{
            $scope.userDetail.rights = [];
        }
    };
    $scope.uncheckMain = function(){
        $scope.userDetail.allchecked = false;
    };

    $scope.cancel       = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);

App.controller('userActionCtrl', ['$scope','$rootScope','$uibModalInstance', 'profileService', '$location', '$sessionStorage', 'localStorageService','userDataDetail',
    function ($scope, $rootScope,$uibModalInstance, profileService, $location, $sessionStorage, localStorageService,userDataDetail) {
    
    var TokenData           = localStorageService.get('authorizeTokenDetail');
    $scope.userDataDetail   = userDataDetail;
    $scope.changeUserStatus = function (index, id, status) {
        var userStatusData  = {access_token: TokenData.access_token,
                                language: $rootScope.language,
                                company_user_id: id,
                                status: !parseInt(status)};

        profileService.changeUserStatus(userStatusData)
                .then(function (data) {
                    $uibModalInstance.close({index:index,data:data});
                }, function (err, status) {
                    $scope.message = err.errorMsg;
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $uibModalInstance.dismiss('cancel');
                });
    };
    $scope.cancel       = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);

App.controller('inviteNewUserCtrl', ['$scope','$rootScope','$uibModalInstance', 'profileService', '$location', '$sessionStorage', 'localStorageService','userData',
    function ($scope, $rootScope,$uibModalInstance, profileService, $location, $sessionStorage, localStorageService,userData) {
    
    var TokenData           = localStorageService.get('authorizeTokenDetail');
    $scope.form             = {};
    $scope.inviteNewUserData= {}; 
    $scope.permissionArr    = userData.permissionArr;
    $scope.inviteNewUser    = function(){
        if($scope.form.inviteNewUser.$valid){
            var rights = [];
            angular.forEach($scope.inviteNewUserData.rights, function(value, key) {
              this.push(value.id);
            }, rights);
            var inviteNewUserObj ={
                                access_token    : TokenData.access_token,
                                language        : $rootScope.language, 
                                email_ids       : $scope.inviteNewUserData.email, 
                                rights_array    : rights,
                                usertype        : TokenData.usertype  
                                };
            profileService.inviteNewUser(inviteNewUserObj)
                .then(function (data) {
                    $uibModalInstance.close({data:data});
                }, function (err, status) {
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                    $uibModalInstance.dismiss('cancel');
                });
        }
        else{
            $scope.inviteNewUserSubmitted = true;
        }
    };
    $scope.checkAll = function() {
        if($scope.inviteNewUserData.allchecked){
            $scope.inviteNewUserData.rights = angular.copy($scope.permissionArr);  
        }
        else{
            $scope.inviteNewUserData.rights = [];
        }
    };
    $scope.uncheckMain = function(){
        $scope.inviteNewUserData.allchecked = false;
    };
    $scope.cancel       = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);

App.controller('CompanyContactCtrl', ['$scope','$rootScope','$uibModalInstance', 'profileService', '$location', '$sessionStorage', 'localStorageService','companyDataDetail',
    function ($scope, $rootScope,$uibModalInstance, profileService, $location, $sessionStorage, localStorageService,companyDataDetail) {
    
    var TokenData = localStorageService.get('authorizeTokenDetail');
    $scope.isCompanyContactSubmitted    = false;
    $scope.companyDataDetail            = companyDataDetail;
    $scope.companyDataDetail.contact_no = ($scope.companyDataDetail.contact_no!==null)?parseInt($scope.companyDataDetail.contact_no):$scope.companyDataDetail.contact_no;
    $scope.form = {};
    $scope.editCompanyContactDetail = function () {
        if ($scope.form.editcompanycontactprofile.$valid) {
            var companyContactData = $scope.companyDataDetail;
            companyContactData.language = $rootScope.language;
            companyContactData.access_token = TokenData.access_token;
            profileService.editCompanyContactDetail(companyContactData)
                    .then(function (data) {
                        $uibModalInstance.close({data:data});
                    }, function (err, status) {
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                        $scope.$parent.message = err.errorMsg;
                        $uibModalInstance.dismiss('cancel');
                    });
        } else {
            $scope.isCompanyContactSubmitted = true;
        }
    };
    $scope.cancel       = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);

App.controller('CompanyFinancialCtrl', ['$scope','$rootScope','$uibModalInstance', 'profileService', '$location', '$sessionStorage', 'localStorageService','financialDataDetail',
    function ($scope, $rootScope,$uibModalInstance, profileService, $location, $sessionStorage, localStorageService,financialDataDetail) {
    
    var TokenData                           = localStorageService.get('authorizeTokenDetail');
    $scope.financialDataDetail              = financialDataDetail;
    $scope.financialDataDetail.dwolla_account_number = ($scope.financialDataDetail.dwolla_account_number!==null)?parseInt($scope.financialDataDetail.dwolla_account_number):$scope.financialDataDetail.dwolla_account_number;
    $scope.financialDataDetail.account_number = ($scope.financialDataDetail.account_number!==null)?parseInt($scope.financialDataDetail.account_number):$scope.financialDataDetail.account_number;
    $scope.financialDataDetail.routing_number = ($scope.financialDataDetail.routing_number!==null)?parseInt($scope.financialDataDetail.routing_number):$scope.financialDataDetail.routing_number;
    $scope.form = {};
    $scope.editCompanyFinancialDetail = function () {
        if ($scope.form.editcompanyfinancialprofile.$valid) {
            var companyFinancialData            = $scope.financialDataDetail;
            companyFinancialData.language       = $rootScope.language;
            companyFinancialData.access_token   = TokenData.access_token;

            profileService.editCompanyFinancialDetail(companyFinancialData)
                .then(function (data) {
                    $uibModalInstance.close({data:data});
                }, function (err, status) {
                    $scope.$parent.isError = true;
                    $scope.$parent.isMessage = false;
                    $scope.$parent.message = err.errorMsg;
                });
        } else {
            $scope.isCompanyFinancialSubmitted = true;
        }
    };
    $scope.cancel       = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);