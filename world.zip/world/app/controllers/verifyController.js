App.controller('verifyController', ['$scope','$rootScope', '$http','$location','$window',
    function ($scope, $rootScope, $http, $location,$window) {	
        if ($location.search().u != '' && $location.search().u != undefined) {
                $http({
                    method: 'POST',
                    url: 'api/signup/verify_user',
                    data: {user_id:$location.search().u,language:$rootScope.language}, // pass in data as strings                   
                    headers: {'Content-Type': 'application/json'},
                }).success(function (data) {                    
                    if (data.error <= 0) {
                        $scope.isMessage    = true;
                        $rootScope.message  = data.msg;
                        $location.$$search  = {};
                        $location.path('/');
                    } else {
                        $scope.isError      = true;
                        $rootScope.errmessage  = data.errorMsg;
                        $location.$$search  = {};
                        $location.path('/');
                    }
                },
                function(err,status){
                    $scope.isError = true;
                    $scope.message = err.errorMsg;
                });

            } 
}]);