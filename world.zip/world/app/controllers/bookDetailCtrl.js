App.controller('bookDetailCtrl', ['$scope', '$rootScope', 'catalogService', '$uibModalInstance', 'localStorageService', 'bookData',
    function ($scope, $rootScope, catalogService, $uibModalInstance, localStorageService, bookData) {
        var TokenData = localStorageService.get('authorizeTokenDetail');
        var bodata = {
            access_token: TokenData.access_token,
            language: $rootScope.language,
            catalog_id: bookData.bookId
        };
        if(bookData.type=='retailer'){
            catalogService.getRetailerBooksDetail(bodata)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.bookDetailData = data.response;
                        if (data.response.catalog.contributor.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.contributor, function (contributorArr) {
                                str += contributorArr.contributorname + '-' + contributorArr.contributorrolename + ' , ';
                            })
                            $scope.bookDetailData.catalog.contributor_role = str.slice(0, -2);
                        };
                        if (data.response.catalog.subject_id.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.subject_id, function (subArr) {
                                str += subArr.name + ' , ';
                            })
                            $scope.bookDetailData.catalog.subject = str.slice(0, -2);
                        };
                        if (data.response.catalog.identifier.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.identifier, function (identifierArr) {
                                str += identifierArr.identifiername + '(' + identifierArr.identifiertypename + ')' + ' , ';
                            })
                            $scope.bookDetailData.catalog.identifier = str.slice(0, -2);
                        };
                        if (data.response.catalog.country_id.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.country_id, function (countryArr) {
                                var arr = countryArr.split('_');
                                str += ((arr[1] !== undefined) ? arr[1] : '') + ' , ';
                            })
                            $scope.bookDetailData.catalog.country_id = str.slice(0, -2);
                        } else {
                            $scope.bookDetailData.catalog.country_id = '';
                        }
                        $scope.bookDetailData.catalog.region_name = data.response.catalog.region_name.toString();
                    } else {
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                        $scope.$parent.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.$parent.message = err.errorMsg;
                    $scope.$parent.isError = true;
                    $scope.$parent.isMessage = false;
                });
        }
        else{
            catalogService.getBooksDetail(bodata)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.bookDetailData = data.response;
                        if (data.response.catalog.contributor.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.contributor, function (contributorArr) {
                                str += contributorArr.contributorname + '-' + contributorArr.contributorrolename + ' , ';
                            })
                            $scope.bookDetailData.catalog.contributor_role = str.slice(0, -2);
                        };

                        if (data.response.catalog.subject_id.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.subject_id, function (subArr) {
                                str += subArr.name + ' , ';
                            })
                            $scope.bookDetailData.catalog.subject = str.slice(0, -2);
                        };

                        if (data.response.catalog.identifier.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.identifier, function (identifierArr) {
                                str += identifierArr.identifiername + '(' + identifierArr.identifiertypename + ')' + ' , ';
                            })
                            $scope.bookDetailData.catalog.identifier = str.slice(0, -2);
                        };
                        if (data.response.catalog.country_id.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.country_id, function (countryArr) {
                                var arr = countryArr.split('_');
                                str += ((arr[1] !== undefined) ? arr[1] : '') + ' , ';
                            })
                            $scope.bookDetailData.catalog.country_id = str.slice(0, -2);
                        } else {
                            $scope.bookDetailData.catalog.country_id = '';
                        }

                        if (data.response.catalog.priceArr.length > 0) {
                            var str = '';
                            _.each(data.response.catalog.priceArr, function (prices) {
                                str += prices.symbol + ' ' + prices.price + ' , ';
                            })
                            $scope.bookDetailData.catalog.price = str.slice(0, -2);
                        };
                        $scope.bookDetailData.catalog.region_name = data.response.catalog.region_name.toString();
                    } else {
                        $scope.$parent.isError = true;
                        $scope.$parent.isMessage = false;
                        $scope.$parent.message = data.errorMsg;
                    }
                }, function (err, status) {
                    $scope.$parent.message = err.errorMsg;
                    $scope.$parent.isError = true;
                    $scope.$parent.isMessage = false;
                });
        }

        $scope.editBook = function () {
            $uibModalInstance.close({ id: $scope.bookDetailData.catalog.id });
            window.location = 'editbook?id=' + $scope.bookDetailData.catalog.id;
        };
        $scope.cancel = function () {
            //$modalInstance.dismiss('cancel');
            $uibModalInstance.dismiss('cancel');
        };
    }]);
