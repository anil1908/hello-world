var App = angular.module('OneWorld', [
    'ui.router',
    'ui.grid',
    'ui.grid.pagination',
    'ui.grid.autoResize',
    'ui.bootstrap',
    'ui.checkbox',
    'angular-loading-bar',
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngSanitize',
    'ngTouch',
    'ngMessages',
    'pascalprecht.translate',
    'tmh.dynamicLocale',
    'remoteValidation',
    'LocalStorageModule',
    'ngStorage',
    'ngCookies',
    'checklist-model',
    'xeditable',
    'ngTagsInput',
    'ngCookies',
    'jkuri.gallery',
    'angular-cache',
    'ui.select2',
    'ivh.treeview'
])
    .constant('DEBUG_MODE', true)
    .constant('DATE_FORMAT', 'MM/dd/yyyy')
    .constant('LOCALES', {
        'locales': {
            'ru_RU': 'Русский',
            'en_US': 'English'
        },
        'preferredLocale': 'en_US',
    })
    .config(['$stateProvider', '$urlRouterProvider', '$locationProvider', '$translateProvider', 'tmhDynamicLocaleProvider', function ($stateProvider, $urlRouterProvider, $locationProvider, $translateProvider, tmhDynamicLocaleProvider) {
        $locationProvider.html5Mode(true);
        $urlRouterProvider.otherwise('/');
        // Now set up the states
        $stateProvider
            .state('home', {
                title: 'HOME_HEADER_TITLE',
                url: '/',
                templateUrl: 'app/views/login.html',
                controller: 'loginController',

            })
            .state('signup', {
                title: 'SIGNUP_HEADER_TITLE',
                url: '/signup',
                templateUrl: 'app/views/signup.html',
                controller: 'signupController',

            })
            .state('verify', {
                title: 'Verify',
                url: '/verify?u',
                templateUrl: 'app/views/verify.html',
                controller: 'verifyController',

            })
            .state('userselection', {
                title: 'SELECT_USERTYPE',
                url: '/userselection',
                templateUrl: 'app/views/usertype.html',
                controller: 'usertypeController',

            })
            .state('resetpasswordchk', {
                title: 'SIGNUP_HEADER_TITLE',
                url: '/resetpasswordchk',
                //templateUrl: 'app/views/resetpassword.html',
                controller: 'resetpasswordchkController',

            })
            .state('resetpassword', {
                title: 'SIGNUP_HEADER_TITLE',
                url: '/resetpassword',
                templateUrl: 'app/views/resetpassword.html',
                controller: 'resetpasswordController',

            })
            .state('dashboard', {
                title: 'DASHBOARD_TITLE',
                url: '/dashboard',
                templateUrl: 'app/views/dashboard.html',
                controller: 'dashboardController',

            })
            .state('profile', {
                title: 'PUBLISHER_COMPANY_PROFILE_TITLE',
                url: '/profile',
                templateUrl: 'app/views/profile.html',
                controller: 'profileController',

            })
            .state('myaccount', {
                title: 'SIGNUP_HEADER_TITLE',
                url: '/myaccount',
                templateUrl: 'app/views/myaccount.html',
                controller: 'myaccountController',

            })
            .state('groups', {
                title: 'GROUPS_HEADER_TITLE',
                url: '/groups',
                templateUrl: 'app/views/groups.html',
                controller: 'groupsController',

            })
            .state('editgroup', {
                title: 'EDIT_GROUPS_HEADER_TITLE',
                url: '/editgroup',
                templateUrl: 'app/views/publishereditgroup.html',
                controller: 'editgroupController',

            })
            .state('businessmodels', {
                title: 'BUSINESS_MODELS_HEADER_TITLE',
                url: '/businessmodels',
                templateUrl: 'app/views/businessmodels.html',
                controller: 'businessmodelsController',

            })
            .state('catalog', {
                title: 'CATALOG',
                url: '/catalog',
                templateUrl: 'app/views/publishercatalog.html',
                controller: 'catalogController'
            })
            .state('maintainbooks', {
                title: 'MAINTAIN_BOOKS_LABEL',
                url: '/maintainbooks',
                templateUrl: 'app/views/publishermaintainbooks.html',
                controller: 'booksController'
            })
            .state('addbook', {
                title: 'MAINTAIN_BOOKS_LABEL',
                url: '/addbook',
                templateUrl: 'app/views/publisheraddbook.html',
                controller: 'addBooksController'
            })
            .state('editbook', {
                title: 'MAINTAIN_BOOKS_LABEL',
                url: '/editbook',
                templateUrl: 'app/views/publisheraddbook.html',
                controller: 'addBooksController'
            })
            .state('channels', {
                title: 'CHANNELS_LABEL',
                url: '/channels',
                templateUrl: 'app/views/channels.html',
                controller: 'channelsController'
            })
            .state('createchannel', {
                title: 'CHANNELS_LABEL',
                url: '/createchannel',
                templateUrl: 'app/views/createchannel.html',
                controller: 'createChannelsController'
            })
            .state('editchannel', {
                title: 'CHANNELS_LABEL',
                url: '/editchannel',
                templateUrl: 'app/views/createchannel.html',
                controller: 'createChannelsController'
            })
            .state('retailerdashboard', {
                title: 'DASHBOARD_TITLE',
                url: '/retailerdashboard',
                templateUrl: 'app/views/retailerdashboard.html',
                controller: 'dashboardController'
            })
            .state('retailerprofile', {
                title: 'RETAILER_COMPANY_PROFILE_TITLE',
                url: '/retailerprofile',
                templateUrl: 'app/views/profile.html',
                controller: 'profileController'
            })
            .state('retailercatalog', {
                title: 'CATALOG',
                url: '/retailercatalog',
                templateUrl: 'app/views/retailercatalog.html',
                controller: 'retailercatalogController'
            })
            .state('retailerwidgets', {
                title: 'CATALOG',
                url: '/retailerwidgets',
                templateUrl: 'app/views/retailerwidgets.html',
                controller: 'retailerwidgetsController'
            })
            .state('createretailerwidgets', {
                title: 'CATALOG',
                url: '/createretailerwidgets',
                templateUrl: 'app/views/createretailerwidgets.html',
                controller: 'createretailerwidgetsController'
            })

            .state('preference', {
                title: 'RETAILER_PREFERENCE',
                url: '/preference',
                templateUrl: 'app/views/retailerpreference.html',
                controller: 'preferenceController'
            })
            .state('aboutbusinessmodel', {
                title: 'ABOUT_BUSINESS_MODELS_LABEL',
                url: '/aboutbusinessmodel',
                templateUrl: 'app/views/retailerbusinessmodel.html',
                controller: 'businessmodelsController'
            })
            .state('admin', {
                title: 'Admin',
                url: '/admin',
                templateUrl: 'app/views/admin/index.html',
            });
    }])
    // Angular debug info
    .config(function ($compileProvider, DEBUG_MODE) {
        if (!DEBUG_MODE) {
            $compileProvider.debugInfoEnabled(false);// disables AngularJS debug info
        }
    })
    // Angular Translate
    .config(function ($translateProvider, DEBUG_MODE, LOCALES) {
        if (DEBUG_MODE) {
            $translateProvider.useMissingTranslationHandlerLog();// warns about missing translates
        }
        $translateProvider.useStaticFilesLoader({
            files: [{
                prefix: 'assets/resources/locale-', // path to translations files
                suffix: '.json'// suffix, currently- extension of the translations
            },
                {
                    prefix: 'assets/resources/validate/locale-validate-', // path to translations files
                    suffix: '.json'// suffix, currently- extension of the translations
                }]
        });
        //$translateProvider.useSanitizeValueStrategy('sanitize');
        $translateProvider.preferredLanguage(LOCALES.preferredLocale);
        // Enable escaping of HTML
        $translateProvider.useSanitizeValueStrategy('escape');
        $translateProvider.useLocalStorage();
    })
    // Angular Dynamic Locale
    .config(function (tmhDynamicLocaleProvider) {
        tmhDynamicLocaleProvider.localeLocationPattern('bower_components/angular-i18n/angular-locale_{{locale}}.js');
    })
    .config(function ($httpProvider) {
        //  $httpProvider.defaults.cache = true;
        $httpProvider.interceptors.push('authInterceptorService');
    })
    .config(['cfpLoadingBarProvider', function (cfpLoadingBarProvider) {
        cfpLoadingBarProvider.spinnerTemplate = '<div class="loading-block"><div class="loading"><img align="" src="assets/images/loading-spinner-grey.gif"> <span>  LOADING...</span></div></div>';
    }])
    .run(function ($http, CacheFactory) {
        $http.defaults.cache = CacheFactory('defaultCache', {
            maxAge: 20 * 60 * 1000,
            cacheFlushInterval: 120 * 60 * 1000,
            deleteOnExpire: 'aggressive'
        });
    })
    .run(['authService', 'LOCALES', '$rootScope', function (authService, LOCALES, $rootScope) {
        $rootScope.language = LOCALES.preferredLocale;
        authService.fillAuthData($rootScope.language);
    }])
    .run(function ($rootScope, $state, $window, $cookieStore, $sessionStorage, $location, authService, LOCALES, localStorageService) {
        $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState) {
            $rootScope.title = toState.title;
            $rootScope.selectedMenu = toState.name;
            $rootScope.$watch($rootScope.userData);
            $rootScope.$watch($rootScope.contentDisplay);
            $rootScope.$watch($rootScope.logo);
            var authArr = ['home', 'verify', 'signup', 'resetpassword'];
            var publisherArr = ['dashboard', 'profile', 'myaccount', 'groups', 'editgroup',
                'businessmodels', 'catalog', 'maintainbooks', 'addbook',
                'editbook', 'channels', 'createchannel', 'editchannel'];
            var retailerArr = ['retailerdashboard', 'profile', 'myaccount', 'preference','aboutbusinessmodel',
                'retailercatalog', 'retailerlist', 'retailerwidgets','createretailerwidgets',
                'retailerreports'];

            var userTokenData = localStorageService.get('authorizeTokenDetail');
            var userData = cookies.get('authorizationData');
            $rootScope.userData = userData;
            //    debugger;
            if (authArr.indexOf(toState.name) < 0 || (userTokenData !== null && userTokenData.keepsignin)) {
                // var authToken = authService.isLoggedIn($rootScope.language);
                authService.isLoggedIn($rootScope.language, function (authToken) {
                    if (!authToken) {
                        $location.path('/');
                    } else {
                        if (userTokenData) {
                            if (parseInt(userTokenData.usertype) === 3) {
                                $sessionStorage.contentDisplay = {
                                    signinMenu: false,
                                    signupMenu: false,
                                    userAccount: true,
                                    menuTab: false,
                                    usertype: userTokenData.usertype
                                };
                                $rootScope.contentDisplay = $sessionStorage.contentDisplay;
                                $location.path('/userselection');
                            } else {
                                $sessionStorage.contentDisplay = {
                                    signinMenu: false,
                                    signupMenu: false,
                                    userAccount: true,
                                    menuTab: true,
                                    usertype: userTokenData.usertype
                                };
                                $rootScope.contentDisplay = $sessionStorage.contentDisplay;
                                if (authArr.indexOf(toState.name) < 0) {
                                    if (userTokenData.usertype == 1) {
                                        if (publisherArr.indexOf(toState.name) >= 0) {
                                            $location.path('/' + toState.name);
                                        }
                                        else {
                                            $location.path('/dashboard');
                                        }
                                    }
                                    else {
                                        if (retailerArr.indexOf(toState.name) >= 0) {
                                            $location.path('/' + toState.name);
                                        }
                                        else {
                                            $location.path('/retailerdashboard');
                                        }
                                    }
                                }
                                else {
                                    if (parseInt(userTokenData.usertype) === 3) {
                                        $location.path('/userselection');
                                    } else {
                                        if (parseInt(userTokenData.logins) > 1) {
                                            $location.path('/dashboard');
                                        } else {
                                            $location.path('/userselection');
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
            }
            else {
                if ($location.search().u === '' || $location.search().u === undefined) {
                    if (userData) {
                        if (parseInt(userTokenData.usertype) === 3) {
                            $location.path('/userselection');
                        } else {

                            if (parseInt(userData.logins) > 1) {
                                $location.path('/dashboard');
                            } else {
                                $location.path('/userselection');
                            }
                        }
                    }
                }
            }

        });
    });

