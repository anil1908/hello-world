var App = angular.module('OneWorld', [
    'ui.router',
    'ui.grid',
    'ui.grid.pagination',
    'ui.grid.autoResize',
    'ui.bootstrap',
    'ui.checkbox',
    'angular-loading-bar',
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngSanitize',
    'ngTouch',
    'ngMessages',
    'pascalprecht.translate',
    'tmh.dynamicLocale',
    'remoteValidation',
    'LocalStorageModule',
    'ngStorage',
    'ngCookies',
    'checklist-model',
    'xeditable',
    'ngTagsInput',
    'ngCookies',
    'jkuri.gallery',
    'angular-cache',
    'ui.select2'
])
        .constant('DEBUG_MODE', true)
        .constant('LOCALES', {
            'locales': {
                'ru_RU': 'Русский',
                'en_US': 'English'
            },
            'preferredLocale': 'en_US',
        })
        .config(['$stateProvider', '$urlRouterProvider', '$locationProvider', '$translateProvider', 'tmhDynamicLocaleProvider', function ($stateProvider, $urlRouterProvider, $locationProvider, $translateProvider, tmhDynamicLocaleProvider) {
                $locationProvider.html5Mode(true);
                $urlRouterProvider.otherwise('/');
                // Now set up the states
                $stateProvider
                        .state('home', {
                            title: 'HOME_HEADER_TITLE',
                            url: '/',
                            templateUrl: 'app/views/login.html',
                            controller: 'loginController',
                            authenticate: false,
                        })
                        .state('userselection', {
                            title: 'SELECT_USERTYPE',
                            url: '/userselection',
                            templateUrl: 'app/views/usertype.html',
                            controller: 'usertypeController',
                            authenticate: false,
                        })
                        .state('signup', {
                            title: 'SIGNUP_HEADER_TITLE',
                            url: '/signup',
                            templateUrl: 'app/views/signup.html',
                            controller: 'signupController',
                            authenticate: false,
                        })
                        .state('verify', {
                            title: 'Verify',
                            url: '/verify?u',
                            templateUrl: 'app/views/verify.html',
                            controller: 'verifyController',
                            authenticate: false,
                        })
                        .state('resetpasswordchk', {
                            title: 'SIGNUP_HEADER_TITLE',
                            url: '/resetpasswordchk',
                            //templateUrl: 'app/views/resetpassword.html',
                            controller: 'resetpasswordchkController',
                            authenticate: false,
                        })
                        .state('resetpassword', {
                            title: 'SIGNUP_HEADER_TITLE',
                            url: '/resetpassword',
                            templateUrl: 'app/views/resetpassword.html',
                            controller: 'resetpasswordController',
                            authenticate: false,
                        })
                        .state('dashboard', {
                            title: 'DASHBOARD_TITLE',
                            url: '/dashboard',
                            templateUrl: 'app/views/dashboard.html',
                            controller: 'dashboardController',
                            authenticate: false,
                        })
                        .state('retailerdashboard', {
                            title: 'DASHBOARD_TITLE',
                            url: '/retailerdashboard',
                            templateUrl: 'app/views/retailerdashboard.html',
                            controller: 'dashboardController',
                            authenticate: false,
                        })
                        .state('profile', {
                            title: 'PUBLISHER_COMPANY_PROFILE_TITLE',
                            url: '/profile',
                            templateUrl: 'app/views/profile.html',
                            controller: 'profileController',
                            authenticate: false,
                        })
                        .state('myaccount', {
                            title: 'SIGNUP_HEADER_TITLE',
                            url: '/myaccount',
                            templateUrl: 'app/views/myaccount.html',
                            controller: 'myaccountController',
                            authenticate: false,
                        })
                        .state('groups', {
                            title: 'GROUPS_HEADER_TITLE',
                            url: '/groups',
                            templateUrl: 'app/views/groups.html',
                            controller: 'groupsController',
                            authenticate: false,
                        })
                        .state('editgroup', {
                            title: 'EDIT_GROUPS_HEADER_TITLE',
                            url: '/editgroup',
                            templateUrl: 'app/views/publishereditgroup.html',
                            controller: 'editgroupController',
                            authenticate: false,
                        })
                        .state('businessmodels', {
                            title: 'BUSINESS_MODELS_HEADER_TITLE',
                            url: '/businessmodels',
                            templateUrl: 'app/views/businessmodels.html',
                            controller: 'businessmodelsController',
                            authenticate: false,
                        })
                        .state('catalog', {
                            title: 'CATALOG',
                            url: '/catalog',
                            templateUrl: 'app/views/publishercatalog.html',
                            controller: 'catalogController',
                            authenticate: false,
                        })
                        .state('maintainbooks', {
                            title: 'MAINTAIN_BOOKS_LABEL',
                            url: '/maintainbooks',
                            templateUrl: 'app/views/publishermaintainbooks.html',
                            controller: 'booksController',
                            authenticate: false,
                        })
                        .state('addbook', {
                            title: 'MAINTAIN_BOOKS_LABEL',
                            url: '/addbook',
                            templateUrl: 'app/views/publisheraddbook.html',
                            controller: 'addBooksController',
                            authenticate: false,
                        })
                        .state('editbook', {
                            title: 'MAINTAIN_BOOKS_LABEL',
                            url: '/editbook',
                            templateUrl: 'app/views/publisheraddbook.html',
                            controller: 'addBooksController',
                            authenticate: false,
                        })
                        .state('channels', {
                            title: 'CHANNELS_LABEL',
                            url: '/channels',
                            templateUrl: 'app/views/channels.html',
                            controller: 'channelsController',
                            authenticate: false,
                        })
                        .state('retailerprofile', {
                            title: 'RETAILER_COMPANY_PROFILE_TITLE',
                            url: '/retailerprofile',
                            templateUrl: 'app/views/profile.html',
                            controller: 'profileController',
                            authenticate: false,
                        })
                        .state('admin', {
                            title: 'Admin',
                            url: '/admin',
                            templateUrl: 'app/views/admin/index.html',
                        });
            }])
        // Angular debug info
        .config(function ($compileProvider, DEBUG_MODE) {
            if (!DEBUG_MODE) {
                $compileProvider.debugInfoEnabled(false);// disables AngularJS debug info
            }
        })
        // Angular Translate
        .config(function ($translateProvider, DEBUG_MODE, LOCALES) {
            if (DEBUG_MODE) {
                $translateProvider.useMissingTranslationHandlerLog();// warns about missing translates
            }
            $translateProvider.useStaticFilesLoader({
                files: [{
                        prefix: 'assets/resources/locale-', // path to translations files
                        suffix: '.json'// suffix, currently- extension of the translations
                    },
                    {
                        prefix: 'assets/resources/validate/locale-validate-', // path to translations files
                        suffix: '.json'// suffix, currently- extension of the translations
                    }]
            });
            //$translateProvider.useSanitizeValueStrategy('sanitize');
            $translateProvider.preferredLanguage(LOCALES.preferredLocale);
            // Enable escaping of HTML
            $translateProvider.useSanitizeValueStrategy('escape');
            $translateProvider.useLocalStorage();
        })
        // Angular Dynamic Locale
        .config(function (tmhDynamicLocaleProvider) {
            tmhDynamicLocaleProvider.localeLocationPattern('bower_components/angular-i18n/angular-locale_{{locale}}.js');
        })
        .config(function ($httpProvider) {
          //  $httpProvider.defaults.cache = true;
            $httpProvider.interceptors.push('authInterceptorService');
        })
        .config(['cfpLoadingBarProvider', function (cfpLoadingBarProvider) {
                cfpLoadingBarProvider.spinnerTemplate = '<div class="loading-block"><div class="loading"><img align="" src="assets/images/loading-spinner-grey.gif"> <span>  LOADING...</span></div></div>';
            }])
        .run(function ($http, CacheFactory) {
            $http.defaults.cache    = CacheFactory('defaultCache',{
                maxAge              : 20*60*1000,
                cacheFlushInterval  : 120*60*1000,
                deleteOnExpire      : 'aggressive'
            });
        })
        .run(['authService', 'LOCALES', '$rootScope', function (authService, LOCALES, $rootScope) {
                $rootScope.language = LOCALES.preferredLocale;
                authService.fillAuthData($rootScope.language);
            }])
        
        .run(function ($rootScope, $state,$window,$cookieStore,$sessionStorage, $location, authService, LOCALES, localStorageService) {
            $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState) {
                if (toState.authenticate && !authService.authentication.isAuth) {
                    // User isn’t authenticated
                    //$state.transitionTo("home");
                    event.preventDefault();
                }
                $rootScope.title        = toState.title;
                $rootScope.selectedMenu = toState.name;
                $rootScope.$watch($rootScope.userData);
                $rootScope.$watch($rootScope.contentDisplay);
                $rootScope.$watch($rootScope.logo);
                var authArr = ['home', 'verify', 'signup', 'resetpassword'];
                var userTokenData   = localStorageService.get('authorizeTokenDetail');
                var userData        = cookies.get('authorizationData');//localStorageService.get('authorizationData');$sessionStorage.authorizationData;
                $rootScope.userData = userData;
                if (authArr.indexOf(toState.name) < 0) {
                    var authToken = authService.isLoggedIn($rootScope.language);
                    if (!authToken) {
                        $location.path('/');
                    } else {
                        if (userTokenData) {
                            if (parseInt(userTokenData.usertype) === 3) {
                                $sessionStorage.contentDisplay = {signinMenu: false,
                                    signupMenu: false,
                                    userAccount: true,
                                    menuTab: false};
                                $rootScope.contentDisplay = $sessionStorage.contentDisplay;
                                $location.path('/userselection');
                            } else {
                                $sessionStorage.contentDisplay = {signinMenu: false,
                                    signupMenu: false,
                                    userAccount: true,
                                    menuTab: true};
                                $rootScope.contentDisplay = $sessionStorage.contentDisplay;
                                $location.path('/' + toState.name);
                            }
                        }
                    }
                } else {
                    if ($location.search().u === '' || $location.search().u === undefined) {
                        if (userData) {
                            if (parseInt(userTokenData.usertype) === 3) {
                                $location.path('/userselection');
                            } else {
                                
                                if (parseInt(userData.logins) > 1) {
                                    $location.path('/dashboard');
                                } else {                                    
                                    $location.path('/userselection');
                                }
                            }
                        }
                    }
                }

            });
        });

