import { TrelliPage } from './app.po';

describe('trelli App', () => {
  let page: TrelliPage;

  beforeEach(() => {
    page = new TrelliPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
