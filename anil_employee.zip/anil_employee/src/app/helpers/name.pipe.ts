import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'name'
})
export class NamePipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (args && Array.isArray(value)) {
          let filterKeys = Object.keys(args);
          return value.filter(item =>
              filterKeys.reduce((memo, keyName) =>
                  (memo && new RegExp(args[keyName], 'gi').test(item[keyName])) || args[keyName] === "", true));
      } else {
          return value;
      }
  }

}
