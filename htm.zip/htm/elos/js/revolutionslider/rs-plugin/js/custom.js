var revapi;

jQuery(document).ready(function() {

	   revapi = jQuery('.tp-banner').revolution(
		{
			delay:9000,
			startwidth:1170,
			startheight:610,
			hideThumbs:10,
			fullWidth:"on",
			forceFullWidth:"on"
		});

});