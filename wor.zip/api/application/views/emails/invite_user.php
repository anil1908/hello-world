<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>1World Content User Invitation</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    </head>
    <body>
        <table border="0" cellpadding="0" cellspacing="0" width="600" align="center" style="border:solid 1px #ededed;">
            <tbody>
                <tr>
                    <td><table border="0" cellpadding="0" cellspacing="0">
                            <tbody>
                                <tr>
                                    <td><table border="0" cellpadding="0" cellspacing="0" style="width:640px">
                                            <tbody>
                                                <tr>
                                                    <td align="center">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td align="left"><a href="#" style="border:0px;" target="_blank"><img alt="1World Content" src="<?php echo base_url() . EMAILLOGO; ?>" /></a></td>
                                                </tr>
                                            </tbody>
                                        </table></td>
                                </tr>
                                <tr>
                                    <td><table width="100%" border="0" cellpadding="20" cellspacing="0">
                                            <tbody>
                                                <tr>
                                                    <td style="font:normal 14px/24px 'Open Sans', sans-serif; color:#5a6168;"><p style="font-size:16px; color:#1980C5; margin-top:0px;">Dear User,</p>

                                                        <p style="font-size:14px; color:#030303; line-height:20px; padding:0 0 12px; margin:0;">You are invited to join 1World Content, Please click on the  sign up link below to accept invitation.</p>
                                                        <p> 
                                                            <a title="Activate Account" href="<?php echo $signupurl; ?>" target="_blank">Click here to sign up</a></p>

                                                        <p style="color:#1980C5;"><strong>Best Regards,</strong><br />
                                                            <span style="color:#030303;">1World Content</span></p>
                                                        <div style="min-height:10px; font-size:12px; color:#5a6168; font-family:'Open Sans', sans-serif;">
                                                            <p>Note : This is an auto generated response. Please do not respond to this mail.</p>
                                                        </div></td>
                                                </tr>
                                            </tbody>
                                        </table></td>
                                </tr>

                            </tbody>
                        </table></td>
                </tr>
            </tbody>
        </table>
    </body>
</html>