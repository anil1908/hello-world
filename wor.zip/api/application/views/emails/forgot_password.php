<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Confirm your 1World Content Exchange account</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    </head>
    <body>
        <table border="0" cellpadding="0" cellspacing="0" width="600" align="center" style="border:solid 1px #ededed;">
    <tbody>
        <tr>
            <td><table border="0" cellpadding="0" cellspacing="0">
                    <tbody>
                        <tr>
                            <td><table border="0" cellpadding="0" cellspacing="0" style="width:640px">
                                    <tbody>
                                        <tr>
                                          <td align="center">&nbsp;</td>
                                        </tr>
                                        <tr>
                                            <td align="left"><a href="#" style="border:0px;" target="_blank"><img alt="1World Content" src="<?php echo base_url() . EMAILLOGO; ?>" /></a></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </td>
                        </tr>
                        <tr>
                            <td><table width="100%" border="0" cellpadding="20" cellspacing="0">
                                    <tbody>
                                        <tr>
                                            <td style="font:normal 14px/24px 'Open Sans', sans-serif; color:#1980C5;"><p style="font-size:16px; color:#1980C5; margin-top:0px;">Dear <?php echo $username; ?>,</p>
                                                <p><span>Thank you for contacting us. Please click on below URL to reset password.</span></p>
                                                <table style="font-family: Arial, Helvetica, sans-serif; font-size: 13px; line-height: 20px;" border="0" width="100%" cellspacing="0" cellpadding="0">
                                                    <tbody>
                                                        <tr>
                                                            <td style="color: #292929;" width="144"><strong><a href="<?php echo $resetpasswordurl; ?>" target="_blank">Reset Password</a></strong><p style="min-height:10px; font-size:12px; color:#5a6168; font-family:'Open Sans', sans-serif;">Note: Link will be expired after 24 hours.</p></td>
                                                            
                                                        </tr>
                                                        
                                                    </tbody>
                                                </table>
                                                <p style="color:#1980C5;"><strong>Best Regards,</strong><br />
                        <span style="color:#030303;">1World Content</span></p>
                                                <div style="min-height:10px; font-size:12px; color:#5a6168; font-family:'Open Sans', sans-serif;">
                                                    <p>Note : This is an auto generated response. Please do not respond to this mail. </p>
                                                </div></td>
                                        </tr>
                                    </tbody>
                                </table></td>
                        </tr>
                        
                    </tbody>
                </table>
            </td>
        </tr>
    </tbody>
</table>
    </body>
</html>