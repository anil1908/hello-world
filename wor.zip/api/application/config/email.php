<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$config = array(
    'protocol' => 'smtp',
    'smtp_host' => 'ssl://smtp.gmail.com',
    'smtp_user' => 'testprojectssmtp@gmail.com',
    'smtp_pass' => 'php12345smtp',
    'smtp_port' => 465,
    'mailtype'=> 'html',
    'crlf' => "\r\n",
    'newline' => "\r\n"
);
