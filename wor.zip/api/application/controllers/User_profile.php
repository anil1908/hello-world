<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User_profile extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('user_profile_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * User Profile details
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_user_profile() {
        $retarray = array();
        $result = array();
        $common_result = array();
        
        $path = realpath(PUBPATH . '../assets/images/userprofile');
        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if($common_result['error']==0){
            //Get user details
            $result = $this->user_profile_model->get_user_details_by_id($common_result['user_id']);
            if (is_object($result) && count($result) > 0) {
                //User details
                $retarray['response'] = array('first_name' => $result->first_name,
                    'last_name' => $result->last_name,
                    'email' => $result->email,
                    'photo' => (!empty($result->photo) && file_exists($path . '/' . $result->photo)) ? base_url() . 'assets/images/userprofile/' . $result->photo : base_url() . 'assets/images/userprofile/profilepicture.jpg',
                    'is_image' => (!empty($result->photo) && file_exists($path . '/' . $result->photo)) ? 1 : 0);
                $retarray['error'] = 0;
            } else {
                $retarray['error'] = 0;
                $retarray['response'] = array();
            }
        }else{
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Change user profile Information
     *
     * @access	public
     * @param	first_name,last_name,password,reenter_password,access_token,language
     * @return	JSON Array
     */
    public function update_user_profile() {
        $retarray = array();
        $common_result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //server side validation
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|xss_clean');
        $this->form_validation->set_rules('reenter_password', 'Re Enter Password', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $first_name = $this->input->post('first_name');
            $last_name = $this->input->post('last_name');
            $password = $this->input->post('password');
            $reenter_password = $this->input->post('reenter_password');
            
            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                //update user data
                $users_data = array('first_name' => $first_name,
                    'last_name' => $last_name);

                if (!empty($password) && !empty($reenter_password)) {
                    $password_array = array('password' => md5($password));
                    $users_data = array_merge($users_data, $password_array);
                }
                $this->user_profile_model->update_users_data_by_id($users_data, $common_result['user_id']);

                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('update_user_profile');
            } else {
                $retarray = $common_result;
            }
            echo json_encode($retarray);
        }
    }

    /**
     * profile Image upload
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function update_user_profile_image() {
        $retarray = array();
        if (!$this->custom_function->check_access_token(1)) {
            $retarray['error'] = 2;
            $retarray['errorMsg'] = $this->lang->line('session_expired');
            echo json_encode($retarray);
            exit;
        }

        $user_id = $this->custom_function->get_user_id_from_access_token(1);
        if (!empty($user_id)) {
            $config['upload_path'] = USER_PROFILE_UPLOAD_PATH;
            $config['allowed_types'] = ALLOWED_FILE_TYPE;
            $config['max_size'] = MAX_FILE_SIZE;
            $config['max_width'] = USER_PROFILE_MAX_WIDTH;
            $config['max_height'] = USER_PROFILE_MAX_HEIGHT;
            $config['file_name'] = "profile" . "_" . $user_id . "_" . time();

            $this->load->library('upload', $config);
            if (!$this->upload->do_upload('file')) {
                //Error
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->upload->display_errors();
                $retarray['thumbnail_name'] = base_url() . 'assets/images/userprofile/profilepicture.jpg';
            } else {
                //Success
                $finfo = $this->upload->data();
                $result = $this->user_profile_model->get_user_details_by_id($user_id);
                if (is_object($result) && count($result) > 0) {
                    $path = realpath(PUBPATH . '../assets/images/userprofile');
                    if (!empty($result->photo) && file_exists($path . '/' . $result->photo)) {
                        $result_file = pathinfo($path . '/' . $result->photo);
                        //unlinking images
                        unlink($path . '/' . $result->photo);
                        unlink($path . '/' . $result_file['filename'] . '_thumb.' . $result_file['extension']);
                    }
                    $users_data = array("photo" => '');
                    $this->user_profile_model->update_users_data_by_id($users_data, $user_id);
                    $retarray['image'] = base_url() . 'assets/images/userprofile/profilepicture.jpg';
                }
                $this->_createThumbnail($config['file_name'] . $finfo['file_ext']);
                $users_data = array('photo' => $config['file_name'] . $finfo['file_ext']);
                $this->user_profile_model->update_users_data_by_id($users_data, $user_id);
                $retarray['thumbnail_name'] = base_url() . 'assets/images/userprofile/' . $config['file_name'] . $finfo['file_ext'];
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('update_user_profile');
            }
        } else {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = $this->lang->line('technical_error');
        }
        echo json_encode($retarray);
    }

    //Create Thumbnail function
    public function _createThumbnail($filename) {
        $config['image_library'] = "gd2";
        $config['source_image'] = "../assets/images/userprofile/" . $filename;
        $config['create_thumb'] = TRUE;
        $config['maintain_ratio'] = TRUE;
        $config['width'] = USER_PROFILE_THUMB_WIDTH;
        $config['height'] = USER_PROFILE_THUMB_HEIGHT;
        $config['overwrite'] = TRUE;

        $this->load->library('image_lib', $config);
        $this->image_lib->resize();
    }

    /**
     * Remove profile image
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function remove_user_profile_image() {
        $retarray = array();
        $result = array();
        $common_result = array();
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common();
        if($common_result['error']==0){
            $result = $this->user_profile_model->get_user_details_by_id($common_result['user_id']);
            if (is_object($result) && count($result) > 0) {
                $path = realpath(PUBPATH . '../assets/images/userprofile');
                if (!empty($result->photo) && file_exists($path . '/' . $result->photo)) {
                    $result_file = pathinfo($path . '/' . $result->photo);
                    //unlinking images
                    unlink($path . '/' . $result->photo);
                    unlink($path . '/' . $result_file['filename'] . '_thumb.' . $result_file['extension']);
                }
                $users_data = array("photo" => '');
                $this->user_profile_model->update_users_data_by_id($users_data, $common_result['user_id']);
                $retarray['error'] = 0;
                $retarray['image'] = base_url() . 'assets/images/userprofile/profilepicture.jpg';
                $retarray['msg'] = $this->lang->line('update_user_profile');
            } else {
                $retarray['error'] = 1;
            }
        }else{
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * user modules list
     *
     * @access	public
     * @param	access_token,language,usertype
     * @return	JSON Array
     */
    public function get_user_modules() {
        $retarray = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        if (!$this->custom_function->check_access_token()) {
            $retarray['error'] = 2;
            $retarray['errorMsg'] = $this->lang->line('session_expired');
            echo json_encode($retarray);
            exit;
        }
        $usertype_id = $this->input->post('usertype');
        if (!empty($usertype_id)) {
            //Get module by usertype
            $retarray['response'] = $this->user_profile_model->get_modules_by_usertype($usertype_id);
            $retarray['error'] = 0;
        } else {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = $this->lang->line('technical_error');
        }
        echo json_encode($retarray);
    }

    /**
     * user details with rights
     *
     * @access	public
     * @param	access_token,language,company_user_id
     * @return	JSON Array
     */
    public function get_user_details_with_rights() {
        $retarray = array();
        $result = array();
        $rightsarray = array();
        $objarr = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        if (!$this->custom_function->check_access_token()) {
            $retarray['error'] = 2;
            $retarray['errorMsg'] = $this->lang->line('session_expired');
            echo json_encode($retarray);
            exit;
        }

        $company_user_id = $this->input->post('company_user_id');
        if (!empty($company_user_id)) {
            $result = $this->user_profile_model->get_user_details_with_rights($company_user_id);
            if (is_object($result) && count($result) > 0) {
                if (!empty($result->rights)) {
                    $rights = (explode(',', $result->rights));
                    foreach ($rights as $r) {
                        $array = explode('-', $r);
                        $objarr['id'] = $array[0];
                        $objarr['name'] = $array[1];
                        $rightsarray[] = (object) $objarr;
                    }
                }
                //user details and rights
                $retarray['response'] = array('id' => $result->id,
                    'first_name' => $result->first_name,
                    'last_name' => $result->last_name,
                    'email' => $result->email,
                    'rights' => (!empty($result->rights)) ? $rightsarray : array());
                $retarray['error'] = 0;
            } else {
                $retarray['error'] = 0;
                $retarray['response']=array();
            }
        } else {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = $this->lang->line('technical_error');
        }
        echo json_encode($retarray);
    }

    /**
     * change user details with rights
     *
     * @access	public
     * @param	access_token,language,first_name,last_name,rights_array,company_user_id
     * @return	JSON Array
     */
    public function update_user_rights() {
        $retarray = array();
        $result = array();
        $usermodule_data = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        if (!$this->custom_function->check_access_token()) {
            $retarray['error'] = 2;
            $retarray['errorMsg'] = $this->lang->line('session_expired');
            echo json_encode($retarray);
            exit;
        }
        $user_id = $this->custom_function->get_user_id_from_access_token();
        $company_user_id = $this->input->post('company_user_id');
        

        $created_on = date('Y-m-d H:i:s');
        if (!empty($user_id) && !empty($company_user_id)) {
            $first_name = $this->input->post('first_name');
            $last_name = $this->input->post('last_name');
            $modulearray = $this->input->post('rights_array');
            //Delete user module rights data
            $module_data = array('deleted_on' => date('Y-m-d H:i:s'),
                'deleted_by' => $user_id);
            $this->user_profile_model->delete_user_module_rights($module_data, $company_user_id);

            if (is_array($modulearray) && count($modulearray) > 0) {
                foreach ($modulearray as $m) {
                    //Insert user module rights data
                    $usermodule_data[] = array("user_id" => $company_user_id,
                        "module_id" => $m,
                        "created_on" => $created_on,
                        "created_by" => $user_id);
                }
                $this->user_profile_model->insert_user_module_rights($usermodule_data);
            }
            //Update user data
            $users_data = array('first_name' => $first_name,
                'last_name' => $last_name);
            $this->user_profile_model->update_users_data_by_id($users_data, $company_user_id);
            $retarray['error'] = 0;
            $retarray['msg'] = $this->lang->line('update_user_profile');
        } else {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = $this->lang->line('technical_error');
        }
        echo json_encode($retarray);
    }

    /**
     * Change user status
     *
     * @access	public
     * @param	access_token,language,company_user_id,status
     * @return	JSON Array
     */
    public function update_user_status() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if($common_result['error']==0){
            $company_user_id = $this->input->post('company_user_id');
            $status = $this->input->post('status');
            $modified_on = date('Y-m-d H:i:s');
            if(!empty($company_user_id)){
                //Update user data
                $users_data = array('status' => $status,
                    'modified_on' => $modified_on,
                    'modified_by' => $common_result['user_id']);
                $this->user_profile_model->update_users_data_by_id($users_data, $company_user_id);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('update_user_status');
                $retarray['response'] = array('active' => ($status == 0) ? 'No' : 'Yes',
                    'action' => ($status == 0) ? 'Activate' : 'Deactivate',
                    'status' => $status);
            }else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        }else{
            $retarray = $common_result;
        }
        echo json_encode($retarray);
    }

    /**
     * Invited user details
     *
     * @access	public
     * @param	language,user_id
     * @return	JSON Array
     */
    public function get_invited_user_details() {
        $retarray = array();
        $result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        //Set language
        $this->custom_function->set_language($this->input->post('language'));
        $encrypt_key = $this->config->item('encryption_key');
        $user_id = $this->encrypt->decode($this->input->post('user_id'), $encrypt_key);

        if (!empty($user_id)) {
            //Get invited user details
            $retarray['response'] = $this->user_profile_model->get_invited_user_details_by_id($user_id);
            $retarray['error'] = 0;
        } else {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = $this->lang->line('technical_error');
        }
        echo json_encode($retarray);
    }

}
