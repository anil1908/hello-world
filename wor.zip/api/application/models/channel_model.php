<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Channel_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Channel list by company id
     *
     * @access	public
     * @param	company_id, pageStart, pageLimit, sortField, sortType, search_name, search_from_date, search_to_date, search_business_model, search_status
     * @return	Array
     */
    public function get_channel_list_by_company_id($company_id, $pageStart, $pageLimit, $sortField, $sortType, $search_name, $search_from_date, $search_to_date, $search_business_model, $search_status) {
        $retarray = array();
        if (!empty($company_id)) {
            $this->db->select("c.id,c.name,c.created_on,CONCAT(bm.name,'-',bm.short_description)as business_model,"
                    . "g.name as group_name,c.start_date,c.end_date,GROUP_CONCAT(DISTINCT r.name)as region,c.status");
            $this->db->from("channels c");
            $this->db->join("business_models bm", "bm.id=c.business_model_id", "LEFT");
            $this->db->join("groups g", "g.id=c.group_id", "LEFT");
            $this->db->join("channels_countries cc", "c.id= cc.channel_id AND (cc.deleted_by < 1 OR cc.deleted_by = 0)", "LEFT");
            $this->db->join("country con", "con.id=cc.country_id", "LEFT");
            $this->db->join("regions r", "r.id=con.region_id", "LEFT");
            $this->db->where("c.company_id='" . $company_id . "' AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            if (!empty($search_name)) {
                $this->db->where("(LOWER(c.name) LIKE '%$search_name%')");
            }
            if (!empty($search_from_date) && !empty($search_to_date)) {
                $search_from_date = date('Y-m-d', strtotime($search_from_date));
                $search_to_date = date('Y-m-d', strtotime($search_to_date));
                $this->db->where("('" . $search_from_date . "' BETWEEN c.start_date AND c.end_date OR '" . $search_to_date . "' BETWEEN c.start_date AND c.end_date)");
            }
            if (!empty($search_business_model)) {
                $this->db->where("(c.business_model_id = '$search_business_model')");
            }
            if ($search_status != -1 && $search_status != '') {
                $this->db->where("(c.status = '$search_status')");
            }
            $this->db->group_by("c.id");
            $this->db->order_by($sortField, $sortType);
            $this->db->limit($pageLimit, $pageStart);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Count channel list
     *
     * @access	public
     * @param	company_id, search_name, search_from_date, search_to_date, search_business_model, search_status
     * @return	Count of rows
     */
    public function get_channel_list_count($company_id, $search_name, $search_from_date, $search_to_date, $search_business_model, $search_status) {
        $iTotal = 0;
        $result = array();
        if (!empty($company_id)) {
            $this->db->select("COUNT(c.id) as num_rows");
            $this->db->from("channels c");
            $this->db->where("c.company_id='" . $company_id . "'");
            if (!empty($search_name)) {
                $this->db->where("(LOWER(c.name) LIKE '%$search_name%')");
            }
            if (!empty($search_from_date) && !empty($search_to_date)) {
                $search_from_date = date('Y-m-d', strtotime($search_from_date));
                $search_to_date = date('Y-m-d', strtotime($search_to_date));
                $this->db->where("('" . $search_from_date . "' BETWEEN c.start_date AND c.end_date OR '" . $search_to_date . "' BETWEEN c.start_date AND c.end_date)");
            }
            if (!empty($search_business_model)) {
                $this->db->where("(c.business_model_id = '$search_business_model')");
            }
            if ($search_status != -1 && $search_status != '') {
                $this->db->where("(c.status = '$search_status')");
            }
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $result = $query->row();
                $iTotal = $result->num_rows;
            }
        }
        return $iTotal;
    }

    /**
     * Channel books by channel id
     *
     * @access	public
     * @param	channel_id
     * @return	Array
     */
    public function get_channel_books_by_channel_id($channel_id) {
        $retarray = array();
        if (!empty($channel_id)) {
            $this->db->select("b.id,b.name");
            $this->db->from("channels c");
            $this->db->join("books b", "b.id=c.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Update channel status
     *
     * @access	public
     * @param	channel_data,channel_id
     * @return	NA
     */
    public function update_channel_data_by_id($channel_data, $channel_id) {
        if (!empty($channel_id) && (is_array($channel_data) && count($channel_data) > 0)) {
            $this->db->where("id", $channel_id);
            $this->db->set('status', 'NOT status', FALSE);
            $this->db->update("channels", $channel_data);
        }
    }

    /**
     * Insert channel
     *
     * @access	public
     * @param	channel_data
     * @return	channel_id
     */
    public function insert_channel($channel_data) {
        $channel_id = 0;
        if (is_array($channel_data) && count($channel_data) > 0) {
            $this->db->insert("channels", $channel_data);
            $channel_id = $this->db->insert_id();
        }
        return $channel_id;
    }

    /**
     * Insert channel book
     *
     * @access	public
     * @param	channel_book_data
     * @return	NA
     */
    public function insert_channel_book($channel_book_data) {
        if (is_array($channel_book_data) && count($channel_book_data) > 0) {
            $this->db->insert_batch("channels_books", $channel_book_data);
        }
    }

    /**
     * Insert channel country
     *
     * @access	public
     * @param	channel_country_data
     * @return	NA
     */
    public function insert_channel_country($channel_country_data) {
        if (is_array($channel_country_data) && count($channel_country_data) > 0) {
            $this->db->insert_batch("channels_countries", $channel_country_data);
        }
    }

    /**
     * Insert channel retailer
     *
     * @access	public
     * @param	channel_retailer_data
     * @return	NA
     */
    public function insert_channel_retailer($channel_retailer_data) {
        if (is_array($channel_retailer_data) && count($channel_retailer_data) > 0) {
            $this->db->insert_batch("channels_retailers", $channel_retailer_data);
        }
    }

    /**
     * Group book by group id
     *
     * @access	public
     * @param	group_id
     * @return	Array
     */
    public function get_group_books_by_group_id($group_id) {
        if (!empty($group_id)) {
            $this->db->where("group_id", $group_id);
            $query = $this->db->get("group_books");
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
    }

    /**
     * Channel book price
     *
     * @access	public
     * @param	channel_id
     * @return	Array
     */
    public function get_channel_books_price_by_channel_id($channel_id) {
        $retarray = array();
        $result = array();
        $idarray = array();
        if (!empty($channel_id)) {
            $this->db->select("b.title,cb.book_id,cb.currency_id,cu.code,cb.standard_price,cb.new_standard_price,cb.publisher_share,c.business_model_id");
            $this->db->from("channels_books cb");
            $this->db->join("currency cu", "cu.id=cb.currency_id", "LEFT");
            $this->db->join("books b", "b.id=cb.book_id AND (b.deleted_by < 1 OR b.deleted_by =0)", "LEFT");
            $this->db->join("channels c", "c.id=cb.channel_id AND (c.deleted_by < 1 OR c.deleted_by =0)", "LEFT");
            $this->db->where("c.id = $channel_id AND (cb.deleted_by < 1 OR cb.deleted_by =0)");
            $this->db->order_by("b.id", "ASC");
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $result = $query->result_array();
                if (is_array($result) && count($result) > 0) {
                    $i = 0;
                    foreach ($result as $key => $val) {
                        if (!in_array($result[$key]['book_id'], $idarray)) {
                            $i = 0;
                            array_push($idarray, $result[$key]['book_id']);
                        }
                        $result[$key]['title'] = strip_slashes($result[$key]['title']);
                        $retarray[$result[$key]['title']][$i]['code'] = $result[$key]['code'];
                        $retarray[$result[$key]['title']][$i]['business_model_id'] = $result[$key]['business_model_id'];
                        $retarray[$result[$key]['title']][$i]['standard_price'] = $result[$key]['standard_price'];
                        $retarray[$result[$key]['title']][$i]['new_standard_price'] = $result[$key]['new_standard_price'];
                        $retarray[$result[$key]['title']][$i]['publisher_share'] = $result[$key]['publisher_share'];
                        $i++;
                    }
                }
            }
        }
        return $retarray;
    }

    /**
     * Check channel name
     *
     * @access	public
     * @param	name,company_id
     * @return	Boolean
     */
    public function check_channel_name($name, $company_id, $channel_id) {
        if (!empty($name) && !empty($company_id)) {
            if (!empty($channel_id)) {
                $this->db->where("id<>", $channel_id);
            }
            $this->db->where("company_id=$company_id AND name='$name' AND (deleted_by < 1 OR deleted_by = 0)");
            $query = $this->db->get("channels");
            if ($query->num_rows() > 0) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }

    /**
     * Group by company id
     *
     * @access	public
     * @param	company_id
     * @return	Array
     */
    public function get_group_by_company_id($company_id) {
        if (!empty($company_id)) {
            $this->db->select("id,name");
            $this->db->where("company_id", $company_id);
            $query = $this->db->get("groups");
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Business model list
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_all_business_model() {
        $result = array();
        $namearray = array();
        $this->db->select("c.category_name,bm.id,CONCAT(bm.name,' - ',bm.short_description)as bm_list, bm.long_description as bm_longtext");
        $this->db->from("business_model_category c");
        $this->db->join("business_models bm", "c.id=bm.category_id");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            if (is_array($result) && count($result) > 0) {
                $i = 0;
                foreach ($result as $key => $val) {
                    if (!in_array($result[$key]['category_name'], $namearray)) {
                        $i = 0;
                        array_push($namearray, $result[$key]['category_name']);
                    }
                    $retarray[$result[$key]['category_name']][$i]['id'] = $result[$key]['id'];
                    $retarray[$result[$key]['category_name']][$i]['bm_list'] = $result[$key]['bm_list'];
                    $retarray[$result[$key]['category_name']][$i]['bm_longtext'] = strip_slashes($result[$key]['bm_longtext']);
                    $i++;
                }
            }
        }
        return $retarray;
    }

    /**
     * Frequently used business model list
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_frequently_used_business_model() {
        $result = array();
        $this->db->select("bm.id,CONCAT(bm.name,' - ',bm.short_description)as bm_list, bm.long_description as bm_longtext");
        $this->db->from("business_models bm");
        $this->db->where("bm.is_popular", 1);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            if (is_array($result) && count($result) > 0) {
                $i = 0;
                foreach ($result as $key => $val) {
                    $retarray['MOST POPULAR'][$i]['bm_id'] = $result[$key]['id'];
                    $retarray['MOST POPULAR'][$i]['bm_list'] = $result[$key]['bm_list'];
                    $retarray['MOST POPULAR'][$i]['bm_longtext'] = $result[$key]['bm_longtext'];
                    $i++;
                }
            }
        }
        $query->free_result();

        $this->db->select("bm.id,CONCAT(bm.name,' - ',bm.short_description)as bm_list,bm.long_description as bm_longtext");
        $this->db->from("users_favourite_business_model ufb");
        $this->db->join("business_models bm", "bm.id=ufb.business_model_id");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $result2 = $query->result_array();
            if (is_array($result2) && count($result2) > 0) {
                $j = 0;
                foreach ($result2 as $key => $val) {
                    $retarray['YOUR FAVORITES'][$j]['bm_id'] = $result2[$key]['id'];
                    $retarray['YOUR FAVORITES'][$j]['bm_list'] = $result2[$key]['bm_list'];
                    $retarray['YOUR FAVORITES'][$j]['bm_longtext'] = $result2[$key]['bm_longtext'];
                    $j++;
                }
            }
        }
        return $retarray;
    }

    /**
     * Region & country 
     *
     * @access	public
     * @param	group_id
     * @return	Array
     */
    public function get_region_with_country() {
        $result = array();
        $namearray = array();
        $retarray = array();
        $this->db->select("r.id as region_id,r.name as region_name,c.id as country_id,c.name as country_name");
        $this->db->from("regions r");
        $this->db->join("country c", "r.id=c.region_id", "LEFT");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            if (is_array($result) && count($result) > 0) {
                $i = 0;
                foreach ($result as $key => $val) {
                    if (!in_array($result[$key]['region_name'], $namearray)) {
                        $i = 0;
                        array_push($namearray, $result[$key]['region_name']);
                    }
                    $retarray[$result[$key]['region_name']]['id'] = $result[$key]['region_id'];
                    $retarray[$result[$key]['region_name']]['label'] = $result[$key]['region_name'];
//                        $retarray[$result[$key]['region_name']]['d_label'] = str_replace(" ", "_", $result[$key]['region_name']);
                    if (!empty($result[$key]['country_id'])) {
                        $retarray[$result[$key]['region_name']]['children'][$i]['id'] = $result[$key]['country_id'] . '_' . str_replace(array('(', ')', ' '), '', $result[$key]['country_name']);
                        $retarray[$result[$key]['region_name']]['children'][$i]['label'] = $result[$key]['country_name'];
                    }
                    $i++;
                }
            }
        }
        return $retarray;
    }

    /**
     * Country by group
     *
     * @access	public
     * @param	group_id
     * @return	Array
     */
    public function get_selected_country_by_group_id($group_id) {
        $retarray = array();
        $this->db->select("GROUP_CONCAT(DISTINCT CONCAT(c.id,'_',REPLACE(c.name,' ','')))as selected_countries");
        $this->db->from("country c");
        $this->db->join("book_countries bc", "c.id = bc.country_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)");
        $this->db->join("groups_books gb", "bc.book_id = gb.book_id");
        $this->db->join("groups g", "g.id=gb.group_id");
        $this->db->where("g.id", $group_id);
        $this->db->group_by("c.id");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Country by channel
     *
     * @access	public
     * @param	channel_id
     * @return	Array
     */
    public function get_selected_country_by_channel_id($channel_id) {
        $retarray = array();
        if (!empty($channel_id)) {
            $this->db->select("GROUP_CONCAT(DISTINCT CONCAT(c.id,'_',REPLACE(c.name,' ','')))as selected_countries");
            $this->db->from("country c");
            $this->db->join("book_countries bc", "c.id = bc.country_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)");
            $this->db->join("channels_countries cc", "c.id=cc.country_id  AND (cc.deleted_by < 1 OR cc.deleted_by = 0)");
            $this->db->join("channels cn", "cn.id=cc.channel_id  AND (cn.deleted_by < 1 OR cn.deleted_by = 0)");
            $this->db->where("cn.id", $channel_id);
            $this->db->group_by("c.id");
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Region by group
     *
     * @access	public
     * @param	group_id
     * @return	Array
     */
    public function get_selected_region_by_group_id($group_id) {
        $retarray = array();
        if (!empty($group_id)) {
            //$this->db->select("GROUP_CONCAT(DISTINCT CONCAT(r.id,'=',r.name))as selected_regions");
            $this->db->select("r.id as selected_regions");
            $this->db->from("regions r");
            $this->db->join("book_regions br", "r.id = br.region_id AND br.book_id = gb.book_id AND (br.deleted_by < 1 OR br.deleted_by = 0)");
            $this->db->from("groups_books gb", "br.book_id = gb.book_id ");
            $this->db->join("groups g", "g.id=gb.group_id");
            $this->db->where("g.id", $group_id);
            $this->db->group_by("r.id");
            $query = $this->db->get();

            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Get book list for channel by group
     *
     * @access	public
     * @param	group_id, selected country array, business model,channel id
     * @return	Array
     */
    public function get_book_for_channel_list($group_id, $country_array, $business_model, $channel_id = NULL) {
        $retarray = array();
        $result = array();        
        $repeat_bookid = array();        
        $converted_price = 0.00;
        $namearray = array();
        if (!empty($channel_id)) {
            $this->db->select("cb.book_id as id,b.title,cb.new_standard_price as price,cb.standard_price,cb.publisher_share,cb.currency_id,c.id as currency_id,c.code");
            $this->db->from("channels_books cb");
            $this->db->join("books b", "b.id = cb.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("currency as c", "cb.currency_id = c.id");
            $this->db->join("channels_countries cc", "cb.channel_id = cc.channel_id AND c.country_id = cc.country_id AND (cc.deleted_by < 1 OR cc.deleted_by = 0)");            
            $this->db->where("cb.channel_id = $channel_id AND cc.country_id IN ($country_array) AND (cb.deleted_by < 1 OR cb.deleted_by = 0) ");
            $this->db->group_by("c.id");
            $this->db->order_by("cb.book_id,c.seq_no,c.code", "ASC");            
            $query = $this->db->get();
            
            if ($query->num_rows() > 0) {
                $bookarr = $query->result_array();
                if (is_array($bookarr) && count($bookarr) > 0) {
                    $c = 0;
                    foreach ($bookarr as $key => $val) {
                        $book_title = stripslashes($bookarr[$key]['title']);
                        if (!in_array($book_title, $namearray)) {
                            $c = 0;
                            array_push($namearray, $book_title);
                        }
                        $retarray[$book_title][$c]['book_id'] = $bookarr[$key]['id'];
                        $retarray[$book_title][$c]['currency'] = $bookarr[$key]['currency_id'] . "=" . $bookarr[$key]['code'];
                        $retarray[$book_title][$c]['original_digital_list'] = $bookarr[$key]['standard_price'];
                        $retarray[$book_title][$c]['adjusted_selling_price'] = (float) $bookarr[$key]['price'];
                        $retarray[$book_title][$c]['publisher_share'] = $bookarr[$key]['publisher_share'];
                        $c++;
                    }
                }
            }
        } else {
            $this->db->select("b.id,b.title,bp.price,`c`.`code`,(CASE WHEN br.region_id = 1 THEN 1 ELSE 0 END) as is_world, group_concat(distinct CONCAT(cu.id, '=', cu.code)) as count_currency");
            $this->db->from("books b");
            $this->db->join("groups_books gb", "b.id=gb.book_id");
            $this->db->join("book_prices bp", "b.id=bp.book_id");            
            $this->db->join("book_regions br", "gb.book_id = br.book_id  AND (br.deleted_by < 1 OR br.deleted_by = 0)", "LEFT");            
            $this->db->join("book_countries bc", "b.id = bc.book_id  AND (bc.deleted_by < 1 OR bc.deleted_by = 0)", "LEFT");            
            $this->db->join("currency c", "c.id=bp.currency_id");            
            $this->db->join("currency cu", "bc.country_id = cu.country_id  AND (bc.deleted_by < 1 OR bc.deleted_by = 0)", "LEFT");            
            $this->db->where("gb.group_id=$group_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->group_by("b.id,c.id");
            $this->db->order_by("b.id,c.seq_no,c.code", "ASC");
            $query = $this->db->get();

            if ($query->num_rows() > 0) {
                $bookarr = $query->result_array();
                $this->db->select("c.id as currency_id,c.code as currency_code");
                $this->db->from("currency c");
                $this->db->where("c.country_id IN ($country_array)");
                $this->db->group_by("c.code");
                $query_country_code = $this->db->get();

                if ($query_country_code->num_rows() > 0) {
                    $currList = $query_country_code->result_array();
                    if (is_array($currList) && count($currList) > 0) {
                        for ($c = 0; $c < count($currList); $c++) {
                            $curr_code[] = $currList[$c]['currency_id'] . "=" . $currList[$c]['currency_code'];
                        }
                    }
                    if (is_array($bookarr) && count($bookarr) > 0) {
                        foreach ($bookarr as $key => $val) {
                            set_time_limit(0);
                            $repeat_another_bookid = $bookarr[$key]['id'];
                            if (!in_array($bookarr[$key]['id'], $repeat_bookid)) {
                                $baseCurrency = $this->GetBookBaseCurrency($currList, $bookarr, $repeat_another_bookid);
                                
                                if($bookarr[$key]['is_world'] > 0){
                                    $this->db->select("id");
                                    $this->db->from("book_regions");
                                    $this->db->where("book_id = " . $bookarr[$key]['id'] . " AND region_id = 1 AND (deleted_by < 1 OR deleted_by = 0)");
                                    $query_result = $this->db->get();
                                    if ($query_result->num_rows() > 0) {
                                        $this->db->select("group_concat(distinct CONCAT(cu.id,'=',cu.code)) as count_currency");
                                        $this->db->from("currency cu");
                                        $this->db->join("country c", "cu.country_id=c.id");                                        
                                        $query_currency= $this->db->get();
                                        if ($query_currency->num_rows() > 0) {
                                            $result = $query_currency->row();
                                        }                                       
                                    }
                                }
                                
                                if (!empty($bookarr[$key]['count_currency'])) {
                                    $book_master_curr = explode(",", $bookarr[$key]['count_currency']);
                                }else{
                                    if(!empty($result->count_currency)){                                        
                                        $book_master_curr = explode(",", $result->count_currency);
                                    }
                                }                                                                                                 
                                if (!empty($book_master_curr)) {
                                    for ($c = 0; $c < count($book_master_curr); $c++) {
                                        if (in_array($book_master_curr[$c], $curr_code)) {
                                            $book_title = stripslashes($bookarr[$key]['title']);
                                            if ($bookarr[$key]['code'] == $book_master_curr[$c]) {

                                                $retarray[$book_title][$c]['book_id'] = $bookarr[$key]['id'];
                                                $retarray[$book_title][$c]['currency'] = $bookarr[$key]['code'];
                                                $retarray[$book_title][$c]['original_digital_list'] = $bookarr[$key]['price'];
                                                if ($business_model == 3 && !empty($bookarr[$key]['price'])) {
                                                    $bookprice = (($bookarr[$key]['price'] * PUB_SHARE) / 100);
                                                    $publisher_share = ($bookarr[$key]['price'] - $bookprice);
                                                    $retarray[$book_title][$c]['adjusted_selling_price'] = (float) $bookprice;
                                                    $retarray[$book_title][$c]['publisher_share'] = $publisher_share;
                                                } else {
                                                    $retarray[$book_title][$c]['adjusted_selling_price'] = (float) $bookarr[$key]['price'];
                                                }
                                            } else {
                                                $currency = explode("=", $book_master_curr[$c]);
                                                $converted_price = $this->convertCurrency($baseCurrency['baseCurrency'], $currency[1], $baseCurrency['basePrice']);
                                                $retarray[$book_title][$c]['book_id'] = $bookarr[$key]['id'];
                                                $retarray[$book_title][$c]['currency'] = $book_master_curr[$c];
                                                $retarray[$book_title][$c]['original_digital_list'] = $converted_price;

                                                if ($business_model == 3 && !empty($converted_price)) {
                                                    $bookprice = (($converted_price * PUB_SHARE) / 100);
                                                    $publisher_share = ($converted_price - $bookprice);
                                                    $retarray[$book_title][$c]['adjusted_selling_price'] = (float) $bookprice;
                                                    $retarray[$book_title][$c]['publisher_share'] = $publisher_share;
                                                } else {
                                                    $retarray[$book_title][$c]['adjusted_selling_price'] = (float) $converted_price;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            $repeat_bookid[] = $bookarr[$key]['id'];
                        }
                    }
                }
            }
        }
        return $retarray;
    }

    /**
     * Get book base currency
     *
     * @access	public
     * @param	selected country curreny list, group books, repeated book
     * @return	Array
     */
    public function GetBookBaseCurrency($currencyList, $bookids, $repeat_bookid) {
        $baseCurrency = array();
        $currency_pref = unserialize(CURRENCY_PREF);

        if (is_array($currencyList) && count($currencyList) > 0 && !empty($bookids)) {
            for ($l = 0; $l < count($currencyList); $l++) {
                $currency[] = $currencyList[$l]['currency_code'];
            }

            $currency = array_diff($currency, $currency_pref);
            /* Sort array alphabetically */
            sort($currency);
            //return $currency;
            if (is_array($bookids) && count($bookids) > 0) {

                for ($i = 0; $i < count($bookids); $i++) {
                    if ($bookids[$i]['id'] == $repeat_bookid) {
                        if (in_array($bookids[$i]['code'], $currency_pref)) {
                            $baseCurrency['basePrice'] = $bookids[$i]['price'];
                            $baseCurrency['baseCurrency'] = $bookids[$i]['code'];
                            break;
                        }
                    }
                }
                if (empty($baseCurrency['baseCurrency'])) {
                    for ($i = 0; $i < count($bookids); $i++) {
                        if ($bookids[$i]['id'] == $repeat_bookid) {
                            $baseCurrency['basePrice'] = $bookids[$i]['price'];
                            $baseCurrency['baseCurrency'] = $bookids[$i]['code'];
                            break;
                        }
                    }
                }
            }
        }
        return $baseCurrency;
    }

    /**
     * Convert currency
     *
     * @access	public
     * @param	currency from, to currency, amount to convert
     * @return	Array
     */
    public function convertCurrency($from_Currency, $to_Currency, $amount) {

        $amount = urlencode($amount);
        $from_Currency = urlencode($from_Currency);
        $to_Currency = urlencode($to_Currency);
        $rawdata = array();

        $converetdPrice = "0.00";
        $url = "https://www.google.com/finance/converter?a=$amount&from=$from_Currency&to=$to_Currency";
        $ch = curl_init();

        $timeout = 0;
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1)");
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        $rawdata = curl_exec($ch);
        curl_close($ch);

        $data = explode('bld>', $rawdata);
        if (!empty($to_Currency) && !empty($data[1])) {
            $data = explode($to_Currency, $data[1]);
        }

        if ($data[0] > 0)
            return round($data[0], 2);
        else
            return $converetdPrice;
        //return round($data[0], 2);
    }

    function array_search_partial($arr, $keyword) {
        foreach ($arr as $index => $string) {
            if (strpos($string, $keyword) !== FALSE)
                return $index;
        }
    }

    /**
     * Retailers list
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_retailers($countryArr) {
        $result = array();
        $retarray = array();
        $usertype = array(2, 3);
        $this->db->select("u.id as user_id,CONCAT(u.first_name,' ',u.last_name)as username");
        $this->db->from("users u");
        $this->db->join("company c", "c.id=u.company_id");       
        //$this->db->join("groups_books gb", "gb.group_id=$group_id");
        //$this->db->join("book_countries bc", "bc.book_id=gb.book_id  AND (bc.deleted_by < 1 OR bc.deleted_by = 0)");
        $this->db->join("retailer_preference_country rpc", "rpc.retailer_id=u.id");
        $this->db->where_in("c.usertype_id", $usertype);
        $this->db->where_in("rpc.country_id", $countryArr);
        $this->db->where("u.status",1);
        $this->db->group_by("u.id");
        $query = $this->db->get();        
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Channel Retailers list
     *
     * @access	public
     * @param	channel_id
     * @return	Array
     */
    public function get_selected_retailers($channel_id) {
        $result = array();
        $retarray = array();
        $this->db->select("u.id as user_id,CONCAT(u.first_name,' ',u.last_name)as username");
        $this->db->from("users u");
        $this->db->join("company c", "c.id=u.company_id");
        $this->db->join("channels_retailers cr", "u.id=cr.retailer_id  AND (cr.deleted_by < 1 OR cr.deleted_by = 0)");
        $this->db->join("channels cn", "cn.id=cr.channel_id AND (cn.deleted_by < 1 OR cn.deleted_by = 0)");
        $this->db->group_by("u.id");
        $this->db->where("cn.id=$channel_id AND u.status=1");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Channel Detail
     *
     * @access	public
     * @param	channel_id
     * @return	Array
     */
    public function get_channel_detail_by_id($channel_id) {
        $result = array();
        $retarray = array();
        $this->db->select("c.id,c.name,DATE_FORMAT(c.start_date,'%m/%d/%Y')as start_date,"
                . "DATE_FORMAT(c.end_date,'%m/%d/%Y')as end_date,c.group_id,c.business_model_id,c.retailers_list,"
                . "c.status,c.business_model_type,c.global_discount as adjustDiscount,c.publisher_payout as payoutDiscount");
        $this->db->from("channels c");
        $this->db->where("c.id=$channel_id  AND (c.deleted_by < 1 OR c.deleted_by = 0)");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $retarray = $query->row();
        }
        return $retarray;
    }

    /**
     * Delete channel data
     *
     * @access	public
     * @param	channel_data,channel_id
     * @return	NA
     */
    public function delete_channel_data($channel_data, $channel_id, $flag = 0) {
        if (!empty($channel_id) && (is_array($channel_data) && count($channel_data) > 0)) {
            $this->db->where_in("channel_id", $channel_id);
            $this->db->update("channels_retailers", $channel_data);

            $this->db->where_in("channel_id", $channel_id);
            $this->db->update("channels_countries", $channel_data);

            $this->db->where_in("channel_id", $channel_id);
            $this->db->update("channels_books", $channel_data);

            if ($flag == 0) {
                $this->db->where_in("id", $channel_id);
                $this->db->update("channels", $channel_data);
            }
        }
    }

    /**
     * Update channel
     *
     * @access	public
     * @param	channel_data,channel_id
     * @return	NA
     */
    public function update_channel($channel_data, $channel_id) {
        if ((is_array($channel_data) && count($channel_data) > 0) && !empty($channel_id)) {
            $this->db->where("id", $channel_id);
            $this->db->update("channels", $channel_data);
        }
    }

}
