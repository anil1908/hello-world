<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class General_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    public function get_modules() {
        $query = $this->db->get('modules');
        return $query->result();
    }

    //found number of rows
    public function found_rows() {
        $iFilteredTotal = 0;
        $this->db->select('FOUND_ROWS() AS found_rows');
        $iFilteredTotal = $this->db->get()->row()->found_rows;
        return $iFilteredTotal;
    }

    //total number of rows
    public function total_rows($wherearr, $sTable) {
        $iTotal = 0;
        $this->db->from($sTable);
        $this->db->where($wherearr);
        $iTotal = $this->db->count_all_results();
        return $iTotal;
    }

    public function get_contributors_role() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("contributors_role");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_contributors_people() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("contributors_people");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_language() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("language");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_subject() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("subjects");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_identifier_types() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("identifier_types");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_regions() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("regions");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_country_by_region($region_array) {
        $retarray = array();
        if (is_array($region_array) && count($region_array) > 0) {

            $this->db->select("id,name");
            if (!in_array(1, $region_array)) {
                $this->db->where_in("region_id", $region_array);
            }
            $query = $this->db->get("country");
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    public function get_review_type() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("review_type");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_review_source() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("review_source");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_review_date_role() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("review_date_role");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_awards() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("awards");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_awards_code() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("awards_code");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_audience() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("audience");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_relation_code() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("relation_code");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_currency() {
        $retarray = array();
        $this->db->select("id,code,seq_no");
        $this->db->from("currency");
        $this->db->where("code<>", "");
        $this->db->group_by("code");
        $this->db->order_by("seq_no,code", "ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    public function get_company_name_by_id($company_id) {
        $retarray = array();
        if (!empty($company_id)) {
            $this->db->select("id,name");
            $this->db->from("company");
            $this->db->where("id", $company_id);

            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }  
}
