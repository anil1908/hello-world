<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Catalog_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    /**
         * Book list by company id
         *
         * @access	public
         * @param	company_id,pagelimit, pagestart, sortfield, sorttype,search,namearray
         * @return	Array
    */
    public function get_book_list_by_company_id($company_id,$pageStart,$pageLimit,$sortField,$sortType,$search,$namearray){
            $retarray = array();
            if(!empty($company_id)){
                $this->db->select("b.id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,b.publication_date,b.imprint,"
                        . "GROUP_CONCAT(DISTINCT bi.identifier_no)as identifier_no,c.name as publisher,"
                        . "GROUP_CONCAT(DISTINCT t.name) as tag");
                $this->db->from("books b");
                $this->db->join("book_identifiers bi","b.id=bi.book_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)","LEFT");
                $this->db->join("book_tags bt","b.id=bt.book_id AND (bt.deleted_by < 1 OR bt.deleted_by = 0)","LEFT");
                $this->db->join("tags t","t.id=bt.tag_id AND (t.deleted_by < 1 OR t.deleted_by = 0)","LEFT");
                $this->db->join("company c","c.id=b.company_id","LEFT");
                $this->db->join("book_contributors bc","b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)","LEFT");
                $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
                $this->db->where("b.company_id=".$company_id." AND (b.deleted_by < 1 OR b.deleted_by = 0)");
                if(!empty($search)){
                    $this->db->where("((LOWER(b.title) LIKE '%$search%') OR (LOWER(cp.name) LIKE '%$search%') OR (LOWER(b.imprint) LIKE '%$search%') OR (LOWER(c.name) LIKE '%$search%') OR ( (b.publication_date = '".date('Y-m-d', strtotime($search))."') OR  (YEAR(b.publication_date)='".date('Y-m-d', strtotime($search))."') OR  (MONTH(b.publication_date)='".date('Y-m-d', strtotime($search))."') OR  (DATE(b.publication_date)='".date('Y-m-d', strtotime($search))."') ) OR (bi.identifier_no LIKE '%$search%'))");
                }
                if(!empty($namearray)){
                    $this->db->where(implode(" OR ", $namearray));
                }
                $this->db->group_by('b.id');
                $this->db->order_by($sortField,$sortType);
                $this->db->limit($pageLimit,$pageStart);
                $query = $this->db->get();
                if($query->num_rows()>0){
                    $retarray = $query->result_array();
                }
            }
            return $retarray;
    }
    /**
         * Book list by selection
         *
         * @access	public
         * @param	company_id
         * @return	Array
    */
    public function get_book_list_by_selection($company_id){
            $retarray = array();
            if(!empty($company_id)){
                $this->db->select("id,title,cover_image as image");
                $this->db->from("books");
                $this->db->where("company_id=".$company_id." AND (deleted_by < 1 OR deleted_by = 0)");
                $query = $this->db->get();
                if($query->num_rows()>0){
                    $retarray = $query->result_array();
                }
            }
            return $retarray;
    }
    /**
         * Book list
         *
         * @access	public
         * @param	company_id,search,namearray
         * @return	Count of rows
    */
    public function get_book_list_count($company_id,$search,$namearray){
            $iTotal = 0;
            $result = array();
            if(!empty($company_id)){
                $this->db->select("COUNT(DISTINCT b.id)as num_rows");
                $this->db->from("books b");
                $this->db->join("book_identifiers bi","b.id=bi.book_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)","LEFT");
                $this->db->join("identifier_types it","it.id=bi.identifier_type_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)","LEFT");
                $this->db->join("book_tags bt","b.id=bt.book_id AND (bt.deleted_by < 1 OR bt.deleted_by = 0)","LEFT");
                $this->db->join("tags t","t.id=bt.tag_id AND (t.deleted_by < 1 OR t.deleted_by = 0)","LEFT");
                $this->db->join("company c","c.id=b.company_id","LEFT");
                $this->db->join("book_contributors bc","b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)","LEFT");
                $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
                $this->db->where("b.company_id=".$company_id." AND (b.deleted_by < 1 OR b.deleted_by = 0)");
                if(!empty($search)){
                    $this->db->where("((LOWER(b.title) LIKE '%$search%') OR (LOWER(cp.name) LIKE '%$search%') OR (LOWER(b.imprint) LIKE '%$search%') OR (LOWER(c.name) LIKE '%$search%') OR ( (b.publication_date = '".date('Y-m-d', strtotime(str_replace('/', '-', $search)))."') OR  (YEAR(b.publication_date)='$search') OR  (MONTH(b.publication_date)='$search') OR  (DATE(b.publication_date)='$search') ) OR (bi.identifier_no LIKE '%$search%'))");
                }
                if(!empty($namearray)){
                    $this->db->where(implode(" OR ", $namearray));
                }
                $query = $this->db->get();                
                if ($query->num_rows() > 0) {
                   $result = $query->row(); 
                   $iTotal = $result->num_rows;
                }                
            }
            return $iTotal;
    }
    /**
         * Book Details
         *
         * @access	public
         * @param	book_id
         * @return	Array
    */
    public function get_book_details_by_id($book_id){
            $retarray = array();
            if(!empty($book_id)){
                $this->db->select("b.id,b.title,b.cover_image as image,b.sub_title,b.volume,b.edition,b.audience_id,b.copyright_year,"
                        . "b.copyright_owner,b.supplier_details,b.supply_date,b.publication_date,b.cover_image,b.title_availability,"
                        //. "group_concat(DISTINCT cr.name) as contributor_role,group_concat(DISTINCT cp.name) as contributor_name,"
                        ."GROUP_CONCAT(DISTINCT CONCAT(cr.id,'-',cp.name,'-',cr.name))as contributor_role,"
                        ."GROUP_CONCAT(DISTINCT CONCAT(it.id,'=',bi.identifier_no,'=',it.name))as identifier,"
                        ."GROUP_CONCAT(DISTINCT CONCAT(r.id))as region_id,"
                        ."GROUP_CONCAT(DISTINCT CONCAT(r.name))as region_name,"
                        ."GROUP_CONCAT(DISTINCT CONCAT(con.id,'=',con.name))as country_name,"
                        . "c.name as publisher,b.imprint,l.name as language,l.id as language_id,GROUP_CONCAT(DISTINCT CONCAT(cur.id,'-',bp.price,'-',(CASE WHEN cur.symbol IS NOT NULL THEN cur.symbol else cur.code end)))as price,"
                        . "GROUP_CONCAT(DISTINCT CONCAT(bs.subject_id,'=',s.name))as subject,b.main_subject_id,b.description,b.keywords,CONCAT(b.min_age_range,'-',b.max_age_range) as age_range,"
                        . "CONCAT(min_us_grade_range,'-',max_us_grade_range)as us_grade_range,GROUP_CONCAT(DISTINCT con.name)as countries_included");
                $this->db->from("books b");
                $this->db->join("book_contributors bc","b.id=bc.book_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)","LEFT");
                $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
                $this->db->join("contributors_role cr","cr.id=bc.role_id","LEFT");
                $this->db->join("book_identifiers bi","b.id=bi.book_id AND(bi.deleted_by < 1 OR bi.deleted_by = 0)","LEFT");
                $this->db->join("identifier_types it","it.id=bi.identifier_type_id","LEFT");
                $this->db->join("company c","c.id=b.company_id","LEFT");
                $this->db->join("language l","l.id=b.language_id","LEFT");
                $this->db->join("book_subjects bs","b.id=bs.book_id AND (bs.deleted_by < 1 OR bs.deleted_by = 0)","LEFT");
                $this->db->join("subjects s","s.id=bs.subject_id","LEFT");
                $this->db->join("book_countries bcon","b.id=bcon.book_id AND (bcon.deleted_by < 1 OR bcon.deleted_by = 0)","LEFT");
                $this->db->join("country con","con.id=bcon.country_id","LEFT");
                $this->db->join("book_regions br","b.id=br.book_id AND (br.deleted_by < 1 OR br.deleted_by = 0)","LEFT");
                $this->db->join("regions r","r.id=br.region_id","LEFT");
                $this->db->join("book_prices bp","bp.book_id='".$book_id."'","LEFT");
                $this->db->join("currency cur","cur.id=bp.currency_id","LEFT");
                $this->db->where("b.id='".$book_id."' AND (b.deleted_by < 1 OR b.deleted_by = 0)");                
                $query = $this->db->get();
               
                if ($query->num_rows() > 0) {
                    $retarray = $query->row();
                }
            }
            return $retarray;
    }
    /**
         * Book reviews
         *
         * @access	public
         * @param	book_id
         * @return	Array
    */
     public function get_book_reviews_by_id($book_id){
            $retarray = array();
            if(!empty($book_id)){
                $this->db->select("rt.name as reviewtype_name,rt.id as reviewtype_id,rs.name as reviewsource_name,rs.id as reviewsource_id,br.title,br.review_text as review,br.url,DATE_FORMAT(br.created_on,'%m/%d/%Y') as created_on,rdr.name as reviewrole_name,rdr.id as reviewrole_id");
                $this->db->from("book_reviews br");
                $this->db->join("review_source rs","rs.id=br.source_id");
                $this->db->join("review_type rt","rt.id=br.type_id");
                $this->db->join("review_date_role rdr","rdr.id=br.review_date_role_id");
                $this->db->where("br.book_id='".$book_id."' AND (br.deleted_by < 1 OR br.deleted_by = 0)");
                $query =  $this->db->get();
                if ($query->num_rows() > 0) {
                    $retarray = $query->result_array();
                }
            }
            return $retarray;
    }
    /**
         * Book Awards
         *
         * @access	public
         * @param	book_id
         * @return	Array
    */
    public function get_book_awards_by_id($book_id){
            $retarray = array();
            if(!empty($book_id)){
                $this->db->select("a.name as award_name,ba.year,c.name as awardcountry_name,c.id as awardcountry_id,ac.name as awardcode_name,ac.id as awardcode_id");
                $this->db->from("awards a");
                $this->db->join("book_awards ba","a.id=ba.award_id AND ba.book_id='".$book_id."' AND (ba.deleted_by < 1 OR ba.deleted_by = 0)");
                $this->db->join("country c","c.id=ba.country_id");
                $this->db->join("awards_code ac","ac.id=ba.award_code_id");
                $query = $this->db->get();
                if ($query->num_rows() > 0) {
                    $retarray = $query->result_array();
                }
            }
            return $retarray;
    }
    /**
         * Book related product
         *
         * @access	public
         * @param	book_id
         * @return	Array
    */
    public function get_book_related_product_by_id($book_id){
            $retarray = array();
            if(!empty($book_id)){
                $this->db->select("b.title,bi.identifier_no,it.name as identifiertype_name,it.id as identifiertype_id,rc.name as relatedcode_name,rc.id as relatedcode_id");
                $this->db->from("book_related br");
                $this->db->join("books b","b.id=br.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
                $this->db->join("book_identifiers bi","b.id=bi.book_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)");
                $this->db->join("identifier_types it","it.id=bi.identifier_type_id");
                $this->db->join("relation_code rc","rc.id=br.relation_code_id");
                $this->db->where("br.book_id='".$book_id."' AND (br.deleted_by < 1 OR br.deleted_by = 0)");
                $this->db->group_by("rc.id");
                $query = $this->db->get();
                if ($query->num_rows() > 0) {
                    $retarray = $query->result_array();
                }
            }
            return $retarray;
    }
    /**
         * Selected company Tag list
         *
         * @access	public
         * @param	company_id,tag_name
         * @return	boolean
    */
    public function get_tag_by_company_id($company_id,$tag_name){
            if(!empty($company_id) && !empty($tag_name)){
                $this->db->where("publisher_id='".$company_id."' AND LOWER(name)='".strtolower($tag_name)."' AND (deleted_by < 1 OR deleted_by = 0)");
                $query = $this->db->get("tags");
                if($query->num_rows()>0){
                    return TRUE;
                }else{
                    return FALSE;
                }
            }
    }
    /**
     * Region & country 
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_region_with_country() {
            $result = array();
            $namearray = array();
            $retarray   = array();
            $this->db->select("r.id as region_id,r.name as region_name,c.id as country_id,c.name as country_name");
            $this->db->from("regions r");
            $this->db->join("country c","r.id=c.region_id","LEFT");
            $query = $this->db->get();
            if($query->num_rows()>0){
                $result = $query->result_array();
                if (is_array($result) && count($result) > 0) {
                    $i=0;
                    foreach ($result as $key=>$val) {
                        if(!in_array($result[$key]['region_name'], $namearray)){
                            $i=0;
                            array_push($namearray, $result[$key]['region_name']);
                        }
                        $retarray[$result[$key]['region_name']]['id'] = $result[$key]['region_id'];
                        $retarray[$result[$key]['region_name']]['label'] = $result[$key]['region_name'];
                        if(!empty($result[$key]['country_id'])){
                            $retarray[$result[$key]['region_name']]['children'][$i]['id'] = $result[$key]['country_id'].'='.$result[$key]['country_name'];
                            $retarray[$result[$key]['region_name']]['children'][$i]['label'] = $result[$key]['country_name'];
                        }
                        $i++;
                    }
                }
            }
            return $retarray;     
    }
    /**
         * Region by country
         *
         * @access	public
         * @param	company_id,tag_name
         * @return	boolean
    */
    public function get_region_by_country($book_country){
            $retarray = array();
            if(is_array($book_country) && count($book_country)>0){
                $this->db->select("GROUP_CONCAT(DISTINCT region_id)as region_ids");
                $this->db->where_in("id",$book_country);
                $query = $this->db->get("country");
                if($query->num_rows()>0){
                    $retarray = $query->row();
                }
            }
            return $retarray;
    }
    /**
         * add tag
         *
         * @access	public
         * @param	tag_data
         * @return	NA
    */
    public function insert_tag($tag_data){
        if(is_array($tag_data) && count($tag_data)>0){
            $this->db->insert("tags",$tag_data);
        }
    }
    /**
         * add tag for individual book
         *
         * @access	public
         * @param	tag_data,book_id,user_id
         * @return	Array
    */
    public function insert_tag_for_individual_book($tag_data,$book_id,$user_id){
            $retarray = array();
            $created_on = date('Y-m-d H:i:s');
             if(is_array($tag_data) && count($tag_data)>0){
                $this->db->insert_batch('tags', $tag_data);
                $total_affected_rows = $this->db->affected_rows();
                $first_id = $this->db->insert_id();
                $last_id = ($first_id + $total_affected_rows - 1);

                if(!empty($first_id) && !empty($last_id)){
                    for($i=$first_id;$i<=$last_id;$i++){
                        $retarray[] = $i;
                        $query = "INSERT book_tags (book_id, tag_id, created_on, created_by)
                                  VALUES('$book_id','$i','$created_on','$user_id')";
                        $this->db->query($query);
                    }
                }
            }
            return $retarray;
    }
    
    
    /**
         * Update tag
         *
         * @access	public
         * @param	tag data,company_id,tag_id
         * @return	NA
    */
    public function update_tag($tag_data,$company_id,$tag_id){
        if(!empty($company_id) && !empty($tag_id)){
            $this->db->where("id",$tag_id);
            $this->db->where("publisher_id",$company_id);
            $this->db->update("tags",$tag_data);
        }  
    }
    /**
         * Update book tag
         *
         * @access	public
         * @param	tag data,tag_id
         * @return	NA
    */
    public function update_book_tag($tag_data,$tag_id){
        if(!empty($tag_id)){
            $this->db->where("tag_id",$tag_id);
            $this->db->update("book_tags",$tag_data);
        }  
    }
    /**
         * Tag list
         *
         * @access	public
         * @param	company_id
         * @return	Array
    */
    public function get_tag_list($company_id){
            $retarray = array();
            if(!empty($company_id)){
                $this->db->select("id,name");
                $this->db->where("publisher_id='".$company_id."' AND (deleted_by < 1 OR deleted_by = 0)");
                $query = $this->db->get('tags');
                if($query->num_rows()>0){
                    $retarray = $query->result_array();
                }
            }
            return strip_slashes($retarray);
    }
    /**
         * Tag list
         *
         * @access	public
         * @param	company_id,search
         * @return	Array
    */
    public function get_tag_list_by_search($company_id,$search=NULL){
            $retarray = array();
            if(!empty($company_id)){
                $this->db->select("id,name");
                if(!empty($search)){
                    $this->db->where("LOWER(name) like '%$search%'");
                }
                $this->db->where("publisher_id='".$company_id."' AND (deleted_by < 1 OR deleted_by = 0)");
                $query = $this->db->get('tags');                                
                if($query->num_rows()>0){
                    $retarray = $query->result_array();
                }
            }
            return strip_slashes($retarray);
    }
    /**
         * Check Book Tag
         *
         * @access	public
         * @param	tag_array,company_id
         * @return	Array
    */
    public function check_book_tag($tag_array,$company_id){
        $retarray = array();
        if(!empty($company_id)){
            $this->db->select("GROUP_CONCAT(id) as tag_ids,GROUP_CONCAT(name) as tag_names");
            $this->db->where_in("LOWER(name)",$tag_array);
            $this->db->where("publisher_id=$company_id and (deleted_by < 1 OR deleted_by = 0)");
            $query = $this->db->get("tags");
            $retarray = $query->row();
        }
        return $retarray;
    }
    /**
         * Insert Book Tag
         *
         * @access	public
         * @param	book_tag_data
         * @return	NA
    */
    public function insert_book_tag($book_tag_data){
        if(is_array($book_tag_data) && count($book_tag_data)>0){
            $this->db->custom_insert_batch("book_tags",$book_tag_data);
        }
    }
    /**
         * Delete book tag by book id
         *
         * @access	public
         * @param	book id,book tag data
         * @return	NA
    */
    public function delete_book_tags_by_id($book_id,$book_tag_data){
        if((is_array($book_tag_data) && count($book_tag_data)>0) && !empty($book_id)){
            $this->db->where("book_id",$book_id);
            $this->db->update("book_tags",$book_tag_data);
        }
    }
    /**
         * Delete all book tag by book id
         *
         * @access	public
         * @param	book id,book tag data
         * @return	NA
    */
    public function delete_all_book_tags_by_id($book_id){
        if(!empty($book_id)){
            $this->db->where("book_id",$book_id);
            $this->db->delete("book_tags");
        }
    }
    /**
         * Insert book tag
         *
         * @access	public
         * @param	book_tag_data
         * @return	NA
    */
    public function insert_book_tag_for_individual_book($book_tag_data){
        if(is_array($book_tag_data) && count($book_tag_data)>0){
            $this->db->insert_batch("book_tags",$book_tag_data);
        }
    }
    /**
         * Book id
         *
         * @access	public
         * @param	company_id
         * @return	Array
    */
    public function get_book_id($company_id){
        $retarray = array();
        if(!empty($company_id)){
            $this->db->select("id");
            $this->db->where("company_id",$company_id);
            $query = $this->db->get("books");
            if($query->num_rows()>0){
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }
    /**
         * Check book exist in group
         *
         * @access	public
         * @param	book_array
         * @return	Array
    */
    public function check_group_books($book_array){
        $retarray = array();
        if(is_array($book_array) && count($book_array)>0){
            $this->db->select("GROUP_CONCAT(book_id) as book_ids");
            $query = $this->db->get("groups_books");
            if($query->num_rows()>0){
                $retarray = $query->row();
            }
        }
        return $retarray;
    }
    /**
         * Check book title
         *
         * @access	public
         * @param	title,company_id
         * @return	Boolean
    */
    public function check_book_title($title,$company_id){
        if(!empty($title) && !empty($company_id)){
            $this->db->where("company_id=$company_id AND title='$title' AND (deleted_by < 1 OR deleted_by = 0)");
            $query = $this->db->get("books");
            if($query->num_rows()>0){
                return TRUE;
            }else{
                return FALSE;
            }
        }
    }
    /**
         * Check book identifier
         *
         * @access	public
         * @param	title,company_id
         * @return	Boolean
    */
    public function check_identifier($identifier_array,$company_id,$book_id=0){
        if(!empty($identifier_array) && !empty($company_id)){
            
            $this->db->where_in('bi.identifier_no',$identifier_array);
            $this->db->from('book_identifiers bi');
            $this->db->join('books b','b.id = bi.book_id');
            if($book_id > 0){
                $this->db->where('b.id<>',$book_id);
            }
            $this->db->where('b.company_id= '.$company_id.' AND(bi.deleted_by < 1 OR bi.deleted_by = 0) AND (b.deleted_by < 1 OR b.deleted_by = 0)');
            $this->db->group_by('b.id');
            $query = $this->db->get();
            if($query->num_rows()>0){
                return TRUE;
            }else{
                return FALSE;
            }
        }
    }
    /**
         * Check book title by id
         *
         * @access	public
         * @param	title,book_id
         * @return	Boolean
    */
    public function check_book_title_by_id($title,$company_id,$book_id){
        if(!empty($title) && !empty($book_id)){
            $this->db->where("id<>",$book_id);
            $this->db->where("company_id=$company_id AND title='$title' AND (deleted_by < 1 OR deleted_by = 0)");
            $query = $this->db->get("books");
            if($query->num_rows()>0){
                return TRUE;
            }else{
                return FALSE;
            }
        }
    }
    /**
         * Check award name
         *
         * @access	public
         * @param	award_name
         * @return	award_id
    */
    public function check_award_name($award_name){
        $award_id =0;
        $retarray = array();
        if(!empty($award_name)){
            $this->db->select("id");
            $this->db->where("LOWER(name)",$award_name);
            $query = $this->db->get("awards");
            if($query->num_rows()>0){
                $retarray = $query->row();
                $award_id = $retarray->id;
            }else{
                $this->db->insert("awards",array("name"=>$award_name));
                $award_id = $this->db->insert_id();
            }
        }
        return $award_id;
    }
    /**
         * Check award name
         *
         * @access	public
         * @param	$contributor_name
         * @return	people_id
    */
    public function check_contributor_people($contributor_name){
        $person_id =0;
        $retarray = array();
        if(!empty($contributor_name)){
            $this->db->select("id");
            $this->db->where("LOWER(name)",$contributor_name);
            $query = $this->db->get("contributors_people");
            if($query->num_rows()>0){
                $retarray = $query->row();
                $person_id = $retarray->id;
            }else{
                $this->db->insert("contributors_people",array("name"=>$contributor_name));
                $person_id = $this->db->insert_id();
            }
        }
        return $person_id;
    }
    /**
         * Insert book
         *
         * @access	public
         * @param	book_data
         * @return	book_id
    */
    public function insert_book($book_data){
        $book_id = 0;
        if(is_array($book_data) && count($book_data)>0){
            $this->db->insert("books",$book_data);
            $book_id = $this->db->insert_id();
        }
        return $book_id;
    }
    /**
         * Insert book contributor
         *
         * @access	public
         * @param	book_contributor_data
         * @return	NA
    */
    public function insert_book_contributor($book_contributor_data){
        if(is_array($book_contributor_data) && count($book_contributor_data)>0){
            $this->db->insert_batch("book_contributors",$book_contributor_data);
        }
    }
    /**
         * Insert book identifier
         *
         * @access	public
         * @param	book_identifier_data
         * @return	NA
    */
    public function insert_book_identifier($book_identifier_data){
        if(is_array($book_identifier_data) && count($book_identifier_data)>0){
            $this->db->insert_batch("book_identifiers",$book_identifier_data);
        }
    }
    /**
         * Insert book price
         *
         * @access	public
         * @param	book_price_data
         * @return	NA
    */
    public function insert_book_price($book_price_data){
        if(is_array($book_price_data) && count($book_price_data)>0){
            $this->db->insert_batch("book_prices",$book_price_data);
        }
    }
    /**
         * Insert book subject
         *
         * @access	public
         * @param	book_subject_data
         * @return	NA
    */
    public function insert_book_subject($book_subject_data){
        if(is_array($book_subject_data) && count($book_subject_data)>0){
            $this->db->insert_batch("book_subjects",$book_subject_data);
        }
    }
    /**
         * Insert book region
         *
         * @access	public
         * @param	book_region_data
         * @return	NA
    */
    public function insert_book_region($book_region_data){
        if(is_array($book_region_data) && count($book_region_data)>0){
            $this->db->insert_batch("book_regions",$book_region_data);
        }
    }
    /**
         * Insert book country
         *
         * @access	public
         * @param	book_subject_data
         * @return	NA
    */
    public function insert_book_country($book_country_data){
        if(is_array($book_country_data) && count($book_country_data)>0){
            $this->db->insert_batch("book_countries",$book_country_data);
        }
    }
    /**
         * Insert book review
         *
         * @access	public
         * @param	book_review_data
         * @return	NA
    */
    public function insert_book_review($book_review_data){
        if(is_array($book_review_data) && count($book_review_data)>0){
            $this->db->custom_insert_batch("book_reviews",$book_review_data);
        }
    }
    /**
         * Insert book award
         *
         * @access	public
         * @param	book_award_data
         * @return	NA
    */
    public function insert_book_award($book_award_data){
        if(is_array($book_award_data) && count($book_award_data)>0){
            $this->db->insert_batch("book_awards",$book_award_data);
        }
    }
    /**
         * Insert book related product
         *
         * @access	public
         * @param	book_related_data
         * @return	NA
    */
    public function insert_book_related($book_related_data){
        if(is_array($book_related_data) && count($book_related_data)>0){
            $this->db->insert_batch("book_related",$book_related_data);
        }
    }
    /**
         * Update book
         *
         * @access	public
         * @param	book_related_data
         * @return	NA
    */
    public function update_book($book_data,$book_id){
        if((is_array($book_data) && count($book_data)>0) && !empty($book_id)){
            $this->db->where("id",$book_id);
            $this->db->update("books",$book_data);
        }
    }
    /**
         * Book Price 
         *
         * @access	public
         * @param	book array
         * @return	Array
    */
    public function get_book_price_by_id($book_array){
        $retarray = array();
        if(is_array($book_array) && count($book_array)>0){
            $this->db->where_in("book_id",$book_array);
            $query = $this->db->get("book_prices");
            if($query->num_rows()>0){
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }
    /**
         * Insert book price history
         *
         * @access	public
         * @param	book_price_data
         * @return	NA
    */
    public function insert_book_price_history($book_price_data){
        if(is_array($book_price_data) && count($book_price_data)>0){
            $this->db->insert_batch("history_book_prices",$book_price_data);
        }
    }
    /**
         * Delete book price 
         *
         * @access	public
         * @param	book_array
         * @return	NA
    */
    public function delete_book_prices_by_id($book_array){
        if(is_array($book_array) && count($book_array)>0){
            $this->db->where_in("book_id",$book_array);
            $this->db->delete("book_prices");
        }
    }
    /**
         * Delete Book data
         *
         * @access	public
         * @param	book_data,book_array
         * @return	NA
    */
    public function delete_books_data($book_data,$book_array,$flag=0){
        if((is_array($book_array) && count($book_array)>0) && (is_array($book_data) && count($book_data)>0)){
            $this->db->where_in("book_id",$book_array);
            $this->db->update("book_tags",$book_data);
            
            $this->db->where_in("book_id",$book_array);
            $this->db->update("book_subjects",$book_data);
            
            $this->db->where_in("book_id",$book_array);
            $this->db->update("book_reviews",$book_data);
            
            $this->db->where_in("book_id",$book_array);
            $this->db->update("book_related",$book_data);
            
            $this->db->where_in("book_id",$book_array);
            $this->db->update("book_regions",$book_data);
            
            $this->db->where_in("book_id",$book_array);
            $this->db->update("book_identifiers",$book_data);
            
            $this->db->where_in("book_id",$book_array);
            $this->db->update("book_countries",$book_data);
            
            $this->db->where_in("book_id",$book_array);
            $this->db->update("book_contributors",$book_data);
            
            $this->db->where_in("book_id",$book_array);
            $this->db->update("book_awards",$book_data);
            
            if($flag==0){
                $this->db->where_in("id",$book_array);
                $this->db->update("books",$book_data);
            }
            if($flag==1){
                $this->delete_book_prices_by_id($book_array);
            }
        }
    }
    
    
    /**
         * Maintain Books list
         *
         * @access	public
         * @param	company_id,pagelimit, pagestart, sortfield, sorttype,search_title,search_author,search_imprint,search_publisher
         * @return	Array
    */
    public function get_maintian_books_list($company_id,$pageStart,$pageLimit,$sortField,$sortType,$search_title,$search_author,$search_imprint,$search_publisher){
            $retarray = array();
            if(!empty($company_id)){
                $this->db->select("b.id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,b.publication_date,b.imprint,"
                        . "GROUP_CONCAT(DISTINCT bi.identifier_no)as identifier_no,c.name as publisher");
                $this->db->from("books b");
                $this->db->join("book_identifiers bi","b.id=bi.book_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)","left");               
                $this->db->join("company c","c.id=b.company_id","left");
                $this->db->join("book_contributors bc","b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)","left");
                $this->db->join("contributors_people cp","cp.id=bc.person_id","left");
                $this->db->where("b.company_id=".$company_id." AND (b.deleted_by < 1 OR b.deleted_by = 0)");                
                if(!empty($search_title)){
                    $this->db->where("(LOWER(b.title) LIKE '%$search_title%')");
                }
                if(!empty($search_author)){
                    $this->db->where("(LOWER(cp.name) LIKE '%$search_author%')");
                }
                if(!empty($search_author)){
                    $this->db->where("(LOWER(b.imprint) LIKE '%$search_imprint%')");
                }
                if(!empty($search_publisher)){
                    $this->db->where("(LOWER(c.name) LIKE '%$search_publisher%')");
                }
                $this->db->group_by('b.id');
                $this->db->order_by($sortField,$sortType);
                $this->db->limit($pageLimit,$pageStart);
                $query = $this->db->get();
                if($query->num_rows()>0){
                    $retarray = $query->result_array();
                }
               
            }
            return $retarray;
    }
    
    /**
         * Maintain Book List Count
         *
         * @access	public
         * @param	company_id,search_title,search_author,search_imprint,search_publisher
         * @return	Count of rows
    */
    public function get_maintian_books_list_count($company_id,$search_title,$search_author,$search_imprint,$search_publisher){
            $iTotal = 0;
            $result = array();
            if(!empty($company_id)){
                $this->db->select("COUNT(DISTINCT b.id)as num_rows");
                $this->db->from("books b");
                $this->db->join("book_identifiers bi","b.id=bi.book_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)","LEFT");
                $this->db->join("identifier_types it","it.id=bi.identifier_type_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)","LEFT");               
                $this->db->join("company c","c.id=b.company_id","LEFT");
                $this->db->join("book_contributors bc","b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)","LEFT");
                $this->db->join("contributors_people cp","cp.id=bc.person_id","LEFT");
                $this->db->where("b.company_id=".$company_id." AND (b.deleted_by < 1 OR b.deleted_by = 0)");                
                if(!empty($search_title)){
                    $this->db->where("(LOWER(b.title) LIKE '%$search_title%')");
                }
                if(!empty($search_author)){
                    $this->db->where("(LOWER(cp.name) LIKE '%$search_author%')");
                }
                if(!empty($search_author)){
                    $this->db->where("(LOWER(b.imprint) LIKE '%$search_imprint%')");
                }
                if(!empty($search_publisher)){
                    $this->db->where("(LOWER(c.name) LIKE '%$search_publisher%')");
                }
                $query = $this->db->get();                
                 
                if ($query->num_rows() > 0) {
                   $result = $query->row(); 
                   $iTotal = $result->num_rows;
                }                
            }
            return $iTotal;
    }

}
