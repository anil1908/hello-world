<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User_profile_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * User details
     *
     * @access	public
     * @param	user_id
     * @return	Array
     */
     public function get_user_details_by_id($user_id) {
        $retarray = array();
        if(!empty($user_id)){
            $this->db->select("first_name,last_name,email,photo");
            $this->db->where("id",$user_id);
            $query = $this->db->get("users");
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }
    /**
     * Invited User details
     *
     * @access	public
     * @param	user_id
     * @return	Array
     */
     public function get_invited_user_details_by_id($user_id) {
        $retarray = array();
        if(!empty($user_id)){
            $this->db->select("u.id as user_id,u.first_name,u.last_name,u.email,u.company_id,c.name as company_name,c.usertype_id as usertype");
            $this->db->from('users u');
            $this->db->join('company c','c.id=u.company_id','LEFT');
            $this->db->where("u.id",$user_id);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }
    /**
     * Update user details
     *
     * @access	public
     * @param	user_id,users_data 
     * @return	NA
     */
    public function update_users_data_by_id($users_data,$user_id){
        if((is_array($users_data) && count($users_data) >0) && !empty($user_id)){
            $this->db->where("id",$user_id);
            $this->db->update("users",$users_data);
        }
    }
    /**
     * User modules by usertype
     *
     * @access	public
     * @param	usertype_id
     * @return	Array
     */
    public function get_modules_by_usertype($usertype_id){
        $retarray = array();
        if(!empty($usertype_id)){
            $this->db->select('id,name');
            $this->db->where('usertype_id',$usertype_id);
            $query = $this->db->get('modules');
            if($query->num_rows()>0){
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }
    /**
     * User details and rights
     *
     * @access	public
     * @param	user_id
     * @return	Array
     */
    public function get_user_details_with_rights($user_id){
        $retarray = array();
        if(!empty($user_id)){
            $this->db->select('u.id,u.first_name,u.last_name,u.email,GROUP_CONCAT(DISTINCT CONCAT(umr.module_id,"-",m.name))as rights');
            $this->db->where('u.id',$user_id);
            $this->db->from('users u');
            $this->db->join('users_module_rights umr','u.id=umr.user_id AND (umr.deleted_by < 1 OR umr.deleted_by =0)','LEFT');
            $this->db->join('modules m','m.id=umr.module_id','LEFT');
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }
    /**
     * User rights
     *
     * @access	public
     * @param	user_id,modulearray
     * @return	NA
     */
    public function get_user_rights_by_id($modulearray,$user_id){
        $retarray = array();
        if(!empty($user_id) && (is_array($modulearray) && count($modulearray)>0)){
            $this->db->select('GROUP_CONCAT(module_id) as module_ids');
            $this->db->where_in('module_id',$modulearray);
            $this->db->where("deleted_by < 1 OR deleted_by = 0");
            $query = $this->db->get("users_module_rights");
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }
    /**
     * Insert user module rights
     *
     * @access	public
     * @param	data
     * @return	NA
     */
    public function insert_user_module_rights($data){
        if(is_array($data) && count($data)>0){
            $this->db->insert_batch('users_module_rights',$data);
        }
    }
    /**
     * Remove user module rights
     *
     * @access	public
     * @param	module_data,user_id
     * @return	NA
     */
    public function delete_user_module_rights($module_data,$user_id){
        if(!empty($user_id)){
            $this->db->where('user_id',$user_id);
            $this->db->update('users_module_rights',$module_data);
        }
    }

}
