App.controller('homeController', ['$scope', '$rootScope','userRightsService','$sessionStorage','$translate', 'authService', '$location','localStorageService', 
    function ($scope, $rootScope,userRightsService,$sessionStorage, $translate, authService, $location,localStorageService) {
    	/*Login And Signup Menu display*/     
        var authTokenData           = localStorageService.get('authorizeTokenDetail');
        $scope.usertype             = (authTokenData!==null)? parseInt(authTokenData.usertype) : '';        
        var userData                = cookies.get('authorizationData');
        $rootScope.userData         = userData; 
        if(userData != null && userData != undefined && userData.email!==''){
            $rootScope.logo = 'main-logo.jpg';
        }
        else{
            $rootScope.logo = 'home-logo.png';
        }
		$scope.showMenu = function (viewLocation) {
	     	var active = (viewLocation === $location.path());
	     	return active;
		};
		$scope.goHome 	= function(){
			$location.path('/');
		}
        $scope.logOut = function () {
            authService.logOut()
            .then(function (data) {
                if (data.error <= 0) {
                    $rootScope.message = '';
                    $location.path('/');
                }
                else{
                    $scope.isError = true;
                    $scope.message = data.errorMsg;
                }
            },
            function (err,status) {
                $scope.message = err.errorMsg;
            });
        };
        $scope.checkRights = function(moduleId){
            return userRightsService.checkUserRights(moduleId);
        }
		/*End Login And Signup Menu display*/
    }
]);