'use strict';
App.controller('editgroupController', ['$scope', '$rootScope', 'groupService', '$uibModal', '$location', '$sessionStorage', 'localStorageService',
    function ($scope, $rootScope, groupService, $uibModal, $location, $sessionStorage, localStorageService) {
        var parameter = $location.search();
        if (parameter.id != '' && parameter.id != undefined) {
            var TokenData = localStorageService.get('authorizeTokenDetail');
            $scope.booksList = [];
            $scope.groupDetail = {};
            $scope.booksListData = {allchecked: false, bookArr: []};
            $scope.pageIds = [];
            $scope.gridOption = {
                filteredItems: 0,
                pageSizeArr: [1, 5, 10, 20, 50, 100],
                currentPage: 1,
                pageLimit: 10,
                sortField: 'b.title',
                sorttype: 'ASC',
                maxsize: 10,
                book_title: '',
                author_name: '',
                imprint: '',
                book_publisher: ''
            };
            $scope.showSelectGroupModal = false;
            $scope.isEditSubmitted = false;
            $scope.getGroupDetails = function () {
                var groupData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    group_id: parameter.id,
                    book_title: $scope.gridOption.book_title,
                    author_name: $scope.gridOption.author_name,
                    imprint: $scope.gridOption.imprint,
                    book_publisher: $scope.gridOption.book_publisher
                };
                $scope.getGroupsData(groupData);
            };

            $scope.$watch('currentPage', function (pageNo) {
                var groupData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    group_id: parameter.id,
                    book_title: $scope.gridOption.book_title,
                    author_name: $scope.gridOption.author_name,
                    imprint: $scope.gridOption.imprint,
                    book_publisher: $scope.gridOption.book_publisher
                };
                $scope.gridOption.currentPage = pageNo;
                $scope.getGroupsData(groupData);
                //or any other code here
            });

            $scope.sort_by = function (sortField) {
                $scope.gridOption.sortField = sortField;
                $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
                var groupData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: sortField,
                    sorttype: $scope.gridOption.sorttype,
                    group_id: parameter.id,
                    book_title: $scope.gridOption.book_title,
                    author_name: $scope.gridOption.author_name,
                    imprint: $scope.gridOption.imprint,
                    book_publisher: $scope.gridOption.book_publisher
                };
                $scope.getGroupsData(groupData);
            };

            $scope.changePageSize = function () {
                $scope.gridOption.currentPage = 1;
                var groupData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    group_id: parameter.id,
                    book_title: $scope.gridOption.book_title,
                    author_name: $scope.gridOption.author_name,
                    imprint: $scope.gridOption.imprint,
                    book_publisher: $scope.gridOption.book_publisher
                };
                $scope.getGroupsData(groupData);
            };

            $scope.cancleSearch = function () {
                $scope.gridOption.book_title = '';
                $scope.gridOption.author_name = '';
                $scope.gridOption.imprint = '';
                $scope.gridOption.book_publisher = '';
                var groupData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    group_id: parameter.id,
                    book_title: $scope.gridOption.book_title,
                    author_name: $scope.gridOption.author_name,
                    imprint: $scope.gridOption.imprint,
                    book_publisher: $scope.gridOption.book_publisher
                };
                $scope.getGroupsData(groupData);
            };

            $scope.searchBook = function () {
                var groupData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    group_id: parameter.id,
                    book_title: $scope.gridOption.book_title,
                    author_name: $scope.gridOption.author_name,
                    imprint: $scope.gridOption.imprint,
                    book_publisher: $scope.gridOption.book_publisher
                };
                $scope.getGroupsData(groupData);
            };

            $scope.getGroupsData = function (groupData) {
                groupService.getGroupDetails(groupData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.groupDetail = data.response.group;
                                $scope.booksList = data.response.group_books;
                                $scope.pageIds = (data.ids !== undefined && data.ids !== null) ? data.ids.split(',') : [];
                                $scope.gridOption.filteredItems = data.response.total_rows;
                                $scope.gridOption.maxsize = Math.ceil(data.response.total_rows / $scope.gridOption.pageLimit);
                                if ($scope.gridOption.maxsize > 5) {
                                    $scope.gridOption.maxsize = 5;
                                }
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.message = err.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            };

            $scope.checkAll = function () {

                if ($scope.booksListData.allchecked) {
                    _.each($scope.booksList, function (element) {
                        var isavl = true;
                        _.each($scope.booksListData.bookArr, function (obj) {
                            if (obj.id === element.id) {
                                isavl = false;
                            }
                        });
                        if (isavl) {
                            $scope.booksListData.bookArr.push(element.id);
                        }
                    });
                } else {
                    var arr = [];
                    angular.forEach($scope.booksListData.bookArr, function(element) {
                        if($scope.pageIds.indexOf(element)<0){
                            arr.push(element);
                        }
                    });
                    $scope.booksListData.bookArr = arr;
                }
                /* if ($scope.booksListData.allchecked) {
                 angular.forEach($scope.booksList, function (element) {
                 $scope.booksListData.bookArr.push(element.id);
                 });
                 } else {
                 var arr = [];
                 angular.forEach($scope.booksListData.bookArr, function (element) {
                 if ($scope.pageIds.indexOf(element.id) < 0) {
                 arr.push(element.id);
                 }
                 });
                 $scope.booksListData.bookArr = arr;
                 }*/
            };

            $scope.uncheckMain = function () {
                $scope.booksListData.allchecked = false;
            };

            $scope.updateGroup = function () {
                if ($scope.editGroup.$valid) {
                    var groupData = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language,
                        group_name: $scope.groupDetail.name,
                        group_id: parameter.id
                    };
                    groupService.editGroupDetail(groupData)
                            .then(function (data) {
                                if (data.error <= 0) {
                                    $location.search({});
                                    $location.path('/groups');
                                    $rootScope.groupsmessage                  = data.msg;
                                    $rootScope.groupsisError                  = false;
                                    $rootScope.groupsisMessage                = true;
                                } else {
                                    $scope.isError = true;
                                    $scope.isMessage = false;
                                    $scope.message = data.errorMsg;
                                }
                            }, function (err, status) {
                                $scope.message = err.errorMsg;
                                $scope.isError = true;
                                $scope.isMessage = false;
                            });
                } else {
                    $scope.isEditSubmitted = true;
                }
            };

            $scope.removeSelectedBookModal = function () {
                if ($scope.booksListData.bookArr.length > 0) {
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/views/publishergroupBookRemove.html',
                        controller: 'groupBookCtrl',
                        resolve: {
                            bookData: function () {
                                return {};
                            }
                        }
                    });
                    modalInstance.result.then(function (dataObj) {
                        $scope.deleteGroupBooks($scope.booksListData.bookArr);
                    }, function () {
                        console.log('error');
                    });
                } else {
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/views/selectone.html',
                        controller: 'groupBookCtrl',
                        resolve: {
                            bookData: function () {
                                return {};
                            }
                        }
                    });
                    modalInstance.result.then(function () {

                    }, function () {
                        console.log('error');
                    });
                }
            };

            $scope.deleteGroupBooks = function (bookArr) {
                var groupData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    group_bookArr: bookArr,
                    group_id: parameter.id
                };
                groupService.deleteGroupBookDetails(groupData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = data.msg;
                                $scope.booksListData.bookArr = [];
                                $scope.getGroupDetails();
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.message = err.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            };
            $scope.goBack = function () {
                $location.path('/groups');
            };

        }
    }]);


App.controller('groupBookCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'bookData',
    function ($scope, $rootScope, $uibModalInstance, bookData) {
        $scope.deleteDone = function () {
            $uibModalInstance.close({});
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);