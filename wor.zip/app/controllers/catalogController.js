'use strict';
App.controller('catalogController', ['$scope','$rootScope','$state','$http','$location','catalogService','$uibModal','localStorageService',
    function ($scope,$rootScope,$state,$http,$location,catalogService,$uibModal,localStorageService) {
        var TokenData           = localStorageService.get('authorizeTokenDetail');
        $scope.booksList        = [];
        $scope.gridOption       = { 
                                filteredItems:0,
                                pageSizeArr : [1, 5, 10, 20, 50, 100],
                                currentPage : 1,
                                pageLimit   : 10,
                                sortField   : 'b.title',
                                sorttype    : 'ASC',
                                maxsize     : 10
                                };
        $scope.state            = false;
        $scope.selectedBookList = [];
        $scope.booksListData    = {bookArr:[],allchecked:false};
        $scope.showDeleteConfirmationModal = false;
        $scope.pageIds           = [];
        $scope.showTagDeleteModal= false; 
        $scope.autoSearchTagArr  = [];
        $scope.tagText           = [];
        $scope.searchAllTag      = [];
        $scope.deleteTag         = [];   
        $scope.showBookGroupModal= false;
       // $scope.bookdetail  = {catalog:{},catalog_awards:[],catalog_related_products:[],catalog_reviews:[]};
        $scope.toggleState  = function() {
            $scope.state = !$scope.state;
        };
        $scope.checkAll     = function() {
            if($scope.booksListData.allchecked){
                _.each($scope.booksList, function(element) {   
                    var isavl   = true;
                    _.each($scope.booksListData.bookArr, function(obj) {
                       if(obj.id===element.id){
                            isavl   = false;
                       } 
                    });
                    if(isavl){
                        $scope.booksListData.bookArr.push(element);   
                    }
                });
            }
            else{
                var arr = [];
                angular.forEach($scope.booksListData.bookArr, function(element) {
                    if($scope.pageIds.indexOf(element.id)<0){
                        arr.push(element);
                    }
                });
                $scope.booksListData.bookArr    = arr;
            }
        };

        $scope.uncheckMain  = function(){
            $scope.booksListData.allchecked = false;
        };

        $scope.getBooks     = function () {
            var booksData = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    pageStart   : ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit   : $scope.gridOption.pageLimit,
                    sortField   : $scope.gridOption.sortField,
                    sorttype    : $scope.gridOption.sorttype
            };
            $scope.getBooksData(booksData);
        };  

        /*Grid Option*/
        $scope.$watch('currentPage', function(pageNo){
            var booksData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                globalText  : $scope.globalText,
                tagText     : $scope.tagText
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getBooksData(booksData);
            //or any other code here
        });

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype  = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var booksData = {
                access_token: TokenData.access_token,
                language    : $rootScope.language,
                pageStart   : ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit   : $scope.gridOption.pageLimit,
                sortField   : sortField,
                sorttype    : $scope.gridOption.sorttype,
                globalText  : $scope.globalText,
                tagText     : $scope.tagText
            };
            $scope.getBooksData(booksData);
        };

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var booksData = {
                access_token: TokenData.access_token,
                language    : $rootScope.language,
                pageStart   : ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit   : $scope.gridOption.pageLimit,
                sortField   : $scope.gridOption.sortField,
                sorttype    : $scope.gridOption.sorttype,
                globalText  : $scope.globalText,
                tagText     : $scope.tagText
            };
            $scope.getBooksData(booksData);
        };

        $scope.globalSearch     = function(){
            var booksData = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    pageStart   : ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit   : $scope.gridOption.pageLimit,
                    sortField   : $scope.gridOption.sortField,
                    sorttype    : $scope.gridOption.sorttype,
                    globalText  : $scope.globalText,
                    tagText     : $scope.tagText
            };
            $scope.getBooksData(booksData);
        };

        $scope.tagSearch        = function(){
            /*var searchTagArr    = [];
            angular.forEach($scope.tagText,function(value,key){
                searchTagArr.push(value.text);
            });*/
            var booksData = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    pageStart   : ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit   : $scope.gridOption.pageLimit,
                    sortField   : $scope.gridOption.sortField,
                    sorttype    : $scope.gridOption.sorttype,
                    globalText  : $scope.globalText,
                    tagText     : $scope.tagText
            };
            $scope.getBooksData(booksData);
        };

        $scope.cancleSearch     = function(){
            $scope.globalText   = '';
            $scope.tagText      = '';
            $scope.tagText      = '';
            var booksData = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    pageStart   : ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit   : $scope.gridOption.pageLimit,
                    sortField   : $scope.gridOption.sortField,
                    sorttype    : $scope.gridOption.sorttype,
                    globalText  : $scope.globalText,
                    tagText     : $scope.tagText
            };
            $scope.getBooksData(booksData);
        };

        /*End Grid Option*/

        $scope.getBooksData = function(booksData){
            catalogService.getBooksList(booksData)
                .then(function(data){
                    if (data.error <= 0) {
                        $scope.pageIds                  = data.ids.split(',');
                        $scope.booksListData.allchecked = false;
                        $scope.booksList                = data.response;
                        $scope.gridOption.filteredItems = data.total_rows;
                        $scope.gridOption.maxsize       = Math.ceil(data.total_rows/$scope.gridOption.pageLimit);
                        if($scope.gridOption.maxsize>5){
                            $scope.gridOption.maxsize   = 5;
                        }
                        $scope.isError  = false;
                        $scope.isMessage= false;
                    } else {
                        $scope.isError  = true;
                        $scope.isMessage= false;
                        $scope.message  = data.errorMsg;
                    }
                },function(err, status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
            });
        };

        /*Book Details*/
        $scope.bookDetailsModal = function(bookId){
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/publisherBookDetail.html',
                controller: 'viewBookDetailCtrl',
                resolve: {
                    bookData :  function (){
                        return {bookId:bookId};
                    }
                }
            });
            modalInstance.result.then(function () {
              
            }, function () {
              console.log('error');
            });
        };

        /*Add  Book in select List*/
        $scope.selectBook       = function(book){
            var bookObj     = {id:book.id,image:book.image,title:book.title};
            var isAvailable = false;
            angular.forEach($scope.selectedBookList, function(value, key) {
                if(value.id==book.id){
                    isAvailable = true;
                }
            });
            if (!isAvailable) {
                $scope.selectedBookList.push(bookObj);
            }
            if ($scope.selectedBookList.length>0){
                $scope.state = true;    
            }
        };
        $scope.deleteSelectBook = function(book){
            $scope.selectedBookList.splice($scope.selectedBookList.indexOf(book),1);
            $scope.state = true;    
        }
        /*End Add  Book in select List*/

        /*Tag Modal*/

        $scope.getAllTagData   = function(){
            var tagData         = {  
                                access_token   : TokenData.access_token,
                                language        : $rootScope.language
                            };
            catalogService.getTagList(tagData)
                .then(function(data){
                    if (data.error <= 0) {
                        var tagarr = [];
                        angular.forEach(data.response,function(value,key){
                            tagarr.push(value.name);
                        });
                        $scope.searchAllTag    = tagarr;
                    } else {
                        $scope.$parent.isError  = true;
                        $scope.$parent.isMessage= false;
                        $scope.$parent.message  = data.errorMsg;
                    }
                },function(err, status){
                    $scope.$parent.message      = err.errorMsg;
                    $scope.$parent.isError      = true;
                    $scope.$parent.isMessage    = false;
            });
        };

        $scope.TagModal         = function(){
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/publisherTag.html',
                controller: 'TagDetailCtrl',
                resolve: {
                    tagData :  function (){
                        return {selectedArr:$scope.booksListData.bookArr};
                    }
                }
            });
            modalInstance.result.then(function () {
                $scope.getBooks();
                $scope.booksListData = {bookArr:[],allchecked:false};
            }, function () {
              console.log('error');
            });
        }; 
        $scope.deleteAllTagConfirmationModal = function(){
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData :  function (){
                        return {ModalTitle:"Confirmation",msg:"Are You Sure You Want To Delete?"};
                    }
                }
            });
            modalInstance.result.then(function () {
                $scope.selectedBookList = [];
                $scope.state            = false;   
                $('.deleteAllTag').trigger('click');
            }, function () {
              console.log('error');
            });
        };

        $scope.addAllBook    = function(){
            var allBookData= {  
                            access_token    : TokenData.access_token,
                            language        : $rootScope.language
                            };
            catalogService.getAllBook(allBookData)
                .then(function(data){
                    if (data.error <= 0) {
                        $scope.selectedBookList = data.response;
                        $scope.state = true;  
                    } else {
                        $scope.isError  = true;
                        $scope.isMessage= false;
                        $scope.message  = data.errorMsg;
                    }
                },function(err, status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
            });
        };

        $scope.addSelectedBook = function(){
            if($scope.booksListData.bookArr.length>0){
                angular.forEach($scope.booksListData.bookArr, function(element) {
                    var idCheck = _.find($scope.selectedBookList, function(value){ 
                        return value.id == element.id; 
                    });
                    if(idCheck===undefined){
                        $scope.selectedBookList.push(element);    
                    }
                });
                $scope.state            = true;    
                $scope.booksListData   = {bookArr:[],allchecked:false};
            }
        };


        $scope.editTagModal     = function(book,tagData){
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/publisherBookTag.html',
                controller: 'bookTagCtrl',
                resolve: {
                    bookData :  function (){
                        return {bookid:book.id,tagData:tagData,tagList:$scope.searchAllTag};
                    }
                }
            });
            modalInstance.result.then(function (dataObj) {
                if (dataObj.data.error <= 0) {
                    $scope.isError  = false;
                    $scope.isMessage= true;
                    $scope.message  = dataObj.data.msg;
                } else {
                    $scope.isError  = true;
                    $scope.isMessage= false;
                    $scope.message  = dataObj.data.errorMsg;
                }
                $scope.getBooks();
            }, function () {
              console.log('error');
            });
        };

        $scope.bookgroupModal    = function(){
            if($scope.selectedBookList.length>0){
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/views/publisherBookGroup.html',
                    controller: 'bookGroupCtrl',
                    resolve: {
                        bookData : function(){
                            return {bookArr:$scope.selectedBookList};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    if (dataObj.data.error <= 0) {
                        var groupInstance = $uibModal.open({
                            animation: true,
                            templateUrl: 'app/views/publisherbookGroupChannel.html',
                            controller: 'bookGroupChannelCtrl',
                            resolve: {
                                groupChannelData : function(){
                                    return {bookGroup:dataObj.bookGroup,groupId:dataObj.data.group_id};
                                }
                            }
                        });

                        groupInstance.result.then(function (dataObj) {
                            $scope.selectedBookList =[];
                            $scope.state    = false;
                            if(dataObj.isRedirect){
                                var gid = parseInt(dataObj.group_id);
                                window.location = 'createchannel?group_id='+gid;
                            }
                        }, function () {
                          console.log('error');
                        });

                    } else {
                        $scope.isError  = true;
                        $scope.isMessage= false;
                        $scope.message  = dataObj.data.errorMsg;
                    }
                }, function () {
                  console.log('error');
                });
            }
            else{
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/views/deleteConfirmationTemplate.html',
                    controller: 'deleteConfirmationCtrl',
                    resolve: {
                        deleteData :  function (){
                            return {ModalTitle:"Warning",msg:"Please select at least one record."};
                        }
                    }
                });
                modalInstance.result.then(function () {
                    
                }, function () {
                  console.log('error');
                });
            }
        };


        $scope.getAllTagData();
        /* Tag Popup Update Book */
        $rootScope.$on('updateBookList', function(event, data) { 
            $scope.getBooks();
        });
        /* End Tag Popup Update Book */
}]);

App.controller('viewBookDetailCtrl', ['$scope','$rootScope','catalogService','$uibModalInstance','localStorageService','bookData',
    function ($scope,$rootScope,catalogService,$uibModalInstance,localStorageService,bookData) {
        var TokenData           = localStorageService.get('authorizeTokenDetail');
        var bookData       ={access_token   : TokenData.access_token,
                            language        : $rootScope.language,
                            catalog_id      : bookData.bookId};
        catalogService.getBooksDetail(bookData)
            .then(function(data){
                if (data.error <= 0) {
                    $scope.bookDetailData       = data.response;
                    if(data.response.catalog.contributor_role.length>0){
                        var str = '';
                        _.each(data.response.catalog.contributor_role, function(contributorArr) {
                            var arr = contributorArr.split('-');
                            str += ((arr[1]!==undefined)?arr[1]+'-'+ arr[2] :'')+' , ';
                        })
                        $scope.bookDetailData.catalog.contributor_role = str.slice(0, -2);
                    };

                    if(data.response.catalog.subject.length>0){
                        var str = '';
                        _.each(data.response.catalog.subject, function(subArr) {
                            var arr = subArr.split('=');
                            str += ((arr[1]!==undefined)?arr[1]:'')+' , ';
                        })
                        $scope.bookDetailData.catalog.subject = str.slice(0, -2);
                    };
                    
                    if(data.response.catalog.identifier.length>0){
                        var str = '';
                        _.each(data.response.catalog.identifier, function(identifierArr) {
                            var arr = identifierArr.split('=');
                            str += ((arr[1]!==undefined)?arr[1]+ '('+arr[2]+')' :'')+' , ';
                        })
                        $scope.bookDetailData.catalog.identifier = str.slice(0, -2);;
                    };
                    if(data.response.catalog.country_id.length>0){
                        var str = '';
                        _.each(data.response.catalog.country_id, function(countryArr) {
                            var arr = countryArr.split('=');
                            str += ((arr[1]!==undefined)?arr[1] :'')+' , ';
                        })
                        $scope.bookDetailData.catalog.country_id = str.slice(0, -2);
                    }
                    else{
                        $scope.bookDetailData.catalog.country_id = '';
                    }
                    
                    if(data.response.catalog.price.length>0){
                        var str = '';
                        _.each(data.response.catalog.price, function(priceArr) {
                            var arr = priceArr.split('-');
                            str += ((arr[1]!==undefined)?arr[2]+' '+arr[1] :'')+' , ';
                        })
                        $scope.bookDetailData.catalog.price = str.slice(0, -2);
                    };
                     $scope.bookDetailData.catalog.region_name = data.response.catalog.region_name.toString();
                } else {
                    $scope.$parent.isError  = true;
                    $scope.$parent.isMessage= false;
                    $scope.$parent.message  = data.errorMsg;
                }
            },function(err, status){
                $scope.$parent.message      = err.errorMsg;
                $scope.$parent.isError      = true;
                $scope.$parent.isMessage    = false;
        });
        
        $scope.editBook         = function(){
            $uibModalInstance.close({id:$scope.bookDetailData.catalog.id});
            window.location = 'editbook?id='+$scope.bookDetailData.catalog.id;
        }
        
        $scope.cancel = function () {
            //$modalInstance.dismiss('cancel');
            $uibModalInstance.dismiss('cancel');
        };
}]);

App.controller('TagDetailCtrl', ['$scope','$rootScope','catalogService','$uibModal','$uibModalInstance','localStorageService','tagData',
    function ($scope,$rootScope,catalogService,$uibModal,$uibModalInstance,localStorageService,tagData) {
        var TokenData           = localStorageService.get('authorizeTokenDetail');
        $scope.form         = {};
        $scope.tagarr       = {};
        $scope.tagRows      = {};
        $scope.editTagData  = {};
        $scope.ModalTitle   = 'Tags';
        $scope.tagGridData  = tagData;
        $scope.tagChecked   = [];
        /*Delete Selected Tag*/

        $scope.deleteTagModal = function(id){
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/publisherDeleteTag.html',
                controller: 'TagDeleteCtrl',
                resolve: {
                    tagData :  function (){
                        return {tagid:id};
                    }
                }
            });
            modalInstance.result.then(function (tagObj) {
                $scope.deleteTag(tagObj.tagid);
            }, function () {
              console.log('error');
            });
           
        };
        $scope.deleteTag    = function(id){
            var deleteTagData= {  
                                access_token    : TokenData.access_token,
                                language        : $rootScope.language,
                                tag_id          : id
                                };
        
            catalogService.deleteTag(deleteTagData)
                .then(function(data){
                    if (data.error <= 0) {
                        $scope.tagsList         = data.response;
                        $scope.isError  = false;
                        $scope.isMessage= true;
                        $scope.message  = data.msg;
                        $scope.$emit('updateBookList', {});
                    } else {
                        $scope.isError  = true;
                        $scope.isMessage= false;
                        $scope.message  = data.errorMsg;
                    }
                },function(err, status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
            });
        };

        $scope.cancel       = function () {
            $uibModalInstance.dismiss('cancel');
        };
        /*get All Tag*/
        $scope.getTagData   = function(){
            var tagData         = {  
                                access_token   : TokenData.access_token,
                                language        : $rootScope.language
                            };
            catalogService.getTagList(tagData)
                .then(function(data){
                    if (data.error <= 0) {
                        $scope.tagsList         = data.response;
                    } else {
                        $scope.$parent.isError  = true;
                        $scope.$parent.isMessage= false;
                        $scope.$parent.message  = data.errorMsg;
                    }
                },function(err, status){
                    $scope.$parent.message      = err.errorMsg;
                    $scope.$parent.isError      = true;
                    $scope.$parent.isMessage    = false;
            });
        };
        /*add tag in selected list*/
        $scope.addTagDetail = function(){
            if($scope.form.addtag.$valid && $scope.tagarr.tagname.trim()){
                var addTagData= {  
                                access_token    : TokenData.access_token,
                                language        : $rootScope.language,
                                tag_name        : $scope.tagarr.tagname.trim()
                                };
        
                catalogService.addTag(addTagData)
                    .then(function(data){
                        if (data.error <= 0) {
                            $scope.tagarr   = {tagname : ''};
                            $scope.tagsList = data.response;
                            $scope.isError  = false;
                            $scope.isMessage= true;
                            $scope.message  = data.msg;
                        } else {
                            $scope.isError  = true;
                            $scope.isMessage= false;
                            $scope.message  = data.errorMsg;
                        }
                    },function(err, status){
                        $scope.message      = err.errorMsg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;
                }); 
            }
        };
        
       /* Popup edit tag*/
        $scope.editTagDetail= function(tagData){
            $scope.editTagData  = {tagname:tagData.name,tagid:tagData.id};
            $scope.tagRows['editing'+tagData.id] = true;
        };

        $scope.updateTag    = function(oldTagName){
            var tagname = $scope.editTagData.tagname.trim();
            if(tagname!==undefined && tagname!==null && tagname!==''){
                var tagId   = $scope.editTagData.tagid.trim();
                if(oldTagName!==tagname){
                    var updateTagData= {  
                                    access_token    : TokenData.access_token,
                                    language        : $rootScope.language,
                                    tag_name        : tagname,
                                    original_tag_name        : oldTagName,
                                    tag_id          : tagId
                                    };
                    catalogService.updateTag(updateTagData)
                        .then(function(data){
                            if (data.error <= 0) {
                                $scope.editTagData              = {tagname:'',tagid:''};
                                $scope.tagRows['editing'+tagId] = false;
                                $scope.tagsList                 = data.response;
                                $scope['isError'+tagId]         = false;
                                $scope['isMessage'+tagId]       = true;
                                $scope['message'+tagId]         = data.msg;
                                $scope.$emit('updateBookList', {});
                            } else {
                                $scope['isError'+tagId]         = true;
                                $scope['isMessage'+tagId]       = false;
                                $scope['message'+tagId]         = data.errorMsg;
                            }
                        },function(err, status){
                            $scope['isError'+tagId]         = true;
                            $scope['isMessage'+tagId]       = false;
                            $scope['message'+tagId]         = data.errorMsg;
                    }); 
                }
                else{
                    $scope.tagRows['editing'+tagId] = false;
                }  
            }
        };
        /*End Popup edit tag*/

        $scope.TagAll           = function(){
            if($scope.tagChecked.id!==undefined && $scope.tagChecked.id.length>0){
                var BookTagData = {  
                                    access_token    : TokenData.access_token,
                                    language        : $rootScope.language,
                                    bookListArr     : [],
                                    tagListArr      :  $scope.tagChecked.id
                                    };
                catalogService.addBookTag(BookTagData)
                    .then(function(data){
                        if (data.error <= 0) {
                            $scope.tagChecked = [];
                            $scope.tagGridData = {};
                            $scope.isError  = false;
                            $scope.isMessage= true;
                            $scope.message  = data.msg;
                            $uibModalInstance.close({});
                            //$scope.$emit('updateBookList', {});
                        } else {
                            $scope.isError  = true;
                            $scope.isMessage= false;
                            $scope.message  = data.errorMsg;
                        }
                    },function(err, status){
                        $scope.message      = err.errorMsg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;
                }); 
            }
        };

        $scope.TagSelected       = function(){
            if($scope.tagChecked.id.length>0){
                var BookTagData = {  
                                    access_token    : TokenData.access_token,
                                    language        : $rootScope.language,
                                    bookListArr     : $scope.tagGridData.selectedArr,
                                    tagListArr      :  $scope.tagChecked.id
                                    };
                catalogService.addBookTag(BookTagData)
                    .then(function(data){
                        if (data.error <= 0) {
                            $scope.tagChecked = [];
                            $scope.tagGridData = {};
                            $scope.isError  = false;
                            $scope.isMessage= true;
                            $scope.message  = data.msg;
                            $uibModalInstance.close({});
                            //$scope.$emit('updateBookList', {});
                        } else {
                            $scope.isError  = true;
                            $scope.isMessage= false;
                            $scope.message  = data.errorMsg;
                        }
                    },function(err, status){
                        $scope.message      = err.errorMsg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;
                }); 
            }
        };

        $scope.checkErr     = function(tagId){
            return $scope['isError'+tagId];
        };
        $scope.getmessage     = function(tagId){
            return $scope['message'+tagId];
        };

        $scope.getTagData();  
}]);

App.controller('TagDeleteCtrl', ['$scope','$uibModalInstance','tagData',
    function ($scope,$uibModalInstance,tagData) {
        $scope.tagData            = tagData;
        $scope.deleteTagDetail    = function(id){
            $uibModalInstance.close({tagid:id});
        }
        $scope.cancel       = function () {
            $uibModalInstance.dismiss('cancel');
        };
}]);

App.controller('bookTagCtrl', ['$scope','$rootScope','$uibModalInstance','bookData','localStorageService','catalogService',
    function ($scope,$rootScope,$uibModalInstance,bookData,localStorageService,catalogService) {
        var TokenData       = localStorageService.get('authorizeTokenDetail');
        $scope.bookTag      = {};
        $scope.bookTag.tags = (bookData.tagData!==null)?bookData.tagData.split(','):[];
        $scope.allTag       = bookData.tagList;
        $scope.tags         = [];
        $scope.deleteTag    = [];
        $scope.ModalTitle   = 'Tag';

        $scope.addBookTags  = function(){
            var BookTagData={  
                            access_token    : TokenData.access_token,
                            language        : $rootScope.language,
                            tagArr          : $scope.bookTag.tags,
                            book_id         : bookData.bookid,
                            deleteTag       : $scope.deleteTag
                            };
            catalogService.addBookRowTag(BookTagData)
                .then(function(data){
                    $uibModalInstance.close({data:data});
                },function(err, status){
                    $uibModalInstance.dismiss('cancel');
                    $scope.$parent.message      = err.errorMsg;
                    $scope.$parent.isError      = true;
                    $scope.$parent.isMessage    = false;
            }); 
        };
        $scope.cancel       = function () {
            $uibModalInstance.dismiss('cancel');
        };
}]);

App.controller('bookGroupCtrl', ['$scope','$rootScope','$uibModalInstance','localStorageService','groupService','bookData',
    function ($scope,$rootScope,$uibModalInstance,localStorageService,groupService,bookData) {
        $scope.bookGroup        = {groupOptions:1,group_id:'',group_name:''};
        $scope.grpmessage       = {groupname:false,groupnamemsg:'',groupid:false,groupidmsg:''};
        $scope.groupList        = [];
   
        $scope.getGroupList     = function(){
            var TokenData       = localStorageService.get('authorizeTokenDetail');
            var BookGroupData={  
                            access_token    : TokenData.access_token,
                            language        : $rootScope.language
                            };
            groupService.getGroupData(BookGroupData)
                .then(function(data){
                    if (data.error <= 0) {
                        $scope.groupList         = data.response;
                    } else {
                        $scope.isError  = true;
                        $scope.isMessage= false;
                        $scope.message  = data.errorMsg;
                    }
                },function(err, status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
            });
        };    

        $scope.addBookGroup     = function(){
            var TokenData       = localStorageService.get('authorizeTokenDetail');
            var istrue          = true;
            var bookarray       = [];
            angular.forEach(bookData.bookArr,function(value,key){
                bookarray.push(value.id);
            });
            var bookGroupData={  
                            access_token    : TokenData.access_token,
                            language        : $rootScope.language,
                            groupOptions    : $scope.bookGroup.groupOptions,
                            group_id        : $scope.bookGroup.group_id.id,
                            group_name      : $scope.bookGroup.group_name,
                            bookArr         : bookarray
                            };
            if($scope.bookGroup.groupOptions===1 && $scope.bookGroup.group_name ==''){
                istrue          = false;
                $scope.grpmessage       = {groupname:true,groupnamemsg:'Enter Group Name.',groupid:false,groupidmsg:''};
            }
            if($scope.bookGroup.groupOptions===2 && $scope.bookGroup.group_id ==''){
                istrue          = false;   
                $scope.grpmessage       = {groupname:true,groupnamemsg:'',groupid:false,groupidmsg:'Enter Group Id.'};
            }
            if(istrue){
                groupService.createGroup(bookGroupData)
                    .then(function(data){
                        if(data.error<=0){
                            $uibModalInstance.close({data:data,bookGroup:$scope.bookGroup});
                        }
                        else{
                            $scope.grpmessage       = {groupname:true,groupnamemsg:data.errorMsg,groupid:false,groupidmsg:''};
                        }
                    },function(err, status){
                        $scope.$parent.message      = err.errorMsg;
                        $scope.$parent.isError      = true;
                        $scope.$parent.isMessage    = false;
                });    
            }
        };
        $scope.cancel           = function () {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.getGroupList();
}]);

App.controller('bookGroupChannelCtrl', ['$scope','$rootScope','userRightsService','$uibModalInstance','groupChannelData','localStorageService',
    function ($scope,$rootScope,userRightsService,$uibModalInstance,groupChannelData,localStorageService) {
        var TokenData       = localStorageService.get('authorizeTokenDetail');
        $scope.groupData    = groupChannelData.bookGroup;
        $scope.groupId      = groupChannelData.groupId;
        $scope.title    = ($scope.groupData.groupOptions==1)?$scope.groupData.group_name:$scope.groupData.group_id.name;

        $scope.checkBtnRights = function(moduleId){
            return userRightsService.checkUserRights(moduleId);
        }

        $scope.groupDone  = function(isRedirect){
            $uibModalInstance.close({isRedirect:isRedirect,group_id:$scope.groupId});
        };

        $scope.cancel       = function () {
            $uibModalInstance.dismiss('cancel');
        };
}]);
