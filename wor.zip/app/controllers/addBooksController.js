'use strict';
App.controller('addBooksController', ['$scope', '$rootScope','$timeout', 'bookService', '$uibModal', '$location', '$sessionStorage', 'localStorageService','DATE_FORMAT','ivhTreeviewMgr',
    function ($scope, $rootScope,$timeout, bookService, $uibModal, $location, $sessionStorage, localStorageService,DATE_FORMAT,ivhTreeviewMgr) {
        var TokenData                   = localStorageService.get('authorizeTokenDetail');
        var parameter                   = $location.search();
        $scope.format                   = DATE_FORMAT;
        $scope.relatedproduct           = {identifiererror:false,identifiermessage:''};
        $scope.awardNameError           = '';
        $scope.dateOptions = {            
            showWeeks: false,
        };
        if(parameter.id!==undefined){
            var bookData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    catalog_id  : parameter.id
            };
            bookService.getBookDetail(bookData)
                .then(function(data){
                    if(data.error<=0){
                        var bookObject  = data.response.catalog;
                        var ageArr      = (bookObject.age_range!==undefined && bookObject.age_range!=='' && bookObject.age_range!==null)?bookObject.age_range.split('-'):[];
                        var gradeArr    = (bookObject.us_grade_range!==undefined && bookObject.us_grade_range!=='' && bookObject.us_grade_range!==null)?bookObject.us_grade_range.split('-'):[]; 
                        $scope.bookDetail = {bookid:parameter.id,title:bookObject.title,sub_title:bookObject.sub_title,
                                            volume:bookObject.volume,edition:bookObject.edition,
                                            contributor:[],identifier:[],priceArr:[],
                                            publisher:bookObject.publisher,imprint:bookObject.imprint,publication_date:new Date(bookObject.publication_date),
                                            language_id:bookObject.language_id,
                                            subject_id : bookObject.subject,
                                            main_subject_id:bookObject.main_subject_id,description:bookObject.description,
                                            keywords:bookObject.keywords,
                                            min_age_range:(ageArr[0]!==undefined)?ageArr[0]:'',max_age_range:(ageArr[1]!==undefined)?ageArr[1]:'',
                                            min_us_grade_range:(gradeArr[0]!==undefined)?gradeArr[0]:'',max_us_grade_range:(gradeArr[1]!==undefined)?gradeArr[1]:'',
                                            region_id:(bookObject.region_id!==undefined)?bookObject.region_id:[],
                                            country_id:(bookObject.country_id!==undefined)?bookObject.country_id:[],
                                            audience_id:bookObject.audience_id,
                                            copyright_year:bookObject.copyright_year,copyright_owner:bookObject.copyright_owner,
                                            supplier_details:bookObject.supplier_details,supply_date:(bookObject.supply_date!=='')?new Date(bookObject.supply_date):'',
                                            title_availability:(bookObject.title_availability!==undefined && bookObject.title_availability!=='')?new Date(bookObject.title_availability):'',
                                            cover_image:bookObject.cover_image,original_image:bookObject.original_image};
                        if(bookObject.contributor_role.length>0){
                            _.each(bookObject.contributor_role, function(contributorArr) {
                                var arr = contributorArr.split('-');
                                $scope.bookDetail.contributor.push({contributorrole:(arr[0]!==undefined)?arr[0]:'',
                                                                    contributorname:(arr[1]!==undefined)?arr[1]:''});
                            })
                        };

                        if(bookObject.identifier.length>0){
                            _.each(bookObject.identifier, function(identifierArr) {
                                var arr = identifierArr.split('=');
                                $scope.bookDetail.identifier.push({identifiertype:(arr[0]!==undefined)?arr[0]:'',
                                                                   identifiername:(arr[1]!==undefined)?arr[1]:'',
                                                                   identifiermessage:'',
                                                                    error : false});
                            });
                        };
                        if(bookObject.price.length>0){
                            _.each(bookObject.price, function(priceval) {
                                var arr = priceval.split('-');
                                $scope.bookDetail.priceArr.push({currency_id:(arr[0]!==undefined)?arr[0]:'',
                                                                 price:(arr[1]!==undefined)?parseFloat(arr[1]):''});
                            })
                        };
                        $scope.bookReviewList           = [];
                        $scope.bookAwardList            = [];
                        $scope.bookRelatedProductsList  = [];
                        if(data.response.catalog_reviews.length>0){
                            _.each(data.response.catalog_reviews, function(reviewsArr) {
                                $scope.bookReviewList.push({reviewtype:{name:reviewsArr.reviewtype_name,id:reviewsArr.reviewtype_id},
                                                           reviewsource:{name:reviewsArr.reviewsource_name,id:reviewsArr.reviewsource_id},
                                                           reviewtitle:reviewsArr.title,
                                                           reviewtext:reviewsArr.review,
                                                           reviewurl:reviewsArr.url,
                                                           reviewdate:new Date(reviewsArr.created_on),
                                                           reviewrole:{name:reviewsArr.reviewrole_name,id:reviewsArr.reviewrole_id}});
                            })
                        }
                        if(data.response.catalog_awards.length>0){
                            _.each(data.response.catalog_awards, function(awardsArr) {
                                $scope.bookAwardList.push({awardcountry:{name:awardsArr.awardcountry_name,id:awardsArr.awardcountry_id},
                                                           awardcode:{name:awardsArr.awardcode_name,id:awardsArr.awardcode_id},
                                                           awardname:awardsArr.award_name,
                                                           awardyear:awardsArr.year});
                            })
                        }
                        if(data.response.catalog_related_products.length>0){
                            _.each(data.response.catalog_related_products, function(productArr) {
                                $scope.bookRelatedProductsList.push({relatedcode:{name:productArr.relatedcode_name,id:productArr.relatedcode_id},
                                                           identifiertype:{name:productArr.identifiertype_name,id:productArr.identifiertype_id},
                                                           identifiername:productArr.identifier_no});
                            })
                        }
                    }
                    else{
                        $scope.message      = err.errorMsg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;    
                    }
                    $scope.getSubjectList();
                    $scope.getRegionList();
                    $scope.getAllCountry();
                    $scope.getCompanyDetail();
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        }
        else{
            $scope.bookDetail               = {bookid:'',title:'',sub_title:'',volume:'',edition:'',
            contributor:[{contributorrole:'',contributorname:''}],
            identifier:[{identifiertype:'',identifiername:'',identifiermessage:'',error : false}],publisher:'',imprint:'',publication_date:'',
            priceArr:[{currency_id:'',price:''}],language_id:'',subject_id:[],main_subject_id:'',
            description:'',keywords:'',min_age_range:'',max_age_range:'',min_us_grade_range:'',
            max_us_grade_range:'',region_id:[],country_id:[],
            audience_id:'1',
            copyright_year:'',copyright_owner:'',supplier_details:'',supply_date: '',
            title_availability:'',original_image:'',cover_image:'assets/images/profilepicture.jpg'};
            $scope.bookReviewList           = [];
            $scope.bookAwardList            = [];
            $scope.bookRelatedProductsList  = [];
        }
        
        $scope.bookReviewDetail         = {reviewtype:{id:'',name:''},reviewsource:{id:'',name:''},
                                            reviewtitle:'',reviewtext:'',reviewurl:'',reviewdate:'',
                                            reviewrole:{id:'',name:''}};
        $scope.bookAwardDetail          = {awardname:'',awardyear:'',
                                            awardcountry:{id:'',name:''},awardcode:{id:'',name:''}};
        $scope.bookRelatedProductDetail = {relatedcode:{id:'',name:''},identifiertype:{id:'',name:''}
                                            ,identifiername:''};                                            
        $scope.bookReviewEdit           = false;
        $scope.bookAwardEdit            = false;
        $scope.bookRelatedProductEdit   = false;
        $scope.productDuplicate         = false;
        $scope.countryRegionArr         = [];
        $scope.editBookReviewObject     = {};
        $scope.editBookAwardObject      = {};
        $scope.companyDetail            = {};
        $scope.editBookRelatedProductObject = {};
        $scope.contributorNameList      = [];
        $scope.identifierNameList       = [];
        $scope.bookAward                = {};
        $scope.AwardList                = [];
        $scope.bookRelatedProducts      = {};
        $scope.contributorList          = [];
        $scope.identifierList           = [];
        $scope.currencyList             = [];
        $scope.languageList             = [];
        $scope.subjectList              = [];
        $scope.regionList               = [];
        $scope.countryList              = [];
        $scope.audienceList             = [];
        $scope.ageRange                 = [];    
        $scope.gradeRange               = ['1','2','3','4','5','6','7','8','9','10','11','12'];
        $scope.yearList                 = ['2016','2017','2018','2019'];
        $scope.reviewTypeList           = [];
        $scope.reviewSourceList         = [];
        $scope.reviewRoleList           = [];
        $scope.awardCountryList         = [];
        $scope.awardCodeList            = [];
        $scope.RelatedCodeList          = [];
        $scope.message                  = '';
        $scope.isError                  = false;
        $scope.isMessage                = false;
        $scope.bookReviewFormSubmit     = false;
        $scope.isSubmitted              = false;
        $scope.bookAwardFormSubmit      = false;
        $scope.bookProductFormSubmit    = false;
        $scope.bookRelatedProductFormSubmit = false;
        $scope.validage     = false;

        for(var i=1;i<=100;i++){
            $scope.ageRange.push(i);
        }
      
        $scope.bookView                 = function(){
            $location.search({});
            $location.path('/maintainbooks');
        }
        $scope.addContributor           = function(){
            $scope.bookDetail.contributor.push({contributorrole:'',contributorname:''});
        };
        $scope.removeContributor        = function(contributorDetail){
            $scope.bookDetail.contributor.splice($scope.bookDetail.contributor.indexOf(contributorDetail),1);
        };
        $scope.getContributorsRole      = function(){
            var contributorData = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getContributorsRoleList(contributorData)
                .then(function(data){
                    $scope.contributorList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });   
        };
        $scope.getContributorsName      = function(){
            var contributorData = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getContributorsNameList(contributorData)
                .then(function(data){
                    $scope.contributorNameList  =   _.pluck(data.response,'name');
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });   
        };
        $scope.addIdentifier            = function(){
            $scope.bookDetail.identifier.push({identifiertype:'',identifiername:''});  
        };
        $scope.removeIdentifier         = function(identifierDetail){
            $scope.bookDetail.identifier.splice($scope.bookDetail.identifier.indexOf(identifierDetail),1);
        };
        $scope.getIdentifierType        = function(){
            var identifierData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getIdentifierTypeList(identifierData)
                .then(function(data){
                    $scope.identifierList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.identifierNameValid      = function(index){
            var isvalid = false;
            if($scope.bookDetail.identifier[index].identifiername==='' || $scope.bookDetail.identifier[index].identifiername===undefined || $scope.bookDetail.identifier[index].identifiername===null){
                $scope.bookDetail.identifier[index]['error']      = true;
                $scope.bookDetail.identifier[index]['identifiermessage']   = 'Enter Name';    
                return true;
            }
            if($scope.bookDetail.identifier[index].identifiername!=='' && ($scope.bookDetail.identifier[index].identifiertype=="2" || $scope.bookDetail.identifier[index].identifiertype=="9") ){
                isvalid = $scope.isValidIsbn($scope.bookDetail.identifier[index].identifiername,$scope.bookDetail.identifier[index].identifiertype); 
                if(!isvalid){
                    $scope.bookDetail.identifier[index]['error']      = true;
                    $scope.bookDetail.identifier[index]['identifiermessage']   = 'Enter Valid ISBN';    
                    isvalid = true;
                }
                else{
                    $scope.bookDetail.identifier[index]['error']      = false;
                    $scope.bookDetail.identifier[index]['identifiermessage']   = '';  
                    isvalid = false;   
                }
            }

            if($scope.bookDetail.identifier[index].identifiername!=='' && ($scope.bookDetail.identifier[index].identifiertype=="3" || $scope.bookDetail.identifier[index].identifiertype=="8") ){
                isvalid = $scope.validateGtin($scope.bookDetail.identifier[index].identifiername,$scope.bookDetail.identifier[index].identifiertype);
                if(!isvalid){
                    $scope.bookDetail.identifier[index]['error']      = true;
                    $scope.bookDetail.identifier[index]['identifiermessage']   = 'Enter Valid GTIN';    
                    isvalid = true;
                }
                else{
                    $scope.bookDetail.identifier[index]['error']      = false;
                    $scope.bookDetail.identifier[index]['identifiermessage']   = '';  
                    isvalid = false;   
                }
            }
            return isvalid;
        };
        $scope.productidentifierNameValid= function(){
            var isvalid = false;
            if($scope.bookRelatedProductDetail.identifiername==='' || $scope.bookRelatedProductDetail.identifiername===undefined || $scope.bookRelatedProductDetail.identifiername===null){
                $scope.relatedproduct.identifiererror      = true;
                $scope.relatedproduct.identifiermessage  = 'Enter Name';    
                return true;
            }
            if($scope.bookRelatedProductDetail.identifiername!=='' && ($scope.bookRelatedProductDetail.identifiertype.id=="2" || $scope.bookRelatedProductDetail.identifiertype.id=="9") ){
                isvalid = $scope.isValidIsbn($scope.bookRelatedProductDetail.identifiername,$scope.bookRelatedProductDetail.identifiertype.id); 
                if(!isvalid){
                    $scope.relatedproduct.identifiererror       = true;
                    $scope.relatedproduct.identifiermessage     = 'Enter Valid ISBN';    
                    isvalid = true;
                }
                else{
                    $scope.relatedproduct.identifiererror       = false;
                    $scope.relatedproduct.identifiermessage     = '';  
                    isvalid = false;   
                }
            }
            if($scope.bookRelatedProductDetail.identifiername!=='' && ($scope.bookRelatedProductDetail.identifiertype.id=="3" || $scope.bookRelatedProductDetail.identifiertype.id=="8") ){
                isvalid = $scope.validateGtin($scope.bookRelatedProductDetail.identifiername,$scope.bookRelatedProductDetail.identifiertype.id);
                if(!isvalid){
                    $scope.relatedproduct.identifiererror     = true;
                    $scope.relatedproduct.identifiermessage   = 'Enter Valid GTIN';    
                    isvalid = true;
                }
                else{
                    $scope.relatedproduct.identifiererror     = false;
                    $scope.relatedproduct.identifiermessage   = '';  
                    isvalid = false;   
                }
            }
            return isvalid;
        };

        $scope.isValidIsbn = function(str,type) {
            var sum,
                weight,
                digit,
                check,
                i;
            str = str.replace(/[^0-9X]/gi, '');
            if (str.length != 10 && str.length != 13) {
                return false;
            }
            else if (str.length == 13 && type==9) {
                sum = 0;
                for (i = 0; i < 12; i++) {
                    digit = parseInt(str[i]);
                    if (i % 2 == 1) {
                        sum += 3*digit;
                    } else {
                        sum += digit;
                    }
                }
                check = (10 - (sum % 10)) % 10;
                return (check == str[str.length-1]);
            }

            else if (str.length == 10 && type==2) {
                weight = 10;
                sum = 0;
                for (i = 0; i < 9; i++) {
                    digit = parseInt(str[i]);
                    sum += weight*digit;
                    weight--;
                }
                check = 11 - (sum % 11);
                if (check == 10) {
                    check = 'X';
                }
                return (check == str[str.length-1].toUpperCase());
            }
            else{
                return false;
            }
        };

        $scope.validateGtin = function( value,type ) {
            var barcode = value.substring( 0, value.length - 1 );
            var checksum = parseInt( value.substring( value.length - 1 ), 10 );
            var calcSum = 0;
            var calcChecksum = 0;
            barcode.split('').map(function( number, index ) {
              number = parseInt( number, 10 );
              if ( value.length % 2 === 0 ) {
                index += 1;
              }
              if ( index % 2 === 0 ) {
                calcSum += number;
              }
              else {
                calcSum += number * 3;
              }
            });
            calcSum %= 10;
            calcChecksum = (calcSum === 0) ? 0 : (10 - calcSum);
            if ( calcChecksum !== checksum ) {
              return false;
            }
            return true;
        };

        $scope.addPrice                 = function(){
            $scope.bookDetail.priceArr.push({currency_id:'',price:''});     
        };
        $scope.removePrice              = function(priceDetail){
            $scope.bookDetail.priceArr.splice($scope.bookDetail.priceArr.indexOf(priceDetail),1);
        };

        $scope.getCountryRegionArr      = function(){
            var Data  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getCountryRegionList(Data)
                .then(function(data){
                    angular.forEach(data.response, function(element) {
                      $scope.countryRegionArr.push(element);
                    });
                    $timeout(function(){
                        if($scope.bookDetail.country_id.length>0){
                            ivhTreeviewMgr.selectEach($scope.countryRegionArr,$scope.bookDetail.country_id);
                        }
                        if($scope.bookDetail.region_id.length===1 && $scope.bookDetail.region_id[0]==1){
                            ivhTreeviewMgr.selectAll($scope.countryRegionArr);
                            ivhTreeviewMgr.deselect($scope.countryRegionArr,$scope.countryRegionArr[0]);
                        }
                    },100);
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });  
        };

        $scope.countryMade              = function(Node, IsSelected,Tree){
            if(Node.label==='World' && Node.children===undefined && IsSelected){
                ivhTreeviewMgr.deselectAll($scope.countryRegionArr);
                $timeout(function(){
                    ivhTreeviewMgr.select($scope.countryRegionArr,$scope.countryRegionArr[0]);   
                },100);
            }
            if(Node.label!=='World' && IsSelected){
                ivhTreeviewMgr.deselect($scope.countryRegionArr,$scope.countryRegionArr[0]);   
            }
        };

        $scope.getCurrencyList          = function(){
            var currencyData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getCurrencyList(currencyData)
                .then(function(data){
                    $scope.currencyList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getCompanyDetail         = function(){
            var companyData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getCompanyDetail(companyData)
                .then(function(data){
                    $scope.bookDetail.publisher  = data.response.name;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getLanguageList          = function(){
            var languageData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getLanguageList(languageData)
                .then(function(data){
                    $scope.languageList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getSubjectList           = function(){
            var subjectData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getSubjectList(subjectData)
                .then(function(data){
                    $scope.subjectList  = data.response;
                    if($scope.bookDetail.subject_id.length>0){
                        $scope.updateSubjectList(function(){
                            $timeout(function(){
                                $('#subject_id').select2();    
                            },0)
                        });
                    }
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.updateSubjectList        = function(callback){
            var subjectArr = [];
            _.each($scope.bookDetail.subject_id, function(subArr) {
                var arr = subArr.split('=');
                var selected = _.where($scope.subjectList,{id:(arr[0]!==undefined)?arr[0]:'',
                                                            name:(arr[1]!==undefined)?arr[1]:''});  
                subjectArr.push(selected[0]);
            })
            $scope.bookDetail.subject_id = subjectArr;
            callback();
        };
        $scope.getRegionList            = function(){
            var regionData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getRegionList(regionData)
                .then(function(data){
                    $scope.regionList  = data.response;
                    if($scope.bookDetail.region_id.length>0){
                        $timeout(function(){
                            $scope.updateCountry();
                            $('#region_id').select2();    
                        },0);
                    }
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getAudienceList          = function(){
            var audienceData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getAudienceList(audienceData)
                .then(function(data){
                    $scope.audienceList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.updateCountry            = function(){
            var countryData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    region_array: $scope.bookDetail.region_id
            };
            bookService.getCountryList(countryData)
                .then(function(data){
                    $scope.countryList  = data.response;
                    $timeout(function(){
                        $('#country_id').select2();    
                    },0);
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getAllCountry            = function(){
            var countryData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    region_array: [1]
            };
            bookService.getCountryList(countryData)
                .then(function(data){
                    $scope.awardCountryList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getReviewTypeList        = function(){
            var reviewData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getReviewTypeList(reviewData)
                .then(function(data){
                    $scope.reviewTypeList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getReviewSourceList      = function(){
            var reviewData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getReviewSourceList(reviewData)
                .then(function(data){
                    $scope.reviewSourceList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.getReviewRoleList        = function(){
            var reviewData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getReviewRoleList(reviewData)
                .then(function(data){
                    $scope.reviewRoleList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }); 
        };
        $scope.getAwardList             = function(){
            var awardData  = {
                        access_token: TokenData.access_token,
                        language        : $rootScope.language
                };
            bookService.getAwardList(awardData)
            .then(function(data){
                $scope.AwardList   = _.pluck(data.response,'name');
            },
            function(err,status){
                $scope.message      = err.errorMsg;
                $scope.isError      = true;
                $scope.isMessage    = false;
            }); 
        };
        $scope.getAwardCodeList         = function(){
            var reviewData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getAwardCodeList(reviewData)
                .then(function(data){
                    $scope.awardCodeList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }); 
        };
        $scope.getRelatedCodeList       = function(){
            var reviewData  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            bookService.getRelatedCode(reviewData)
                .then(function(data){
                    $scope.RelatedCodeList  = data.response;
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }); 
        };
        $scope.addBookReview            = function(){
            if($scope.addbookreviewform.$valid){
                $scope.bookReviewList.push($scope.bookReviewDetail);
                $scope.bookReviewDetail = {reviewtype:{id:'',name:''},reviewsource:{id:'',name:''},
                                            reviewtitle:'',reviewtext:'',reviewurl:'',reviewdate:'',
                                            reviewrole:{id:'',name:''}};
                $scope.bookReviewFormSubmit     = false;
            }
            else{
                $scope.bookReviewFormSubmit     = true;
            }
        };
        $scope.deleteBookReview         = function(bookReview){
            $scope.bookReviewList.splice($scope.bookReviewList.indexOf(bookReview),1);
        };
        $scope.editBookReview           = function(bookReview){
            var reviewsourceval = _.where($scope.reviewSourceList, {id: bookReview.reviewsource.id, name: bookReview.reviewsource.name});
            var reviewtypeval   = _.where($scope.reviewTypeList, {id: bookReview.reviewtype.id, name: bookReview.reviewtype.name});
            var reviewroleval = _.where($scope.reviewRoleList, {id: bookReview.reviewrole.id, name: bookReview.reviewrole.name});
            $scope.bookReviewEdit       = true;
            $scope.editBookReviewObject       = bookReview;
            $scope.bookReviewDetail = {reviewtype:(reviewtypeval[0]!==undefined)?reviewtypeval[0]:{},
                                        reviewsource:(reviewsourceval[0]!==undefined)?reviewsourceval[0]:{},
                                        reviewtitle:bookReview.reviewtitle,reviewtext:bookReview.reviewtext,
                                        reviewurl:bookReview.reviewurl,reviewdate:bookReview.reviewdate,
                                        reviewrole:(reviewroleval[0]!==undefined)?reviewroleval[0]:{}};
        };
        $scope.updateBookReview         = function(){
            if($scope.addbookreviewform.$valid){
                $scope.bookReviewList.splice($scope.bookReviewList.indexOf($scope.editBookReviewObject),1);
                $scope.bookReviewList.push($scope.bookReviewDetail);
                $scope.bookReviewDetail     = {reviewtype:{id:'',name:''},reviewsource:{id:'',name:''},
                                                reviewtitle:'',reviewtext:'',reviewurl:'',reviewdate:'',
                                                reviewrole:{id:'',name:''}};
                $scope.bookReviewEdit       = false;
                $scope.editBookReviewObject = {};
            }
            else{
                $scope.bookReviewFormSubmit     = true;
            }
        };
        $scope.addBookAward             = function(){
            var checkAwardName          = _.where($scope.bookAwardList,{awardname:$scope.bookAwardDetail.awardname});
            if(checkAwardName.length<=0){
                if($scope.addbookawardform.$valid && $scope.bookAwardDetail.awardcountry.id!='' && $scope.bookAwardDetail.awardcode.id!=''){
                    $scope.bookAwardList.push($scope.bookAwardDetail);
                    $scope.bookAwardDetail          = {awardname:'',awardyear:'',
                                                        awardcountry:{id:'',name:''},awardcode:{id:'',name:''}};
                    $scope.bookAwardFormSubmit     = false;
                    $scope.addbookawardform.awardcountry.$invalid = false;
                    $scope.addbookawardform.awardcode.$invalid = false;
                }
                else{
                    $scope.bookAwardFormSubmit     = true;
                    $scope.addbookawardform.awardcountry.$invalid = true;
                    $scope.addbookawardform.awardcode.$invalid = true;
                }
            }
            else{
                $scope.bookAwardFormSubmit     = true;
                $scope.awardNameError          = 'Enter Different Award Name';
            }
        };
        $scope.deleteBookAward          = function(bookAward){
            $scope.bookAwardList.splice($scope.bookAwardList.indexOf(bookAward),1);
        };
        $scope.editBookAward            = function(bookAward){
            $scope.awardNameError       = '';
            var awardcountryval = _.where($scope.awardCountryList, {id: bookAward.awardcountry.id, name: bookAward.awardcountry.name});
            var awardcodeval    = _.where($scope.awardCodeList, {id: bookAward.awardcode.id, name: bookAward.awardcode.name});
            $scope.bookAwardEdit        = true;
            $scope.editBookAwardObject  = bookAward;
            $scope.bookAwardDetail      = {awardname:bookAward.awardname,awardyear:bookAward.awardyear,
                                            awardcountry:(awardcountryval[0]!==undefined)?awardcountryval[0]:{},
                                            awardcode:(awardcodeval[0]!==undefined)?awardcodeval[0]:{}};
        };
        $scope.updateBookAward          = function(){
            if($scope.addbookawardform.$valid){
                $scope.bookAwardList.splice($scope.bookAwardList.indexOf($scope.editBookAwardObject),1);
                $scope.bookAwardList.push($scope.bookAwardDetail);
                $scope.bookAwardDetail          = {awardname:'',awardyear:'',
                                                    awardcountry:{id:'',name:''},awardcode:{id:'',name:''}};
                $scope.bookAwardEdit        = false;
                $scope.editBookAwardObject  = {};
            }
            else{
                $scope.bookReviewFormSubmit     = true;
            }
        };
        $scope.addBookRelatedProduct    = function(){
            if($scope.addbookproductform.$valid && !$scope.relatedproduct.identifiererror 
            && $scope.bookRelatedProductDetail.identifiertype.id!=''  && $scope.bookRelatedProductDetail.identifiertype.id!=undefined
            && $scope.bookRelatedProductDetail.relatedcode.id!=''  && $scope.bookRelatedProductDetail.relatedcode.id!=undefined ){

                var isName  = _.where($scope.bookRelatedProductsList,{identifiername:$scope.bookRelatedProductDetail.identifiername});
                if(isName.length<=0){
                    $scope.bookRelatedProductsList.push($scope.bookRelatedProductDetail);
                    $scope.bookRelatedProductDetail = {relatedcode:{id:'',name:''},
                                                        identifiertype:{id:'',name:''},
                                                        identifiername:''};
                    $scope.bookProductFormSubmit    = false;
                    $scope.addbookproductform.identifiertype.$invalid = false;
                    $scope.addbookproductform.relatedcode.$invalid = false;
                    $scope.bookProductFormSubmit    = false;    
                    $scope.productDuplicate         = false;
                }
                else{
                    $scope.productDuplicate         = true;
                }
            }
            else{
                $scope.bookProductFormSubmit    = true;
                if($scope.bookRelatedProductDetail.identifiertype.id==''  || $scope.bookRelatedProductDetail.identifiertype.id==undefined){
                    $scope.addbookproductform.identifiertype.$invalid = true;    
                }
                if($scope.bookRelatedProductDetail.relatedcode.id==''  || $scope.bookRelatedProductDetail.relatedcode.id==undefined){
                    $scope.addbookproductform.relatedcode.$invalid = true;
                }
                $scope.bookProductFormSubmit    = true;
                $scope.productDuplicate         = false;
            }
        };
        $scope.deleteBookRelatedProduct = function(bookProduct){
            $scope.bookRelatedProductsList.splice($scope.bookRelatedProductsList.indexOf(bookProduct),1);
        };
        $scope.editBookRelatedProduct   = function(bookProduct){
            var identifiertypeval = _.where($scope.identifierList, {id: bookProduct.identifiertype.id, name: bookProduct.identifiertype.name});
            var relatedcodeval    = _.where($scope.RelatedCodeList, {id: bookProduct.relatedcode.id, name: bookProduct.relatedcode.name});
            $scope.bookRelatedProductEdit        = true;
            $scope.editBookRelatedProductObject  = bookProduct;
            $scope.bookRelatedProductDetail      = {relatedcode     :(relatedcodeval[0]!==undefined)?relatedcodeval[0]:{},
                                                    identifiertype  :(identifiertypeval[0]!==undefined)?identifiertypeval[0]:{},
                                                    identifiername  :bookProduct.identifiername};
        };
        $scope.updateBookRelatedProduct = function(){
            if($scope.addbookproductform.$valid){
                $scope.bookRelatedProductsList.splice($scope.bookRelatedProductsList.indexOf($scope.editBookRelatedProductObject),1);
                $scope.bookRelatedProductsList.push($scope.bookRelatedProductDetail);
                $scope.bookRelatedProductDetail = {relatedcode:{id:'',name:''},identifiertype:{id:'',name:''}
                                            ,identifiername:''};
                $scope.bookRelatedProductEdit        = false;
                $scope.editBookRelatedProductObject  = {};
                $scope.bookRelatedProductFormSubmit  = false;
            }
            else{
                $scope.bookRelatedProductFormSubmit     = true;
            }
        };
        $scope.setFile = function(element) {
            $scope.currentFile  = element.files[0];
            var reader          = new FileReader();
            reader.onload       = function(event){
                $scope.bookDetail.cover_image   = event.target.result;
                $scope.$apply();
            }
            reader.readAsDataURL(element.files[0]);
        };

        $scope.addBookDetail            = function(){
            
            if($scope.addbook.$valid){
                angular.forEach($scope.countryRegionArr,function(value,key){
                    if(value.selected){
                        $scope.bookDetail.region_id.push(value.id);
                    }
                    if(value.children!==undefined && value.children.length>0){
                        angular.forEach(value.children,function(childvalue,childkey){
                            if(childvalue.selected){
                                if($scope.bookDetail.region_id.indexOf(value.id)<0){
                                    $scope.bookDetail.region_id.push(value.id)
                                }
                                var arr = childvalue.id.split('=');
                                $scope.bookDetail.country_id.push(arr[0]);
                            }       
                        });
                    }
                });
                var bookData  = {
                        access_token: TokenData.access_token,
                        language        : $rootScope.language,
                        bookDetail      : $scope.bookDetail,
                        bookReview      : $scope.bookReviewList,
                        bookAward       : $scope.bookAwardList,
                        relatedProduct  : $scope.bookRelatedProductsList,
                };
                bookService.insertBookDetail(bookData)
                .then(function(data){
                    if(data.error<=0){
                        $location.search({});
                        $location.path('/maintainbooks');
                        $rootScope.maintainbooksmessage                  = data.msg;
                        $rootScope.maintainbooksisError                  = false;
                        $rootScope.maintainbooksisMessage                = true;
                    }
                    else{
                        $scope.message      = data.errorMsg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;
                    }
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }); 
            }
            else{
                $scope.isSubmitted    = true;
                $scope.bookReviewFormSubmit = false;
                $scope.bookAwardFormSubmit = false;
                $scope.bookProductFormSubmit = false;
            }
        };

        $scope.editBookDetail           = function(){
            if($scope.addbook.$valid){
                $scope.bookDetail.region_id = [];
                $scope.bookDetail.country_id = [];
                angular.forEach($scope.countryRegionArr,function(value,key){
                    if(value.selected){
                        $scope.bookDetail.region_id.push(value.id);
                    }
                    if(value.children!==undefined && value.children.length>0){
                        angular.forEach(value.children,function(childvalue,childkey){
                            if(childvalue.selected){
                                if($scope.bookDetail.region_id.indexOf(value.id)<0){
                                    $scope.bookDetail.region_id.push(value.id)
                                }
                                var arr = childvalue.id.split('=');
                                $scope.bookDetail.country_id.push(arr[0]);
                            }       
                        });
                    }
                });

                var bookData  = {
                        access_token: TokenData.access_token,
                        language        : $rootScope.language,
                        book_id         : parameter.id,
                        bookDetail      : $scope.bookDetail,
                        bookReview      : $scope.bookReviewList,
                        bookAward       : $scope.bookAwardList,
                        relatedProduct  : $scope.bookRelatedProductsList,
                };
                bookService.updateBookDetail(bookData)
                .then(function(data){
                    if(data.error<=0){
                        $location.search({});
                        $location.path('/maintainbooks');
                        $rootScope.maintainbooksmessage                  = data.msg;
                        $rootScope.maintainbooksisError                  = false;
                        $rootScope.maintainbooksisMessage                = true;
                    }
                    else{
                        $scope.message      = data.errorMsg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;
                    }
                },
                function(err,status){
                    $rootScope.maintainbooksmessage      = err.errorMsg;
                    $rootScope.maintainbooksisError      = true;
                    $rootScope.maintainbooksisMessage    = false;
                }); 
            }
            else{
                $scope.isSubmitted    = true;
                $scope.bookReviewFormSubmit = false;
                $scope.bookAwardFormSubmit = false;
                $scope.bookProductFormSubmit = false;
            }
        };


        if(parameter.id===undefined){
            $scope.getSubjectList();
            $scope.getRegionList();
            $scope.getAllCountry();
            $scope.getCompanyDetail();
        }
        $scope.getCountryRegionArr();
        $scope.getContributorsRole();
        $scope.getIdentifierType();
        $scope.getCurrencyList();
        $scope.getLanguageList();
        $scope.getAudienceList();
        $scope.getReviewTypeList();
        $scope.getReviewSourceList();
        $scope.getReviewRoleList();
        $scope.getAwardCodeList();
        $scope.getRelatedCodeList();
        $scope.getAwardList();
        $scope.getContributorsName();
}]);
