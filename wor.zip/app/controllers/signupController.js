App.controller('signupController', ['$scope', '$rootScope','$sessionStorage','authService', '$location','signupService',
    function ($scope, $rootScope,$sessionStorage,authService,$location,signupService) {
        $sessionStorage.contentDisplay ={signinMenu:true,
                                        signupMenu:false,
                                        userAccount:false,
                                        menuTab:false,
                                        usertype:''};
        $rootScope.contentDisplay       = $sessionStorage.contentDisplay;
        
        $scope.formdata     = {};
        $scope.isSubmitted  = false;
        $scope.isMessage    = false;
        $scope.isError      = false;
        $scope.usertypes    = null;
        $scope.message      = '';
        $scope.isCompany    = true;
        $scope.isEmail      = false;
        $scope.isUserType   = false;

        /*Invitation User*/
        if ($location.search().u != '' && $location.search().u != undefined) {

            authService.logOut()
            .then(function (data) {
                if (data.error <= 0) {
                    var userData = {};
                    userData.language   = $rootScope.language;
                    userData.user_id    = $location.search().u;
                    $location.search({});
                    signupService.signupInviteUser(userData)
                        .then(function(data){
                            if(data.error<=0){
                                $scope.isCompany    = false;
                                $scope.isEmail      = true;
                                $scope.isUserType   = true;
                                $scope.formdata     = {usertype :data.response.usertype,
                                                        email   : data.response.email,
                                                        company_name: data.response.company_name,
                                                        user_id : data.response.user_id,
                                                        company_id : data.response.company_id,
                                                        first_name : data.response.first_name,
                                                        last_name : data.response.last_name};
                            }
                            else{
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        },
                        function(err){
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        })
                }
                else{
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = data.errorMsg;
                }
            },
            function (err,status) {
                $scope.isError = true;
                $scope.isMessage = false;
                $scope.message = data.errorMsg;
            });
        }
        /*End Invitation User*/

        //Create User
        $scope.createUser = function () {
            $scope.formdata.language = $rootScope.language;           
            if ($scope.signup.$valid && $scope.formdata.tnc) {
                signupService.createUser($scope.formdata)
                .then(function(data){
                    if (data.error <= 0) {
                        //Reset form & form data
                        $scope.formdata = {};
                        $scope.signup.$setPristine();
                        $scope.isMessage = true;
                        $scope.isError = false;
                    } else {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = data.errorMsg;
                    }
                },function(err,status){
                    $scope.isError = true;
                    $scope.isMessage = false;
                    $scope.message = err.errorMsg;
                });
            } 
            else {
                $scope.isSubmitted = true;
            }
        };
        //Call on page load to get all usertypes from master table
        $scope.getusertypes = function () {
            signupService.getUserTypes($rootScope.language)
                .then(function (data) {
                    if (data.error <= 0) {
                        $scope.usertypes = data.response;
                    }
                    else{
                        $scope.isError = true;
                        $scope.message = data.errorMsg;
                    }
                },
                function (err,status) {
                    $scope.message = err.errorMsg;
                });
        };
        //Call on back button
        $scope.redirect = function (hash) {
            $location.path(hash);
        };
        $scope.getusertypes();
    }]);


