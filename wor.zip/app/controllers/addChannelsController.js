'use strict';
App.controller('createChannelsController', ['$scope', '$rootScope', 'channelService', '$uibModal', '$location', '$sessionStorage', 'localStorageService','DATE_FORMAT','ivhTreeviewMgr','$timeout',
    function ($scope,$rootScope,channelService,$uibModal, $location, $sessionStorage, localStorageService,DATE_FORMAT,ivhTreeviewMgr,$timeout) {
        var TokenData                   = localStorageService.get('authorizeTokenDetail');
        $scope.format                   = DATE_FORMAT;
        var parameter                   = $location.search();
        $scope.channelId                = '';
        if(parameter.id!==undefined){
            $scope.channelId                = parameter.id;
            var data  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    channel_id  : parameter.id
            };
            channelService.getChannelDetail(data)
                .then(function(data){
                    if(data.error<=0){
                        var channelData  = data.response;
                        $scope.channelDetail  = {name:channelData.name,
                                                status:(channelData.status==1)?true:false,
                                                startdate:new Date(channelData.start_date),
                                                enddate:new Date(channelData.end_date),
                                                group_id:channelData.group_id,
                                                businessModelId:channelData.business_model_id,
                                                business_model_type:channelData.business_model_type,
                                                retailers_list:channelData.retailers_list,
                                                frequentlyUsedModel:'',
                                                allBusinessModel:'',
                                                country_id:[],
                                                region_id:'',
                                                payoutDiscount:parseFloat(channelData.payoutDiscount),
                                                adjustDiscount:parseFloat(channelData.adjustDiscount)};
                        if($scope.channelDetail.retailers_list=='Blacklist'){
                            $scope.channelDetail.groupOptions = 1;
                        }else if ($scope.channelDetail.retailers_list=='Whitelist') {
                            $scope.channelDetail.groupOptions = 0;
                        }else{
                            $scope.channelDetail.groupOptions = 2;
                        }
                    }
                    else{
                        $scope.message      = data.errorMsg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;
                    }
                    $scope.getGroupList();
                    $scope.getBussinessModelList();
                    $scope.getCountryRegionArr();
                },function(err){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        }
        else{
            $scope.channelDetail            = {name:'',status:0,groupOptions:3,startdate:'',
                                            enddate:'',group_id:'',frequentlyUsedModel:'',
                                            allBusinessModel:'',businessModelId:'',
                                            business_model_type:'',retailers_list:'All',
                                            country_id:[],region_id:'',payoutDiscount:0,
                                            adjustDiscount:0};
        }
        $scope.isSubmitted              = false;
        $scope.message                  = '';
        $scope.isError                  = false;
        $scope.isMessage                = false;
        $scope.groupList                = [];
        $scope.bussinessModelList       = {allBusinessModel:{},frequentlyUsedModel:{}};
        $scope.regionCountryList        = [];
        $scope.retailerList             = [];
        $scope.retailerDetailList       = [];
        $scope.includeRetailerList      = [];
        $scope.excludeRetailerList      = [];
        $scope.countryRegionArr         = [];
        $scope.today                    = new Date();
        $scope.currentTab               = 1;
        $scope.submitErr                = {tab1:false,tab2:false,tab2ErrorMsg:'',tab3:false,
                                            tab3ErrorMsg:'',tab4:false,tab5:false};
        $scope.modelDetail              = {name:'',description:''};
        $scope.bookPricingDetail        = {};
        $scope.errpayoutDiscount        = false;
        $scope.erradjustDiscount        = false;
        $scope.retailerErrMesage        = false;
        $scope.paydiscount              = 0;
        $scope.adjdiscount              = 0;
        $scope.activeTab                = {tab1:'active',tab2:'',tab3:'',tab4:'',tab5:''};
        $scope.businessDesArr           = [];
        $scope.goNext                   = function(i){
            $scope.progressNext(++i);
        };
        $scope.progressNext             = function(step){
            var isvalid  = true;
            var activestep  = step;
            if(parseInt($scope.currentTab)===1 || step>1){
                isvalid  = $scope['addchanneltab1'].$valid;
                $scope.submitErr['tab'+$scope.currentTab]   = true;
                if(!isvalid){
                    $scope.currentTab           = 1;
                    var percent                 = (1/ 5) * 100;
                    $('.tab-pane').removeClass('in active');
                    $('.progress-bar').css({width: percent + '%'});
                    $('.progress-bar').text("Step 1  of 5");
                    $('#step1').addClass('in active');
                    return false;
                }
            }
            if(parseInt($scope.currentTab)===2 || step>2){
                if($scope.channelDetail.allBusinessModel==='' && 
                    $scope.channelDetail.frequentlyUsedModel==='')
                {
                    isvalid                         = false;
                    activestep          = 2;
                    $scope.submitErr['tab'+$scope.currentTab]   = true;
                    $scope.submitErr.tab2ErrorMsg   = 'Select Atleast One Model.';
                    if(step<$scope.currentTab){
                        activestep          = step;
                    }
                    $scope.currentTab           = activestep;
                    var percent                 = (activestep/ 5) * 100;
                    $('.tab-pane').removeClass('in active');
                    $('.progress-bar').css({width: percent + '%'});
                    $('.progress-bar').text("Step  "+activestep+"  of 5");
                    $('#step'+activestep).addClass('in active');
                    
                    //$scope.activeTab                = {tab1:'',tab2:'active',tab3:'',tab4:'',tab5:''};
                    return false;
                }
            }
            if(parseInt($scope.currentTab)===3 || step>3){
                $scope.channelDetail.country_id = [];
                if($scope.channelDetail.region_id==1){
                    angular.forEach($scope.countryRegionArr,function(value,key){
                        if(value.children!==undefined && value.children.length>0){
                            angular.forEach(value.children,function(childvalue,childkey){
                                var arr = childvalue.id.split('_');
                                $scope.channelDetail.country_id.push(arr[0]);
                            });
                        }
                    });
                }
                else{
                    angular.forEach($scope.countryRegionArr,function(value,key){
                        if(value.children!==undefined && value.children.length>0){
                            angular.forEach(value.children,function(childvalue,childkey){
                                if(childvalue.selected){
                                    var arr = childvalue.id.split('_');
                                    $scope.channelDetail.country_id.push(arr[0]);
                                }       
                            });
                        }
                    });
                }
                if($scope.channelDetail.region_id==='' && $scope.channelDetail.country_id.length<=0){
                    isvalid                         = false;
                    activestep          = 3;
                    $scope.submitErr['tab'+$scope.currentTab]   = true;
                    $scope.submitErr.tab3ErrorMsg   = 'Select Atleast One Country Or Region.';
                    if(step<$scope.currentTab){
                        activestep          = step;
                    }
                    $scope.currentTab           = activestep;
                    var percent                 = (activestep/ 5) * 100;
                    $('.tab-pane').removeClass('in active');
                    $('.progress-bar').css({width: percent + '%'});
                    $('.progress-bar').text("Step  "+activestep+"  of 5");
                    $('#step'+activestep).addClass('in active');
                    $scope.activeTab                = {tab1:'',tab2:'',tab3:'active',tab4:'',tab5:''};
                    return false;
                }
                else{
                    if(step>3 && step<5){
                        var arr = [];
                        if($scope.channelDetail.frequentlyUsedModel!==''){
                            arr     = $scope.channelDetail.frequentlyUsedModel.split('=');
                        }
                        else{
                            arr     = $scope.channelDetail.allBusinessModel.split('=');
/*                            $scope.channelDetail.businessModelId = parseFloat(arr[0]);
                            $scope.modelDetail              = {name:arr[1],description:$scope.businessDesArr[arr[0]]};    
                            */
                        }
                        $scope.channelDetail.businessModelId = parseFloat(arr[0]);
                        $scope.modelDetail              = {name:arr[1],description:$scope.businessDesArr[arr[0]]};    

                        var data  = {
                            access_token: TokenData.access_token,
                            language    : $rootScope.language,
                            group_id    : $scope.channelDetail.group_id,
                            countryArr  : $scope.channelDetail.country_id,
                            business_id : $scope.channelDetail.businessModelId,
                            channel_id  : (parameter.id!==undefined && parameter.id!==null && parameter.id!=='')?parameter.id:''
                        };
                        channelService.getConversion(data)
                        .then(function(data){
                            if(data.error<=0){
                                angular.forEach(data.response,function(bookval,bookkey){
                                    var arr = [];
                                    angular.forEach(bookval,function(val,key){
                                        var currencyArr = val.currency.split('=');
                                        if(currencyArr.length>0){
                                            val.currency_id     = currencyArr[0];
                                            val.currency_name   = currencyArr[1];
                                        }
                                        arr.push(val);
                                    });
                                    $scope.bookPricingDetail[bookkey] = arr;
                                });
                                $scope.channelDetail.payoutDiscount = parseFloat(data.payoutDiscount);
                                $scope.channelDetail.adjustDiscount = 0;
                                $scope.paydiscount                  = parseFloat(data.payoutDiscount);
                            }
                            else{
                                $scope.message      = err.errorMsg;
                                $scope.isError      = true;
                                $scope.isMessage    = false;
                            }
                        },function(err){
                            $scope.message      = err.errorMsg;
                            $scope.isError      = true;
                            $scope.isMessage    = false;
                        });
                    }
                }
            }
            if(parseInt($scope.currentTab)===4 || step>4){
                $scope.getRetailerList();
            }
            if(step<$scope.currentTab || isvalid){
                $scope.currentTab           = step;
                var percent                 = (parseInt(step) / 5) * 100;
                $('.tab-pane').removeClass('in active');
                $('.progress-bar').css({width: percent + '%'});
                $('.progress-bar').text("Step " + step + " of 5");
                $('#step'+step).addClass('in active');
                $scope.submitErr                = {tab1:false,tab2:false,tab2ErrorMsg:'',
                                                    tab3:false,tab3ErrorMsg:'',tab4:false,
                                                    tab5:false};
                $scope.activeTab                = {tab1:'',tab2:'',tab3:'',tab4:'',tab5:''};
                $scope.activeTab['tab'+step]    = 'active';
            }
        };
        $scope.goBack                   = function(){
            $location.search({});
            $location.path('/channels');
        };
        $scope.getGroupList             = function(){
            var data  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            channelService.getGroupList(data)
            .then(function(data){
                if(data.error<=0){
                    $scope.groupList    = data.response;
                }
                else{
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }
            },function(err){
                $scope.message      = err.errorMsg;
                $scope.isError      = true;
                $scope.isMessage    = false;
            });
        };
        $scope.getBussinessModelList    = function(){
            var data  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language
            };
            channelService.getBussinessModelList(data)
            .then(function(data){
                if(data.error<=0){
                    $scope.bussinessModelList    = {allBusinessModel:data.response.all_business_model,
                                                    frequentlyUsedModel:data.response.frequently_used_model};
                    $scope.businessDesArr       = [];
                    if($scope.channelDetail.business_model_type==0){
                        angular.forEach($scope.bussinessModelList.allBusinessModel,function(businessval,businesskey){
                            angular.forEach(businessval,function(value,key){
                                if(value.id==$scope.channelDetail.businessModelId){
                                    $scope.channelDetail.allBusinessModel = value.id+'='+value.bm_list;
                                }
                                $scope.businessDesArr[value.id] = value.bm_longtext;
                            });
                        });
                    }
                    else{
                        if($scope.channelDetail.business_model_type==1){
                            angular.forEach($scope.bussinessModelList.frequentlyUsedModel['YOUR FAVORITES'],function(frequentlyval,frequentlykey){
                                if(value.id==$scope.channelDetail.businessModelId){
                                    $scope.channelDetail.frequentlyUsedModel = value.id+'='+value.bm_list;
                                }
                                $scope.businessDesArr[value.id] = value.bm_longtext;
                            });
                        }
                        else{
                            angular.forEach($scope.bussinessModelList.frequentlyUsedModel['MOST POPULAR'],function(frequentlyval,frequentlykey){
                                if(value.id==$scope.channelDetail.businessModelId){
                                    $scope.channelDetail.frequentlyUsedModel = value.bm_id+'='+value.bm_list+'='+frequentlykey;
                                }
                                $scope.businessDesArr[value.id] = value.bm_longtext;
                            });
                        }
                    }
                }
                else{
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }
            },function(err){
                $scope.message      = err.errorMsg;
                $scope.isError      = true;
                $scope.isMessage    = false;
            });
        };
        $scope.getGroupData             = function(){
            if($scope.channelDetail.group_id!=='' && 
                $scope.channelDetail.group_id!==undefined &&
                $scope.channelDetail.group_id!==null){
                $scope.getCountryRegionArr();
            }
            else{
                $scope.retailerList             = [];
                $scope.countryRegionArr         = []; 
            }
        };
        $scope.getCountryRegionArr      = function(){
            var Data  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    group_id    : $scope.channelDetail.group_id,
                    channel_id  : (parameter.id!==undefined && parameter.id!==null && parameter.id!=='')?parameter.id:''
            };
            channelService.getCountryRegionList(Data)
                .then(function(data){
                    $scope.channelDetail.region_id  = '';
                    $scope.countryRegionArr         = [];
                    $scope.setCountryList(data,function(data){
                        if(data.selected_countries.length>0){
                            ivhTreeviewMgr.selectEach($scope.countryRegionArr,data.selected_countries);
                            $timeout(function(){
                                $('.treelist').attr('disabled',true);
                                angular.forEach(data.selected_countries,function(val,key){
                                    $('#'+val).attr('disabled',false);
                                });
                            },1000); 
                        }  
                        if(data.selected_regions!==undefined && data.selected_regions.length===1 && data.selected_regions[0]==1){
                            ivhTreeviewMgr.deselectAll($scope.countryRegionArr);
                            ivhTreeviewMgr.select($scope.countryRegionArr,$scope.countryRegionArr[0]);
                            $scope.channelDetail.region_id  = 1;
                            $timeout(function(){
                                $('.treelist').attr('disabled',true);
                                $('#1').attr('disabled',false);
                            },1000); 
                        }
                        if(data.selected_countries.length<=0 && data.selected_regions.length<=0 ){
                            $timeout(function(){
                                $('.treelist').attr('disabled',true);
                            });
                        }
                    });
                },
                function(err,status){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                });
        };
        $scope.setCountryList           = function(data,call){
            angular.forEach(data.response, function(element) {
              $scope.countryRegionArr.push(element);
            });
            call(data);
        };
        $scope.countryMade              = function(Node, IsSelected,Tree){
            if(Node.label==='World' && Node.children===undefined && IsSelected){
                ivhTreeviewMgr.deselectAll($scope.countryRegionArr);
                $timeout(function(){
                    ivhTreeviewMgr.select($scope.countryRegionArr,$scope.countryRegionArr[0]);   
                },100);
            }
            if(Node.label!=='World' && IsSelected){
                ivhTreeviewMgr.deselect($scope.countryRegionArr,$scope.countryRegionArr[0]);   
            }
        };
        $scope.getRetailerList          = function(){
            var data  = {
                    access_token: TokenData.access_token,
                    language    : $rootScope.language,
                    group_id    : $scope.channelDetail.group_id,
                    country_id  : $scope.channelDetail.country_id,
                    channel_id  : (parameter.id!==undefined && parameter.id!==null && parameter.id!=='')?parameter.id:''
            };
            channelService.getRetailerList(data)
            .then(function(data){
                if(data.error<=0){
                    $scope.retailerDetailList = data.response;
                    $scope.retailerList    = _.pluck(data.response,'username');
                    $('#excludeGroupName,#includeGroupName').autocomplete({
                        source: $scope.retailerList
                    });
                    if(data.selected_retailers.length>0){
                        var arr = [];
                        angular.forEach(data.selected_retailers,function(retval,retkey){
                            arr.push({name:retval.username});
                        });
                        if($scope.channelDetail.groupOptions==0){
                            $scope.includeRetailerList = arr;
                        }
                        else{
                            $scope.excludeRetailerList = arr;
                        }
                    }
                }
                else{
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;
                }
            },function(err){
                $scope.message      = err.errorMsg;
                $scope.isError      = true;
                $scope.isMessage    = false;
            });
        };
        $scope.changeGroupOption        = function(){
            if($scope.channelDetail.groupOptions==0){
                $scope.channelDetail.retailers_list     = 'Whitelist';
                $scope.excludeRetailerList              = [];
                $scope.channelDetail.excludeGroupName   = '';
            }
            if($scope.channelDetail.groupOptions==1){
                $scope.channelDetail.retailers_list     = 'Blacklist';
                $scope.includeRetailerList              = [];
                $scope.channelDetail.includeGroupName   = '';
            }
        };
        $scope.recalculatePrice         = function(variable){
            if(parseFloat($scope.channelDetail[variable])>=0 && parseFloat($scope.channelDetail[variable])<=100){
                //if($scope.channelDetail.payoutDiscount!=0 || $scope.channelDetail.adjustDiscount!=0){
                //var priceObj    = {};
                angular.forEach($scope.bookPricingDetail,function(bookvalue,bookkey){
                    var arr     = [];
                    angular.forEach(bookvalue,function(value,key){
                        if(variable=='payoutDiscount'){
                            $scope.paydiscount              = $scope.channelDetail.payoutDiscount;
                            $scope.recalculatePayoutPrice(bookkey,key);
                        }
                        else{
                            $scope.adjdiscount      = $scope.channelDetail.adjustDiscount;
                            $scope.recalculateAdjustPrice(bookkey,key);
                        }
                        //$scope.bookPrice(bookkey,key);
                    });
                });
                //}
                $scope.errpayoutDiscount        = false;
                $scope.erradjustDiscount        = false;
            }
            else{       
                $scope.errpayoutDiscount        = false;
                $scope.erradjustDiscount        = false;
                $scope['err'+variable]          = true;
            }
        };
        $scope.bookPrice           = function(book,value){
            var orignalObj = $scope.bookPricingDetail[book][value];
            /* For Adjustment + payable Change  */
            if($scope.channelDetail.businessModelId==3){
                if($scope.channelDetail.adjustDiscount!=0){
                    var adjdiscount = (parseFloat(orignalObj.original_digital_list)*$scope.channelDetail.adjustDiscount)/100;
                    if($scope.channelDetail.payoutDiscount!=0){
                        var discountval = parseFloat(orignalObj.original_digital_list)-parseFloat(adjdiscount);
                        var paydiscount = (parseFloat(discountval)*parseFloat($scope.channelDetail.payoutDiscount))/100;
                        $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = parseFloat(paydiscount);
                        $scope.bookPricingDetail[book][value]['publisher_share'] = parseFloat(parseFloat(orignalObj.original_digital_list)-parseFloat(paydiscount));
                    }
                    else{
                        $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = parseFloat(parseFloat(orignalObj.adjusted_selling_price)-parseFloat(adjdiscount));
                    }
                }
                else{
                    var paydiscount = (parseFloat(orignalObj.original_digital_list)*parseFloat($scope.channelDetail.payoutDiscount))/100;
                    $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = parseFloat(paydiscount);
                    $scope.bookPricingDetail[book][value]['publisher_share'] = parseFloat(parseFloat(orignalObj.original_digital_list)-parseFloat(paydiscount));
                }
            }
            /*End For Adjustment + payable Change  */
            /* For Adjustment  Change  */
            else{
                var adjdiscount = (parseFloat(orignalObj.original_digital_list)*$scope.channelDetail.adjustDiscount)/100;
                $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = parseFloat(parseFloat(orignalObj.original_digital_list)-parseFloat(adjdiscount));
            }
            /* End For Adjustment Change  */
        };
        $scope.recalculatePayoutPrice   = function(book,value){
            var orignalObj = $scope.bookPricingDetail[book][value];
            var adjdiscount = (parseFloat(orignalObj.original_digital_list)*parseFloat($scope.adjdiscount))/100;
            var orignalPrice = parseFloat(orignalObj.original_digital_list)-parseFloat(adjdiscount);
            if($scope.paydiscount>=0){
                var sharePrice = parseFloat(orignalPrice)*parseFloat($scope.paydiscount)/100;
                var adjustedPrice = parseFloat(orignalPrice)-parseFloat(sharePrice);
                $scope.bookPricingDetail[book][value]['publisher_share']        = sharePrice;
                $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = adjustedPrice;
            }
            /*var paydiscount = (parseFloat(orignalObj.original_digital_list)*parseFloat($scope.channelDetail.payoutDiscount))/100;
            $scope.bookPricingDetail[book][value]['publisher_share'] = parseFloat(paydiscount);
            $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = parseFloat(parseFloat(orignalObj.original_digital_list)-parseFloat(paydiscount));*/
        };
        $scope.recalculateAdjustPrice   = function(book,value){
            var orignalObj = $scope.bookPricingDetail[book][value];
            var adjdiscount = (parseFloat(orignalObj.original_digital_list)*$scope.channelDetail.adjustDiscount)/100;
            if($scope.channelDetail.businessModelId==3){
                var orignalPrice = parseFloat(orignalObj.original_digital_list)-parseFloat(adjdiscount);
                if($scope.paydiscount>=0){
                    var sharePrice = parseFloat(orignalPrice)*parseFloat($scope.paydiscount)/100;
                    var adjustedPrice = parseFloat(orignalPrice)-parseFloat(sharePrice);
                    $scope.bookPricingDetail[book][value]['publisher_share']        = sharePrice;
                    $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = adjustedPrice;
                }
            }
            else{
                $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = parseFloat(orignalObj.original_digital_list)-parseFloat(adjdiscount);
            }            
        };

        $scope.resetBookPrice           = function(book,value){
            var orignalObj = $scope.bookPricingDetail[book][value];
            if($scope.channelDetail.businessModelId==3){
                var adjustedPrice = parseFloat(orignalObj.original_digital_list)*parseFloat($scope.paydiscount)/100;
                $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = parseFloat(adjustedPrice);
                var publisherprice = parseFloat(orignalObj.original_digital_list)-parseFloat(adjustedPrice);
                $scope.bookPricingDetail[book][value]['publisher_share'] = parseFloat(publisherprice);
            }
            else{
                $scope.bookPricingDetail[book][value]['adjusted_selling_price'] = parseFloat(orignalObj.original_digital_list);
            }
        };
        $scope.addIncluderRetailer      = function(){
            if($scope.channelDetail.includeGroupName!=='' && $scope.channelDetail.includeGroupName!==undefined && $scope.channelDetail.includeGroupName!==null){
                var indexId = $scope.retailerList.indexOf($scope.channelDetail.includeGroupName);
                if(indexId>=0){
                    var isAvialable =   _.where($scope.includeRetailerList,{name:$scope.channelDetail.includeGroupName});
                    if(isAvialable.length<=0){
                        $scope.includeRetailerList.push({name:$scope.channelDetail.includeGroupName});    
                    }
                }
                $scope.channelDetail.includeGroupName = '';
            }
        };
        $scope.addExcludeRetailer       = function(){
            if($scope.channelDetail.excludeGroupName!=='' && $scope.channelDetail.excludeGroupName!==undefined && $scope.channelDetail.excludeGroupName!==null){
                var indexId = $scope.retailerList.indexOf($scope.channelDetail.excludeGroupName);
                if(indexId>=0){
                    var isAvialable =   _.where($scope.excludeRetailerList,{name:$scope.channelDetail.excludeGroupName});
                    if(isAvialable.length<=0){
                        $scope.excludeRetailerList.push({name:$scope.channelDetail.excludeGroupName});    
                    }
                }
                $scope.channelDetail.excludeGroupName = '';
            }
        };
        $scope.deleteIncludeRetailer    = function(obj){
            $scope.includeRetailerList.splice($scope.includeRetailerList.indexOf(obj),1);
        };
        $scope.deleteExcludeRetailer    = function(obj){
            $scope.excludeRetailerList.splice($scope.excludeRetailerList.indexOf(obj),1);
        };
        $scope.addChannel               = function(){
            var isValidData = true;
            var retailerArr = [];
            if($scope.channelDetail.groupOptions==0){
                if($scope.includeRetailerList.length<=0){
                    isValidData = false;
                }
                else{
                    angular.forEach($scope.includeRetailerList,function(value,key){
                        var ret_arr =_.where($scope.retailerDetailList,{username:value.name});
                        if(ret_arr.length>0){
                            retailerArr.push(ret_arr[0].user_id);
                        }
                    });
                }
            }
            else{
                if($scope.excludeRetailerList.length<=0){
                    isValidData = false;
                }
                else{
                    angular.forEach($scope.excludeRetailerList,function(value,key){
                        var ret_arr =_.where($scope.retailerDetailList,{username:value.name});
                        if(ret_arr.length>0){
                            retailerArr.push(ret_arr[0].user_id);
                        }
                    });
                }
            }
            if(isValidData){
                var data  = {
                        access_token        : TokenData.access_token,
                        language            : $rootScope.language,
                        channelArr          : $scope.channelDetail,
                        channelBook         : $scope.bookPricingDetail,
                        channelCountry      : $scope.channelDetail.country_id,
                        channelRetailer     : retailerArr
                };
                $scope.submitChannel(data);
            }
            else{
                $scope.retailerErrMesage = true;
            }  
        };
        $scope.editChannel              = function(){
            var isValidData = true;
            var retailerArr = [];
            if($scope.channelDetail.groupOptions==0){
                if($scope.includeRetailerList.length<=0){
                    isValidData = false;
                }
                else{
                    angular.forEach($scope.includeRetailerList,function(value,key){
                        var ret_arr =_.where($scope.retailerDetailList,{username:value.name});
                        if(ret_arr.length>0){
                            retailerArr.push(ret_arr[0].user_id);
                        }
                    });
                }
            }
            else{
                if($scope.excludeRetailerList.length<=0){
                    isValidData = false;
                }
                else{
                    angular.forEach($scope.excludeRetailerList,function(value,key){
                        var ret_arr =_.where($scope.retailerDetailList,{username:value.name});
                        if(ret_arr.length>0){
                            retailerArr.push(ret_arr[0].user_id);
                        }
                    });
                }
            }
            if(isValidData){
                var dataArr  = {
                        access_token        : TokenData.access_token,
                        language            : $rootScope.language,
                        channelArr          : $scope.channelDetail,
                        channelBook         : $scope.bookPricingDetail,
                        channelCountry      : $scope.channelDetail.country_id,
                        channelRetailer     : retailerArr,
                        channel_id          : $scope.channelId
                };
                $scope.updateChannel(dataArr);
            }   
            else{
                $scope.retailerErrMesage = true;
            }  
        };
        $scope.processAll               = function(){
            var data  = {
                        access_token        : TokenData.access_token,
                        language            : $rootScope.language,
                        channelArr          : $scope.channelDetail,
                        channelBook         : $scope.bookPricingDetail,
                        channelCountry      : $scope.channelDetail.country_id,
                        channelRetailer     : [],
                        channel_id          : $scope.channelId
                    };
            if($scope.channelId!=='' && $scope.channelId!==undefined && $scope.channelId!==null){
                $scope.updateChannel(data);
            }
            else{
                $scope.submitChannel(data);
            }
        }
        $scope.submitChannel            = function(dataArr){
            channelService.createChannel(dataArr)
                .then(function(data){
                    if(data.error<=0){
                        $location.search({});
                        $rootScope.channelmessage      = data.msg;
                        $rootScope.channelisError      = false;
                        $rootScope.channelisMessage    = true;
                        $location.path('/channels');
                    }
                    else{
                        $scope.message      = data.errorMsg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;
                    }
                },function(err){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;

                    $scope.currentTab           = 1;
                    var percent                 = (1/ 5) * 100;
                    $('.tab-pane').removeClass('in active');
                    $('.progress-bar').css({width: percent + '%'});
                    $('.progress-bar').text("Step 1  of 5");
                    $('#step1').addClass('in active');
                    return false;
                });
        };
        $scope.updateChannel            = function(dataArr){
            channelService.updateChannel(dataArr)
                .then(function(data){
                    if(data.error<=0){
                        $location.search({});
                        $rootScope.channelmessage      = data.msg;
                        $rootScope.channelisError      = false;
                        $rootScope.channelisMessage    = true;
                        $location.path('/channels');
                    }
                    else{
                        $scope.message      = data.errorMsg;
                        $scope.isError      = true;
                        $scope.isMessage    = false;
                    }
                },function(err){
                    $scope.message      = err.errorMsg;
                    $scope.isError      = true;
                    $scope.isMessage    = false;

                    $scope.currentTab           = 1;
                    var percent                 = (1/ 5) * 100;
                    $('.tab-pane').removeClass('in active');
                    $('.progress-bar').css({width: percent + '%'});
                    $('.progress-bar').text("Step 1  of 5");
                    $('#step1').addClass('in active');
                    return false;
                });
        };
        $scope.resetModel               = function(isFrequentlyModel){
            if(isFrequentlyModel){
                var arr = $scope.channelDetail.frequentlyUsedModel.split('=');
                if(arr[2]!==undefined && arr[2]=="YOUR FAVORITES"){
                    $scope.channelDetail.business_model_type = 1;
                }
                else{
                    $scope.channelDetail.business_model_type = 2;    
                }
                $scope.channelDetail.allBusinessModel   = '';
            }
            else{
                $scope.channelDetail.frequentlyUsedModel = '';
                $scope.channelDetail.business_model_type = 0;
            }
        }
        if(parameter.id===undefined){
            $scope.getGroupList();
            $scope.getBussinessModelList();
            if(parameter.group_id!==undefined && parameter.group_id!==null && parameter.group_id!==''){
                $scope.channelDetail.group_id = parameter.group_id;
                $scope.getGroupData();
            }
        }
}]);

