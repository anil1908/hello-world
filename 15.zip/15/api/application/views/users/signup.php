<select onchange="javascript:window.location.href = '<?php echo base_url(); ?>LanguageSwitcher/switchLang/' + this.value;">
    <option value="english" <?php if ($this->session->userdata('site_lang') == 'english') echo 'selected="selected"'; ?>>English</option>
    <option value="french" <?php if ($this->session->userdata('site_lang') == 'french') echo 'selected="selected"'; ?>>French</option>    
</select>
<p><?php echo $this->lang->line('welcome_message'); ?></p>
<div class="login" ng-app="signupapp" ng-controller="SignupCtrl"> 
    <!-- END LOGO --> 
    <!-- BEGIN LOGIN -->
    
    <div class="content">        
        <?php $attributes = array('novalidate' => '', 'name' => 'signup'); ?>    
        <?php echo form_open('', $attributes); ?>
        <h3 class="form-title"> <?php echo $this->lang->line('signup_title'); ?> </h3>
        <p> <?php echo $this->lang->line('signup_instruction'); ?> </p>
        <div class="form-group">
            <label class="control-label visible-ie8 visible-ie9"><?php echo $this->lang->line('signup_first_name'); ?></label>
            <div class="input-icon"> <i class="fa fa-font"></i>
                <input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="<?php echo $this->lang->line('signup_first_name'); ?>" name="first_name" id="first_name" ng-model="formdata.first_name" value="" required   />
            </div>
            <div ng-messages="signup.first_name.$error"  ng-show="submitted && signup.first_name.$error.required" />            
                <div ng-message="required">Please enter first name</div>
            </div>
        </div>
        <div class="form-group">
            <label class="control-label visible-ie8 visible-ie9"><?php echo $this->lang->line('signup_last_name'); ?></label>
            <div class="input-icon"> <i class="fa fa-font"></i>
                <input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="<?php echo $this->lang->line('signup_last_name'); ?>" name="last_name"  id="last_name" value="" maxlength="50" />
            </div>
        </div>

        <div class="form-group">
            <label class="control-label visible-ie8 visible-ie9"><?php echo $this->lang->line('signup_company_name'); ?></label>
            <div class="input-icon"> 
                <i class="fa fa-building-o"></i>
                <input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="<?php echo $this->lang->line('signup_company_name'); ?>" name="company_name" id="company_name" maxlength="50" />
            </div>
        </div>

        <div class="form-group"> 
            <!--ie8, ie9 does not support html5 placeholder, so we just show field title for that-->
            <label class="control-label visible-ie8 visible-ie9"><?php echo $this->lang->line('signup_email'); ?></label>
            <div class="input-icon"> <i class="fa fa-envelope"></i>
                <input class="form-control placeholder-no-fix" type="text" autocomplete="off" placeholder="<?php echo $this->lang->line('signup_email'); ?>" name="email" id="email" value="" maxlength="50" />
            </div>
        </div>
        <div class="form-group">
            <label class="control-label visible-ie8 visible-ie9"><?php echo $this->lang->line('signup_password'); ?></label>
            <div class="input-icon"> <i class="fa fa-lock"></i>
                <input class="form-control placeholder-no-fix" type="password" autocomplete="off" id="password" placeholder="<?php echo $this->lang->line('signup_password'); ?>" name="password" maxlength="50"/>
            </div>
        </div>
        <div class="form-group agree">
            <label>
                <input type="checkbox" name="tnc" id="tnc"/>
                <?php echo $this->lang->line('signup_policy'); ?> </label>                        
        </div>
        <div class="form-actions clearfix">
            <button type="button"  id="back-btn"  class="btn default"> <?php echo $this->lang->line('signup_back'); ?> </button>
            <button type="button" ng-click="submitted=true;createUser(signup)"   id="register-submit-btn" class="btn default pull-right"> <?php echo $this->lang->line('signup_button'); ?>  </button>
        </div>
        <?php echo form_close(); ?>  
    </div>
    <!-- END LOGIN --> 
    <!-- BEGIN COPYRIGHT --> 
</div>
<script type="text/javascript" src="<? echo base_url(); ?>assets/js/angular.min.js"></script>
<script type="text/javascript" src="<? echo base_url(); ?>assets/js/angular-messages.js"></script>
<script type="text/javascript" src="<? echo base_url(); ?>assets/js/signup.js"></script>