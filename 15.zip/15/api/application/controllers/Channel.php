<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Channel extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('channel_model');
        $this->load->model('general_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * Channel list
     *
     * @access	public
     * @param	access_token,language,search_name,search_from_date,search_to_date,search_model,pageStart,pageLimit,sortField,sorttype
     * @return	JSON Array
     */
    public function get_channel_list() {
        $retarray = array();
        $result = array();
        $id_array = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        $this->form_validation->set_rules('search_name', 'Group Name', 'trim|xss_clean');
        $this->form_validation->set_rules('search_from_date', 'From Date', 'trim|xss_clean');
        $this->form_validation->set_rules('search_to_date', 'To Date', 'trim|xss_clean');
        $this->form_validation->set_rules('search_model', 'Business Model', 'trim|xss_clean');


        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            $search_business_model = 0;
            $search_status = -1;
            if ($common_result['error'] == 0) {
                $search_name = addslashes(strtolower($this->input->post('search_name')));
                $search_from_date = $this->input->post('search_from_date');
                $search_to_date = $this->input->post('search_to_date');
                $modelarr = $this->input->post('search_model');

                if (count($modelarr) > 0) {
                    $search_business_model = (!empty($modelarr['id']) ? $modelarr['id'] : 0);
                }
                $search_status = $this->input->post('search_status');
                $pageStart = (!empty($this->input->post('pageStart'))) ? $this->input->post('pageStart') : 0;
                $pageLimit = (!empty($this->input->post('pageLimit'))) ? $this->input->post('pageLimit') : 10;
                $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'c.created_on';
                $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'DESC';

                $retarray['response'] = array();
                //Get channel list
                $result = $this->channel_model->get_channel_list_by_company_id($common_result['company_id'], $pageStart, $pageLimit, $sortField, $sortType, $search_name, $search_from_date, $search_to_date, $search_business_model, $search_status);
                $retarray['found_rows'] = $this->general_model->found_rows();
                $wherearr = array('company_id' => $common_result['company_id']);
                $retarray['total_rows'] = $this->channel_model->get_channel_list_count($common_result['company_id'], $search_name, $search_from_date, $search_to_date, $search_business_model, $search_status);
                $i = 0;
                if (is_array($result) && count($result) > 0) {
                    $retarray['error'] = 0;
                    foreach ($result as $key => $val) {
                        array_push($id_array, $result[$key]['id']);
                        //Channel list
                        $retarray['response'][$i] = array('id' => $result[$key]['id'],
                            'name' => strip_slashes($result[$key]['name']),
                            'created_on' => date('m/d/Y', strtotime($result[$key]['created_on'])),
                            'business_model' => $result[$key]['business_model'],
                            'group_name' => strip_slashes($result[$key]['group_name']),
                            'window' => date('m/d/Y', strtotime($result[$key]['start_date'])) . " To " . date('m/d/Y', strtotime($result[$key]['end_date'])),
                            'region' => $result[$key]['region'],
                            'status' => $result[$key]['status'],
                        );
                        $i++;
                    }
                    //ids
                    $retarray['ids'] = implode(',', $id_array);
                } else {
                    $retarray = array("error" => 0,
                        "found_rows" => 0,
                        "total_rows" => 0,
                        "response" => array(),
                        "ids" => '');
                }
            } else {
                $retarray = $common_result;
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Change channel status
     *
     * @access	public
     * @param	access_token,language,channel_id,status
     * @return	JSON Array
     */
    public function update_channel_status() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $channel_id = $this->input->post('channel_id');
            $status = $this->input->post('status');
            $modified_on = date('Y-m-d H:i:s');

            if (!empty($channel_id)) {
                //update channel data
                $channel_data = array('modified_on' => $modified_on,
                    'modified_by' => $common_result['user_id']);
                $this->channel_model->update_channel_data_by_id($channel_data, $channel_id);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('update_channel_status');
                $retarray['response'] = array();
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Delete channel
     *
     * @access	public
     * @param	access_token,language,channelArr
     * @return	JSON Array
     */
    public function delete_channel() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $channel_id = $this->input->post('channelArr');
            $deleted_on = date('Y-m-d H:i:s');
            if (is_array($channel_id) && count($channel_id) > 0) {
                //Delete channel data
                $channel_data = array('deleted_on' => $deleted_on,
                    'deleted_by' => $common_result['user_id']);
                $this->channel_model->delete_channel_data($channel_data, $channel_id);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('delete_channel_success');
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Channel Price
     *
     * @access	public
     * @param	access_token,language,channel_id
     * @return	JSON Array
     */
    public function get_channel_price() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $channel_id = $this->input->post('channel_id');
            if (!empty($channel_id)) {
                //Get channel book price
                $retarray['response'] = $this->channel_model->get_channel_books_price_by_channel_id($channel_id);
                if(!empty($retarray['response'])){
                    $result = array_keys($retarray['response']);
                    if(!empty($retarray['response'][$result[0]][0]['business_model_id'])){
                         $retarray['business_id'] = $retarray['response'][$result[0]][0]['business_model_id'];
                    }
                }                                             
                $retarray['error'] = 0;
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Regions and countries
     *
     * @access	public
     * @param	access_token,language,group_id,channel_id
     * @return	JSON Array
     */
    public function get_region_with_country() {
        $retarray = array();
        $result_country = array();
        $result_region = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $group_id = $this->input->post("group_id");
            $channel_id = $this->input->post("channel_id");
            //Get region with country
            $retarray['response'] = $this->channel_model->get_region_with_country();
            if (!empty($channel_id)) {
                $result_country = $this->channel_model->get_selected_country_by_channel_id($channel_id);
            } else {
                $result_country = $this->channel_model->get_selected_country_by_group_id($group_id);
                $result_region = $this->channel_model->get_selected_region_by_group_id($group_id);
            }
            if (is_array($result_country) && count($result_country) > 0) {
                $arr = array();
                foreach ($result_country as $key => $val) {
                    array_push($arr, str_replace(array('(', ')'), "", $val['selected_countries']));
                }
                $retarray['selected_countries'] = $arr;
            } else {
                $retarray['selected_countries'] = array();
            }

            if (is_object($result_region) && !empty($result_region->selected_regions)) {
                $retarray['selected_regions'] = explode(',', $result_region->selected_regions);
                //If World is avaliable as selected region then give empty country array
                if (in_array(1, $retarray['selected_regions'])) {
                    $retarray['selected_countries'] = array();
                }
            } else {
                $retarray['selected_regions'] = array();
            }
            $retarray['total_country']=$this->general_model->get_count_country();
            $retarray['error'] = 0;
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Group list
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_group() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            //Get group
            $retarray['response'] = $this->channel_model->get_group_by_company_id($common_result['company_id']);
            $retarray['error'] = 0;
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Business model list
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_business_model() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            //Get all business model
            $retarray['response']['all_business_model'] = $this->channel_model->get_all_business_model();
            //Get frequently used business model
            $retarray['response']['frequently_used_model'] = $this->channel_model->get_frequently_used_business_model();
            $retarray['error'] = 0;
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Price conversion
     *
     * @access	public
     * @param	access_token,language,group_id,countryArr,business_id,channel_id
     * @return	JSON Array
     */
    public function get_conversion() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $group_id = $this->input->post("group_id");
            $business_model = $this->input->post("business_id");
            $channel_id = $this->input->post("channel_id");
            $countryArr = implode(',', array_unique($this->input->post("countryArr")));
            //Get channel book with price
            $retarray['response'] = $this->channel_model->get_book_for_channel_list($group_id, $countryArr, $business_model, $channel_id);
            $retarray['error'] = 0;
            $retarray['payoutDiscount'] = PUB_SHARE;
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Retailer list
     *
     * @access	public
     * @param	access_token,language,group_id,channel_id,country_id
     * @return	JSON Array
     */
    public function get_retailers() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $group_id = $this->input->post("group_id");
            $channel_id = $this->input->post("channel_id");
            $country_id = $this->input->post("country_id");
            if (empty($group_id) && empty($channel_id)) {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("technical_error");
                $this->output->set_output(json_encode($retarray));
                $this->output->_display();
                exit;
            }
            $retarray['selected_retailers'] = array();
            if (!empty($country_id)) {
                //Get retailers
                $retarray['response'] = $this->channel_model->get_retailers($country_id);
                if (!empty($channel_id)) {
                    $retarray['selected_retailers'] = $this->channel_model->get_selected_retailers($channel_id);
                } 
            }
            $retarray['error'] = 0;
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Create Channel 
     *
     * @access	public
     * @param	access_token,language,channelArr,channelBook,channelCountry,channelRetailer
     * @return	JSON Array
     */
    public function create_channel() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $channel_array = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $channel_array = $this->input->post("channelArr");
            $channel_book_array = $this->input->post("channelBook");
            $channel_country_array = $this->input->post("channelCountry");
            $channel_retailer_array = $this->input->post("channelRetailer");
            if (is_array($channel_array) && count($channel_array) > 0) {
                $result = $this->channel_model->check_channel_name($channel_array['name'], $common_result['company_id'],0);
                if ($result) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line("channel_name_exists");
                    $this->output->set_output(json_encode($retarray));
                    $this->output->_display();
                    exit;
                }
                //Server side validation
                foreach ($channel_array as $key=>$val){
                    $this->form_validation->set_rules("channelArr[".$key."]", $key, 'trim|xss_clean');
                    if(!is_array($channel_array[$key])){
                        ($key=="name")? $this->form_validation->set_rules("channelArr[".$key."]", "Name", 'trim|required|xss_clean'):'';
                        ($key=="startdate")? $this->form_validation->set_rules("channelArr[".$key."]", "Start Date", 'trim|required|xss_clean'):'';
                        ($key=="enddate")? $this->form_validation->set_rules("channelArr[".$key."]", "End Date", 'trim|required|xss_clean'):'';
                        ($key=="group_id")? $this->form_validation->set_rules("channelArr[".$key."]", "Group", 'trim|required|xss_clean'):'';
                        ($key=="businessModelId")? $this->form_validation->set_rules("channelArr[".$key."]", "Business Model", 'trim|required|xss_clean'):'';
                    }
                    
                }
                $created_on = date('Y-m-d H:i:s');
                if ($this->form_validation->run() == FALSE) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = validation_errors();
                } else {
                    //Insert channel data
                    $channel_data = array("company_id" => $common_result['company_id'],
                        "name" => $channel_array['name'],
                        "start_date" => date('Y-m-d', strtotime($channel_array['startdate'])),
                        "end_date" => date('Y-m-d', strtotime($channel_array['enddate'])),
                        "group_id" => $channel_array['group_id'],
                        "business_model_id" => $channel_array['businessModelId'],
                        "business_model_type" => $channel_array['business_model_type'],
                        "global_discount" => $channel_array['adjustDiscount'],
                        "publisher_payout" => ($channel_array['businessModelId']!=1)?$channel_array['payoutDiscount']:0,
                        "retailers_list" => $channel_array['retailers_list'],
                        "status" => 1,
                        "created_on" => $created_on,
                        "created_by" => $common_result['user_id']);
                    $channel_id = $this->channel_model->insert_channel($channel_data);
                    if ($channel_id > 0) {
                        if (!empty($channel_book_array)) {
                            foreach ($channel_book_array as $cbkey => $cbval) {
                                foreach ($cbval as $key => $val) {
                                    //Insert channel book data
                                    $channel_book_data[] = array("channel_id" => $channel_id,
                                        "book_id" => $cbval[$key]['book_id'],
                                        "currency_id" => $cbval[$key]['currency_id'],
                                        "standard_price" => sprintf('%4f',$cbval[$key]['original_digital_list']),
                                        "new_standard_price" => sprintf('%4f',$cbval[$key]['adjusted_selling_price']),
                                        "publisher_share" =>(!empty($cbval[$key]['publisher_share']))? sprintf('%4f',$cbval[$key]['publisher_share']):0,
                                        "created_on" => $created_on,
                                        "created_by" => $common_result['user_id']);
                                }
                            }
                            $this->channel_model->insert_channel_book($channel_book_data);
                            unset($channel_book_data);
                        }
                        if (!empty($channel_country_array)) {
                            foreach ($channel_country_array as $cid => $cname) {
                                //Insert channel country data
                                $channel_country_data[] = array("channel_id" => $channel_id,
                                    "country_id" => $cname,
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }

                            $this->channel_model->insert_channel_country($channel_country_data);
                            unset($channel_country_data);
                        }
                        if (!empty($channel_retailer_array)) {
                            foreach ($channel_retailer_array as $crid => $crname) {
                                //Insert channel retailer data
                                $channel_retailer_data[] = array("channel_id" => $channel_id,
                                    "retailer_id" => $crname,
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }
                            $this->channel_model->insert_channel_retailer($channel_retailer_data);
                            unset($channel_retailer_data);
                        }
                    }
                    $retarray['error'] = 0;
                    $retarray['msg'] = $this->lang->line("channel_create_success");
                }
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Update Channel 
     *
     * @access	public
     * @param	access_token,language,channel_id,channelArr,channelBook,channelCountry,channelRetailer
     * @return	JSON Array
     */
    public function update_channel() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $channel_id = $this->input->post("channel_id");
            $channel_array = $this->input->post("channelArr");
            $channel_book_array = $this->input->post("channelBook");
            $channel_country_array = $this->input->post("channelCountry");
            $channel_retailer_array = $this->input->post("channelRetailer");
            if ((is_array($channel_array) && count($channel_array) > 0) && $channel_id > 0) {
                $result = $this->channel_model->check_channel_name($channel_array['name'], $common_result['company_id'], $channel_id);
                if ($result) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line("channel_name_exists");
                    $this->output->set_output(json_encode($retarray));
                    $this->output->_display();
                    exit;
                }
                //Server side validation
                foreach ($channel_array as $key=>$val){
                    $this->form_validation->set_rules("channelArr[".$key."]", $key, 'trim|xss_clean');
                    if(!is_array($channel_array[$key])){
                        ($key=="name")? $this->form_validation->set_rules("channelArr[".$key."]", "Name", 'trim|required|xss_clean'):'';
                        ($key=="startdate")? $this->form_validation->set_rules("channelArr[".$key."]", "Start Date", 'trim|required|xss_clean'):'';
                        ($key=="enddate")? $this->form_validation->set_rules("channelArr[".$key."]", "End Date", 'trim|required|xss_clean'):'';
                        ($key=="group_id")? $this->form_validation->set_rules("channelArr[".$key."]", "Group", 'trim|required|xss_clean'):'';
                        ($key=="businessModelId")? $this->form_validation->set_rules("channelArr[".$key."]", "Business Model", 'trim|required|xss_clean'):'';
                    }
                    
                }
                $created_on = date('Y-m-d H:i:s');
                if ($this->form_validation->run() == FALSE) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = validation_errors();
                } else {
                    //Update channel data
                    $channel_data = array("company_id" => $common_result['company_id'],
                        "name" => $channel_array['name'],
                        "start_date" => date('Y-m-d', strtotime($channel_array['startdate'])),
                        "end_date" => date('Y-m-d', strtotime($channel_array['enddate'])),
                        "group_id" => $channel_array['group_id'],
                        "business_model_id" => $channel_array['businessModelId'],
                        "business_model_type" => $channel_array['business_model_type'],
                        "global_discount" => $channel_array['adjustDiscount'],
                        "publisher_payout" => ($channel_array['businessModelId']!=1)?$channel_array['payoutDiscount']:0,
                        "retailers_list" => $channel_array['retailers_list'],
                        "status" => $channel_array['status'],
                        "created_on" => $created_on,
                        "created_by" => $common_result['user_id']);
                    $this->channel_model->update_channel($channel_data, $channel_id);
                    $created_on = date('Y-m-d H:i:s');
                    $deleted_on = date('Y-m-d H:i:s');
                    $delete_channel_data = array("deleted_on" => $deleted_on,
                        "deleted_by" => $common_result['user_id']);
                    $channel_array = array($channel_id);
                    $this->channel_model->delete_channel_data($delete_channel_data, $channel_array, 1);
                    if (!empty($channel_book_array)) {
                        foreach ($channel_book_array as $cbkey => $cbval) {
                            foreach ($cbval as $key => $val) {
                                //Insert channel book data
                                $channel_book_data[] = array("channel_id" => $channel_id,
                                    "book_id" => $cbval[$key]['book_id'],
                                    "currency_id" => $cbval[$key]['currency_id'],
                                    "standard_price" => $cbval[$key]['original_digital_list'],
                                    "new_standard_price" => $cbval[$key]['adjusted_selling_price'],
                                    "publisher_share" => $cbval[$key]['publisher_share'],
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }
                        }
                        $this->channel_model->insert_channel_book($channel_book_data);
                        unset($channel_book_data);
                    }
                    if (!empty($channel_country_array)) {
                        foreach ($channel_country_array as $cid => $cname) {
                            //Insert channel country data
                            $channel_country_data[] = array("channel_id" => $channel_id,
                                "country_id" => $cname,
                                "created_on" => $created_on,
                                "created_by" => $common_result['user_id']);
                        }

                        $this->channel_model->insert_channel_country($channel_country_data);
                        unset($channel_country_data);
                    }
                    if (!empty($channel_retailer_array)) {
                        foreach ($channel_retailer_array as $crid => $crname) {
                            //Insert channel retailer data
                            $channel_retailer_data[] = array("channel_id" => $channel_id,
                                "retailer_id" => $crname,
                                "created_on" => $created_on,
                                "created_by" => $common_result['user_id']);
                        }
                        $this->channel_model->insert_channel_retailer($channel_retailer_data);
                        unset($channel_retailer_data);
                    }
                    $retarray['error'] = 0;
                    $retarray['msg'] = $this->lang->line("channel_update_success");
                }
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Channel detail
     *
     * @access	public
     * @param	access_token,language,channel_id
     * @return	JSON Array
     */
    public function get_channel_detail() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $channel_id = $this->input->post("channel_id");
            if(!empty($channel_id)){
                //Get channel detail
                $retarray['response'] = $this->channel_model->get_channel_detail_by_id($channel_id);
                $retarray['error'] = 0;
            }else{
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

}
