<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('users_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * Login
     *
     * @access	public
     * @param	language,email,password
     * @return	JSON Array
     */
    public function login() {
        $retarray = array();
        $result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        //Set language
        $this->custom_function->set_language($this->input->post('language'));

        //Server side validations
        $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $email = $this->input->post('email');
            $password = md5($this->input->post('password'));

            //User data for validate
            $users_data = array('email' => $email,
                'password' => $password,
                'status' => '1');
            //To check valid user
            $result = $this->users_model->validate_user($users_data);
            if (count($result) > 0) {
                if (!empty($result->user_id)) {

                    $access_token = $this->encrypt->encode($result->user_id, $this->config->item('encryption_key'));

                    $path = realpath(PUBPATH . '../assets/images/userprofile');

                    //Set session data
                    $this->session->set_userdata('user_id', $result->user_id);
                    $this->session->set_userdata('company_id', $result->company_id);
                    $this->session->set_userdata('usertype', $result->usertype);
                    $this->session->set_userdata('access_token', $access_token);

                    //User data
                    $retarray = array('email' => $email,
                        'user_id' => $result->user_id,
                        'first_name' => strip_slashes($result->first_name),
                        'last_name' => strip_slashes($result->last_name),
                        'usertype' => $result->usertype,
                        'logins' => $result->logins,
                        'invited_by' => (!empty($result->invited_by)) ? $result->invited_by : 0,
                        'module_rights' => (!empty($result->rights)) ? array_map('intval', explode(',', $result->rights)) : array(),
                        'photo' => (!empty($result->photo) && file_exists($path . '/' . $result->photo)) ? base_url() . 'assets/images/userprofile/' . $result->photo : base_url() . 'assets/images/userprofile/profilepicture.jpg',
                        'access_token' => $access_token,
                        'error' => 0);
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line("invalid_login");
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("invalid_login");
            }
        }
        $this->output->set_output(json_encode($retarray));
    }
    
    /**
     * Admin Login
     *
     * @access	public
     * @param	language,email,password
     * @return	JSON Array
     */
    public function admin_login() {
        $retarray = array();
        $result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        //Set language
        $this->custom_function->set_language($this->input->post('language'));

        //Server side validations
        $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $email = $this->input->post('email');
            $password = md5($this->input->post('password'));

            //User data for validate
            $users_data = array('email' => $email,
                'password' => $password,
                'status' => '1',
                'c.usertype_id'=>4);
            //To check valid user
            $result = $this->users_model->validate_admin_user($users_data);
            if (count($result) > 0) {
                if (!empty($result->user_id)) {

                    $access_token = $this->encrypt->encode($result->user_id, $this->config->item('encryption_key'));

                    $path = realpath(PUBPATH . '../assets/images/userprofile');

                    //Set session data
                    $this->session->set_userdata('user_id', $result->user_id);
                    $this->session->set_userdata('company_id', $result->company_id);
                    $this->session->set_userdata('usertype', $result->usertype);
                    $this->session->set_userdata('access_token', $access_token);

                    //User data
                    $retarray = array('email' => $email,
                        'user_id' => $result->user_id,
                        'first_name' => strip_slashes($result->first_name),
                        'last_name' => strip_slashes($result->last_name),
                        'usertype' => $result->usertype,                        
                        'photo' => (!empty($result->photo) && file_exists($path . '/' . $result->photo)) ? base_url() . 'assets/images/userprofile/' . $result->photo : base_url() . 'assets/images/userprofile/profilepicture.jpg',
                        'access_token' => $access_token,
                        'error' => 0);
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line("invalid_login");
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("invalid_login");
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Get users login 
     *
     * @access	public
     * @param	access_token,language,usertype_id
     * @return	JSON Array
     */
    public function get_users_logins() {
        $retarray = array();
        $result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        if (!$this->custom_function->check_access_token()) {
            $retarray['error'] = 2;
            $retarray['errorMsg'] = $this->lang->line('session_expired');
            $this->output->set_output(json_encode($retarray));
            $this->output->_display();
            exit;
        }
        //Get user_id
        $user_id = $this->custom_function->get_user_id_from_access_token();
        $usertype_id = $this->input->post('usertype_id');

        if (!empty($user_id) && !empty($usertype_id)) {
            //Insert audit log data
            $auditlog_data = array("user_id" => $user_id,
                "user_ip" => $_SERVER['REMOTE_ADDR'],
                "usertype_id" => $usertype_id,
                "log_date" => date("Y-m-d H:i:s"));
            $this->users_model->add_audit_log($auditlog_data);
            $this->session->set_userdata('usertype', $usertype_id);
            $result = $this->users_model->get_user_login_count($user_id, $usertype_id);
            if (!empty($result)) {
                $retarray['error'] = 0;
                $result_rights = $this->users_model->get_user_module_rights_by_user_id($user_id,$usertype_id);
                if(is_object($result_rights) && !empty($result_rights->rights)){
                    $retarray['module_rights'] = (!empty($result_rights->rights)) ? array_map('intval', explode(',', $result_rights->rights)) : array();
                }
                //User login count
                $retarray['logins'] = $result;
            } else {
                $retarray['error'] = 0;
                $retarray['logins'] = 0;
                $retarray['module_rights']=array();
            }
        } else {
            $retarray['error'] = 1;
            $retarray['logins'] = 0;
            $retarray['module_rights']=array();
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Get users data
     *
     * @access	public
     * @param	string
     * @return	JSON Array
     */
    public function get_users_data() {
        $retarray = array();
        $result = $this->users_model->get_users_data();
        if (is_array($result) && count($result) > 0) {

            for ($i = 0; $i < count($result); $i++) {
                if (!empty($result[$i]->id)) {
                    $retarray[] = array('first_name' => strip_slashes($result[$i]->first_name), 'last_name' => strip_slashes($result[$i]->last_name), 'email' => $result[$i]->email);
                }
            }
        }
        $this->output->set_output(json_encode($retarray));                
    }

    /**
     * Forgot password
     *
     * @access	public
     * @param	language,email
     * @return	JSON Array
     */
    public function forgot_password() {
        $retarray = array();
        $result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        //Set language
        $this->custom_function->set_language($this->input->post('language'));

        //Server side validation
        $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $email = $this->input->post('email');
            //Get user detail
            $result = $this->users_model->get_user_detail_by_email($email);

            if (is_object($result) && count($result) > 0) {
                if ($result->id > 0) {
                    $time = time();
                    $hash = md5($result->id . $time);
                    $data = array(
                        'username' => $result->first_name . (!empty($result->last_name) ? ' ' . $result->last_name : ''),
                        'resetpasswordurl' => base_url() . 'resetpasswordchk?u=' . $this->encrypt->encode($result->id, $this->config->item('encryption_key')) . '&h=' . $hash . '&t=' . $time,
                    );

                    $template = 'emails/forgot_password.php';
                    $subject = 'Forgot password';
                    //Send mail
                    $this->custom_function->send_mail($data, $email, $template, $subject);
                    $retarray['error'] = 0;
                    $retarray['msg'] = $this->lang->line('forgot_email_success');
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('forgot_email');
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('forgot_email');
            }
        }
        $this->output->set_output(json_encode($retarray));
    }
    
    /**
     * Forgot password for admin
     *
     * @access	public
     * @param	language,email
     * @return	JSON Array
     */
    public function admin_forgot_password() {
        $retarray = array();
        $result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        //Set language
        $this->custom_function->set_language($this->input->post('language'));

        //Server side validation
        $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $email = $this->input->post('email');
            //Get user detail
            $result = $this->users_model->get_admin_detail_by_email($email);

            if (is_object($result) && count($result) > 0) {
                if ($result->id > 0) {
                    $time = time();
                    $hash = md5($result->id . $time);
                    $data = array(
                        'username' => $result->first_name . (!empty($result->last_name) ? ' ' . $result->last_name : ''),
                        'resetpasswordurl' => base_url() . 'admin/resetpasswordchk?u=' . $this->encrypt->encode($result->id, $this->config->item('encryption_key')) . '&h=' . $hash . '&t=' . $time,
                    );

                    $template = 'emails/forgot_password.php';
                    $subject = 'Forgot password';
                    //Send mail
                    $this->custom_function->send_mail($data, $email, $template, $subject);
                    $retarray['error'] = 0;
                    $retarray['msg'] = $this->lang->line('forgot_email_success');
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('admin_forgot_email');
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('admin_forgot_email');
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Check reset password url
     *
     * @access	public
     * @param	language,user_id,time,hash
     * @return	JSON Array
     */
    public function check_reset_password_url() {
        $retarray = array();
        $result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        //Set language
        $this->custom_function->set_language($this->input->post('language'));
        if (!empty($this->input->post('user_id')))
            $user_id = $this->input->post('user_id');

        //Get user confirm status
        $result = $this->users_model->get_user_confirm_status_by_id($user_id);
        if (is_object($result) && count($result) > 0) {
            if ($result->status == 0) {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('account_inactive');
                $this->output->set_output(json_encode($retarray));
                $this->output->_display();
                exit;
            }
        }
        $original_time = $this->input->post('time');
        $original_hash = $this->input->post('hash');
        $encrypt_key = $this->config->item('encryption_key');
        $original_userid = $this->encrypt->decode($user_id, $encrypt_key);

        if (!empty($original_userid) && !empty($original_hash)) {
            $hash = md5($original_userid . $original_time);
            if ($hash == $original_hash) {
                if (!empty($original_time)) {
                    if ($original_time > time() - 24 * 60 * 60) {
                        $retarray['error'] = 0;
                    } else {
                        $retarray['error'] = 1;
                        $retarray['errorMsg'] = $this->lang->line('link_expired');
                    }
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('link_expired');
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Reset password
     *
     * @access	public
     * @param	language,new_password,user_id
     * @return	JSON Array
     */
    public function reset_password() {
        $retarray = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        //Set language
        $this->custom_function->set_language($this->input->post('language'));

        //Server side validation
        $this->form_validation->set_rules('new_password', 'Password', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $encrypt_key = $this->config->item('encryption_key');
            $user_id = $this->encrypt->decode($this->input->post('user_id'), $encrypt_key);
            $new_password = md5($this->input->post('new_password'));
            $modified_on = date('Y-m-d H:i:s');
            if (!empty($user_id)) {
                //Update user data
                $users_data = array('password' => $new_password,
                    'modified_on' => $modified_on,
                    'modified_by' => $user_id);
                $this->users_model->update_user_details($users_data, $user_id);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('reset_password_success');
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Validate token for keep me signed in user
     *
     * @access	public
     * @param	language, access_token
     * @return	JSON Array
     */
    public function validate_token() {
        $retarray = array();
        $result = array();
        $output = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        //Set language
        $this->custom_function->set_language($this->input->post('language'));
        $encrypt_key = $this->config->item('encryption_key');
        if (!empty($this->input->post('access_token'))) {
            $decrypt_access_token = $this->encrypt->decode($this->input->post('access_token'), $encrypt_key);
            if (!empty($decrypt_access_token)) {
                $output = $this->users_model->validate_token($decrypt_access_token);
                if (is_object($output) && count($output) > 0) {
                    //User data
                    $path = realpath(PUBPATH . '../assets/images/userprofile');
                    $retarray['error'] = 0;
                    $retarray['user_id'] = $output->id;
                    $retarray['email'] = $output->email;
                    $retarray['first_name'] = strip_slashes($output->first_name);
                    $retarray['last_name'] = strip_slashes($output->last_name);
                    $retarray['usertype'] = $output->usertype;
                    $retarray['logins'] = $output->logins;
                    $retarray['access_token'] = $this->input->post('access_token');
                    $retarray['photo'] = (!empty($output->photo) && file_exists($path . '/' . $output->photo)) ? base_url() . 'assets/images/userprofile/' . $output->photo : base_url() . 'assets/images/userprofile/profilepicture.jpg';
                } else {
                    $retarray['error'] = 2;
                    $retarray['errorMsg'] = $this->lang->line('session_expired');
                }
            }
        } else {
            $retarray['error'] = 2;
            $retarray['errorMsg'] = $this->lang->line('session_expired');
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Logout
     *
     * @access	public
     * @param	NA
     * @return	JSON Array
     */
    public function logout() {
        $retarray = array();
        //Unset session data
        $this->session->unset_userdata('user_id');
        $this->session->unset_userdata('company_id');
        $this->session->unset_userdata('usertype');
        $this->session->unset_userdata('access_token');
        $retarray['error'] = 0;
        $this->output->set_output(json_encode($retarray));
    }

}
