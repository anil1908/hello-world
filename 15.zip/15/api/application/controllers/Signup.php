<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Signup extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('users_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * Register user
     *
     * @access	public
     * @param	language,usertype,first_name,last_name,company_name,email,password,user_id,company_id
     * @return	JSON Array
     */
    public function register_user() {
        $retarray = array();
        $company_data = array();

        $this->config->load('email');

        $_POST = json_decode(file_get_contents('php://input'), true);
        $this->custom_function->set_language($this->input->post('language'));

        // Server Side Validations
        $this->form_validation->set_rules('usertype', 'Usertype', 'trim|required|xss_clean');
        $this->form_validation->set_rules('first_name', 'First Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('last_name', 'Last Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('company_name', 'Company Name', 'trim|required|xss_clean');
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email|xss_clean|callback_validate_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $usertype = $this->input->post('usertype');
            $company_name = $this->input->post('company_name');
            $first_name = $this->input->post('first_name');
            $last_name = $this->input->post('last_name');
            $email = $this->input->post('email');
            $password = md5($this->input->post('password'));
            $created_on = date('Y-m-d H:i:s');
            if (!empty($this->input->post('user_id')))
                $user_id = $this->input->post('user_id');
            if (!empty($this->input->post('company_id')))
                $company_id = $this->input->post('company_id');
            
            if (!empty($user_id) && !empty($company_id)) {
                $modified_on = date('Y-m-d H:i:s');
                //Update user data
                $users_data = array('first_name' => $first_name,
                    'last_name' => $last_name,
                    'password' => $password,
                    'modified_on' => $modified_on,
                    'modified_by' => $user_id);
                $this->users_model->update_user_details($users_data, $user_id);
            } else {
                //Insert company data
                $company_data = array('usertype_id' => $usertype,
                    'name' => $company_name,
                    'created_on' => $created_on);
                $company_id = $this->users_model->add_company_details($company_data);
                if ($company_id > 0) {
                    //Insert user data
                    $users_data = array('company_id' => $company_id,
                        'first_name' => $first_name,
                        'last_name' => $last_name,
                        'email' => $email,
                        'password' => $password,
                        'is_confirm' => 0,
                        'status' => 0,
                        'created_on' => $created_on);
                    $user_id = $this->users_model->add_user_details($users_data, $usertype);
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('technical_error');
                    $this->output->set_output(json_encode($retarray));
                    $this->output->_display();
                    exit;
                }
            }

            if ($user_id > 0) {
                $data = array(
                    'username' => $first_name . (!empty($last_name) ? ' ' . $last_name : ''),
                    'useremail' => $email,
                    'confirmurl' => base_url() . 'verify?u=' . $this->encrypt->encode($user_id, $this->config->item('encryption_key')),
                );

                $template = 'emails/confirmation.php';
                $subject = 'Confirm your 1World Content account';
                //Send mail
                $this->custom_function->send_mail($data, $email, $template, $subject);
                $retarray['error'] = 0;
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Validate email for duplication
     *
     * @access	public
     * @param	value
     * @return	JSON Array
     */
    public function email_check() {
        $retarray = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        $email = $this->input->post('value');
        if (!empty($email)) {
            //Check exist email
            $result = $this->users_model->email_exists($email);
            $retarray = array('isValid' => $result, 'value' => $email);
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Validate email for duplication
     *
     * @access	public
     * @param	email,user_id
     * @return	boolean
     */
    public function validate_email($email) {
        $_POST = json_decode(file_get_contents('php://input'), true);
        $user_id = $this->input->post('user_id');
        //Check email exist for invited user
        $result = $this->users_model->email_exists_invite($email, $user_id);
        if ($result) {
            return TRUE;
        } else {
            $this->form_validation->set_message('validate_email', $this->lang->line('email_exists'));
            return FALSE;
        }
    }

    /**
     * Validate user from signup link
     *
     * @access	public
     * @param	language,user_id
     * @return	JSON Array
     */
    public function verify_user() {
        $retarray = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        $this->custom_function->set_language($this->input->post('language'));


        $encrypt_key = $this->config->item('encryption_key');
        $original_userid = $this->encrypt->decode($this->input->post('user_id'), $encrypt_key);
        if (!empty($original_userid)) {
            //Check user confirmation status
            $result = $this->users_model->get_user_confirm_status_by_id($original_userid);
            if ($result->is_confirm >= '1') {
                $retarray['msg'] = $this->lang->line('account_already_confirmed');
            } else {
                //Update user data
                $users_data = array('is_confirm' => 1,
                    'status' => 1,
                    'modified_on' => date('Y-m-d H:i:s'),
                    'modified_by' => $original_userid);
                $result = $this->users_model->update_user_confirmation($original_userid, $users_data);
                $retarray['msg'] = $this->lang->line('account_confirmed');
            }
            $retarray['error'] = 0;
        } else {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = $this->lang->line('invalid_user');
        }
        $this->output->set_output(json_encode($retarray));
    }

}
