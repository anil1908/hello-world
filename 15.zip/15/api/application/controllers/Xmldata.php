<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Xmldata extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

//        $this->load->model('xmldata_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        //$xml=simplexml_load_string($xmlData) or die("Error: Cannot create object");
        $xml = simplexml_load_file('xml_file/Canongate.xml') or die("Error: Cannot create object");

        foreach ($xml->Product as $data) {
            set_time_limit(0);

            $company_id = 2;		 	 	 
            $book_title = (!empty($data->DescriptiveDetail->TitleDetail->TitleElement->TitleText) ? $data->DescriptiveDetail->TitleDetail->TitleElement->TitleText : $data->DescriptiveDetail->TitleDetail->TitleElement->TitleWithoutPrefix);
            $sub_title = (!empty($data->DescriptiveDetail->TitleDetail->TitleElement->Subtitle) ? $data->DescriptiveDetail->TitleDetail->TitleElement->Subtitle : '' );	
            $book_description = $data->CollateralDetail->TextContent->Text;	
            $imprint = $data->PublishingDetail->Imprint->ImprintName;
            $this->db->select("id");
            $this->db->from("language");
            $this->db->where("LOWER(code)",strtolower($data->DescriptiveDetail->Language->LanguageCode));
            $sublquery = $this->db->get();
            $array_lang = $sublquery->row();
            $language_id = $array_lang['id'];		

            if(isset($data->DescriptiveDetail->Subject->MainSubject)){
                $this->db->select("id");
                $this->db->from("subjects");
                $this->db->where("LOWER(code)",strtolower($data->DescriptiveDetail->Subject->SubjectCode));
                $subquery = $this->db->get();
                $array = $subquery->row();		
                    if(!empty($array['id']))
                        $main_subject = $array['id'];						
            }


            $publication_date = date('Y-m-d',  strtotime($data->PublishingDetail->PublishingDate->Date));   
            $audience = $data->CollateralDetail->TextContent->ContentAudience;
            $audience = $audience + 1;
            $copyright_year = $data->PublishingDetail->CopyrightStatement->CopyrightYear;	
            if(!empty($data->PublishingDetail->CopyrightStatement->CopyrightOwner->PersonName)){
                $copyright_owner = $data->PublishingDetail->CopyrightStatement->CopyrightOwner->PersonName;	
            }else{
                $copyright_owner = $data->PublishingDetail->CopyrightStatement->CopyrightOwner->CorporateName;
                $supplier_details = $data->ProductSupply->SupplyDetail->Supplier->SupplierName;
                $supply_date = date('Y-m-d',  strtotime($data->ProductSupply->SupplyDetail->SupplyDate->Date)); 
            }

            if(!empty($main_subject)){
                $book_data = array("company_id"=>$company_id,
                                   "title"=>$book_title,
                                   "sub_title"=>$sub_title,
                                   "description"=>$book_description,
                                   "imprint"=>$imprint,
                                   "language_id"=>$language_id,
                                   "main_subject_id"=>$main_subject,
                                   "publication_date"=>$publication_date,
                                   "audience_id"=>$audience,
                                   "copyright_year"=>$copyright_year,
                                   "copyright_owner"=>$copyright_owner,
                                   "supplier_details"=>$supplier_details,
                                   "supply_date"=>$supply_date);
                $this->db->insert("books",$book_data);
            }else{
                $book_data = array("company_id"=>$company_id,
                                   "title"=>$book_title,
                                   "sub_title"=>$sub_title,
                                   "description"=>$book_description,
                                   "imprint"=>$imprint,
                                   "language_id"=>$language_id,
                                   "publication_date"=>$publication_date,
                                   "audience_id"=>$audience,
                                   "copyright_year"=>$copyright_year,
                                   "copyright_owner"=>$copyright_owner,
                                   "supplier_details"=>$supplier_details,
                                   "supply_date"=>$supply_date);
                $this->db->insert("books",$book_data);
            }
            unset($main_subject);
            $last_id = $this->db->insert_id();
            if ($last_id > 0) {
                echo "New book No. " . $last_id . " created successfully," . "<br>";

                //For Awards
                if(!empty($data->CollateralDetail->Prize->PrizeName)){
                    $this->db->select("id");
                    $this->db->from("awards");
                    $this->db->where("LOWER(name)",stripslashes(strtolower($data->CollateralDetail->Prize->PrizeName)));
                    $award_query = $this->db->get();
                    $array = $subquery->row();	
                    $award_code = $data->CollateralDetail->Prize->PrizeCode;
                    $award_year = $data->CollateralDetail->Prize->PrizeYear;

                    if(!empty($data->CollateralDetail->Prize->PrizeCountry)){
                        $this->db->select("id");
                        $this->db->from("country");
                        $this->db->where("LOWER(iso)",strtolower($data->CollateralDetail->Prize->PrizeCountry));
                        $prizequery = $this->db->get();
                        $prizearray = $prizequery->row();						
                    }

                    if(is_array($array) && count($array) > 0 && !empty($array['id'])){
                        //Insert to book_awards
                        $book_award_data = array("book_id"=>$last_id,
                                                 "award_id"=>$array['id'],
                                                 "award_code_id"=>$award_code,
                                                 "year"=>$award_year,
                                                 "country_id"=>$prizearray[0]['id']);
                        $this->db->insert("book_awards",$book_award_data);	
                    }else{
                        $award_data = array("name"=>$data->CollateralDetail->Prize->PrizeName);
                        $this->db->insert("awards",$award_data);	
                        $award_id = $this->db->insert_id();
                        if(!empty($award_id)){
                            $book_award_data = array("book_id"=>$last_id,
                                                 "award_id"=>$award_id,
                                                 "award_code_id"=>$award_code,
                                                 "year"=>$award_year,
                                                 "country_id"=>$prizearray[0]['id']);
                            $this->db->insert("book_awards",$book_award_data);
                        }
                    }
                }	

                //For Contributors
                if(!empty($data->DescriptiveDetail->Contributor->PersonName)){
                    $this->db->select("id");
                    $this->db->from("contributors_people");
                    $this->db->where("LOWER(name)",strtolower($data->DescriptiveDetail->Contributor->PersonName));
                    $cont_query = $this->db->get(); 
                    $contarray = $cont_query->row();	

                    $this->db->select("id");
                    $this->db->from("contributors_role");
                    $this->db->where("LOWER(code)",strtolower($data->DescriptiveDetail->Contributor->ContributorRole));
                    $controle_query = $this->db->get();
                    $controlearray = $controle_query->row();	

                    if(is_array($contarray) && count($contarray) > 0 && !empty($contarray['id'])){
                        $book_contributor_data = array("book_id"=>$last_id,
                                                       "person_id"=>$contarray['id'],
                                                       "role_id"=>$controlearray['id']);
                        $this->db->insert("book_contributors",$book_contributor_data);	
                    }else{
                        $contributor_people_data = array("name"=>$data->DescriptiveDetail->Contributor->PersonName);
                        $this->db->insert("contributors_people",$contributor_people_data);	
                        $person_id = $this->db->insert_id();
                        if(!empty($person_id)){
                            $book_contributor_data = array("book_id"=>$last_id,
                                                       "person_id"=>$person_id,
                                                       "role_id"=>$controlearray['id']);
                            $this->db->insert("book_contributors",$book_contributor_data);
                        }
                    }
                }

                if(!empty($data->DescriptiveDetail->Contributor->CorporateName)){
                    $this->db->select("id");
                    $this->db->from("contributors_people");
                    $this->db->where("LOWER(name)",strtolower($data->DescriptiveDetail->Contributor->CorporateName));
                    $cont_query = $this->db->get(); 
                    $contarray = $cont_query->row();	

                    $this->db->select("id");
                    $this->db->from("contributors_role");
                    $this->db->where("LOWER(code)",strtolower($data->DescriptiveDetail->Contributor->ContributorRole));
                    $controle_query = $this->db->get();
                    $controlearray = $controle_query->row();	

                    if(is_array($contarray) && count($contarray) > 0 && !empty($contarray['id'])){
                        $book_contributor_data = array("book_id"=>$last_id,
                                                       "person_id"=>$contarray['id'],
                                                       "role_id"=>$controlearray['id']);
                        $this->db->insert("book_contributors",$book_contributor_data);
                    }else{
                        $contributor_people_data = array("name"=>$data->DescriptiveDetail->Contributor->CorporateName);
                        $this->db->insert("contributors_people",$contributor_people_data);	
                        $person_id = $this->db->insert_id();
                        if(!empty($person_id)){
                            $book_contributor_data = array("book_id"=>$last_id,
                                                       "person_id"=>$person_id,
                                                       "role_id"=>$controlearray['id']);
                            $this->db->insert("book_contributors",$book_contributor_data);
                        }
                    }
                }

                //For Regions & Country include or exclude
                if(is_object($data->PublishingDetail->SalesRights->Territory)){
                    if(!empty($data->PublishingDetail->SalesRights->Territory->RegionsIncluded)){
                        $this->db->select("id");
                        $this->db->from("regions");
                        $this->db->where("LOWER(code)",strtolower($data->PublishingDetail->SalesRights->Territory->RegionsIncluded));
                        $reg_query = $this->db->get(); 
                        $reg_arr =$reg_query->row();		
                        if(!empty($reg_arr[0]['id'])){
                            $book_region_data = array("book_id"=>$last_id,
                                                      "region_id"=>$reg_arr[0]['id']);
                            $this->db->insert("book_regions",$book_region_data);    
                        }
                    }

                    if(!empty($data->PublishingDetail->SalesRights->Territory->CountriesIncluded)){
                        $this->db->select("id");
                        $this->db->from("country");
                        $this->db->where("LOWER(iso)",strtolower($data->PublishingDetail->SalesRights->Territory->CountriesIncluded));
                        $coun_query = $this->db->get(); 
                        $coun_arr =$coun_query->row();		
                        if(!empty($coun_arr[0]['id'])){
                            $book_country_data = array("book_id"=>$last_id,
                                                       "country_id"=>$coun_arr[0]['id']);
                            $this->db->insert("book_countries",$book_country_data);
                        }
                    }
                }

                //For book identifiers
                if(count($data->ProductIdentifier) > 0){

                    for($x=0;$x<count($data->ProductIdentifier);$x++){
                        $ident_type = $data->ProductIdentifier[$x]->ProductIDType;
                        if(!empty($ident_type)){
                            $this->db->select("id");
                            $this->db->from("identifier_types");
                            $this->db->where("id",$ident_type);
                            $chk_idtype = $this->db->get(); 
                            $typearr = $chk_idtype->row();	
                            if(!empty($typearr['id'])){
                                $book_identifier_data = array("book_id"=>$last_id,
                                                              "identifier_type_id"=>$typearr['id'],
                                                              "identifier_no"=>$data->ProductIdentifier[$x]->IDValue);
                                $this->db->insert("book_identifiers",$book_identifier_data);
                            }
                        }
                    }
                }

                //For book prices		
                if(count($data->ProductSupply->SupplyDetail->Price) > 0){

                    for($p=0;$p<count($data->ProductSupply->SupplyDetail->Price);$p++){
                        $this->db->select("id");
                        $this->db->from("currency");
                        $this->db->where("LOWER(code)",strtolower($data->ProductSupply->SupplyDetail->Price[$p]->CurrencyCode));
                        $currquery = $this->db->get();
                        $array_curr = $currquery->row();
                        $currency_id = $array_curr['id'];

                        if(!empty($data->ProductSupply->SupplyDetail->Price[$p]->PriceAmount)){
                            $book_price_data = array("book_id"=>$last_id,
                                                     "price"=>$data->ProductSupply->SupplyDetail->Price[$p]->PriceAmount,
                                                     "currency_id"=>$currency_id);
                            $this->db->insert("book_prices",$book_price_data);
                            unset($currency_id);
                        }					
                    }
                }


                //For related books		
                if(count($data->RelatedMaterial->RelatedProduct) > 0){

                    for($r=0;$r<count($data->RelatedMaterial->RelatedProduct);$r++){								
                        if(!empty($data->RelatedMaterial->RelatedProduct[$r]->ProductRelationCode)){
                            $ident_type = $data->RelatedMaterial->RelatedProduct[$r]->ProductIdentifier->ProductIDType;
                            if(!empty($ident_type)){
                                $this->db->select("id");
                                $this->db->from("identifier_types");
                                $this->db->where("id",$ident_type);
                                $selidtype = $this->db->get();							
                                $typearr = $selidtype->row();	
                                if(!empty($typearr['id'])){
                                    $book_related_data = array("book_id"=>$last_id,
                                                               "relation_code_id"=>$typearr['id'],
                                                               "identifier_type_id"=>$ident_type,
                                                               "identifier"=>$data->RelatedMaterial->RelatedProduct[$r]->ProductIdentifier->IDValue);
                                    $this->db->insert("book_related",$book_related_data);								
                                }
                            }
                        }					
                    }
                }

                //For related books		
                if(count($data->DescriptiveDetail->Subject) > 0){

                    for($s=0;$s<count($data->DescriptiveDetail->Subject);$s++){								
                        if(!empty($data->DescriptiveDetail->Subject[$s]->SubjectCode)){
                            $this->db->select("id");
                            $this->db->from("subjects");
                            $this->db->where("LOWER(code)",strtolower($data->DescriptiveDetail->Subject[$s]->SubjectCode));
                            $subquery = $this->db->get();						
                            $subarray = $subquery->row();	
                            if(!empty($subarray['id'])){
                                    $book_subject_data = array("book_id"=>$last_id,
                                                               "subject_id"=>$subarray['id']);
                                    $this->db->insert("book_subjects",$book_subject_data);
                            }else{
                                if(!empty($data->DescriptiveDetail->Subject[$s]->SubjectHeadingText)){
                                    $subject_data = array("name"=>$last_id,
                                                          "code"=>$data->DescriptiveDetail->Subject[$s]->SubjectHeadingText."',".$data->DescriptiveDetail->Subject[$s]->SubjectCode);
                                    $this->db->insert("subjects",$subject_data);	
                                    $subject_id = $this->db->insert_id();
                                    if(!empty($subject_id)){
                                        $book_subject_data = array("book_id"=>$last_id,
                                                               "subject_id"=>$subject_id);
                                        $this->db->insert("book_subjects",$book_subject_data);	
                                        unset($subject_id);
                                    }
                                }
                            }
                        }					
                    }
                }
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
        }
    }

}
