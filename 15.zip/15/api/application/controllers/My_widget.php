<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class My_widget extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code

        $this->load->model('my_widget_model');
        $this->load->model('general_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {

    }

    /**
     * My Lists
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_my_widget() {
        $retarray = array();
        $common_result = array();

        //Get user_id and company_id
        $common_result = $this->custom_function->_common();
        if ($common_result['error'] == 0) {
            $retarray['error'] = 0;
            //Get My List
            $retarray['response'] = $this->my_widget_model->get_my_widget_company_id($common_result['company_id']);
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * My List listing
     *
     * @access	public
     * @param	access_token,language,pageStart,pageLimit,sortField,sorttype,search_name,search_from_date,search_to_date,search_created_by
     * @return	JSON Array
     */
    public function get_my_widget_list() {
        $retarray = array();
        $result = array();
        $id_array = array();
        $common_result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);

        //Server side validation
        $this->form_validation->set_rules('widget_name', 'Widget Name', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $search_name = addslashes(strtolower($this->input->post('widget_name')));
            $pageStart = (!empty($this->input->post('pageStart'))) ? $this->input->post('pageStart') : 0;
            $pageLimit = (!empty($this->input->post('pageLimit'))) ? $this->input->post('pageLimit') : 10;
            $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'w.created_on';
            $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'DESC';

            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                $retarray['error'] = 0;
                //Get my list
                $result = $this->my_widget_model->get_my_widget_by_company_id($common_result['company_id'], $pageStart, $pageLimit, $sortField, $sortType, $search_name);
                $retarray['found_rows'] = $this->general_model->found_rows();
                $wherearr = array('company_id' => $common_result['company_id']);
                $retarray['total_rows'] = $this->my_widget_model->get_my_widget_count($common_result['company_id'], $search_name);
                $i = 0;
                if (is_array($result) && count($result) > 0) {
                    $retarray['error'] = 0;
                    foreach ($result as $key => $val) {
                        array_push($id_array, $result[$key]['id']);
                        //My list
                        $retarray['response'][$i] = array('id' => $result[$key]['id'],
                            'name' => strip_slashes($result[$key]['name']),
                            'created_on' => date('m/d/Y', strtotime($result[$key]['created_on'])),
                            'created_by' => $result[$key]['created_by'],
                            'no_of_books' => $result[$key]['no_of_books']
                        );
                        $i++;
                    }
                    //lists ids
                    $retarray['ids'] = implode(',', $id_array);
                } else {
                    $retarray = array("error" => 0,
                        "found_rows" => 0,
                        "total_rows" => 0,
                        "response" => array(),
                        "ids" => '');
                }
            } else {
                $retarray = $common_result;
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Create my widget
     *
     * @access	public
     * @param	widgets,bookArr
     * @return	JSON Array
     */
    public function create_my_widget() {
        $retarray = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $widgets = $this->input->post("widgets");
            $widget_book_array = $this->input->post("bookArr");
            if (is_array($widgets) && count($widgets) > 0) {
                //Check widget name
                $result = $this->my_widget_model->check_widget_name($widgets['widgetname'], $common_result['company_id']);
                if ($result) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line("widget_name_exists");
                    $this->output->set_output(json_encode($retarray));
                    $this->output->_display();
                    exit;
                }
                $created_on = date('Y-m-d H:i:s');
                //Server side validation
                foreach ($widgets as $key=>$val){
                    $this->form_validation->set_rules("widget[".$key."]", $key, 'trim|xss_clean');
                    ($key=="widgetname")? $this->form_validation->set_rules("widgets[".$key."]", "Name", 'trim|required|xss_clean'):'';
                    ($key=="color")? $this->form_validation->set_rules("widgets[".$key."]", "Color", 'trim|required|xss_clean'):'';
                    ($key=="metadata")? $this->form_validation->set_rules("widgets[".$key."]", "Metadata", 'trim|required|xss_clean'):'';
                    ($key=="coversaccross")? $this->form_validation->set_rules("widgets[".$key."]", "Covers Across", 'trim|required|xss_clean'):'';
                    ($key=="coversdown")? $this->form_validation->set_rules("widgets[".$key."]", "Covers Down", 'trim|required|xss_clean'):'';
                    ($key=="placementlogo")? $this->form_validation->set_rules("widgets[".$key."]", "Placement Logo", 'trim|required|xss_clean'):'';
                    ($key=="coverssize")? $this->form_validation->set_rules("widgets[".$key."]", "Covers Size", 'trim|required|xss_clean'):'';
                }

                if ($this->form_validation->run() == FALSE) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = validation_errors();
                } else {
                    //Insert widget data
                    $widget_data = array("company_id" => $common_result['company_id'],
                        "name" => $widgets['widgetname'],
                        "color" => $widgets['color'],
                        "metadata" => $widgets['metadata'],
                        "covers_across" => $widgets['coversaccross'],
                        "covers_down" => $widgets['coversdown'],
                        "is_search" => $widgets['showsearchbox'],
                        "logo_placement" => $widgets['placementlogo'],
                        "cover_size" => $widgets['coverssize'],
                        "css_classes" =>  (!empty($widgets['css_classes']))?$widgets['css_classes']:'',
                        "headline_text" =>  $widgets['hadlinetext'],
                        "created_on" => $created_on,
                        "created_by" => $common_result['user_id']);
//                    echo "<pre>";print_r($widget_data);exit;
                    $widget_id = $this->my_widget_model->insert_widget($widget_data);
                    unset($widget_data);
                    if ($widget_id > 0) {
                        if (is_array($widget_book_array) && count($widget_book_array) > 0) {
                            foreach ($widget_book_array as $key=>$val) {
                                //Insert group book data
                                $widget_book_data[] = array("widget_id" => $widget_id,
                                    "book_id" => $widget_book_array[$key]['book_id'],
                                    "sequence"=>$widget_book_array[$key]['sequence'],
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }
                            $this->my_widget_model->insert_widget_books($widget_book_data,$widget_book_array,$created_on,$common_result['user_id']);

                            $retarray['error'] = 0;
                            $retarray['widget_id'] = $widget_id;
                        } else {
                            $retarray['error'] = 1;
                            $retarray['errorMsg'] = $this->lang->line('technical_error');
                        }
                        $retarray['error'] = 0;
                        $retarray['msg'] = $this->lang->line("widget_create_success");
                    }
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("insufficient_widget_detail");
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    public function get_widget_details_by_id(){
        $retarray = array();

        $_POST = json_decode(file_get_contents('php://input'), true);

        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $widget_id = $this->input->post('widget_id');
            if (!empty($widget_id)) {
                $retarray['error'] = 0;
                //Get widget details
                $retarray['response']['widgets'] = $this->my_widget_model->get_my_widget_details_by_id($widget_id);
                //Get widget book details
                $retarray['response']['book'] = $this->my_widget_model->get_widget_book_details_by_id($widget_id);
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    public function get_widget_details_by_location_and_id(){
        $retarray = array();
        $result = array();
        $result_currency_id = array();
        $currencyArr = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        $widget_id = $this->input->post('widget_id');

//        echo $ip_address = $_SERVER['REMOTE_ADDR'];
//        exit;
        $ip_address = "180.211.99.238";//INR
//            $ip_address = $this->input->post("ip_address");
            //$ip_address="195.34.28.52";
            //$ip_address="50.30.152.130";//CAD
//            $ip_address="85.90.227.224";//bbd
        $result = $this->custom_function->ip_info($ip_address);
//        echo "<pre>";print_r($result);exit;
        if(is_object($result)){
            if(!empty($result->geoplugin_currencyCode)){
                $currency_code = strtolower($result->geoplugin_currencyCode);
                $result_currency_id = $this->my_widget_model->get_currency_id_from_code($currency_code);
                $currencyArr = $result_currency_id->currency_ids;
            }else{
                if(!empty($result->geoplugin_countryCode)){
                    $country_code = $result->geoplugin_countryCode;
                    $result_currency_id = $this->my_widget_model->get_currency_id_from_country_code($country_code);
                    $currencyArr = $result_currency_id->currency_ids;
                }
            }
        }
        
        if (!empty($widget_id) && !empty($currencyArr)) {
            $retarray['error'] = 0;
            //Get widget details
            $retarray['response']['widgets'] = $this->my_widget_model->get_my_widget_details_by_id($widget_id);
            //Get widget book details
            $retarray['response']['book'] = $this->my_widget_model->get_widget_book_details_by_id($widget_id,$currencyArr);
        } else {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = $this->lang->line('technical_error');
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Create my widget
     *
     * @access	public
     * @param	widgets,bookArr
     * @return	JSON Array
     */
    public function update_my_widget() {
        $retarray = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $widget_id = $this->input->post("widget_id");
            $widgets = $this->input->post("widgets");
            $widget_book_array = $this->input->post("bookArr");
            if (is_array($widgets) && count($widgets) > 0) {
                //Check widget name
                $result = $this->my_widget_model->check_widget_name_by_id($widgets['widgetname'],$widget_id);
                if ($result) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line("widget_name_exists");
                    $this->output->set_output(json_encode($retarray));
                    $this->output->_display();
                    exit;
                }
                $modified_on = date('Y-m-d H:i:s');
                //Server side validation
                foreach ($widgets as $key=>$val){
                    $this->form_validation->set_rules("widget[".$key."]", $key, 'trim|xss_clean');
                    ($key=="widgetname")? $this->form_validation->set_rules("widgets[".$key."]", "Name", 'trim|required|xss_clean'):'';
                    ($key=="color")? $this->form_validation->set_rules("widgets[".$key."]", "Color", 'trim|required|xss_clean'):'';
                    ($key=="metadata")? $this->form_validation->set_rules("widgets[".$key."]", "Metadata", 'trim|required|xss_clean'):'';
                    ($key=="coversaccross")? $this->form_validation->set_rules("widgets[".$key."]", "Covers Across", 'trim|required|xss_clean'):'';
                    ($key=="coversdown")? $this->form_validation->set_rules("widgets[".$key."]", "Covers Down", 'trim|required|xss_clean'):'';
                    ($key=="placementlogo")? $this->form_validation->set_rules("widgets[".$key."]", "Placement Logo", 'trim|required|xss_clean'):'';
                    ($key=="coverssize")? $this->form_validation->set_rules("widgets[".$key."]", "Covers Size", 'trim|required|xss_clean'):'';
                }

                if ($this->form_validation->run() == FALSE) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = validation_errors();
                } else {
                    //Insert widget data
                    $widget_data = array("company_id" => $common_result['company_id'],
                        "name" => $widgets['widgetname'],
                        "color" => $widgets['color'],
                        "metadata" => $widgets['metadata'],
                        "covers_across" => $widgets['coversaccross'],
                        "covers_down" => $widgets['coversdown'],
                        "is_search" => $widgets['showsearchbox'],
                        "logo_placement" => $widgets['placementlogo'],
                        "cover_size" => $widgets['coverssize'],
                        "css_classes" =>  (!empty($widgets['css_classes']))?$widgets['css_classes']:'',
                        "headline_text" =>  $widgets['hadlinetext'],
                        "modified_on" => $modified_on,
                        "modified_by" => $common_result['user_id']);
                    $this->my_widget_model->update_widget($widget_data,$widget_id);
                    unset($widget_data);
                    if ($widget_id > 0) {
                        $created_on = date('Y-m-d H:i:s');
                        $deleted_on = date('Y-m-d H:i:s');
                        $delete_widget_data = array("deleted_on"=>$deleted_on,
                                                  "deleted_by"=>$common_result['user_id']);
                        $widget_array = array($widget_id);
                        $this->my_widget_model->delete_widget_data($delete_widget_data,$widget_array,1);
                        if (is_array($widget_book_array) && count($widget_book_array) > 0) {
                            foreach ($widget_book_array as $key=>$val) {
                                //Insert group book data
                                $widget_book_data[] = array("widget_id" => $widget_id,
                                    "book_id" => $widget_book_array[$key]['book_id'],
                                    "sequence"=>$widget_book_array[$key]['sequence'],
                                    "created_on" => $created_on,
                                    "created_by" => $common_result['user_id']);
                            }
                            $this->my_widget_model->insert_widget_books($widget_book_data,$widget_book_array,$created_on,$common_result['user_id']);
                            $retarray['error'] = 0;
                            $retarray['widget_id'] = $widget_id;
                        } else {
                            $retarray['error'] = 1;
                            $retarray['errorMsg'] = $this->lang->line('technical_error');
                        }
                        $retarray['error'] = 0;
                        $retarray['msg'] = $this->lang->line("widget_update_success");
                    }
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("insufficient_widget_detail");
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }


    /**
     * Delete Widget
     *
     * @access	public
     * @param   widgetArr
     * @return	JSON Array
     */
    public function delete_widget() {
        $retarray = array();
        $common_result = array();
        $widget_array = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $widget_array = $this->input->post("widgetArr");
            $deleted_on = date('Y-m-d H:i:s');
            if (is_array($widget_array) && count($widget_array) > 0) {
                //Delete widget data
                $widget_data = array("deleted_on"=>$deleted_on,
                                     "deleted_by"=>$common_result['user_id']);
                $this->my_widget_model->delete_widget_data($widget_data,$widget_array);

                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line("widget_delete_success");
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }
    
    /**
     * Insert payment details
     *
     * @access	public
     * @param	first_name,last_name,card_type,card_number,expiration_date,verification_number,amount,address1,address2,city,country,state,zip_code
     * @return	JSON Array
     */
    public function insert_payment_details() {
        $retarray = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $created_on = date('Y-m-d H:i:s');
        //Server side validation
        $this->form_validation->set_rules("consumer_name","Name", 'trim|required|xss_clean');
        $this->form_validation->set_rules("consumer_email", "email", 'trim|required|xss_clean');
        $this->form_validation->set_rules("contact_no", "Contact Number", 'trim|xss_clean');
        $this->form_validation->set_rules("quantity", "quantity", 'trim|required|xss_clean');

        if ($this->form_validation->run() != FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $PayPalApiUsername = PAYPAL_API_USERNAME; //Paypal API username
            $PayPalApiPassword = PAYPAL_API_PASSWORD; //Paypal API password
            $PayPalApiSignature = PAYPAL_API_SIGNATURE; //Paypal API Signature

            $firstName = urlencode(addslashes($this->input->post('firstName')));
            $lastName = urlencode(addslashes($this->input->post('lastName')));
            $creditCardType = urlencode($this->input->post('creditCardType'));
            $creditCardNumber = urlencode($this->input->post('creditCardNumber'));
            $expDateMonth = urlencode($this->input->post('expDateMonth'));
            $padDateMonth = str_pad($expDateMonth, 2, '0', STR_PAD_LEFT);
            $expDateYear = urlencode($this->input->post('expDateYear'));
            $cvv2Number = urlencode($this->input->post('cvv2Number'));
            $address1 = urlencode(addslashes($this->input->post('address1')));
            $address2 = urlencode(addslashes($this->input->post('address2')));
            $city = urlencode(addslashes($this->input->post('city')));
            $country = urlencode(addslashes($this->input->post('country')));
            $state = urlencode(addslashes($this->input->post('state')));
            $zip = urlencode(addslashes($this->input->post('zip')));

            $paymentAction = urlencode("Sale");
            $currencyCode = urlencode($this->input->post('currency'));
            $amount = urlencode($this->input->post('hidamount'));
            //$amount = urlencode(1.00);
            
            
            $firstName = "test";
            $lastName = "test";
            $creditCardType = "Visa";
            $creditCardNumber = 4111111111111111;
            $expDateMonth = 0616;
            $padDateMonth = 06;
            $expDateYear =2016;
            $cvv2Number =123;
            $address1 ="test";
            $address2 ="test";
            $city ="Ahmedabad";
            $country ="India";
            $state ="Gujarat";
            $zip = 380007;
            $currencyCode ="USD";
            $countryCode ="IN";
            $amount =urlencode(1.00);
            
            $nvpRecurring = '';
            $methodToCall = 'doDirectPayment';
            $email = 'testprojects801@gmail.com';
            
            $nvpstr = '&EMAIL=' . $email . '&PAYMENTACTION=' . $paymentAction . '&AMT=' . $amount . '&CREDITCARDTYPE=' . $creditCardType . '&ACCT=' . $creditCardNumber . '&EXPDATE=' . $padDateMonth . $expDateYear . '&CVV2=' . $cvv2Number . '&FIRSTNAME=' . $firstName . '&LASTNAME=' . $lastName . '&STREET=' . $address1 . '&CITY=' . $city . '&STATE=' . $state . '&ZIP=' . $zip . '&COUNTRYCODE=' . $countryCode . '&CURRENCYCODE=' . $currencyCode . $nvpRecurring;

            $this->load->library('Paypal_pro');
//            $paypalPro = $this->paypal_pro->__construct($PayPalApiUsername, $PayPalApiPassword, $PayPalApiSignature, '', '', PAYPAL_IS_ONLINE, FALSE);
//            $resArray = $paypalPro->hash_call($methodToCall, $nvpstr);
            echo "<pre>";print_r($resArray);exit;
//            $ack = strtoupper($resArray->ACK);
//
//            if (is_array($resArray) && count($resArray) > 0) {
//                $consumer_name = $this->input->post('firstName') . ' ' .$this->input->post('lastName');
//                $consumer_email = addslashes($this->input->post('email'));
//                $contact_no = addslashes($this->input->post('contact_no'));
//                $widget_id = $this->input->post("widget_id");
//                $business_model_id = $this->input->post("business_model_id");
//                $book_id = $this->input->post('book_id');
//                $quantity = $this->input->post("quantity");
//                $currency_id = $this->input->post("currency_id");
//                $transaction_id = $resArray->TRANSACTIONID;
//                $payment_status = $resArray->ACK;
//                $payment_comment = $this->input->post("payment_comment");
//                $payment_date = date('Y-m-d H:i:s');
//                
//                $channel_id = $this->input->post("channel_id");
//            
//                $source = $this->input->post("source");
//                $source_ip = $_SERVER['REMOTE_ADDR'];
//                $result = $this->custom_function->ip_info($ip_address);
//
//                if(is_object($result)){
//                    if(!empty($result->geoplugin_countryCode)){
//                        $country_code = strtolower($result->geoplugin_countryCode);
//                        $result_country = $this->my_widget_model->get_country_id_from_code($country_code);
//                        $source_country = $result_country->country_id;
//                    }
//                }
//                
//                //Insert transaction data
//                $transaction_data = array("consumer_name" => $first_name ." ".$last_name,
//                    "consumer_email" => $consumer_email,
//                    "contact_no" => $contact_no,
//                    "widget_id" => $widget_id,
//                    "business_model_id" =>$business_model_id,
//                    "channel_id" =>$channel_id,
//                    "book_id" => $book_id,
//                    "quantity" =>$quantity,
//                    "transaction_id" =>$transaction_id,
//                    "source" => $source,
//                    "source_ip" => $source_ip,
//                    "source_country" => $source_country,
//                    "payment_status" => $payment_status,
//                    "is_success" => 1,
//                    "payment_date" => $payment_date,
//                    "payment_comment" => $payment_comment,
//                    "created_on" => $created_on);
//                $id = $this->my_widget_model->insert_transaction($transaction_data);
//                if($id > 0){
//                    $retarray['error']=0;
////                    header("location:" . WEBURL . "thankyou?tid=" . $resArray['TRANSACTIONID'] . "&paystatus=" . $resArray["ACK"] . "&message=" . $resArray["L_LONGMESSAGE0"]);
//                }else{
//                    $retarray['error']=1;
//                    $retarray['errorMsg'] = $this->lang->line('technical_error');
//                }
//            }else{
//                $retarray['error']=1;
//                $retarray['errorMsg'] = $this->lang->line('technical_error');
//            }
        }
        $this->output->set_output(json_encode($retarray));
    }

}
