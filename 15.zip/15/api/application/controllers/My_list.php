<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class My_list extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('my_list_model');
        $this->load->model('retailer_catalog_model');
        $this->load->model('general_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * My Lists 
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_my_lists() {
        $retarray = array();
        $common_result = array();

        //Get user_id and company_id
        $common_result = $this->custom_function->_common();
        if ($common_result['error'] == 0) {
            $retarray['error'] = 0;
            //Get My List
            $retarray['response'] = $this->my_list_model->get_my_list_company_id($common_result['company_id']);
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * My List listing
     *
     * @access	public
     * @param	access_token,language,pageStart,pageLimit,sortField,sorttype,search_name,search_from_date,search_to_date,search_created_by
     * @return	JSON Array
     */
    public function get_my_lists_list() {
        $retarray = array();
        $result = array();
        $id_array = array();
        $common_result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);

        //Server side validation
        $this->form_validation->set_rules('search_name', 'List Name', 'trim|xss_clean');
        $this->form_validation->set_rules('search_created_by', 'Created By', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $search_name = addslashes(strtolower($this->input->post('search_name')));
            $search_created_by = addslashes(strtolower($this->input->post('search_created_by')));
            $pageStart = (!empty($this->input->post('pageStart'))) ? $this->input->post('pageStart') : 0;
            $pageLimit = (!empty($this->input->post('pageLimit'))) ? $this->input->post('pageLimit') : 10;
            $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'l.created_on';
            $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'DESC';

            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                $retarray['error'] = 0;
                //Get my list
                $result = $this->my_list_model->get_my_list_by_company_id($common_result['company_id'], $pageStart, $pageLimit, $sortField, $sortType, $search_name, $search_created_by);
                $retarray['found_rows'] = $this->general_model->found_rows();
                $wherearr = array('company_id' => $common_result['company_id']);
                $retarray['total_rows'] = $this->my_list_model->get_my_list_count($common_result['company_id'], $search_name, $search_created_by);
                $i = 0;
                if (is_array($result) && count($result) > 0) {
                    $retarray['error'] = 0;
                    foreach ($result as $key => $val) {
                        array_push($id_array, $result[$key]['id']);
                        //My list
                        $retarray['response'][$i] = array('id' => $result[$key]['id'],
                            'name' => strip_slashes($result[$key]['name']),
                            'created_on' => date('m/d/Y', strtotime($result[$key]['created_on'])),
                            'created_by' => $result[$key]['created_by'],
                            'no_of_books' => $result[$key]['no_of_books']
                        );
                        $i++;
                    }
                    //lists ids 
                    $retarray['ids'] = implode(',', $id_array);
                } else {
                    $retarray = array("error" => 0,
                        "found_rows" => 0,
                        "total_rows" => 0,
                        "response" => array(),
                        "ids" => '');
                }
            } else {
                $retarray = $common_result;
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Create my lists
     *
     * @access	public
     * @param	listOptions,bookArr,list_name,list_id
     * @return	JSON Array
     */
    public function create_my_lists() {
        $retarray = array();
        $common_result = array();
        $book_array = array();
        $list_book_data = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $selection = $this->input->post('listOptions');
            $book_array = $this->input->post("bookArr");
            $created_on = date("Y-m-d H:i:s");
            //New My List
            if ($selection == 1) {
                $list_name = $this->input->post("list_name");

                //Server side validation
                $this->form_validation->set_rules('list_name', 'List Name', 'trim|required|xss_clean');

                if ($this->form_validation->run() == FALSE) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = validation_errors();
                } else {
                    //Check list name
                    $result = $this->my_list_model->check_list_name($list_name, $common_result['company_id']);
                    if ($result) {
                        $retarray['error'] = 1;
                        $retarray['errorMsg'] = $this->lang->line("list_name_exists");
                        $this->output->set_output(json_encode($retarray));
                        $this->output->_display();
                        exit;
                    }
                    //Insert list data
                    $list_data = array("name" => $list_name,
                        "company_id" => $common_result['company_id'],
                        "created_on" => $created_on,
                        "created_by" => $common_result['user_id']);
                    $list_id = $this->my_list_model->insert_lists($list_data);
                }
            }
            //Existing list
            else if ($selection == 2) {
                $list_id = $this->input->post('list_id');
            }
            if (!empty($list_id) && $list_id > 0) {
                if (is_array($book_array) && count($book_array) > 0) {
                    foreach ($book_array as $b) {
                        //Insert list book data
                        $list_book_data[] = array("list_id" => $list_id,
                            "book_id" => $b,
                            "created_on" => $created_on,
                            "created_by" => $common_result['user_id']);
                    }
                    $this->my_list_model->insert_lists_books($list_book_data);
                    $retarray['error'] = 0;
                    $retarray['list_id'] = $list_id;
                    $retarray['msg'] = $this->lang->line("list_create_success");
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('technical_error');
                }
            } else {
                $retarray['error'] = 0;
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * lists details
     *
     * @access	public
     * @param	list_id,book_title,author_name,book_publisher,pageStart,pageLimit
     * @return	JSON Array
     */
    public function lists_details() {
        $retarray = array();
        $result = array();
        $id_array = array();
        $common_result = array();
        
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Server side validation
        $this->form_validation->set_rules('book_title', 'Title', 'trim|xss_clean');
        $this->form_validation->set_rules('author_name', 'Author', 'trim|xss_clean');
        $this->form_validation->set_rules('book_publisher', 'Publisher', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {            
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $list_id = $this->input->post("list_id");

            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {

                $retarray['error'] = 0;
                $pageStart = (!empty($this->input->post('pagestart'))) ? $this->input->post('pagestart') : 0;
                $pageLimit = (!empty($this->input->post('pagelimit'))) ? $this->input->post('pagelimit') : 10;
                $search_title = addslashes(strtolower($this->input->post('book_title')));
                $search_author = addslashes(strtolower($this->input->post('author_name')));
                $search_publisher = addslashes(strtolower($this->input->post('book_publisher')));
                if (!empty($list_id)) {
                    //Get list details
                    $result_list = $this->my_list_model->get_my_list_details_by_id($list_id);
                    if (is_object($result_list) && count($result_list) > 0) {
                        //list data
                        $retarray['response']['lists'] = array("id" => $result_list->id,
                            "name" => strip_slashes($result_list->name),
                            "created_on" => $result_list->created_on,
                            "first_name" => strip_slashes($result_list->first_name));
                    }
                    //Get lists books details
                    $retarray['response']['books'] = $this->my_list_model->get_book_details_by_list_id($common_result['user_id'], $list_id, $pageStart, $pageLimit, $search_title, $search_author, $search_publisher);                    
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('technical_error');
                }
            } else {
                $retarray = $common_result;
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Update list name
     *
     * @access	public
     * @param   access_token,language,list_name,list_id
     * @return	JSON Array
     */
    public function update_lists_name() {
        $retarray = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {

            //Server side validation
            $this->form_validation->set_rules('list_name', 'List Name', 'trim|required|xss_clean');

            if ($this->form_validation->run() == FALSE) {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = validation_errors();
            } else {
                $list_name = $this->input->post('list_name');
                $list_id = $this->input->post('list_id');
                if (!empty($list_id)) {
                    //Check list name
                    $result = $this->my_list_model->check_list_name_by_id($list_name, $list_id);
                    if (!$result) {
                        $modified_on = date('Y-m-d H:i:s');
                        //Update list data
                        $list_data = array("name" => $list_name,
                            "modified_on" => $modified_on,
                            "modified_by" => $common_result['user_id']);
                        $this->my_list_model->update_list_name($list_data, $list_id);
                        $retarray['error'] = 0;
                        $retarray['msg'] = $this->lang->line("list_name_update_success");
                    } else {
                        $retarray['error'] = 1;
                        $retarray['errorMsg'] = $this->lang->line("list_name_exists");
                    }
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('technical_error');
                }
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Delete lists books
     *
     * @access	public
     * @param	list_bookArr,list_id
     * @return	JSON Array
     */
    public function delete_lists_books() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $lists_book_array = array();
        $lists_book_data = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $created_on = date('Y-m-d H:i:s');
            $lists_book_array = $this->input->post("list_bookArr");
            $list_id = $this->input->post('list_id');

            if (is_array($lists_book_array) && count($lists_book_array) > 0) {
                //Get lists books
                $result = $this->my_list_model->get_lists_books($lists_book_array, $list_id);
                if (is_array($result) && count($result) > 0) {
                    foreach ($result as $r) {
                        //Insert lists book history data
                        $lists_book_data[] = array("list_id" => $r['list_id'],
                            "book_id" => $r['book_id'],
                            "created_on" => $created_on,
                            "created_by" => $common_result['user_id']);
                    }
                    $this->my_list_model->insert_history_lists_books($lists_book_data);
                    $this->my_list_model->delete_lists_books($lists_book_array,$list_id);
                    $retarray['error'] = 0;
                    $retarray['msg'] = $this->lang->line("lists_book_delete_success");
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("select_book");
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Delete lists 
     *
     * @access	public
     * @param	listArr
     * @return	JSON Array
     */
    public function delete_list() {
        $retarray = array();
        $common_result = array();
        $lists_array = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $lists_array = $this->input->post("listArr");

            $created_on = date('Y-m-d H:i:s');
            if (is_array($lists_array) && count($lists_array) > 0) {
                //Get list books
                $result = $this->my_list_model->get_lists_books_by_lists_id($lists_array);

                //Lists having books
                if (is_array($result) && count($result) > 0) {
                    foreach ($result as $r) {
                        //Insert list book history data
                        $lists_book_data[] = array("list_id" => $r['list_id'],
                            "book_id" => $r['book_id'],
                            "created_on" => $created_on,
                            "created_by" => $common_result['user_id']);
                    }
                    $this->my_list_model->insert_history_lists_books($lists_book_data);
                    $this->my_list_model->delete_lists_books_by_lists_id($lists_array);
                }
                $result = $this->my_list_model->get_lists_name($lists_array);

                if (is_object($result) && !empty($result->lists_names)) {
                    $lists_names = explode(',', $result->lists_names);
                    $main_lists_array = array_combine($lists_array, $lists_names);

                    foreach ($main_lists_array as $id => $name) {
                        //Insert list history data
                        $lists_data[] = array("company_id" => $common_result['company_id'],
                            "list_id" => $id,
                            "name" => $name,
                            "created_on" => $created_on,
                            "created_by" => $common_result['user_id']);
                    }
                    $this->my_list_model->insert_history_lists($lists_data);
                    $this->my_list_model->delete_lists_by_id($lists_array);
                }

                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line("list_delete_success");
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }
    
    /**
     * Create widget from my list
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_my_lists_book_details_by_id() {
        $retarray = array();
        $common_result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $retarray['error'] = 0;
            $list_id = $this->input->post("list_id");
            //Get list book details by id
            $result = $this->my_list_model->get_my_lists_book_details_by_id($list_id);
            if(is_object($result) && !empty($result->book_ids)){
                //Retailer catalog
                $retarray['response'] = $this->retailer_catalog_model->get_retailer_catalog_by_id($common_result['user_id'],$curation_id=0,$search='',$business_model_id=0,1,$result->book_ids,NULL,NULL,1);
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

}
