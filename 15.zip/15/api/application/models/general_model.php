<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class General_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }
    
    /**
     * Get module master data
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_modules() {
        $query = $this->db->get('modules');
        return $query->result();
    }

    //found number of rows
    public function found_rows() {
        $iFilteredTotal = 0;
        $this->db->select('FOUND_ROWS() AS found_rows');
        $iFilteredTotal = $this->db->get()->row()->found_rows;
        return $iFilteredTotal;
    }

    //total number of rows
    public function total_rows($wherearr, $sTable) {
        $iTotal = 0;
        $this->db->from($sTable);
        $this->db->where($wherearr);
        $iTotal = $this->db->count_all_results();
        return $iTotal;
    }

    /**
     * Contributor role
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_contributors_role() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("contributors_role");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Contributor people
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_contributors_people() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("contributors_people");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Language
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_language() {
        $retarray = array();
        $this->db->select("id,name");
        $this->db->order_by("name", "ASC");
        $query = $this->db->get("language");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Subject
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_subject($subject_name = '') {
        $retarray = array();
        $this->db->select("id,name");
        if (!empty($subject_name)) {
            $this->db->where("LOWER(name) LIKE %$subject_name%");
        }
        $query = $this->db->get("subjects");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Identifier type
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_identifier_types() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("identifier_types");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Region
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_regions() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("regions");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Country by region
     *
     * @access	public
     * @param	region_array
     * @return	Array
     */
    public function get_country_by_region($region_array) {
        $retarray = array();
        if (is_array($region_array) && count($region_array) > 0) {

            $this->db->select("id,name");
            if (!in_array(1, $region_array)) {
                $this->db->where_in("region_id", $region_array);
            }
            $this->db->order_by("name", "ASC");
            $query = $this->db->get("country");
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Review type
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_review_type() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("review_type");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Review Source
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_review_source() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("review_source");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Review date role
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_review_date_role() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("review_date_role");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Awards
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_awards() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("awards");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Award code
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_awards_code() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("awards_code");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Audience
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_audience() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("audience");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Relation code
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_relation_code() {
        $retarray = array();
        $this->db->select("id,name");
        $query = $this->db->get("relation_code");
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Currency
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_currency() {
        $retarray = array();
        $this->db->select("id,code,seq_no");
        $this->db->from("currency");
        $this->db->where("code<>", "");
        $this->db->group_by("code");
        $this->db->order_by("seq_no,code", "ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Company by id
     *
     * @access	public
     * @param	company_id
     * @return	Array
     */
    public function get_company_name_by_id($company_id) {
        $retarray = array();
        if (!empty($company_id)) {
            $this->db->select("id,name");
            $this->db->from("company");
            $this->db->where("id", $company_id);

            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Count country
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_count_country() {
        $iTotal = 0;
        $this->db->select("count(id) as total_record");
        $query = $this->db->get("country");
        if ($query->num_rows() > 0) {
            $result = $query->row();
            $iTotal = $result->total_record;
        }
        return $iTotal;
    }

}
