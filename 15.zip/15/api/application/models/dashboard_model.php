<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Company details by id
     *
     * @access	public
     * @param	company_id
     * @return	Array
     */
    public function get_company_details_by_id($company_id) {
        $retarray = array();
        if (!empty($company_id)) {
            $this->db->select("c.name,c.logo,u.usertype");
            $this->db->from("company c");
            $this->db->join("usertypes u", "u.id=c.usertype_id");
            $this->db->where("c.id", $company_id);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

}
