<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class User_profile_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * User details
     *
     * @access	public
     * @param	user_id
     * @return	Array
     */
    public function get_user_details_by_id($user_id) {
        $retarray = array();
        if (!empty($user_id)) {
            $this->db->select("first_name,last_name,email,photo");
            $this->db->where("id", $user_id);
            $query = $this->db->get("users");
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Invited User details
     *
     * @access	public
     * @param	user_id
     * @return	Array
     */
    public function get_invited_user_details_by_id($user_id) {
        $retarray = array();
        if (!empty($user_id)) {
            $this->db->select("u.id as user_id,u.first_name,u.last_name,u.email,u.company_id,c.name as company_name,c.usertype_id as usertype");
            $this->db->from('users u');
            $this->db->join('company c', 'c.id=u.company_id', 'LEFT');
            $this->db->where("u.id", $user_id);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Update user details
     *
     * @access	public
     * @param	user_id,users_data 
     * @return	NA
     */
    public function update_users_data_by_id($users_data, $user_id) {
        if ((is_array($users_data) && count($users_data) > 0) && !empty($user_id)) {
            $this->db->where("id", $user_id);
            $this->db->update("users", $users_data);
        }
    }

    /**
     * User modules by usertype
     *
     * @access	public
     * @param	usertype_id
     * @return	Array
     */
    public function get_modules_by_usertype($usertype_id) {
        $retarray = array();
        if (!empty($usertype_id)) {
            $this->db->select('id,name');
            $this->db->where('usertype_id', $usertype_id);
            $query = $this->db->get('modules');
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * User details and rights
     *
     * @access	public
     * @param	user_id
     * @return	Array
     */
    public function get_user_details_with_rights($user_id) {
        $retarray = array();
        if (!empty($user_id)) {
            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select('u.id,u.first_name,u.last_name,u.email,GROUP_CONCAT(DISTINCT CONCAT(umr.module_id,"-",m.name))as rights');
            $this->db->where('u.id', $user_id);
            $this->db->from('users u');
            $this->db->join('users_module_rights umr', 'u.id=umr.user_id AND (umr.deleted_by < 1 OR umr.deleted_by =0)', 'LEFT');
            $this->db->join('modules m', 'm.id=umr.module_id', 'LEFT');
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * User rights
     *
     * @access	public
     * @param	user_id,modulearray
     * @return	NA
     */
    public function get_user_rights_by_id($modulearray, $user_id) {
        $retarray = array();
        if (!empty($user_id) && (is_array($modulearray) && count($modulearray) > 0)) {
            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select('GROUP_CONCAT(module_id) as module_ids');
            $this->db->where_in('module_id', $modulearray);
            $this->db->where("deleted_by < 1 OR deleted_by = 0");
            $query = $this->db->get("users_module_rights");
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Insert user module rights
     *
     * @access	public
     * @param	data
     * @return	NA
     */
    public function insert_user_module_rights($data) {
        if (is_array($data) && count($data) > 0) {
            $this->db->insert_batch('users_module_rights', $data);
        }
    }

    /**
     * Remove user module rights
     *
     * @access	public
     * @param	module_data,user_id
     * @return	NA
     */
    public function delete_user_module_rights($module_data, $user_id) {
        if (!empty($user_id)) {
            $this->db->where('user_id', $user_id);
            $this->db->update('users_module_rights', $module_data);
        }
    }

    /**
     * Retailer preference
     *
     * @access	public
     * @param	user_id
     * @return	Array
     */
    public function get_retailer_preferences($user_id) {
        $retmodelarray = array();
        $retcountryarray = array();
        $retlangarray = array();
        $retarray = array();
        $retmarkup = array();
        if (!empty($user_id)) {
            $this->db->select('business_model_id');
            $this->db->where('retailer_id', $user_id);
            $query = $this->db->get("retailer_preference_business_models");
            if ($query->num_rows() > 0) {
                $retmodelarray = $query->result_array();
                if (is_array($retmodelarray) && count($retmodelarray) > 0) {
                    for ($i = 0; $i < count($retmodelarray); $i++) {
                        $retarray['businessmodel_id'][] = $retmodelarray[$i]['business_model_id'];
                    }
                }
            }

            $this->db->select('c.id,c.name,rpc.is_primary_selling_country');
            $this->db->from('retailer_preference_country rpc');
            $this->db->join('country c', 'rpc.country_id = c.id');
            $this->db->where('rpc.retailer_id', $user_id);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retcountryarray = $query->result_array();
                if (is_array($retcountryarray) && count($retcountryarray) > 0) {
                    for ($i = 0; $i < count($retcountryarray); $i++) {
                        if ($retcountryarray[$i]['is_primary_selling_country'] > 0) {
                            $retarray['main_country_id'] = $retcountryarray[$i]['id'];
                        }
                        $retarray['country_id'][] = array('id' => $retcountryarray[$i]['id'],
                            'name' => strip_slashes($retcountryarray[$i]['name']));
                    }
                }
            }

            $this->db->select('language_id');
            $this->db->where('retailer_id', $user_id);
            $query = $this->db->get("retailer_preference_language");
            if ($query->num_rows() > 0) {
                $retlangarray = $query->result_array();
                if (is_array($retlangarray) && count($retlangarray) > 0) {
                    for ($i = 0; $i < count($retlangarray); $i++) {
                        $retarray['language_id'][] = $retlangarray[$i]['language_id'];
                    }
                }
            }

            $this->db->select('default_markup_over_cost');
            $this->db->where('retailer_id', $user_id);
            $query = $this->db->get("retailer_preference_markup");
            if ($query->num_rows() > 0) {
                $retmarkup = $query->row();
                if (!empty($retmarkup->default_markup_over_cost)) {
                    $retarray['markup'] = ((float) $retmarkup->default_markup_over_cost);
                }
            }
        }
        return $retarray;
    }

    /**
     * Update Retailer Preference Data
     *
     * @access	public
     * @param	modelarr, countryarr, langarr, main_country_id, markup, user_id
     * @return	NA
     */
    public function update_retailer_preferences($modelarr, $countryarr, $langarr, $main_country_id, $markup, $user_id) {
        $insarr = array();
        if (is_array($modelarr) && count($modelarr) > 0) {
            $this->db->where("retailer_id", $user_id);
            $this->db->delete("retailer_preference_business_models");
            if (!in_array(3, $modelarr)) {
                $this->db->where("retailer_id", $user_id);
                $this->db->delete("retailer_preference_markup");
            }
            for ($m = 0; $m < count($modelarr); $m++) {
                $insarr[] = array('business_model_id' => $modelarr[$m],
                    'retailer_id' => $user_id,
                    'created_on' => date('Y-m-d H:i:s'),
                    'created_by' => $user_id);
            }
            if (is_array($insarr) && count($insarr) > 0) {
                $this->db->insert_batch('retailer_preference_business_models', $insarr);
                unset($insarr);
            }
        }

        if (is_array($countryarr) && count($countryarr) > 0) {
            $this->db->where("retailer_id", $user_id);
            $this->db->delete("retailer_preference_country");
            for ($m = 0; $m < count($countryarr); $m++) {
                //Setting primary selling country
                if ($countryarr[$m] == $main_country_id) {
                    $insarr[] = array('country_id' => $countryarr[$m],
                        'is_primary_selling_country' => 1,
                        'retailer_id' => $user_id,
                        'created_on' => date('Y-m-d H:i:s'),
                        'created_by' => $user_id);
                } else {
                    $insarr[] = array('country_id' => $countryarr[$m],
                        'retailer_id' => $user_id,
                        'is_primary_selling_country' => 0,
                        'created_on' => date('Y-m-d H:i:s'),
                        'created_by' => $user_id);
                }
            }
            if (is_array($insarr) && count($insarr) > 0) {
                $this->db->insert_batch('retailer_preference_country', $insarr);
                unset($insarr);
            }
        }

        if (is_array($langarr) && count($langarr) > 0) {
            $this->db->where("retailer_id", $user_id);
            $this->db->delete("retailer_preference_language");
            for ($m = 0; $m < count($langarr); $m++) {
                $insarr[] = array('language_id' => $langarr[$m],
                    'retailer_id' => $user_id,
                    'created_on' => date('Y-m-d H:i:s'),
                    'created_by' => $user_id);
            }
            if (is_array($insarr) && count($insarr) > 0) {
                $this->db->insert_batch('retailer_preference_language', $insarr);
                unset($insarr);
            }
        }

        if (isset($markup) && $markup > 0) {
            $this->db->select("id");
            $this->db->where("retailer_id='" . $user_id . "'");
            $query = $this->db->get('retailer_preference_markup');
            if ($query->num_rows() > 0) {
                $insarr = array('default_markup_over_cost' => $markup,
                    'retailer_id' => $user_id,
                    'modified_on' => date('Y-m-d H:i:s'),
                    'modified_by' => $user_id);
                $this->db->where('retailer_id', $user_id);
                $this->db->update('retailer_preference_markup', $insarr);
                unset($insarr);
            } else {
                $insarr = array('default_markup_over_cost' => $markup,
                    'retailer_id' => $user_id,
                    'created_on' => date('Y-m-d H:i:s'),
                    'created_by' => $user_id);
                $this->db->insert("retailer_preference_markup", $insarr);
                unset($insarr);
            }
        }
    }

}
