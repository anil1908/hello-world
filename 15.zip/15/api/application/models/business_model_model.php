<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Business_model_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Business model category
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_business_model_category() {
        $retarray = array();
        $this->db->select('id,LOWER(category_name) as name');
        $query = $this->db->get('business_model_category');
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Business model list
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_business_model_list() {
        $retarray = array();
        $this->db->select('id,name,short_description');
        $query = $this->db->get('business_models');
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Business model category list
     *
     * @access	public
     * @param	category_id,user_id,sortField,sortType
     * @return	Array
     */
    public function get_business_model_category_list_by_id($category_id, $user_id, $sortField, $sortType) {
        $retarray = array();
        $val = '';
        if (!empty($category_id)) {
            $this->db->select("bm.category_id as id,bm.id as model_id,bm.name,bm.short_description,bm.long_description,IF(ufb.id IS NULL, 0, 1) as isfav");
            $this->db->from("business_models bm");
            $this->db->join("business_model_category c", "c.id = bm.category_id", "LEFT");
            $this->db->join("users_favourite_business_model ufb", "ufb.business_model_id = bm.id AND ufb.user_id = $user_id", "LEFT");
            if ($category_id != 'fav') {
                $this->db->where('bm.category_id', $category_id);
            } else {
                $this->db->where('ufb.user_id', $user_id);
            }
            $this->db->order_by($sortField, $sortType);

            $query = $this->db->get();

            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Business model associative details by id
     *
     * @access	public
     * @param	modelid,company_id
     * @return	Array
     */
    public function get_model_associative_details_by_id($modelid, $company_id) {
        $retarray_channels = array();
        $retarray_groups = array();
        $retarray_books = array();
        $resultarr = array();
        if (!empty($modelid)) {
            //Query for associative channels
            $this->db->select("name as channel_name");
            $this->db->from("channels");
            $this->db->where("business_model_id = $modelid AND company_id = $company_id AND (deleted_by < 1 OR deleted_by = 0) AND status = 1 ");
            $this->db->order_by('name', 'ASC');
            $query = $this->db->get();

            if ($query->num_rows() > 0) {
                $resultarr['channel_data'] = $query->result_array();
            }

            //Query for associative groups
            $this->db->select("g.name as group_name");
            $this->db->from("groups g");
            $this->db->join("channels c", "c.group_id = g.id AND c.company_id = g.company_id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->where("c.business_model_id = $modelid  AND c.company_id = $company_id AND c.status = 1 ");
            $this->db->group_by('g.id');
            $this->db->order_by('g.name', 'ASC');
            $query = $this->db->get();

            if ($query->num_rows() > 0) {
                $resultarr['group_data'] = $query->result_array();
            }

            //Query for associative books
            $this->db->select("b.title as book_name");
            $this->db->from("books b");
            $this->db->join("channels_books cb", "cb.book_id = b.id AND (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            $this->db->join("channels c", "c.id = cb.channel_id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->where("c.business_model_id = $modelid  AND c.company_id = $company_id AND c.status = 1 AND (b.deleted_by < 1 OR b.deleted_by = 0) ");
            $this->db->group_by('b.id');
            $this->db->order_by('b.title', 'ASC');
            $query = $this->db->get();

            if ($query->num_rows() > 0) {
                $resultarr['book_data'] = $query->result_array();
            }
        }
        return $resultarr;
    }

    /**
     * Insert Business model category list to favourite
     *
     * @access	public
     * @param	favourite_data
     * @return	NA
     */
    public function insert_user_favourite_business_model($favourite_data) {
        if (is_array($favourite_data) && count($favourite_data) > 0) {
            $this->db->insert("users_favourite_business_model", $favourite_data);
        }
    }

    /**
     * Delete Business model category list from favourite
     *
     * @access	public
     * @param	unfavourite_data
     * @return	NA
     */
    public function delete_user_favourite_business_model($unfavourite_data) {
        if (is_array($unfavourite_data) && count($unfavourite_data) > 0) {
            $this->db->where($unfavourite_data);
            $this->db->delete("users_favourite_business_model");
        }
    }

}
