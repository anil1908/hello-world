<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class My_widget_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->model('retailer_catalog_model');
    }

    /**
     * My widget
     *
     * @access	public
     * @param	company_id
     * @return	Array
     */
    public function get_my_widget_company_id($company_id) {
        $retarray = array();
        if (!empty($company_id)) {
            $this->db->select("id,name");
            $this->db->where("company_id =$company_id AND (deleted_by < 1 OR deleted_by =0)");
            $query = $this->db->get("widgets");
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * My widget by company id
     *
     * @access	public
     * @param	company_id,pageStart, pageLimit, sortField, sortType, search_name,search_from_date,search_to_date, search_created_by
     * @return	Array
     */
    public function get_my_widget_by_company_id($company_id, $pageStart, $pageLimit, $sortField, $sortType, $search_name) {
        $retarray = array();
        if (!empty($company_id)) {
            $this->db->select("w.id,w.name,w.created_on,CONCAT(u.first_name,' ',u.last_name)as created_by,COUNT(wb.book_id)as no_of_books");
            $this->db->from("widgets w");
            $this->db->join("widgets_books wb", "w.id=wb.widget_id AND (wb.deleted_by < 1 OR wb.deleted_by = 0)", "LEFT");
            $this->db->join("users u", "u.id=w.created_by");
            $this->db->where("(w.deleted_by < 1 OR w.deleted_by =0)");
            if (!empty($search_name)) {
                $this->db->where("(LOWER(w.name) LIKE '%$search_name%')");
            }

            $this->db->where("w.company_id",$company_id);
            $this->db->group_by('w.id');
            $this->db->order_by($sortField, $sortType);
            $this->db->limit($pageLimit, $pageStart);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Count my list
     *
     * @access	public
     * @param	company_id,search_name
     * @return	count of rows
     */
    public function get_my_widget_count($company_id, $search_name) {
        $iTotal = 0;
        $result = array();
        if (!empty($company_id)) {
            $this->db->select("COUNT(w.id) as num_rows");
            $this->db->from("widgets w");
            $this->db->join("users u", "u.id=w.created_by", "LEFT");
            $this->db->where("(w.deleted_by < 1 OR w.deleted_by =0)");
            if (!empty($name_search)) {
                $this->db->where("(LOWER(w.name) LIKE '%$search_name%')");
            }
            $this->db->where("w.company_id",$company_id);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $result = $query->row();
                $iTotal = $result->num_rows;
            }
        }
        return $iTotal;
    }

    /**
     * My List Detail
     *
     * @access	public
     * @param	list_id
     * @return	Array
     */
    public function get_my_widget_details_by_id($widget_id) {
        $retarray = array();
        if (!empty($widget_id)) {
            $this->db->select("id as widget_id,name as widgetname,color,metadata,covers_across as coversaccross,covers_down as coversdown,is_search as showsearchbox,logo_placement as placementlogo,cover_size as coverssize,headline_text as hadlinetext,css_classes");
            $this->db->from("widgets");
            $this->db->where("id=$widget_id AND (deleted_by < 1 OR deleted_by = 0)");
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Check widget name
     *
     * @access	public
     * @param	widget_name,widget_id
     * @return	boolean
     */
    public function check_widget_name_by_id($widget_name, $widget_id) {
        $retarray = array();
        if (!empty($widget_id) && !empty($widget_name)) {
            $this->db->where("id<>", $widget_id);
            $this->db->where("LOWER(name)", strtolower($widget_name));
            $this->db->where("(deleted_by < 1 OR deleted_by =0)");
            $query = $this->db->get("widgets");

            if ($query->num_rows() > 0) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }


    /**
     * Book Details of my lists
     *
     * @access	public
     * @param	retailer_id,list_id, pageStart, pageLimit, search_title, search_author, search_publisher
     * @return	Array
     */
    public function get_book_details_by_list_id($retailer_id, $list_id, $pageStart, $pageLimit, $search_title, $search_author, $search_publisher) {
        $retarray = array();
        $bookidarray = array();
        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        if (!empty($list_id)) {
            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select("b.id as book_id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,b.publication_date,b.imprint,cm.name as publisher,c.retailers_list,cr.retailer_id");
            $this->db->from("my_lists_books lb");
            $this->db->join("books b", "b.id=lb.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("company cm", "cm.id=b.company_id", "LEFT");
            $this->db->join("book_contributors bc", "bc.role_id=1 AND lb.book_id = bc.book_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)", "LEFT");
            $this->db->join("contributors_people cp", "cp.id=bc.person_id", "LEFT");
            $this->db->from("channels_books as cb", "cb.book_id=b.id AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            $this->db->join("channels as c", "cb.channel_id = c.id AND c.status = 1 AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->join("channels_retailers as cr", "c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)", "LEFT");
            $this->db->join("users as u", "u.id=$retailer_id AND u.status = 1");
            $this->db->join("currency as cu", "cb.currency_id = cu. id");
            $this->db->join("retailer_preference_country as rpc", "rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id");
            $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id", "LEFT");
            $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
            $this->db->join("business_models bm", "bm.id = c.business_model_id");
            $this->db->where("lb.list_id",$list_id);
            if (!empty($search_title)) {
                $this->db->where("LOWER(b.title) LIKE '%$search_title%'");
            }
            if (!empty($search_author)) {
                $this->db->where("LOWER(cp.name) LIKE '%$search_author%'");
            }

            if (!empty($search_publisher)) {
                $this->db->where("LOWER(cm.name) LIKE '%$search_publisher%'");
            }

            $this->db->order_by("b.id,rpc.country_id", "DESC");
            $this->db->order_by("cu.seq_no,cu.code", "ASC");
            $this->db->group_by("b.id,c.retailers_list");
            $this->db->limit($pageLimit, $pageStart);
            $query = $this->db->get();

            if ($query->num_rows() > 0) {
                $bookarr = $query->result_array();
                if (is_array($bookarr) && count($bookarr) > 0) {
                    $c = 0;
                    $d = 0;
                    $cnt = 0;
                    foreach ($bookarr as $key => $val) {
                        if (($bookarr[$key]['retailers_list'] == 'Blacklist' && $bookarr[$key]['retailer_id'] == $retailer_id) || ($bookarr[$key]['retailers_list'] == 'Whitelist' && $bookarr[$key]['retailer_id'] != $retailer_id)) {

                        } else {
                            if (in_array($bookarr[$key]['book_id'], $bookidarray)) {
                                continue;
                            } else {
                                array_push($bookidarray, $bookarr[$key]['book_id']);
                                $retarray[$c]['book_id'] = $bookarr[$key]['book_id'];
                                $retarray[$c]['title'] = strip_slashes($bookarr[$key]['title']);
                                $retarray[$c]['author'] = $bookarr[$key]['author'];
                                $retarray[$c]['image'] = (!empty($bookarr[$key]['image']) && file_exists($path . '/' . $bookarr[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $bookarr[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                                $retarray[$c]['price'] = $this->retailer_catalog_model->get_retailer_catalog_price_by_id($bookarr[$key]['book_id'], $retailer_id);
                                $c++;
                            }
                        }
                    }
                }
            }
        }

        return strip_slashes($retarray);
    }

    /**
     * Count of Book Details
     *
     * @access	public
     * @param	list_id,search_title, search_author, search_publisher
     * @return	count of rows
     */
    public function get_book_details_count($list_id, $search_title, $search_author, $search_publisher) {
        $iTotal = 0;
        $result = array();
        if (!empty($list_id)) {
            $this->db->select("COUNT(gb.id) as num_rows");
            $this->db->from("my_lists_books lb");
            $this->db->join("books b", "b.id=lb.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("company c", "c.id=b.company_id", "LEFT");
            $this->db->join("book_contributors bc", "bc.role_id=1 AND lb.book_id = bc.book_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)", "LEFT");
            $this->db->join("contributors_people cp", "cp.id=bc.person_id", "LEFT");
            $this->db->where("lb.list_id",$list_id);
            if (!empty($search_title)) {
                $this->db->where("LOWER(b.title) LIKE '%$search_title%'");
            }
            if (!empty($search_author)) {
                $this->db->where("LOWER(cp.name) LIKE '%$search_author%'");
            }

            if (!empty($search_publisher)) {
                $this->db->where("LOWER(c.name) LIKE '%$search_publisher%'");
            }
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $result = $query->row();
                $iTotal = $result->num_rows;
            }
        }
        return $iTotal;
    }

    /**
     * Check My List name
     *
     * @access	public
     * @param	widget name,company_id
     * @return	boolean
     */
    public function check_widget_name($widget_name, $company_id) {
        if (!empty($company_id)) {
            $this->db->where("company_id",$company_id);
            $this->db->where("name",$widget_name);
            $this->db->where("(deleted_by < 1 OR deleted_by =0)");
            $query = $this->db->get("widgets");
            if ($query->num_rows() > 0) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }

    /**
     * Insert widget
     *
     * @access	public
     * @param	widget_data
     * @return	widget_id
     */
    public function insert_widget($widget_data) {
        $widget_id = 0;
        if (is_array($widget_data) && count($widget_data) > 0) {
            $this->db->insert("widgets", $widget_data);
            $widget_id = $this->db->insert_id();
        }
        return $widget_id;
    }

    /**
     * Insert widget books
     *
     * @access	public
     * @param	widget_book_data, widget_book_array, created_on, created_by
     * @return	NA
     */
    public function insert_widget_books($widget_book_data,$widget_book_array,$created_on,$created_by) {
        $retarray = array();
        if (is_array($widget_book_data) && count($widget_book_data) > 0) {
            $this->db->custom_insert_batch("widgets_books", $widget_book_data);
            $total_affected_rows = $this->db->affected_rows();
            $first_id = $this->db->insert_id();
            $last_id = ($first_id + $total_affected_rows - 1);

            if (!empty($first_id) && !empty($last_id)) {
                    $i = $first_id;
                    if (!empty($widget_book_array)) {
                        foreach ($widget_book_array as $key=>$val){
                                foreach ($widget_book_array[$key]['business_model'] as $bmkey=>$bmval){
                                        $business_model_id = $widget_book_array[$key]["business_model"][$bmkey]["business_model_id"];
                                        if($widget_book_array[$key]["business_model"][$bmkey]["is_visible"])
                                        $is_visible = 1;
                                        else
                                        $is_visible = 0;
                                        $query = "INSERT widgets_books_models (widget_book_id, business_model_id, is_visible, created_on, created_by)
                                                  VALUES($i,$business_model_id,$is_visible,'$created_on','$created_by')";
                                        $this->db->query($query);
                                        if($business_model_id==3){
                                            $widget_business_model_id = $this->db->insert_id();
                                            if($widget_book_array[$key]['is_business_model']==true){
                                                foreach ($widget_book_array[$key]['book_price'] as $bpkey=>$bpval){
                                                    $widget_book_price_data[] = array("widget_book_model_id"=>$widget_business_model_id,
                                                    "channel_id"=>$widget_book_array[$key]['book_price'][$bpkey]['channel_id'],
                                                    "book_id"=>$widget_book_array[$key]['book_price'][$bpkey]['book_id'],
                                                    "currency_id"=>$widget_book_array[$key]['book_price'][$bpkey]['currency_id'],
                                                    "original_digital_price"=>$widget_book_array[$key]['book_price'][$bpkey]['original_digital_list'],
                                                    "selling_price"=>$widget_book_array[$key]['book_price'][$bpkey]['selling_price'],
                                                    "custom_selling_price"=>$widget_book_array[$key]['book_price'][$bpkey]['custom_selling_price'],
                                                    "is_custom_price"=>$widget_book_array[$key]['book_price'][$bpkey]['is_custom_price'],
                                                    "created_on"=>$created_on,
                                                    "created_by"=>$created_by);
                                                }
                                            }
                                        }
                                    }
                                    $i++;
                        }
                        if(!empty($widget_book_price_data)){
                            $this->my_widget_model->insert_widget_books_price($widget_book_price_data);
                        }
                    }
                }
        }
        return $retarray;
    }

    /**
     * Insert widget books price
     *
     * @access	public
     * @param	widget_book_price_data
     * @return	NA
     */
    public function insert_widget_books_price($widget_book_price_data) {
        $retarray = array();
        if (is_array($widget_book_price_data) && count($widget_book_price_data) > 0) {
            $this->db->custom_insert_batch("widgets_books_price", $widget_book_price_data);
        }
        return $retarray;
    }

    /**
     * Update Widget
     *
     * @access	public
     * @param	widget_data, widget_id
     * @return	NA
     */
    public function update_widget($widget_data, $widget_id) {
        if ((is_array($widget_data) && count($widget_data) > 0) && !empty($widget_id)) {
            $this->db->where("id", $widget_id);
            $this->db->update("widgets", $widget_data);
        }
    }

    /**
     * Widget book details
     *
     * @access	public
     * @param	widget_id, currencyArr,
     * @return	Array
     */
    public function get_widget_book_details_by_id($widget_id, $currencyArr=array()) {
        $retarray = array();
        $bookarr = array();
        $business_model_array = array();
        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        $currency_id=array();
        if(!empty($currencyArr)){
           $currency_id = $currencyArr;
        }

        $this->db->simple_query('SET SESSION group_concat_max_len=15000');
        $this->db->select("wb.id as widget_book_id,GROUP_CONCAT(wbm.business_model_id) as business_model_id,b.id as book_id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,rpm.default_markup_over_cost");
        $this->db->from("widgets_books wb");
        $this->db->join("widgets w","w.id=wb.widget_id AND (w.deleted_by < 1 OR w.deleted_by =0)");
        $this->db->join("books b", "wb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
        $this->db->join("widgets_books_models wbm","wb.id=wbm.widget_book_id");
        $this->db->join("book_contributors bc", "b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)", "LEFT");
        $this->db->join("contributors_people cp", "cp.id=bc.person_id", "LEFT");
        $this->db->join("retailer_preference_markup as rpm", "rpm.retailer_id=wb.created_by", "LEFT");
        $this->db->where("w.id = $widget_id AND (wb.deleted_by < 1 OR wb.deleted_by =0)");
        $this->db->group_by("b.id");
        $this->db->order_by("wb.sequence","ASC");
        $query = $this->db->get();
//        echo $this->db->last_query();exit;
        if ($query->num_rows() > 0) {
            $bookarr = $query->result_array();
            if (is_array($bookarr) && count($bookarr) > 0) {
                $c = 0;
                foreach ($bookarr as $key => $val) {
                        if(!empty($bookarr[$key]['business_model_id'])){
                            $business_model_array = explode(',',$bookarr[$key]['business_model_id']);
                        }
                        $retarray[$c]['book_id'] = $bookarr[$key]['book_id'];
                        $retarray[$c]['title'] = strip_slashes($bookarr[$key]['title']);
                        $retarray[$c]['author'] = $bookarr[$key]['author'];
                        $retarray[$c]['image'] = (!empty($bookarr[$key]['image']) && file_exists($path . '/' . $bookarr[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $bookarr[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                        $retarray[$c]['default_markup'] = (!empty($bookarr[$key]['default_markup_over_cost']))?$bookarr[$key]['default_markup_over_cost'] :0;
                        $retarray[$c]['business_model'] = $this->get_widget_business_model_by_id($bookarr[$key]['widget_book_id']);
                        $retarray[$c]['price'] = $this->get_widget_book_price_by_id($bookarr[$key]['book_id'], $widget_id, $currency_id,$business_model_array);
                        $c++;
                }
            }
        }
        return $retarray;
    }

    /**
     * Widget business model details
     *
     * @access	public
     * @param	widget_book_id
     * @return	Array
     */
    public function get_widget_business_model_by_id($widget_book_id){
        $retarray = array();
        if(!empty($widget_book_id)){
            $this->db->select("bm.id,bm.name,bm.short_description as short_desc,IF(wbm.is_visible, 'true', 'false') as is_visible");
            $this->db->from("widgets_books_models wbm");
            $this->db->join("business_models bm","bm.id=wbm.business_model_id");
            $this->db->where("(wbm.deleted_by < 1 OR wbm.deleted_by = 0) AND wbm.widget_book_id=$widget_book_id");
            $query = $this->db->get();
            if($query->num_rows() > 0){
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Currency id from code
     *
     * @access	public
     * @param	currency_code
     * @return	Array
     */
    public function get_currency_id_from_code($currency_code){
        $retarray = array();
        if(!empty($currency_code)){
            $this->db->select("GROUP_CONCAT(id) as currency_ids");
            $this->db->from("currency");
            $this->db->where("LOWER(code)",$currency_code);
            $query = $this->db->get();
            if($query->num_rows() > 0){
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Currency id from country code
     *
     * @access	public
     * @param	currency_code
     * @return	Array
     */
    public function get_currency_id_from_country_code($country_code){
        $retarray = array();
        if(!empty($country_code)){
            $this->db->select("GROUP_CONCAT(c.id) as currency_ids");
            $this->db->from("currency c");
            $this->db->join("country cou","cou.id=c.country_id");
            $this->db->where("LOWER(cou.iso)",$country_code);
            $query = $this->db->get();
            if($query->num_rows() > 0){
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Widget book price
     *
     * @access	public
     * @param	book_id, widget_id, currency_id , business_model_array
     * @return	Array
     */
    public function get_widget_book_price_by_id($book_id, $widget_id, $currency_id ,$business_model_array) {
        $retarray = array();
        $pricearr = array();
        $country_id ='';
        if(is_array($business_model_array) && count($business_model_array) > 0){
            foreach ($business_model_array as $bm){

                if($bm==3){
                    $this->db->select("rpm.default_markup_over_cost,wbp.channel_id,wbp.book_id,wbp.original_digital_price,wbp.selling_price,wbp.custom_selling_price,wbp.is_custom_price,wbp.currency_id,(CASE WHEN cu.symbol IS NOT NULL THEN cu.symbol else cu.code end)as symbol,cu.id as currency_id,cu.code,bm.id as bm_id,bm.name as bm_name,bm.short_description as short_desc");
                    $this->db->from("widgets_books_price wbp");
                    $this->db->join("widgets_books_models as wbm","wbm.id=wbp.widget_book_model_id AND (wbm.deleted_by < 1 OR wbm.deleted_by = 0)");
                    $this->db->join("widgets_books as wb","wb.book_id in($book_id) AND wbm.widget_book_id = wb.id AND wb.book_id=wbp.book_id AND (wb.deleted_by < 1 OR wb.deleted_by = 0)");
                    $this->db->join("widgets w","wb.widget_id = w.id AND (`w`.`deleted_by` < 1 OR `w`.`deleted_by` = 0)");
                    $this->db->join("books as b", "wb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
                    $this->db->join("currency as cu", "wbp.currency_id = cu. id");
                    $this->db->join("retailer_preference_country as rpc", "rpc.retailer_id =wbp.created_by AND cu.country_id = rpc.country_id");
                    $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id", "LEFT");
                    $this->db->join("retailer_preference_markup as rpm", "rpm.retailer_id=wbp.created_by", "LEFT");
                    $this->db->join("business_models bm", "bm.id = wbm.business_model_id");
                    $this->db->where("w.id=$widget_id AND (wbp.deleted_by < 1 OR wbp.deleted_by = 0) AND wbm.is_visible=1");
                    if(!empty($currency_id)){
                        $this->db->where("wbp.currency_id in ($currency_id)");
                    }
                    $this->db->order_by("wbp.channel_id,b.id,rpc.country_id", "DESC");
                    $this->db->order_by("cu.seq_no,cu.code", "ASC");
                    $this->db->group_by("wbp.currency_id");
                    $query_price = $this->db->get();
                }else {
                    $this->db->select("rpm.default_markup_over_cost,c.id as channel_id,cb.book_id,cb.new_standard_price as original_digital_price,cb.new_standard_price as selling_price,cb.currency_id,(CASE WHEN cu.symbol IS NOT NULL THEN cu.symbol else cu.code end)as symbol,cu.id as currency_id,cu.code,bm.id as bm_id,bm.name as bm_name,bm.short_description as short_desc");
                    $this->db->from("channels_books cb");
                    $this->db->join("widgets_books wb","wb.book_id = cb.book_id AND  (`wb`.`deleted_by` < 1 OR `wb`.`deleted_by` = 0)");
                    $this->db->join("books b","b.id = wb.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
                    $this->db->join("widgets_books_models wbm","wb.id = wbm.widget_book_id AND wbm.is_visible=1 AND (wbm.deleted_by < 1 OR wbm.deleted_by = 0)");
                    $this->db->join("currency as cu","cu.id = cb.currency_id");
                    $this->db->join("widgets w","wb.widget_id = w.id AND (w.deleted_by < 1 OR w.deleted_by = 0)");
                    $this->db->join("channels c","cb.channel_id = c.id AND wbm.business_model_id = c.business_model_id AND   (c.deleted_by < 1 OR c.deleted_by = 0)");
                    $this->db->join("channels_retailers cr", "c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)", "LEFT");
                    $this->db->join("retailer_preference_markup rpm", "rpm.retailer_id=w.created_by", "LEFT");
                    $this->db->join("business_models bm","bm.id = c.business_model_id");
                    if(!empty($currency_id)){
                        $this->db->where("cb.currency_id in ($currency_id)");
                    }else{
                        $this->db->join("retailer_preference_country rpc", "rpc.retailer_id ='".$this->session->userdata('user_id')."' AND cu.country_id = rpc.country_id");
                        $this->db->join("country cou", "rpc.country_id = cou.id AND cu.country_id = cou.id", "LEFT");
                        $country_id .= ",rpc.country_id";
                    }
                    $this->db->where("w.id = $widget_id AND wb.book_id in($book_id) AND c.business_model_id != 3 AND (cb.deleted_by < 1 OR cb.deleted_by = 0)");
                    $this->db->where("((c.retailers_list='All') OR (c.retailers_list='Whitelist' AND cr.retailer_id =w.created_by) OR (c.retailers_list='Blacklist' AND cr.retailer_id !=c.created_by))");
                    $this->db->order_by("c.id,b.id $country_id", "DESC");
                    $this->db->order_by("cu.seq_no,cu.code","ASC");
                    $query_price = $this->db->get();
                }

                 if ($query_price->num_rows() > 0) {
                    $pricearr = $query_price->result_array();
                    if (is_array($pricearr) && count($pricearr) > 0) {
                        $d = 0;
                        foreach ($pricearr as $key => $val) {
                                $channel_id = $pricearr[$key]['channel_id'];
                                if (empty($retarray[$channel_id]['main_price'])) {
                                    $retarray[$channel_id]['main_price'] = $pricearr[$key]['symbol'] . " " .(float) sprintf('%4f',$pricearr[$key]['original_digital_price']) . " " . $pricearr[$key]['bm_name'];
                                    $retarray[$channel_id]['price_list'] = $pricearr[$key]['symbol'] . " " .(float) sprintf('%4f',$pricearr[$key]['original_digital_price']);
                                    $retarray[$channel_id]['selling_price'] = $pricearr[$key]['symbol'] . " " .(float) sprintf('%4f',$pricearr[$key]['selling_price']). " " . $pricearr[$key]['bm_name'];
                                    $retarray[$channel_id]['symbol_val'] = $pricearr[$key]['symbol'];
                                    $retarray[$channel_id]['default_markup'] = (!empty($pricearr[$key]['default_markup_over_cost']))? $pricearr[$key]['default_markup_over_cost']:0;
                                    $retarray[$channel_id]['price_val'] = (float)sprintf('%4f',$pricearr[$key]['original_digital_price']);
                                    $retarray[$channel_id]['business_model'] = $pricearr[$key]['bm_name'] . "-" . $pricearr[$key]['short_desc'];
                                    $retarray[$channel_id]['business_model_id'] = $pricearr[$key]['bm_id'];
                                    $retarray[$channel_id]['business_model_name'] = $pricearr[$key]['bm_name'];
                                    $retarray[$channel_id]['business_model_short_desc'] = $pricearr[$key]['short_desc'];
                                }
                                $retarray[$channel_id]['price'][$d]['channel_id'] = $pricearr[$key]['channel_id'];
                                $retarray[$channel_id]['price'][$d]['book_id'] = $pricearr[$key]['book_id'];
                                $retarray[$channel_id]['price'][$d]['original_digital_list'] = (float) sprintf('%4f',$pricearr[$key]['original_digital_price']);
                                $retarray[$channel_id]['price'][$d]['selling_price'] = (float) sprintf('%4f',$pricearr[$key]['selling_price']);
                                $retarray[$channel_id]['price'][$d]['custom_selling_price'] =(!empty($pricearr[$key]['custom_selling_price']))?(float)  sprintf('%4f',$pricearr[$key]['custom_selling_price']):0;
                                $retarray[$channel_id]['price'][$d]['is_custom_price'] = (!empty($pricearr[$key]['is_custom_price'])) ? (int)$pricearr[$key]['is_custom_price']: 0;
                                $retarray[$channel_id]['price'][$d]['currency_id'] = $pricearr[$key]['currency_id'];
                                $retarray[$channel_id]['price'][$d]['currency_symbol'] = $pricearr[$key]['symbol'];
                                $retarray[$channel_id]['price'][$d]['currency'] = $pricearr[$key]['code'];
                                $d++;
                        }
                    }
                }
            }
        }
        return $retarray;
    }

    /**
     * Delete widget data
     *
     * @access	public
     * @param	widget_data,widget_id,flag
     * @return	NA
     */
    public function delete_widget_data($widget_data, $widget_id ,$flag =0) {
        if (!empty($widget_id) && (is_array($widget_data) && count($widget_data) > 0)) {

            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select("group_concat(id) as widget_book_id");
            $this->db->from("widgets_books");
            $this->db->where_in("widget_id",$widget_id);
            $query = $this->db->get();
            $result = $query->row();
            if(is_object($result) && !empty($result->widget_book_id)){
                $widget_book_id_array = explode(',', $result->widget_book_id);

                $this->db->select("group_concat(id) as widget_books_model_id");
                $this->db->from("widgets_books_models");
                $this->db->where("business_model_id",3);
                $this->db->where_in("widget_book_id", $widget_book_id_array);
                $query_wbm = $this->db->get();
                $result_wbm = $query_wbm->row();
                if(is_object($result_wbm) && !empty($result_wbm->widget_books_model_id)){
                    $widget_books_model_array = explode(',', $result_wbm->widget_books_model_id);
                    $this->db->where_in("widget_book_model_id", $widget_books_model_array);
                    $this->db->update("widgets_books_price", $widget_data);
                }

                $this->db->where_in("widget_book_id", $widget_book_id_array);
                $this->db->update("widgets_books_models", $widget_data);
            }
            $this->db->where_in("widget_id", $widget_id);
            $this->db->update("widgets_books", $widget_data);

            if($flag==0){
                $this->db->where_in("id", $widget_id);
                $this->db->update("widgets", $widget_data);
            }
        }
    }
    
    /**
     * Insert transaction
     *
     * @access	public
     * @param	transaction_data
     * @return	NA
     */
    public function insert_transaction($transaction_data){
        if(is_array($transaction_data) && count($transaction_data) > 0){
            $this->db->insert("transactions", $transaction_data);
        }
    }
    /**
     * Country id
     *
     * @access	public
     * @param	country_code
     * @return	Array
     */
    public function get_country_id_from_code($country_code){
        $retarray = array();
        if(!empty($country_code)){
            $this->db->select("id as country_id");
            $this->db->from("country");
            $this->db->where("LOWER(iso)",$country_code);
            $query = $this->db->get();
            if($query->num_rows() > 0){
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

}
