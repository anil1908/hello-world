<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Retailer_catalog_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Curation list
     *
     * @access	public
     * @param	sortField, sortType, flag, search_name, pageStart, pageLimit
     * @return	Array
     */
    public function get_curation_list($sortField, $sortType, $flag=0, $search_name, $pageStart, $pageLimit) {
        $retarray = array();
        $this->db->select("rc.id,rc.name,DATE_FORMAT(rc.created_on,'%m/%d/%Y') as created_on,CONCAT(u.first_name,' ',u.last_name)as created_by,COUNT(rcb.book_id)as no_of_books");
        $this->db->from("retailer_curation rc");
        $this->db->join("retailer_curation_books rcb", "rc.id=rcb.retailer_curation_id AND (rcb.deleted_by < 0 OR rcb.deleted_by =0)", "LEFT");
        $this->db->join("users u", "u.id=rc.created_by");
        $this->db->where("(rc.deleted_by < 1 OR rc.deleted_by =0)");
        if (!empty($search_name)) {
            $this->db->where("(LOWER(rc.name) LIKE '%$search_name%')");
        }
        $this->db->group_by('rc.id');
        $this->db->order_by($sortField, $sortType);
        if($flag==1){
            $this->db->limit($pageLimit, $pageStart);
        }
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }
    /**
     * Count of curation list
     *
     * @access	public
     * @param	sortField, sortType, flag, search_name, pageStart, pageLimit
     * @return	Array
     */
    public function get_curation_list_count($search_name) {
        $iTotal = 0;
        $result = array();
        $this->db->select("COUNT(DISTINCT rc.id)as num_rows");
        $this->db->from("retailer_curation rc");
        $this->db->join("retailer_curation_books rcb", "rc.id=rcb.retailer_curation_id AND (rcb.deleted_by < 0 OR rcb.deleted_by =0)", "LEFT");
        $this->db->join("users u", "u.id=rc.created_by");
        $this->db->where("(rc.deleted_by < 1 OR rc.deleted_by =0)");
        if (!empty($search_name)) {
            $this->db->where("(LOWER(rc.name) LIKE '%$search_name%')");
        }
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $result = $query->row();
            $iTotal = $result->num_rows;
        }
        return $iTotal;
    }

    /**
     * Retailer Catalog
     *
     * @access	public
     * @param	retailer_id, curation_id, search, business_model_id, flag=0, book_id, pageStart , pageLimit, show_all
     * @return	Array
     */
    public function get_retailer_catalog_by_id($retailer_id, $curation_id, $search, $business_model_id, $flag=0, $book_id=NULL,$pageStart=NULL, $pageLimit=NULL, $show_all=0) {
        $retarray = array();
        $bookarr = array();
        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        $book = '';
        if (!empty($book_id)) {
            $book .= "AND cb.book_id in($book_id)";
        }
        if (!empty($curation_id)) {
            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select("b.id as book_id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,rpm.default_markup_over_cost");
            $this->db->from("channels_books as cb");
            $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("retailer_curation_books as rcb", "rcb.retailer_curation_id= $curation_id AND b.id=rcb.book_id AND (rcb.deleted_by < 1 OR rcb.deleted_by =0)");
            $this->db->join("retailer_curation as rc", "rc.id=rcb.retailer_curation_id AND (rc.deleted_by < 1 OR rc.deleted_by =0)");
            $this->db->join("book_contributors bc", "b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)", "LEFT");
            $this->db->join("contributors_people cp", "cp.id=bc.person_id", "LEFT");
            $this->db->join("channels as c", "cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->join("channels_retailers as cr", "c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)", "LEFT");
            $this->db->join("users as u", "u.id=$retailer_id AND u.status = 1");
            $this->db->join("currency as cu", "cb.currency_id = cu. id");
            $this->db->join("retailer_preference_country as rpc", "rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id");
            $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id", "LEFT");
            $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_markup as rpm", "rpm.retailer_id=$retailer_id", "LEFT");
            $this->db->join("business_models bm", "bm.id = c.business_model_id");
            $this->db->where("c.status = 1 $book AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            $this->db->where("((c.retailers_list='All') OR (c.retailers_list='Whitelist' AND cr.retailer_id =$retailer_id) OR (c.retailers_list='Blacklist' AND cr.retailer_id !=$retailer_id))");
            if (!empty($search)) {
                $this->db->where("((LOWER(b.title) LIKE '%$search%') OR (LOWER(cp.name) LIKE '%$search%'))");
            }
            if (!empty($business_model_id)) {
                $this->db->where_in("c.business_model_id", $business_model_id);
            }
            $this->db->order_by("c.id,b.id,rpc.country_id", "DESC");
            $this->db->order_by("cu.seq_no,cu.code", "ASC");
            $this->db->group_by("b.id");
            //flag=1 for adding all result from all pages
            if($flag==0){
                $this->db->limit($pageLimit, $pageStart);
            }
            $query = $this->db->get();
        } else {

            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select("b.id as book_id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,rpm.default_markup_over_cost");
            $this->db->from("channels_books as cb");
            $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("book_contributors bc", "b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)", "LEFT");
            $this->db->join("contributors_people cp", "cp.id=bc.person_id", "LEFT");
            $this->db->join("channels as c", "cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->join("channels_retailers as cr", "c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)", "LEFT");
            $this->db->join("users as u", "u.id=$retailer_id AND u.status = 1");
            $this->db->join("currency as cu", "cb.currency_id = cu. id");
            $this->db->join("retailer_preference_country as rpc", "rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id");
            $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id", "LEFT");
            $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_markup as rpm", "rpm.retailer_id=$retailer_id", "LEFT");
            $this->db->join("business_models bm", "bm.id = c.business_model_id");
            $this->db->where("c.status = 1 $book AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            $this->db->where("((c.retailers_list='All') OR (c.retailers_list='Whitelist' AND cr.retailer_id =$retailer_id) OR (c.retailers_list='Blacklist' AND cr.retailer_id !=$retailer_id))");
            if (!empty($search)) {
                $this->db->where("((LOWER(b.title) LIKE '%$search%') OR (LOWER(cp.name) LIKE '%$search%'))");
            }
            if (!empty($business_model_id)) {
                $this->db->where_in("c.business_model_id", $business_model_id);
            }
            $this->db->order_by("b.id,rpc.country_id", "DESC");
            $this->db->order_by("cu.seq_no,cu.code", "ASC");
            $this->db->group_by("b.id");            
            //flag=1 for adding all result from all pages
            if($flag==0){
                $this->db->limit($pageLimit, $pageStart);
            }
            $query = $this->db->get();
        }
        if ($query->num_rows() > 0) {
            $bookarr = $query->result_array();
            if (is_array($bookarr) && count($bookarr) > 0) {
                $c = 0;
                foreach ($bookarr as $key => $val) {
                            $retarray[$c]['book_id'] = $bookarr[$key]['book_id'];
                            $retarray[$c]['title'] = strip_slashes($bookarr[$key]['title']);
                            $retarray[$c]['author'] = $bookarr[$key]['author'];
                            $retarray[$c]['image'] = (!empty($bookarr[$key]['image']) && file_exists($path . '/' . $bookarr[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $bookarr[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                            //flag=1 for adding all result from all pages
                            if($flag==0 || $show_all==1){
                                $retarray[$c]['default_markup'] = (!empty($bookarr[$key]['default_markup_over_cost']))?$bookarr[$key]['default_markup_over_cost'] :0;
                                $retarray[$c]['price'] = $this->get_retailer_catalog_price_by_id($bookarr[$key]['book_id'], $retailer_id, $business_model_id);
                                $retarray[$c]['business_model'] = $this->get_retailer_catalog_business_model_by_id($bookarr[$key]['book_id'], $retailer_id);
                            }
                            $c++;
                }
            }
        }
        return $retarray;
    }

    /**
     * Retailer Catalog price
     *
     * @access	public
     * @param	book_id,retailer_id,business_model_id
     * @return	Array
     */
    public function get_retailer_catalog_price_by_id($book_id, $retailer_id, $business_model_id = null) {
        $retarray = array();
        $pricearr = array();
        $channelarray = array();

        $this->db->select("cb.new_standard_price,rpm.default_markup_over_cost as default_markup,c.retailers_list,cr.retailer_id,c.id as channel_id,(CASE WHEN cu.symbol IS NOT NULL THEN cu.symbol else cu.code end)as symbol,cu.id as currency_id,cu.code,bm.id as bm_id,bm.name as bm_name,bm.short_description as short_desc");
        $this->db->from("channels_books as cb");
        $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
        $this->db->join("channels as c", "cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
        $this->db->join("channels_retailers as cr", "c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)", "LEFT");
        $this->db->join("users as u", "u.id=$retailer_id AND u.status = 1");
        $this->db->join("currency as cu", "cb.currency_id = cu. id");
        $this->db->join("retailer_preference_country as rpc", "rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id");
        $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id", "LEFT");
        $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
        $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
        $this->db->join("business_models bm", "bm.id = c.business_model_id");
        $this->db->join("retailer_preference_markup as rpm", "rpm.retailer_id=$retailer_id", "LEFT");
        $this->db->where("c.status = 1 AND cb.book_id in($book_id) AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
        $this->db->where("((c.retailers_list='All') OR (c.retailers_list='Whitelist' AND cr.retailer_id =$retailer_id) OR (c.retailers_list='Blacklist' AND cr.retailer_id !=$retailer_id))");
        if (!empty($business_model_id)) {
            $this->db->where_in("c.business_model_id", $business_model_id);
        }
        $this->db->order_by("c.id,b.id,rpc.country_id", "DESC");
        $this->db->order_by("cu.seq_no,cu.code", "ASC");
        $query_price = $this->db->get();

        if ($query_price->num_rows() > 0) {
            $pricearr = $query_price->result_array();
            if (is_array($pricearr) && count($pricearr) > 0) {
                foreach ($pricearr as $key => $val) {
                        $channel_id = $pricearr[$key]['channel_id'];
                        if (!in_array($channel_id, $channelarray)) {
                            $d = 0;
                            array_push($channelarray, $channel_id);
                        }
                        if (empty($retarray[$channel_id]['main_price'])) {
                            $retarray[$channel_id]['main_price'] = $pricearr[$key]['symbol'] . " " .(float) sprintf('%4f',$pricearr[$key]['new_standard_price']) . " " . $pricearr[$key]['bm_name'];
                            $retarray[$channel_id]['price_list'] = $pricearr[$key]['symbol'] . " " .(float) sprintf('%4f',$pricearr[$key]['new_standard_price']);
                            $retarray[$channel_id]['symbol_val'] = $pricearr[$key]['symbol'];
                            $retarray[$channel_id]['price_val'] = $price_val = (float) sprintf('%4f',$pricearr[$key]['new_standard_price']);
                            $retarray[$channel_id]['default_markup'] = $default_markup = $pricearr[$key]['default_markup'];
                            $sellprice = (($price_val* $default_markup)/100)+$price_val;
                            $retarray[$channel_id]['selling_price'] = (float) sprintf('%0.4f',$sellprice);
                            $retarray[$channel_id]['business_model'] = $pricearr[$key]['bm_name'] . "-" . $pricearr[$key]['short_desc'];
                            $retarray[$channel_id]['business_model_id'] = $pricearr[$key]['bm_id'];
                            $retarray[$channel_id]['business_model_name'] = $pricearr[$key]['bm_name'];
                            $retarray[$channel_id]['business_model_short_desc'] = $pricearr[$key]['short_desc'];
                        }
                        $retarray[$channel_id]['price'][$d]['currency_id'] = $pricearr[$key]['currency_id'];
                        $retarray[$channel_id]['price'][$d]['currency_symbol'] = $pricearr[$key]['symbol'];
                        $retarray[$channel_id]['price'][$d]['currency'] = $pricearr[$key]['code'];
                        $retarray[$channel_id]['price'][$d]['original_digital_list'] = (float) sprintf('%4f',$pricearr[$key]['new_standard_price']);
                        $d++;
                }
            }
        }
        return $retarray;
    }

    /**
     * Retailer Catalog business model
     *
     * @access	public
     * @param	book_id,retailer_id
     * @return	Array
     */
    public function get_retailer_catalog_business_model_by_id($book_id, $retailer_id) {
        $retarray = array();
        if(!empty($book_id) && !empty($retailer_id)){
            $this->db->select("bm.id,bm.name,bm.short_description");
            $this->db->from("channels_books as cb");
            $this->db->join("books as b", "cb.book_id = b.id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("channels as c", "cb.channel_id = c.id AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->join("users as u", "u.id=$retailer_id AND u.status = 1");
            $this->db->join("business_models bm", "bm.id = c.business_model_id");
            $this->db->where("c.status = 1 AND cb.book_id in($book_id) AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            $this->db->group_by("bm.id");
            $query_business_model = $this->db->get();
            if ($query_business_model->num_rows() > 0) {
               $retarray = $query_business_model->result_array();
            }
        }
        return $retarray;
    }


    /**
     * Book Details
     *
     * @access	public
     * @param	book_id
     * @return	Array
     */
    public function get_book_details_by_id($book_id) {
        $retarray = array();
        if (!empty($book_id)) {
            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select("b.id,b.title,b.cover_image as image,b.sub_title,b.volume,b.edition,b.audience_id,b.copyright_year,"
                    . "b.copyright_owner,b.supplier_details,b.supply_date,b.publication_date,b.cover_image,b.title_availability,"
                    . "b.main_subject_id,"
                    . "b.description,b.keywords,CONCAT(b.min_age_range,'-',b.max_age_range) as age_range,CONCAT(b.min_us_grade_range,'-',b.max_us_grade_range)as us_grade_range,"
                    . "GROUP_CONCAT(DISTINCT CONCAT(r.id))as region_id,"
                    . "GROUP_CONCAT(DISTINCT CONCAT(r.name))as region_name,"
                    . "GROUP_CONCAT(DISTINCT CONCAT(con.id,'_',con.name))as country_name,"
                    . "c.name as publisher,b.imprint,l.name as language,l.id as language_id,"
                    . "GROUP_CONCAT(DISTINCT con.name)as countries_included");
            $this->db->from("books b");
            $this->db->join("company c", "c.id=b.company_id", "LEFT");
            $this->db->join("language l", "l.id=b.language_id", "LEFT");
            $this->db->join("book_countries bcon", "b.id=bcon.book_id AND (bcon.deleted_by < 1 OR bcon.deleted_by = 0)", "LEFT");
            $this->db->join("country con", "con.id=bcon.country_id", "LEFT");
            $this->db->join("book_regions br", "b.id=br.book_id AND (br.deleted_by < 1 OR br.deleted_by = 0)", "LEFT");
            $this->db->join("regions r", "r.id=br.region_id", "LEFT");
            $this->db->where("b.id = $book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $query = $this->db->get();

            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Delete curation data
     *
     * @access	public
     * @param	curation_data,curation_id,flag
     * @return	NA
     */
    public function delete_curation_data($curation_data, $curation_id, $flag = 0) {
        if (!empty($curation_id) && (is_array($curation_data) && count($curation_data) > 0)) {
            $this->db->where_in("retailer_curation_id", $curation_id);
            $this->db->update("retailer_curation_books", $curation_data);

            if ($flag == 0) {
                $this->db->where_in("id", $curation_id);
                $this->db->update("retailer_curation", $curation_data);
            }
        }
    }

    /**
     * All Books list
     *
     * @access	public
     * @param	pagelimit, pagestart, sortfield, sorttype,search_title,search_author,search_imprint,search_publisher
     * @return	Array
     */
    public function get_all_books_list($pageStart, $pageLimit, $sortField, $sortType, $search_title, $search_author, $search_imprint, $search_publisher) {
        $retarray = array();
        $this->db->simple_query('SET SESSION group_concat_max_len=15000');
        $this->db->select("b.id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,b.publication_date,b.imprint,"
                . "GROUP_CONCAT(DISTINCT bi.identifier_no)as identifier_no,c.name as publisher");
        $this->db->from("books b");
        $this->db->join("book_identifiers bi", "b.id=bi.book_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)", "left");
        $this->db->join("company c", "c.id=b.company_id", "left");
        $this->db->join("book_contributors bc", "b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)", "left");
        $this->db->join("contributors_people cp", "cp.id=bc.person_id", "left");
        $this->db->where("(b.deleted_by < 1 OR b.deleted_by = 0)");
        if (!empty($search_title)) {
            $this->db->where("(LOWER(b.title) LIKE '%$search_title%')");
        }
        if (!empty($search_author)) {
            $this->db->where("(LOWER(cp.name) LIKE '%$search_author%')");
        }
        if (!empty($search_imprint)) {
            $this->db->where("(LOWER(b.imprint) LIKE '%$search_imprint%')");
        }
        if (!empty($search_publisher)) {
            $this->db->where("(LOWER(c.name) LIKE '%$search_publisher%')");
        }
        $this->db->group_by('b.id');
        $this->db->order_by($sortField, $sortType);
        $this->db->limit($pageLimit, $pageStart);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Maintain Book List Count
     *
     * @access	public
     * @param	search_title,search_author,search_imprint,search_publisher
     * @return	Count of rows
     */
    public function get_all_books_list_count($search_title, $search_author, $search_imprint, $search_publisher) {
        $iTotal = 0;
        $result = array();
        $this->db->select("COUNT(DISTINCT b.id)as num_rows");
        $this->db->from("books b");
        $this->db->join("book_identifiers bi", "b.id=bi.book_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)", "LEFT");
        $this->db->join("identifier_types it", "it.id=bi.identifier_type_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)", "LEFT");
        $this->db->join("company c", "c.id=b.company_id", "LEFT");
        $this->db->join("book_contributors bc", "b.id=bc.book_id AND bc.role_id=1 AND (bc.deleted_by < 1 OR bc.deleted_by =0)", "LEFT");
        $this->db->join("contributors_people cp", "cp.id=bc.person_id", "LEFT");
        $this->db->where("(b.deleted_by < 1 OR b.deleted_by = 0)");
        if (!empty($search_title)) {
            $this->db->where("(LOWER(b.title) LIKE '%$search_title%')");
        }
        if (!empty($search_author)) {
            $this->db->where("(LOWER(cp.name) LIKE '%$search_author%')");
        }
        if (!empty($search_imprint)) {
            $this->db->where("(LOWER(b.imprint) LIKE '%$search_imprint%')");
        }
        if (!empty($search_publisher)) {
            $this->db->where("(LOWER(c.name) LIKE '%$search_publisher%')");
        }
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $result = $query->row();
            $iTotal = $result->num_rows;
        }
        return $iTotal;
    }
    /**
     * Check curation name
     *
     * @access	public
     * @param	curation_name
     * @return	Boolean
     */
    public function check_curation_name($curation_name) {
        if (!empty($curation_name)) {
            $this->db->where("(deleted_by < 1 OR deleted_by = 0)");
            $this->db->where("name",$curation_name);
            $query = $this->db->get("retailer_curation");
            if ($query->num_rows() > 0) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }
    /**
     * Insert curation
     *
     * @access	public
     * @param	curation_data
     * @return	curation_id
     */
    public function insert_curation($curation_data){
        $curation_id =0;
        if(is_array($curation_data) && count($curation_data) > 0){
            $this->db->insert("retailer_curation", $curation_data);
            $curation_id = $this->db->insert_id();
        }
        return $curation_id;
    }

    /**
     * Book list by selection
     *
     * @access	public
     * @param	NA
     * @return	Array
     */
    public function get_book_list_by_selection() {
        $retarray = array();
        $this->db->select("id,title,cover_image as image");
        $this->db->from("books");
        $this->db->where("(deleted_by < 1 OR deleted_by = 0)");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $retarray = $query->result_array();
        }
        return $retarray;
    }

    /**
     * Curation Detail
     *
     * @access	public
     * @param	curation_id
     * @return	Array
     */
    public function get_curation_details_by_id($curation_id) {
        $retarray = array();
        if (!empty($curation_id)) {
            $this->db->select("rc.id,rc.name");
            $this->db->from("retailer_curation rc");
            $this->db->where("rc.id",$curation_id);
            $this->db->where("(deleted_by < 1 OR deleted_by =0)");
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Book Details of curation
     *
     * @access	public
     * @param	curation_id
     * @return	Array
     */
    public function get_book_details_by_curation_id($curation_id) {
        $retarray = array();
        if (!empty($curation_id)) {
            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select("b.id,b.title,GROUP_CONCAT(DISTINCT cp.name) as author,b.publication_date,b.imprint,GROUP_CONCAT(DISTINCT bi.identifier_no) as identifier_no,c.name as publisher");
            $this->db->from("retailer_curation_books rcb");
            $this->db->join("books b", "b.id=rcb.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("book_identifiers bi", "b.id=bi.book_id AND (bi.deleted_by < 1 OR bi.deleted_by = 0)", "LEFT");
            $this->db->join("identifier_types it", "it.id=bi.identifier_type_id", "LEFT");
            $this->db->join("company c", "c.id=b.company_id", "LEFT");
            $this->db->join("book_contributors bc", "bc.role_id=1 AND rcb.book_id = bc.book_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)", "LEFT");
            $this->db->join("contributors_people cp", "cp.id=bc.person_id", "LEFT");
            $this->db->where("rcb.retailer_curation_id=$curation_id AND (rcb.deleted_by < 1 OR rcb.deleted_by = 0)");
            $this->db->group_by("rcb.id");
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Check curation name
     *
     * @access	public
     * @param	curation_name,curation_id
     * @return	boolean
     */
    public function check_curation_name_by_id($curation_name, $curation_id) {
        $retarray = array();
        if (!empty($curation_id) && !empty($curation_name)) {
            $this->db->where("id<>", $curation_id);
            $this->db->where("LOWER(name)", strtolower($curation_name));
            $this->db->where("(deleted_by < 1 OR deleted_by = 0)");
            $query = $this->db->get("retailer_curation");
            if ($query->num_rows() > 0) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }

    /**
     * Update curation name
     *
     * @access	public
     * @param	curation_data,curation_id
     * @return	NA
     */
    public function update_curation_name($curation_data, $curation_id) {
        if (!empty($curation_id) && (is_array($curation_data) && count($curation_data) > 0)) {
            $this->db->where("id", $curation_id);
            $this->db->update("retailer_curation", $curation_data);
        }
    }

    /**
     * Insert curation books
     *
     * @access	public
     * @param	curation_book_data
     * @return	NA
     */
    public function insert_curation_books($curation_book_data) {
        if (is_array($curation_book_data) && count($curation_book_data) > 0) {
            $this->db->custom_insert_batch("retailer_curation_books", $curation_book_data);
        }
    }
    /**
     * Delete curation books
     *
     * @access	public
     * @param	curation_book_data,curation_id
     * @return	NA
     */
    public function delete_curation_books($curation_book_data,$curation_id) {
        if (is_array($curation_book_data) && count($curation_book_data) > 0) {
            $this->db->where("retailer_curation_id",$curation_id);
            $this->db->update("retailer_curation_books", $curation_book_data);
        }
    }

    /**
     * Insert curation book
     *
     * @access	public
     * @param	curation_book_data
     * @return	NA
     */
    public function insert_curation_books_by_curation_id($curation_book_data) {
        if (is_array($curation_book_data) && count($curation_book_data) > 0) {
            $this->db->custom_insert_batch("retailer_curation_books", $curation_book_data);
        }
    }
    /**
     * Delete curation book
     *
     * @access	public
     * @param	curation_book_data,curation_book_array,curation_id
     * @return	NA
     */
    public function delete_curation_books_by_curation_id($curation_book_data,$curation_book_array,$curation_id) {
        if ((is_array($curation_book_data) && count($curation_book_data) > 0) && !empty($curation_id)) {
            $this->db->where("retailer_curation_id", $curation_id);
            $this->db->where_in("book_id", $curation_book_array);
            $this->db->update("retailer_curation_books",$curation_book_data);
        }
    }
}
