'use strict';
App.factory('authService', ['$http', '$q', '$rootScope', '$sessionStorage', 'localStorageService',
    function ($http, $q, $rootScope, $sessionStorage, localStorageService) {
        var serviceBase = 'http://180.211.99.238:8092/1world/';
        var authServiceFactory = {};
        var _authentication = {
            isAuth: false,
            email: ""
        };
        var adminDetail = {
            user_id: '',
            first_name: "",
            last_name: "",
            email: '',
            photo: ''
        };
        var adminloginDetail = {
            access_token: '',
            usertype: ''
        };
        var _saveRegistration = function (registration) {
            _logOut();
            return $http.post(serviceBase + 'api/account/register', registration).then(function (response) {
                return response;
            });
        };
        /**
         * @description
         * # login request
         */
        var _login = function (loginData) {
            var deferred = $q.defer();
            $http({
                headers: { 'Content-Type': 'application/json' },
                url: '../api/users/admin_login',
                method: "POST",
                data: loginData
            })
                .success(function (response) {
                    if (response.error <= 0) {
                        adminDetail.user_id = response.user_id;
                        adminDetail.first_name = response.first_name;
                        adminDetail.last_name = response.last_name;
                        adminDetail.email = response.email;
                        adminDetail.photo = response.photo;

                        cookies.set('adminauthorizationData', adminDetail);
                        _authentication.isAuth = true;
                        _authentication.email = loginData.email;
                        adminloginDetail.access_token = response.access_token;
                        adminloginDetail.usertype = response.usertype;
                        localStorageService.set('adminauthorizeTokenDetail', adminloginDetail);
                        $rootScope.logo = 'main-logo.jpg';
                        $rootScope.adminData = {
                            first_name: response.first_name,
                            last_name: response.last_name,
                            photo: response.photo
                        };
                        deferred.resolve(response);
                    } else {
                        deferred.resolve(response);
                    }
                }).error(function (err, status) {
                    _logOut();
                    deferred.reject(err);
                });
            return deferred.promise;
        };
        /**
         * @description
         * # logout request
         */
        var _logOut = function () {
            var deferred = $q.defer();
            $http({
                headers: { 'Content-Type': 'application/json' },
                url: '../api/users/logout',
                method: "POST"
            })
                .success(function (response) {
                    cookies.del('adminauthorizationData');
                    localStorageService.remove('adminauthorizeTokenDetail');
                    _authentication.isAuth = false;
                    _authentication.email = "";
                    deferred.resolve(response);
                }).error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var _fillAuthData = function (language) {
            var authData = cookies.get('adminauthorizationData');
            if (authData) {
                _authentication.isAuth = true;
                _authentication.email = authData.email;
            }
        };
        /**
         * @description
         * # forget password request
         */
        var _forgetPassword = function (forgetData) {
            var deferred = $q.defer();
            $http({
                headers: { 'Content-Type': 'application/json' },
                method: 'POST',
                url: '../api/users/admin_forgot_password',
                data: forgetData
            })
                .success(function (response) {
                    deferred.resolve(response);
                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };
        /**
         * @description
         * # reset password request
         */
        var _checkResetPassword = function (resetUserData) {
            var deferred = $q.defer();
            $http({
                headers: { 'Content-Type': 'application/json' },
                method: 'POST',
                url: '../api/users/check_reset_password_url',
                data: resetUserData
            })
                .success(function (response) {
                    localStorageService.set('resetId', resetUserData.user_id);
                    deferred.resolve(response);
                })
                .error(function (err, status) {
                    localStorageService.set('resetId', '');
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        var _resetPassword = function (resetData) {
            var deferred = $q.defer();
            resetData.user_id = localStorageService.get('resetId');
            $http({
                headers: { 'Content-Type': 'application/json' },
                method: 'POST',
                url: '../api/users/reset_password',
                data: resetData
            })
                .success(function (response) {
                    if (response.error <= 0) {
                        localStorageService.set('resetId', '');
                        deferred.resolve(response);
                    } else {
                        deferred.reject(err);
                    }
                })
                .error(function (err, status) {
                    deferred.reject(err);
                });
            return deferred.promise;
        };

        authServiceFactory.saveRegistration = _saveRegistration;
        authServiceFactory.login = _login;
        authServiceFactory.logOut = _logOut;
        authServiceFactory.fillAuthData = _fillAuthData;
        authServiceFactory.authentication = _authentication;
        authServiceFactory.forgetPassword = _forgetPassword;
        authServiceFactory.checkResetPassword = _checkResetPassword;
        authServiceFactory.resetPassword = _resetPassword;
        return authServiceFactory;
    }]);