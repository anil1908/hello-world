'use strict';
App.controller('adminloginController', ['$scope', '$rootScope', '$sessionStorage', '$translate', '$location', 'authService',
    function ($scope, $rootScope, $sessionStorage, $translate, $location, authService) {
        $sessionStorage.contentDisplay = {signinMenu: false,
            signupMenu: true,
            userAccount: false,
            menuTab: false,
            usertype: ''
        };
        $rootScope.contentDisplay = $sessionStorage.contentDisplay;
        $scope.isSubmitted = false;
        $scope.forgetSubmitted = false;
        $scope.signinblock = true;
        $scope.message = "";
        $scope.isMessage = false;
        $scope.slides = [];
        $scope.activate_message = ($rootScope.message) ? $rootScope.message : false;
        $scope.error_message = ($rootScope.errmessage) ? $rootScope.errmessage : false;
        $rootScope.errmessage = '';
        $scope.loginData = {email: '', password: ''};
        $scope.forgetData = {email: ''};
        /*
        * @description
        End Home Slider*/
        $scope.goHome = function () {
            $location.path('/');
        };
         /*
        * @description
        login config*/
        $scope.login = function () {
            if ($scope.signin.$valid) {
                $scope.loginData.language = $rootScope.language;
                authService.login($scope.loginData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $location.path('/curation');
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.activate_message = '';
                                $scope.message = data.errorMsg;
                            }
                        },
                        function (err) {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.activate_message = '';
                            $scope.message = err.errorMsg;
                        });
            } else {
                $scope.isSubmitted = true;
            }
        };
        $scope.changeTab = function (status) {
            $scope.signinblock = status;
            $scope.adminloginData = {email: '', password: ''};
            $scope.forgetData = {email: ''};
            $scope.forgetSubmitted = false;
            $scope.activate_message = false;
            $scope.isSubmitted = false;
        };
         /*
        * @description
        forgetPassword config*/
        $scope.forgetPassword = function () {
            if ($scope.forgetpassword.$valid) {
                $scope.forgetData.language = $rootScope.language;
                authService.forgetPassword($scope.forgetData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.signinblock = true;
                                $scope.isError = false;
                                $scope.activate_message = data.msg;
                                $scope.forgetData = {email: ''};
                            } else {
                                $scope.isError = true;
                                $scope.activate_message = false;
                                $scope.message = data.errorMsg;
                            }
                        },
                                function (err) {
                                    $scope.isError = true;
                                    $scope.activate_message = false;
                                    $scope.message = err.errorMsg;
                                });
            } else {
                $scope.forgetSubmitted = true;
            }
        };
        $scope.authentication = authService.authentication;
    }
]);

