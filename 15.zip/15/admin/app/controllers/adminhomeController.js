App.controller('adminhomeController', ['$scope', '$rootScope', '$sessionStorage', '$translate', 'authService', '$location', 'localStorageService',
    function ($scope, $rootScope, $sessionStorage, $translate, authService, $location, localStorageService) {
        /*
        * @description
        Login And Signup Menu display*/
        var authTokenData = localStorageService.get('adminauthorizeTokenDetail');
        var adminData = cookies.get('adminauthorizationData');
        $rootScope.adminData = adminData;
        $scope.goHome = function () {
            $location.path('/');
        }
        $scope.logOut = function () {
            authService.logOut()
                .then(function (data) {
                    if (data.error <= 0) {
                        $rootScope.message = '';
                        $location.search({});
                        $location.path('/');
                    } else {
                        $scope.isError = true;
                        $scope.message = data.errorMsg;
                    }
                },
                function (err, status) {
                    $scope.message = err.errorMsg;
                });
        };
        /*End Login And Signup Menu display*/
    }
]);