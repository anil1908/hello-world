import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpModule ,BaseRequestOptions} from '@angular/http';
import { MockBackend, MockConnection } from '@angular/http/testing';
import { fakeBackendProvider } from './helpers/fake-backend';
import { routing } from './common/app.routes';
import { ValidationService } from './common/validation.service';
import { NgbModule, NgbInputDatepicker, NgbDatepickerConfig } from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { EmployeeComponent } from './employee/employee.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { EmployeeService } from './employee/employee.service';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import 'rxjs/Rx';
import { NamePipe } from './helpers/name.pipe';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    EmployeeComponent,
    HeaderComponent,
    FooterComponent,
    AddEmployeeComponent,
    NamePipe
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    routing,
    NgbModule.forRoot(),
  ],
  providers: [
    MockBackend,
    BaseRequestOptions,
    ValidationService,
    fakeBackendProvider,
    EmployeeService
  ],
  entryComponents: [
    AddEmployeeComponent,    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
