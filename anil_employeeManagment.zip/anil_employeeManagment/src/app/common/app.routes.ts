import { NgModule } from '@angular/core';
import { Routes, RouterModule, ROUTER_CONFIGURATION } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { EmployeeComponent } from '../employee/employee.component';
// Route Configuration
const appRoutes: Routes = [
    {
        path: 'home',
        component: HomeComponent,
        data: {
            title: 'Home'
        }
    },
    {
        path: '',
        component: EmployeeComponent,
        data: {
            title: 'Employee'
        }
    },
    { path: '**', redirectTo: '' }
]
export const routing = RouterModule.forRoot(appRoutes);
