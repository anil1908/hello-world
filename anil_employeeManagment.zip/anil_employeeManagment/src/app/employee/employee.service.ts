import { Injectable } from '@angular/core';
import { HttpModule, Headers, Http, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/Rx';


@Injectable()
export class EmployeeService {

  constructor(private http: Http) { }

  getAll() {
    return this.http.get('/api/employees', this.jwt())
      .map(this.extractData)
      .catch(this.handleError);
  }

  getById(id: number) {
    return this.http.get('/api/getemployee/' + id, this.jwt()).map(
      (response: Response) => response.json()
    );
  }

  create(employee: any) {
    return this.http.post('/api/create_employees', employee, this.jwt()).map(
      (response: Response) => response.json()
    );
  }

  delete(id: number) {
    return this.http.delete('/api/delete_employee/' + id, this.jwt()).map(
      (response: Response) => response.json()
    );
  }

  private extractData(res: Response) {
    let body = res.json();
    return body || {};
  }
  private handleError(error: Response | any) {
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }

  

  private jwt() {
    let headers = new Headers({ 'Authorization': 'Bearer fake-jwt-token' });
    return new RequestOptions({ headers: headers });
  }

}