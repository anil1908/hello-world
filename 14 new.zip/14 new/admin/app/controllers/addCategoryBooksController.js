'use strict';
App.controller('addCategoryBooksController', ['$scope', '$rootScope', '$state', '$location', 'admincatalogService', '$uibModal', 'localStorageService',
    function ($scope, $rootScope, $state, $location, admincatalogService, $uibModal, localStorageService) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        var parameter = $location.search();
        if(parameter.id!==undefined && parameter.id!==null && parameter.id!==''){
            $scope.curationId = parameter.id;
            $scope.booksList = [];
            $scope.gridOption = {
                filteredItems: 0,
                pageSizeArr: [1, 5, 10, 20, 50, 100],
                currentPage: 1,
                pageLimit: 10,
                sortField: 'b.title',
                sorttype: 'ASC',
                maxsize: 10,
                search_title :'',
                search_author :'',
                search_imprint :'',
                search_publisher :''
            };
            $scope.isCurationSubmited = false;
            $scope.state = false;
            $scope.selectedBookList = [];
            $scope.booksListData = {bookArr: [], allchecked: false};
            $scope.showDeleteConfirmationModal = false;
            $scope.pageIds = [];
            $scope.autoSearchTagArr = [];

            $scope.toggleState = function () {
                $scope.state = !$scope.state;
            };
            $scope.checkAll = function () {
                if ($scope.booksListData.allchecked) {
                    _.each($scope.booksList, function (element) {
                        var isavl = true;
                        _.each($scope.booksListData.bookArr, function (obj) {
                            if (obj.id === element.id) {
                                isavl = false;
                            }
                        });
                        if (isavl) {
                            $scope.booksListData.bookArr.push(element);
                        }
                    });
                } else {
                    var arr = [];
                    angular.forEach($scope.booksListData.bookArr, function (element) {
                        if ($scope.pageIds.indexOf(element.id) < 0) {
                            arr.push(element);
                        }
                    });
                    $scope.booksListData.bookArr = arr;
                }
            };
            $scope.uncheckMain = function () {
                $scope.booksListData.allchecked = false;
            };
            $scope.curationDetail = {
                curation_name :''
            };
            /*
            * @description
            * Grid Option*/
            $scope.getBooks = function () {
                var booksData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    search_title: $scope.gridOption.search_title,
                    search_author: $scope.gridOption.search_author,
                    search_imprint: $scope.gridOption.search_imprint,
                    search_publisher: $scope.gridOption.search_publisher
                };
                $scope.getBooksData(booksData);
            };

            $scope.$watch('currentPage', function (pageNo) {
                var booksData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    search_title: $scope.gridOption.search_title,
                    search_author: $scope.gridOption.search_author,
                    search_imprint: $scope.gridOption.search_imprint,
                    search_publisher: $scope.gridOption.search_publisher
                };
                $scope.gridOption.currentPage = pageNo;
                $scope.getBooksData(booksData);
                //or any other code here
            });

            $scope.sort_by = function (sortField) {
                $scope.gridOption.sortField = sortField;
                $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
                var booksData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: sortField,
                    sorttype: $scope.gridOption.sorttype,
                    search_title: $scope.gridOption.search_title,
                    search_author: $scope.gridOption.search_author,
                    search_imprint: $scope.gridOption.search_imprint,
                    search_publisher: $scope.gridOption.search_publisher
                };
                $scope.getBooksData(booksData);
            };

            $scope.changePageSize = function () {
                $scope.gridOption.currentPage = 1;
                var booksData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    search_title: $scope.gridOption.search_title,
                    search_author: $scope.gridOption.search_author,
                    search_imprint: $scope.gridOption.search_imprint,
                    search_publisher: $scope.gridOption.search_publisher
                };
                $scope.getBooksData(booksData);
            };

            $scope.searchBooks = function () {
                var booksData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    sorttype: $scope.gridOption.sorttype,
                    search_title: $scope.gridOption.search_title,
                    search_author: $scope.gridOption.search_author,
                    search_imprint: $scope.gridOption.search_imprint,
                    search_publisher: $scope.gridOption.search_publisher
                };
                $scope.getBooksData(booksData);
            };

            $scope.cancleSearch = function () {
                $scope.globalText = '';
                $scope.tagText = [];
                var booksData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                    pageLimit: $scope.gridOption.pageLimit,
                    sortField: $scope.gridOption.sortField,
                    search_title: '',
                    search_author: '',
                    search_imprint: '',
                    search_publisher: ''
                };
                $scope.getBooksData(booksData);
            };

            $scope.getBooksData = function (booksData) {
                admincatalogService.getBooksList(booksData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.pageIds = data.ids.split(',');
                                $scope.booksListData.allchecked = false;
                                $scope.booksList = data.response;
                                $scope.gridOption.filteredItems = data.total_rows;
                                $scope.gridOption.maxsize = Math.ceil(data.total_rows / $scope.gridOption.pageLimit);
                                if ($scope.gridOption.maxsize > 5) {
                                    $scope.gridOption.maxsize = 5;
                                }
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.message = err.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            };
            /*
            * @description
            * End Grid Option*/

            /*
            * @description
            * Add  Book in Curation*/
            $scope.selectBook = function (book) {
                var bookObj = {id: book.id, image: book.image, title: book.title};
                var isAvailable = false;
                angular.forEach($scope.selectedBookList, function (value, key) {
                    if (value.id == book.id) {
                        isAvailable = true;
                    }
                });
                if (!isAvailable) {
                    $scope.selectedBookList.push(bookObj);
                }
                if ($scope.selectedBookList.length > 0) {
                    $scope.state = true;
                }
            };
            /*
            * @description
            * delete  Book in Curation*/
            $scope.deleteSelectBook = function (book) {
                var bookarray = [];
                bookarray.push(book.id);
                var curationData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    curation_id :$scope.curationId,
                    bookArr :bookarray
                };
                admincatalogService.deleteCurationBooks(curationData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.isError = false;
                                $scope.isMessage = true;
                                $scope.message = "Curation Book Deleted.";
                                $scope.selectedBookList.splice($scope.selectedBookList.indexOf(book), 1);
                                $scope.state = true;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.message = err.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            }
            /*
            * @description
            *  Add All Book in Curation*/
            $scope.addAllBook = function () {
                var allBookData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language
                };
                admincatalogService.getAllBook(allBookData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.selectedBookList = data.response;
                                $scope.state = true;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.message = err.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            };
            /*
            * @description
            *  Add Selected Book in Curation*/
            $scope.addSelectedBook = function () {
                if ($scope.booksListData.bookArr.length > 0) {
                    var addBookArr = [];
                    angular.forEach($scope.booksListData.bookArr, function (element) {
                        var idCheck = _.find($scope.selectedBookList, function (value) {
                            return value.id == element.id;
                        });
                        if (idCheck === undefined) {
                            addBookArr.push(element.id);
                            $scope.selectedBookList.push(element);
                        }
                    });
                    if(addBookArr.length>0){
                        var curationData = {
                            access_token: TokenData.access_token,
                            language: $rootScope.language,
                            curation_id : $scope.curationId,
                            bookArr     : addBookArr
                        }
                        admincatalogService.addcurationBooks(curationData)
                            .then(function (data) {
                                if (data.error <= 0) {
                                    $scope.isError = false;
                                    $scope.isMessage = true;
                                    $scope.message = data.msg;
                                } else {
                                    $scope.isError = true;
                                    $scope.isMessage = false;
                                    $scope.message = data.errorMsg;
                                }
                            }, function (err, status) {
                                $scope.message = err.errorMsg;
                                $scope.isError = true;
                                $scope.isMessage = false;
                            });
                    }
                    $scope.state = true;
                    $scope.booksListData = {bookArr: [], allchecked: false};
                }
            };

            $scope.getCategoryDetail = function(){
                var categoryData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    curation_id : $scope.curationId
                }
                admincatalogService.getCategoryDetail(categoryData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $scope.curationDetail.curation_name = data.response.curation.name;
                                $scope.selectedBookList = data.response.curation_books;
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.message = err.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            };

            $scope.updateCuration = function(){
                if($scope.updatecuration.$valid){
                    // var bookArr =[];
                    // angular.forEach($scope.selectedBookList,function(val,key){
                    //     this.push(val.id);
                    // },bookArr);
                    var curationData = {
                        access_token: TokenData.access_token,
                        language: $rootScope.language,
                        curation_id : $scope.curationId,
                        curation_name : $scope.curationDetail.curation_name
                    }
                    admincatalogService.updatecuration(curationData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $rootScope.iscurationError = false;
                                $rootScope.iscurationMessage = true;
                                $rootScope.curationmessage = data.msg;
                                $location.search({});
                                $location.path('/curation');
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.message = err.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
                }
                else{
                    $scope.isCurationSubmited = true;
                }
            };

            $scope.deleteAllBookConfirmationModal = function(){
                if($scope.selectedBookList.length>0){
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/views/deleteConfirmationTemplate.html',
                        controller: 'deleteConfirmationCtrl',
                        resolve: {
                            deleteData: function () {
                                return {ModalTitle: "Confirmation", msg: "Are you sure you want to delete the record(s)?"};
                            }
                        }
                    });
                    modalInstance.result.then(function () {
                        var bookarray = [];
                        angular.forEach($scope.selectedBookList,function(bval,bkey){
                            this.push(bval.id);
                        },bookarray);
                        var curationData = {
                            access_token: TokenData.access_token,
                            language: $rootScope.language,
                            curation_id :$scope.curationId,
                            bookArr :bookarray
                        };
                        admincatalogService.deleteCurationBooks(curationData)
                                .then(function (data) {
                                    if (data.error <= 0) {
                                        $scope.isError = false;
                                        $scope.isMessage = true;
                                        $scope.message = "Curation Book(s) Deleted.";
                                        $scope.selectedBookList = [];
                                        $scope.state = false;
                                    } else {
                                        $scope.isError = true;
                                        $scope.isMessage = false;
                                        $scope.message = data.errorMsg;
                                    }
                                }, function (err, status) {
                                    $scope.message = err.errorMsg;
                                    $scope.isError = true;
                                    $scope.isMessage = false;
                                });

                    }, function () {
                        console.log('error');
                    });
                }
                else{
                    var modalInstance = $uibModal.open({
                        animation: true,
                        templateUrl: 'app/views/deleteConfirmationTemplate.html',
                        controller: 'deleteConfirmationCtrl',
                        resolve: {
                            deleteData: function () {
                                return {ModalTitle: "Warning", msg: "No record(s) Found For Delete?"};
                            }
                        }
                    });
                    modalInstance.result.then(function () {

                    }, function () {
                        console.log('error');
                    });
                }
            };
            /*
            * @description
            * Tag Popup Update Book */
            $rootScope.$on('updateBookList', function (event, data) {
                $scope.getBooks();
            });
            $scope.getCategoryDetail();
        }
        else{
            $location.path('/curation')
        }
    }]);
