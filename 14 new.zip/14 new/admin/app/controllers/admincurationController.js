App.controller('admincurationController', ['$scope', '$rootScope', '$uibModal', '$sessionStorage', '$translate', '$location', 'localStorageService','curationService',
    function ($scope, $rootScope,$uibModal, $sessionStorage, $translate, $location, localStorageService,curationService) {
        /*
        * @description
        Login And Signup Menu display*/
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        var adminData = cookies.get('adminauthorizationData');
        $rootScope.adminData = adminData;
        $scope.goHome = function () {
            $location.path('/');
        };
        $scope.gridOption = {
            filteredItems: 0,
            pageSizeArr: [1, 5, 10, 20, 50, 100],
            currentPage: 1,
            pageLimit: 10,
            sortField: 'name',
            sorttype: 'ASC',
            search_name : '',
            maxsize: 10
        };
        $scope.curationList = [];
        $scope.curationListData = {
            curationArr :[],
            allchecked   : false
        };
        $scope.isError = ($rootScope.iscurationError !== undefined) ? $rootScope.iscurationError : false;
        $scope.isMessage = ($rootScope.iscurationMessage !== undefined) ? $rootScope.iscurationMessage : false;
        $scope.message = ($rootScope.curationmessage !== undefined) ? $rootScope.curationmessage : '';
        /**
         * @description
         * List checked - unchecked event
         */
        $scope.checkAll = function () {
            if ($scope.curationListData.allchecked) {
                _.each($scope.curationList, function (element) {
                    var isavl = true;
                    _.each($scope.curationListData.curationArr, function (obj) {
                        if (obj.id === element.id) {
                            isavl = false;
                        }
                    });
                    if (isavl) {
                        $scope.curationListData.curationArr.push(element);
                    }
                });
            } else {
                var arr = [];
                angular.forEach($scope.curationListData.curationArr, function (element) {
                    if ($scope.pageIds!==undefined && $scope.pageIds.indexOf(element.id) < 0) {
                        arr.push(element);
                    }
                });
                $scope.curationListData.curationArr = arr;
            }
        };

        $scope.uncheckMain = function () {
            $scope.curationListData.allchecked = false;
        };

        /*
         * @description
         * Grid Option
         * */
        $scope.$watch('currentPage', function (pageNo) {
            var curationData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: (pageNo - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                searchtext: $scope.gridOption.search_name
            };
            $scope.gridOption.currentPage = pageNo;
            $scope.getCurationList(curationData);
            //or any other code here
        });

        $scope.changePageSize = function () {
            $scope.gridOption.currentPage = 1;
            var curationData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                searchtext: $scope.gridOption.search_name
            };
            $scope.getCurationList(curationData);
        };

        $scope.sort_by = function (sortField) {
            $scope.gridOption.sortField = sortField;
            $scope.gridOption.sorttype = ($scope.gridOption.sorttype === 'DESC') ? 'ASC' : 'DESC';
            var curationData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: sortField,
                sorttype: $scope.gridOption.sorttype,
                searchtext: $scope.gridOption.search_name
            };
           $scope.getCurationList(curationData);
        };

        $scope.globalSearch = function(){
            var curationData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                searchtext: $scope.gridOption.search_name
            };
            $scope.getCurationList(curationData);
        };

        $scope.getCuration = function(){
            var curationData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                pageStart: ($scope.gridOption.currentPage - 1) * $scope.gridOption.pageLimit,
                pageLimit: $scope.gridOption.pageLimit,
                sortField: $scope.gridOption.sortField,
                sorttype: $scope.gridOption.sorttype,
                searchtext: $scope.gridOption.search_name
            };
            $scope.getCurationList(curationData);
        };

        $scope.getCurationList = function (curationData) {
            curationService.getCurationList(curationData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.curationList = data.response;
                            $rootScope.iscurationError = false;
                            $rootScope.iscurationMessage = false;
                            $rootScope.curationmessage = '';
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.isError = true;
                        $scope.isMessage = false;
                        $scope.message = err.errorMsg;
                    });
        };
/*
         * @description
         * Curation delete
         * */
        $scope.deleteCurationRow = function (curationObj) {
            var arr = [];
            arr.push({id: curationObj.id});
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/deleteConfirmationTemplate.html',
                controller: 'deleteConfirmationCtrl',
                resolve: {
                    deleteData: function () {
                        return {ModalTitle: "Confirmation", msg: "Are you sure you want to delete the record(s)?"};
                    }
                }
            });
            modalInstance.result.then(function () {
                $scope.deleteCurationArr(arr,false);
            }, function () {
                console.log('error');
            });

        };

        $scope.deleteSelectedCuration = function () {
            if ($scope.curationListData.curationArr.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/views/curationdelete.html',
                    controller: 'curationDeleteCtrl',
                    resolve: {
                        curationData: function () {
                            return {curationArr: $scope.curationListData.curationArr};
                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {
                    $scope.deleteCurationArr(dataObj.curationArr,true);
                }, function () {
                    console.log('error');
                });
            } else {
                var modalInstance = $uibModal.open({
                    animation: true,
                    templateUrl: 'app/views/selectone.html',
                    controller: 'curationDeleteCtrl',
                    resolve: {
                        curationData: function () {

                        }
                    }
                });
                modalInstance.result.then(function (dataObj) {

                }, function () {
                    console.log('Closed');
                });
            }
        };

        $scope.deleteCurationArr = function (dataObj,isArr) {
            var curationIdArr = [];
            angular.forEach(dataObj, function (value, key) {
                curationIdArr.push(value.id);
            });
            var curationData = {
                access_token: TokenData.access_token,
                language: $rootScope.language,
                curationArr: curationIdArr
            };
            curationService.deleteCuration(curationData)
                    .then(function (data) {
                        if (data.error <= 0) {
                            $scope.isError = false;
                            $scope.isMessage = true;
                            $scope.message = data.msg;
                            if(isArr){
                                $scope.curationListData.curationArr = [];
                            }
                            else{
                                var curationArr = [];
                                angular.forEach($scope.curationListData.curationArr,function(listval,listkey){
                                    if(curationIdArr[0]!=listval.id){
                                        this.push(listval);
                                    }
                                },curationArr);
                                $scope.curationListData.curationArr = curationArr;
                            }
                            $scope.getCuration();
                        } else {
                            $scope.isError = true;
                            $scope.isMessage = false;
                            $scope.message = data.errorMsg;
                        }
                    }, function (err, status) {
                        $scope.message = err.errorMsg;
                        $scope.isError = true;
                        $scope.isMessage = false;
                    });
        };

        $scope.createNewCategoryModal = function(){
            var modalInstance = $uibModal.open({
                animation: true,
                templateUrl: 'app/views/addcuration.html',
                controller: 'addCurationCtrl',
                resolve: {
                    curationData: function () {
                        return {};
                    }
                }
            });
            modalInstance.result.then(function (curationObj) {
                window.location = 'editcuration?id=' + curationObj.curation_id;
            }, function () {
                console.log('error');
            });
        }

    }
]);

App.controller('curationDeleteCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'curationData', 'localStorageService',
    function ($scope, $rootScope, $uibModalInstance, curationData, localStorageService) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.ModalTitle = 'Confirmation';
        $scope.curationDelete = function () {
            $uibModalInstance.close({curationArr: curationData.curationArr});
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
}]);


App.controller('addCurationCtrl', ['$scope', '$rootScope', '$uibModalInstance', 'curationData', 'localStorageService','curationService',
    function ($scope, $rootScope, $uibModalInstance, curationData, localStorageService,curationService) {
        var TokenData = localStorageService.get('adminauthorizeTokenDetail');
        $scope.ModalTitle = 'Create New Category';
        $scope.curationformData = {categoryname:''};
        $scope.isSubmitted = false;
        $scope.createcuration = function(){
            if($scope.addcuration.$valid){
                var curationData = {
                    access_token: TokenData.access_token,
                    language: $rootScope.language,
                    curation_name: $scope.curationformData.categoryname
                };
                curationService.addCuration(curationData)
                        .then(function (data) {
                            if (data.error <= 0) {
                                $uibModalInstance.close({curation_id: data.curation_id,msg: data.msg});
                            } else {
                                $scope.isError = true;
                                $scope.isMessage = false;
                                $scope.message = data.errorMsg;
                            }
                        }, function (err, status) {
                            $scope.message = err.errorMsg;
                            $scope.isError = true;
                            $scope.isMessage = false;
                        });
            }
            else{
                $scope.isSubmitted = true;
            }
        };
        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
}]);
