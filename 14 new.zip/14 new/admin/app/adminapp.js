var App = angular.module('OneWorld', [
    'ui.router',
    'ui.grid',
    'ui.grid.pagination',
    'ui.grid.autoResize',
    'ui.bootstrap',
    'ui.checkbox',
    'angular-loading-bar',
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngSanitize',
    'ngTouch',
    'pascalprecht.translate',
    'tmh.dynamicLocale',
    'LocalStorageModule',
    'ngStorage',
    'checklist-model',
    'xeditable',
    'ngTagsInput',
    'angular-cache',
    'ui.select2',
    'ivh.treeview',
    'dndLists',
    'colorpicker.module',
    'ngCkeditor',
    'angular-clipboard'
])
        .constant('DEBUG_MODE', true)
        .constant('DATE_FORMAT', 'MM/dd/yyyy')
        .constant('LOCALES', {
            'locales': {
                'ru_RU': 'Русский',
                'en_US': 'English'
            },
            'preferredLocale': 'en_US',
        })
        // Angular state change
        .config(['$stateProvider','$urlRouterProvider', '$locationProvider', '$translateProvider', 'tmhDynamicLocaleProvider',
                function ($stateProvider, $urlRouterProvider, $locationProvider, $translateProvider, tmhDynamicLocaleProvider) {
                $locationProvider.html5Mode(true);
                $urlRouterProvider.otherwise('/');
                // Now set up the states
                $stateProvider
                        .state('admin', {
                            title: 'ADMIN_HEADER_TITLE',
                            url: '/',
                            templateUrl: 'app/views/adminlogin.html',
                            controller: 'adminloginController'
                        })
                        .state('resetpasswordchk', {
                            title: 'SIGNUP_HEADER_TITLE',
                            url: '/resetpasswordchk',
                            controller: 'adminresetpasswordchkController'
                        })
                        .state('resetpassword', {
                            title: 'SIGNUP_HEADER_TITLE',
                            url: '/resetpassword',
                            templateUrl: 'app/views/adminresetpassword.html',
                            controller: 'adminresetpasswordController'
                        })
                        .state('curation', {
                            title: 'SIGNUP_HEADER_TITLE',
                            url: '/curation',
                            templateUrl: 'app/views/curationList.html',
                            controller: 'admincurationController'
                        })
                        .state('editcuration', {
                            title: 'MAINTAIN_BOOKS_LABEL',
                            url: '/editcuration',
                            templateUrl: 'app/views/admincategorybook.html',
                            controller: 'addCategoryBooksController'
                        });
            }])
        // Angular debug info
        .config(function ($compileProvider, DEBUG_MODE) {
            if (!DEBUG_MODE) {
                $compileProvider.debugInfoEnabled(false);// disables AngularJS debug info
            }
        })
        // Angular Translate
        .config(function ($translateProvider, DEBUG_MODE, LOCALES) {
            if (DEBUG_MODE) {
                $translateProvider.useMissingTranslationHandlerLog();// warns about missing translates
            }
            $translateProvider.useStaticFilesLoader({
                files: [{
                        prefix: '../assets/resources/locale-', // path to translations files
                        suffix: '.json'// suffix, currently- extension of the translations
                    },
                    {
                        prefix: '../assets/resources/validate/locale-validate-', // path to translations files
                        suffix: '.json'// suffix, currently- extension of the translations
                    }]
            });
            //$translateProvider.useSanitizeValueStrategy('sanitize');
            $translateProvider.preferredLanguage(LOCALES.preferredLocale);
            // Enable escaping of HTML
            $translateProvider.useSanitizeValueStrategy('escape');
            $translateProvider.useLocalStorage();
        })
        // Angular Dynamic Locale
        .config(function (tmhDynamicLocaleProvider) {
            tmhDynamicLocaleProvider.localeLocationPattern('../bower_components/angular-i18n/angular-locale_{{locale}}.js');
        })
        .config(function ($httpProvider) {
            //  $httpProvider.defaults.cache = true;
            $httpProvider.interceptors.push('authInterceptorService');
        })
        .config(['cfpLoadingBarProvider', function (cfpLoadingBarProvider) {
                cfpLoadingBarProvider.spinnerTemplate = '<div class="loading-block"><div class="loading"><img align="" src="assets/images/loading-spinner-grey.gif"> <span>  LOADING...</span></div></div>';
        }])
        //angular cache data
        .run(function ($http, CacheFactory) {
            $http.defaults.cache = CacheFactory('defaultCache', {
                maxAge: 20 * 60 * 1000,
                cacheFlushInterval: 120 * 60 * 1000,
                deleteOnExpire: 'aggressive'
            });
        })
        .run(['authService', 'LOCALES', '$rootScope', function (authService, LOCALES, $rootScope) {
                $rootScope.language = LOCALES.preferredLocale;
                authService.fillAuthData($rootScope.language);
            }])
        .run(function ($rootScope, $state, $window, beforeUnload, $cookieStore, $sessionStorage, $location, authService, LOCALES, localStorageService) {
            $rootScope.$on("$stateChangeStart", function (event, toState, toParams, fromState) {
                $rootScope.title = toState.title;
                $rootScope.selectedMenu = toState.name;
                $rootScope.$watch($rootScope.adminData);
                $rootScope.$watch($rootScope.isHeader);
                $rootScope.$watch($rootScope.logo);
                var authArr = [ 'verify', 'resetpassword','admin'];

                var userTokenData = localStorageService.get('adminauthorizeTokenDetail');
                var adminData = cookies.get('adminauthorizationData');
                $rootScope.adminData = adminData;
                if (adminData !== null) {
                    $rootScope.isHeader = true;
                    if(authArr.indexOf(toState.name)<0){
                        $location.path('/' + toState.name);
                    }
                    else{
                        $location.path('/curation');
                    }
                }
                else
                {
                    $rootScope.isHeader = false;
                    if(authArr.indexOf(toState.name)<0){
                        $location.path('/admin');
                    }
                }
            });
    });

