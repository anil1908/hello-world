/**
 * @description
 * # browser unload event
 */
'use strict';
App.factory('beforeUnload', ['$rootScope', '$window',
    function ($rootScope, $window) {
        $window.onbeforeunload = function (e) {
            var confirmation = {};
            var event = $rootScope.$broadcast('onBeforeUnload', confirmation);
            if (event.defaultPrevented) {
                return confirmation.message;
            }
        };

        $window.onunload = function () {
            $rootScope.$broadcast('onUnload');
        };
        return {};
    }]);