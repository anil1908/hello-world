/**
 * @description
 * # request responce intercepter
 */
'use strict';
App.factory('authInterceptorService', ['$q', '$rootScope', '$location', '$sessionStorage', 'localStorageService',
    function ($q, $rootScope, $location, $sessionStorage, localStorageService) {
        var authInterceptorServiceFactory = {};
        var _request = function (config) {
            config.headers = config.headers || {};
            var authData = cookies.get('adminauthorizationData');
            $rootScope.loadingBlock = true;
            return config;
        };

        var _response = function (config) {
            $rootScope.loadingBlock = false;
            if (config.data.error === 2) {
                $rootScope.logo = 'home-logo.png';
                cookies.del('adminauthorizationData');
                localStorageService.remove('authorizeTokenDetail');
                $location.path('/');
            }
            return config;
        };

        var _responseError = function (rejection) {
            if (rejection.status === 401) {
                // $location.path('/');
            }
            return $q.reject(rejection);
        };
        authInterceptorServiceFactory.request = _request;
        authInterceptorServiceFactory.responseError = _responseError;
        authInterceptorServiceFactory.response = _response;
        return authInterceptorServiceFactory;
    }
]);