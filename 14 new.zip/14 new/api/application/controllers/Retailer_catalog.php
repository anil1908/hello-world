<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Retailer_catalog extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code

        $this->load->model('retailer_catalog_model');
        $this->load->model('general_model');
        $this->load->model('catalog_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {

    }

    /**
     * Curation list
     *
     * @access	public
     * @param	access_token,language,pagestart,pagelimit,sortField,sorttype,searchtext,flag
     * @return	JSON Array
     */
    public function get_curation_list() {
        $retarray = array();
        $result = array();
        $common_result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        $pageStart = (!empty($this->input->post('pagestart'))) ? $this->input->post('pagestart') : 0;
        $pageLimit = (!empty($this->input->post('pagelimit'))) ? $this->input->post('pagelimit') : 10;
        $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'rc.created_on';
        $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'DESC';

        $this->form_validation->set_rules('searchtext', 'Search Text', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if($common_result['error']==0){
                $search_name = addslashes($this->input->post("searchtext"));
                //flag 0 for all listing in retailer catalog
                $flag = $this->input->post("flag");
                //Get company details
                $retarray['response'] = $this->retailer_catalog_model->get_curation_list($sortField, $sortType, $flag, $search_name, $pageStart, $pageLimit);
                $retarray['found_rows'] = $this->general_model->found_rows();
                $retarray['total_rows'] = $this->retailer_catalog_model->get_curation_list_count($search_name);
                $retarray['error']=0;
            }else{
                $retarray = $common_result;
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Retailer catalog
     *
     * @access	public
     * @param	access_token,language,pagestart,pagelimit,curation_id,business_id,searchtext,book_id
     * @return	JSON Array
     */
    public function get_retailer_catalog_by_id() {
        $retarray = array();
        $result = array();
        $common_result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);
        $pageStart = (!empty($this->input->post('pagestart'))) ? $this->input->post('pagestart') : 0;
        $pageLimit = (!empty($this->input->post('pagelimit'))) ? $this->input->post('pagelimit') : 10;

        $this->form_validation->set_rules('searchtext', 'Search Text', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if($common_result['error']==0){
                $curation_id = $this->input->post("curation_id");
                $business_model_id= $this->input->post("business_id");
                $search = addslashes($this->input->post("searchtext"));
                $book_id = $this->input->post("book_id");
                //Get company details
                $retarray['response'] = $this->retailer_catalog_model->get_retailer_catalog_by_id($common_result['user_id'],$curation_id,$search,$business_model_id,0,$book_id,$pageStart,$pageLimit,$show_all=0);
                $retarray['error']=0;
            }else{
                $retarray = $common_result;
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

     /**
     * Retailer catalog list by selection
     *
     * @access	public
     * @param	access_token,language,curation_id,business_id,searchtext
     * @return	JSON Array
     */
    public function get_retailer_catalog_by_selection() {
        $retarray = array();
        $result = array();
        $common_result = array();

        $_POST = json_decode(file_get_contents('php://input'), true);

        $this->form_validation->set_rules('searchtext', 'Search Text', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                $curation_id = $this->input->post("curation_id");
                $business_model_id= $this->input->post("business_id");
                $search = addslashes($this->input->post("searchtext"));
                //Get retailer catalog
                $retarray['error']=0;
                $retarray['response'] = $this->retailer_catalog_model->get_retailer_catalog_by_id($common_result['user_id'],$curation_id,$search,$business_model_id,1,NULL,NULL,NULL,$show_all=0);
            } else {
                $retarray = $common_result;
            }
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Book Details
     *
     * @access	public
     * @param	access_token,language,catalog_id
     * @return	JSON Array
     */
    public function get_catalog_details_by_id() {
        $retarray = array();
        $result = array();
        $result_contributor = array();
        $result_price = array();
        $result_subject = array();
        $identifier_array = array();
        $error_array = array();
        $result_identifier = array();
        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        $_POST = json_decode(file_get_contents('php://input'), true);
        if (!$this->custom_function->check_access_token()) {
            $retarray['error'] = 2;
            $retarray['errorMsg'] = $this->lang->line('session_expired');
            $this->output->set_output(json_encode($retarray));
            $this->output->_display();
            exit;
        }


        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $book_id = $this->input->post('catalog_id');
            if (!empty($book_id)) {
                //Get catalog details
                $result = $this->retailer_catalog_model->get_book_details_by_id($book_id);
                if (is_object($result) && count($result) > 0) {
                    $retarray['error'] = 0;
                    //Catalog Details
                    $result_contributor = $this->catalog_model->get_book_contributor_detail_by_id($book_id);
                    $result_subject = $this->catalog_model->get_book_subject_detail_by_id($book_id);
                    $identifier_array= $this->catalog_model->get_book_identifier_detail_by_id($book_id);
                    $error_array = array("error"=>false,"identifiermessage"=>'');
                    foreach ($identifier_array as $key=>$val){
                        $result_identifier[]=array_merge($identifier_array[$key],$error_array);
                    }
                    $retarray['response']['catalog'] = array('id' => $result->id,
                        'title' => strip_slashes($result->title),
                        'image' => (!empty($result->image) && file_exists($path . '/' . $result->image)) ? base_url() . 'assets/images/bookcovers/' . $result->image : base_url() . 'assets/images/bookcovers/img-cover.png',
                        'sub_title' => $result->sub_title,
                        'volume' => $result->volume,
                        'edition' => $result->edition,
                        'contributor' => (!empty($result_contributor)) ? $result_contributor : array(),
                        'identifier' => (!empty($result_identifier)) ? $result_identifier : array(),
                        'publisher' => $result->publisher,
                        'imprint' => $result->imprint,
                        'publication_date' => date('m/d/Y',strtotime($result->publication_date)),
                        'language' => $result->language,
                        'language_id' => $result->language_id,
                        'subject_id' => (!empty($result_subject)) ? $result_subject : array(),
                        'main_subject_id' => $result->main_subject_id,
                        'description' => (strlen($result->description) > 50) ? substr($result->description, 0, 50) . ".." : $result->description,
                        'keywords' => $result->keywords,
                        'age_range' => $result->age_range,
                        'us_grade_range' => $result->us_grade_range,
                        'region_id' => (!empty($result->region_id)) ? explode(',', $result->region_id) : array(),
                        'region_name' => (!empty($result->region_name)) ? explode(',', $result->region_name) : array(),
                        'country_id' => (!empty($result->country_name)) ? explode(',', $result->country_name) : array(),
                        'audience_id' => $result->audience_id,
                        'copyright_year' => $result->copyright_year,
                        'copyright_owner' => $result->copyright_owner,
                        'supplier_details' => $result->supplier_details,
                        'supply_date' => date('m/d/Y',strtotime($result->supply_date)),
                        'title_availability' => date('m/d/Y',strtotime($result->title_availability)),
                        'countries_included' => $result->countries_included,
                        'cover_image' =>(!empty($result->cover_image) && file_exists($path . '/' . $result->cover_image)) ? base_url() . 'assets/images/bookcovers/' . $result->cover_image : base_url() . 'assets/images/bookcovers/img-cover.png',
                        'original_image' =>(!empty($result->cover_image) && file_exists($path . '/' . $result->cover_image)) ?$result->cover_image :''
                    );
                    //Catalog prices
                    $retarray['response']['catalog_prices'] = (array)$this->retailer_catalog_model->get_retailer_catalog_price_by_id($book_id,$common_result['user_id']);
                    //Catalog reviews
                    $retarray['response']['catalog_reviews'] = $this->catalog_model->get_book_reviews_by_id($book_id);
                    //Catalog awards
                    $retarray['response']['catalog_awards'] = $this->catalog_model->get_book_awards_by_id($book_id);
                    //Catalog related product
                    $retarray['response']['catalog_related_products'] = $this->catalog_model->get_book_related_product_by_id($book_id);
                } else {
                    $retarray['error'] = 0;
                    $retarray['response'] = array();
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }
    /**
     * Catalog price 
     *
     * @access	public
     * @param	access_token,language,catalog_array
     * @return	JSON Array
     */
    public function  get_price_by_catalog(){
        $retarray = array();
        $result = array();
        $common_result = array();

        $path = realpath(PUBPATH . '../assets/images/bookcovers');

        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $catalog_array = $this->input->post("catalog_array");
            if(is_array($catalog_array) && count($catalog_array) > 0){
                //Get retailer catalog price
                $retarray['error']=0;
                $retarray['response'] = $this->retailer_catalog_model->get_retailer_catalog_price_by_id($catalog_array,$common_result['user_id']);
            }else{
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }


    /**
     * All Books list
     *
     * @access	public
     * @param	access_token,language,
     *          pageStart,pageLimit,
     *          sortField,sorttype,search_title,search_author,search_imprint,search_publisher
     * @return	JSON Array
     */
    public function get_all_books_list() {
        $retarray = array();
        $result = array();
        $id_array = array();
        $common_result = array();

        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        $_POST = json_decode(file_get_contents('php://input'), true);
        $pageStart = (!empty($this->input->post('pageStart'))) ? $this->input->post('pageStart') : 0;
        $pageLimit = (!empty($this->input->post('pageLimit'))) ? $this->input->post('pageLimit') : 10;
        $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'b.publication_date';
        $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'DESC';

        $this->form_validation->set_rules('search_title', 'Search value', 'trim|xss_clean');
        $this->form_validation->set_rules('search_author', 'Search tag value', 'trim|xss_clean');
        $this->form_validation->set_rules('search_imprint', 'Search tag value', 'trim|xss_clean');
        $this->form_validation->set_rules('search_publisher', 'Search tag value', 'trim|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            $search_title = addslashes(strtolower($this->input->post('search_title')));
            $search_author = addslashes(strtolower($this->input->post('search_author')));
            $search_imprint = addslashes(strtolower($this->input->post('search_imprint')));
            $search_publisher = addslashes(strtolower($this->input->post('search_publisher')));

            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                $retarray['error'] = 0;
                //Get book list
                $result = $this->retailer_catalog_model->get_all_books_list($pageStart, $pageLimit, $sortField, $sortType, $search_title, $search_author, $search_imprint, $search_publisher);
                $retarray['found_rows'] = $this->general_model->found_rows();
                $wherearr = array('company_id' => $common_result['company_id']);
                $retarray['total_rows'] = $this->retailer_catalog_model->get_all_books_list_count($search_title, $search_author, $search_imprint, $search_publisher);
                $i = 0;
                if (is_array($result) && count($result) > 0) {
                    $retarray['error'] = 0;
                    foreach ($result as $key => $val) {
                        array_push($id_array, $result[$key]['id']);
                        //Book list
                        $retarray['response'][$i] = array('id' => $result[$key]['id'],
                            'title' => strip_slashes($result[$key]['title']),
                            'author' => (!empty($result[$key]['author']))? $result[$key]['author']:'',
                            'publication_date' =>(!empty($result[$key]['publication_date']))?date('m/d/Y', strtotime($result[$key]['publication_date'])):NULL,
                            'imprint' => strip_slashes($result[$key]['imprint']),
                            'identifier_no' => (strlen($result[$key]['identifier_no']) > 20) ? substr($result[$key]['identifier_no'], 0, 20) . ".." : $result[$key]['identifier_no'],
                            'publisher' => strip_slashes($result[$key]['publisher']),
                        );
                        $retarray['response'][$i]['image'][0]['thumb'] = (!empty($result[$key]['image']) && file_exists($path . '/' . $result[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $result[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                        $retarray['response'][$i]['image'][0]['img'] = (!empty($result[$key]['image']) && file_exists($path . '/' . $result[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $result[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                        $retarray['response'][$i]['image'][0]['description'] = "";
                        $i++;
                    }
                    $retarray['ids'] = implode(',', $id_array);
                } else {
                    $retarray = array("error" => 0,
                        "found_rows" => 0,
                        "total_rows" => 0,
                        "response" => array(),
                        "ids" => '');
                }
            } else {
                $retarray = $common_result;
            }
        }
        $this->output->set_output(json_encode($retarray));
    }
    /**
     * Insert curation
     *
     * @access	public
     * @param	access_token,language,curation_name
     * @return	JSON Array
     */
    public function insert_curation() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        $this->form_validation->set_rules('curation_name', 'Curation Name', 'trim|required|xss_clean');

        if ($this->form_validation->run() == FALSE) {
            $retarray['error'] = 1;
            $retarray['errorMsg'] = validation_errors();
        } else {
            //Get user_id and company_id
            $common_result = $this->custom_function->_common($_POST);
            if ($common_result['error'] == 0) {
                $curation_name = $this->input->post('curation_name');
                $result = $this->retailer_catalog_model->check_curation_name($curation_name);
                if ($result) {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line("curation_name_exists");
                    $this->output->set_output(json_encode($retarray));
                    $this->output->_display();
                    exit;
                }
                $created_on = date('Y-m-d H:i:s');
                //Delete curation data
                $curation_data = array('name' => $curation_name,
                    'created_on'=>$created_on,
                    'created_by' => $common_result['user_id']);
                $curation_id = $this->retailer_catalog_model->insert_curation($curation_data);
                $retarray['error'] = 0;
                $retarray['curation_id']= $curation_id;
                $retarray['msg'] = $this->lang->line('insert_curation_success');
            } else {
                $retarray = $common_result;
            }
        }
        $this->output->set_output(json_encode($retarray));
    }
    /**
     * Delete curation
     *
     * @access	public
     * @param	access_token,language,curationArr
     * @return	JSON Array
     */
    public function delete_curation() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $curation_id = $this->input->post('curationArr');
            $deleted_on = date('Y-m-d H:i:s');
            if (is_array($curation_id) && count($curation_id) > 0) {
                //Delete curation data
                $curation_data = array('deleted_on' => $deleted_on,
                    'deleted_by' => $common_result['user_id']);
                $this->retailer_catalog_model->delete_curation_data($curation_data, $curation_id);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line('delete_curation_success');
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }

    /**
     * Book list
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_catalog_list_by_selection() {
        $retarray = array();
        $result = array();
        $common_result = array();

        $path = realpath(PUBPATH . '../assets/images/bookcovers');

        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            //Get book list
            $result = $this->retailer_catalog_model->get_book_list_by_selection();
            $i = 0;
            if (is_array($result) && count($result) > 0) {
                $retarray['error'] = 0;
                foreach ($result as $key => $val) {
                    //Book list
                    $retarray['response'][$i] = array('id' => $result[$key]['id'],
                        'title' => strip_slashes($result[$key]['title'])
                    );
                    $retarray['response'][$i]['image'][0]['thumb'] = (!empty($result[$key]['image']) && file_exists($path . '/' . $result[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $result[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                    $retarray['response'][$i]['image'][0]['img'] = (!empty($result[$key]['image']) && file_exists($path . '/' . $result[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $result[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                    $retarray['response'][$i]['image'][0]['description'] = "";
                    $i++;
                }
            } else {
                $retarray['error'] = 0;
                $retarray['response'] = array();
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }
    
    /**
     * Curation details
     *
     * @access	public
     * @param	curation_id
     * @return	JSON Array
     */
    public function curation_details() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        
        $_POST = json_decode(file_get_contents('php://input'), true);

        $curation_id = $this->input->post("curation_id");

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $retarray['error'] = 0;

            if (!empty($curation_id)) {
                //Get curation details
                $result_curation = $this->retailer_catalog_model->get_curation_details_by_id($curation_id);
                if (is_object($result_curation) && count($result_curation) > 0) {
                    //Curation data
                    $retarray['response']['curation'] = array("id" => $result_curation->id,
                        "name" => strip_slashes($result_curation->name));
                }

                //Get curation books details
                $result = $this->retailer_catalog_model->get_book_details_by_curation_id($curation_id);
                $i = 0;
                if (is_array($result) && count($result) > 0) {
                    $retarray['error'] = 0;
                    foreach ($result as $key => $val) {
                        //Curation book list
                        $retarray['response']['curation_books'][$i] = array('id' => $result[$key]['id'],
                            'title' => strip_slashes($result[$key]['title']),
                            'author' => (!empty($result[$key]['author']))? $result[$key]['author']:'',
                            'publication_date' =>(!empty($result[$key]['publication_date']))?date('m/d/Y', strtotime($result[$key]['publication_date'])):NULL,
                            'imprint' => strip_slashes($result[$key]['imprint']),
                            'identifier_no' => (!empty($result[$key]['identifier_no'])) ? strip_slashes($result[$key]['identifier_no']) :'',
                            'publisher' => strip_slashes($result[$key]['publisher'])
                        );
                        $retarray['response']['curation_books'][$i]['image'][0]['thumb'] = (!empty($result[$key]['image']) && file_exists($path . '/' . $result[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $result[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                        $retarray['response']['curation_books'][$i]['image'][0]['img'] = (!empty($result[$key]['image']) && file_exists($path . '/' . $result[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $result[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                        $retarray['response']['curation_books'][$i]['image'][0]['description'] = "";
                        $i++;
                    }
                } else {
                    $retarray['error'] = 0;
                    $retarray['response']['curation_books'] = array();
                }
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line('technical_error');
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }
    
    /**
     * Update curation
     *
     * @access	public
     * @param   access_token,language,curation_name,curation_id,bookArr
     * @return	JSON Array
     */
    public function update_curation() {
        $retarray = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {

            //Server side validation
            $this->form_validation->set_rules('curation_name', 'Curation Name', 'trim|required|xss_clean');

            if ($this->form_validation->run() == FALSE) {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = validation_errors();
            } else {
                $curation_name = $this->input->post('curation_name');
                $curation_id = $this->input->post('curation_id');
                if (!empty($curation_id)) {
                    //Check curation name
                    $result = $this->retailer_catalog_model->check_curation_name_by_id($curation_name, $curation_id);
                    if (!$result) {
                        $modified_on = date('Y-m-d H:i:s');
                        
                        //Update curation data
                        $curation_data = array("name" => $curation_name,
                            "modified_on" => $modified_on,
                            "modified_by" => $common_result['user_id']);
                        $this->retailer_catalog_model->update_curation_name($curation_data, $curation_id);
                        $retarray['error'] = 0;
                        $retarray['curation_id'] = $curation_id;
                        $retarray['msg'] = $this->lang->line("curation_update_success");
                    } else {
                        $retarray['error'] = 1;
                        $retarray['errorMsg'] = $this->lang->line("curation_name_exists");
                    }
                } else {
                    $retarray['error'] = 1;
                    $retarray['errorMsg'] = $this->lang->line('technical_error');
                }
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }
    
    /**
     * Insert curation books
     *
     * @access	public
     * @param	bookArr,curation_id
     * @return	JSON Array
     */
    public function add_curation_books() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $curation_book_array = array();
        $curation_book_data = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $created_on = date('Y-m-d H:i:s');
            $curation_book_array = $this->input->post("bookArr");
            $curation_id = $this->input->post('curation_id');

            if (is_array($curation_book_array) && count($curation_book_array) > 0) {
                //Delete curation book data
                foreach ($curation_book_array as $cba){
                    $curation_book_data[] = array("retailer_curation_id"=>$curation_id,
                        "book_id"=>$cba,
                        "created_on" => $created_on,
                        "created_by" => $common_result['user_id']);
                }
                $this->retailer_catalog_model->insert_curation_books_by_curation_id($curation_book_data);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line("curation_book_insert_success");
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("select_book");
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }
    /**
     * Delete curation books
     *
     * @access	public
     * @param	bookArr,curation_id
     * @return	JSON Array
     */
    public function delete_curation_books() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $curation_book_array = array();
        $curation_book_data = array();
        $_POST = json_decode(file_get_contents('php://input'), true);

        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if ($common_result['error'] == 0) {
            $deleted_on = date('Y-m-d H:i:s');
            $curation_book_array = $this->input->post("bookArr");
            $curation_id = $this->input->post('curation_id');

            if (is_array($curation_book_array) && count($curation_book_array) > 0) {
                //Delete curation book data
                $curation_book_data = array("deleted_on" => $deleted_on,
                    "deleted_by" => $common_result['user_id']);
                $this->retailer_catalog_model->delete_curation_books_by_curation_id($curation_book_data,$curation_book_array,$curation_id);
                $retarray['error'] = 0;
                $retarray['msg'] = $this->lang->line("curation_book_delete_success");
            } else {
                $retarray['error'] = 1;
                $retarray['errorMsg'] = $this->lang->line("select_book");
            }
        } else {
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }
    
}
