<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Business_model extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        // Your own constructor code      

        $this->load->model('business_model_model');
    }

    /**
     * Default Method of a class
     *
     * @access	public
     * @param	NA
     * @return	NA
     */
    public function index() {
        
    }

    /**
     * Business model category 
     *
     * @access	public
     * @param	access_token,language,categoryid,sortField,sorttype
     * @return	JSON Array
     */
    public function get_business_model_category() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if($common_result['error']==0){
            $category_id=$this->input->post('categoryid');  
            $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'b.id';
            $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'ASC';
            $retarray['response']['category']=array();
            //Get category of business model
            $result=$this->business_model_model->get_business_model_category();
            if(is_array($result) && count($result)>0){
                $retarray['error']=0;
                // Business model category
                $retarray['response']['category']=$result;                
                $retarray['response']['category'][0]['list']=$this->business_model_model->get_business_model_category_list_by_id($category_id,$common_result['user_id'],$sortField,$sortType);
            }else{
                $retarray['error']=0;
                $retarray['response']=array();
            }
        }else{
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));        
    }
    
    /**
     * Business model category list by selection
     *
     * @access	public
     * @param	access_token,language,categoryid,sortField,sorttype
     * @return	JSON Array
     */
    public function get_business_model_category_list_by_id() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if($common_result['error']==0){
            $category_id=$this->input->post('categoryid');  
            $sortField = (!empty($this->input->post('sortField'))) ? $this->input->post('sortField') : 'b.id';
            $sortType = (!empty($this->input->post('sorttype'))) ? $this->input->post('sorttype') : 'ASC';
            $retarray['response']=array();
            //Get business model category list
            $result = $this->business_model_model->get_business_model_category_list_by_id($category_id,$common_result['user_id'],$sortField,$sortType);
             
            if(is_array($result) && count($result)>0){
                $retarray['error']=0;
                //Business model category list
                $retarray['response'] = $result;
            }else{
                $retarray['error']=0;
                $retarray['response']=array();
            }
        }else{
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
        unset($retarray);
        unset($result);
    }
    
    /**
     * Business model details by id
     *
     * @access	public
     * @param	access_token,language,modelid
     * @return	JSON Array
     */
    public function get_model_associative_details_by_id() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        
        if($common_result['error']==0){
            $modelid = $this->input->post('modelid');              
            $retarray['response']=array();
            //Get business model details
            $result = $this->business_model_model->get_model_associative_details_by_id($modelid,$common_result['company_id']);
             
            if(is_array($result) && count($result)>0){
                $retarray['error']=0;
                //Business model category list
                $retarray['response'] = $result;
            }else{
                $retarray['error']=0;
                $retarray['response']=array();
            }
        }else{
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
        unset($retarray);
        unset($result);
    }
    
     /**
     * Business model list
     *
     * @access	public
     * @param	access_token,language
     * @return	JSON Array
     */
    public function get_business_model_list() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        
        if($common_result['error']==0){          
            $retarray['response']=array();
            //Get business model details
            $result = $this->business_model_model->get_business_model_list();
             
            if(is_array($result) && count($result)>0){
                $retarray['error']=0;
                //Business model category list
                $retarray['response'] = $result;
            }else{
                $retarray['error']=0;
                $retarray['response']=array();
            }
        }else{
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
        unset($retarray);
        unset($result);
    }
    
    /**
     * Add to favourite business model category list
     *
     * @access	public
     * @param	access_token,language,business_model_id
     * @return	JSON Array
     */
    public function insert_business_model_category_list_to_favourite() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if($common_result['error']==0){
            $business_model_id=$this->input->post("business_model_id");
            $created_on=date("Y-m-d H:i:s");
            if(!empty($business_model_id)){
                //Insert favourite business model category list data
                $favourite_data=array("user_id"=>$common_result['user_id'],
                                      "business_model_id"=>$business_model_id,
                                      "created_on"=>$created_on,
                                      "created_by"=>$common_result['user_id']);
                $this->business_model_model->insert_user_favourite_business_model($favourite_data);
                $retarray['error']=0;
                $retarray['msg']=$this->lang->line("favourite_business_model");
            }else{
                $retarray['error']=1;
                $retarray['errorMsg']=$this->lang->line("technical_error");
            }
        }else{
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }
    /**
     * Delete from favourite business model category list
     *
     * @access	public
     * @param	access_token,language,business_model_id
     * @return	JSON Array
     */
    public function delete_business_model_category_list_from_favourite() {
        $retarray = array();
        $result = array();
        $common_result = array();
        $_POST = json_decode(file_get_contents('php://input'), true);
        
        //Get user_id and company_id
        $common_result = $this->custom_function->_common($_POST);
        if($common_result['error']==0){
            $business_model_id=$this->input->post("business_model_id");
            if(!empty($business_model_id)){
                //Delete favourite business model category list data
                $unfavourite_data=array("user_id"=>$common_result['user_id'],
                            "business_model_id"=>$business_model_id);
                $this->business_model_model->delete_user_favourite_business_model($unfavourite_data);
                $retarray['error']=0;
                $retarray['msg']=$this->lang->line("unfavourite_business_model");
            }else{
                $retarray['error']=1;
                $retarray['errorMsg']=$this->lang->line("technical_error");
            }
        }else{
            $retarray = $common_result;
        }
        $this->output->set_output(json_encode($retarray));
    }
    
}
