<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class My_list_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->model('retailer_catalog_model');
    }

    /**
     * My list
     *
     * @access	public
     * @param	company_id
     * @return	Array
     */
    public function get_my_list_company_id($compnay_id) {
        $retarray = array();
        if (!empty($compnay_id)) {
            $this->db->select("id,name");
            $this->db->where("company_id", $compnay_id);
            $query = $this->db->get("my_lists");
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * My list
     *
     * @access	public
     * @param	company_id,pageStart, pageLimit, sortField, sortType, search_name,search_from_date,search_to_date, search_created_by
     * @return	Array
     */
    public function get_my_list_by_company_id($company_id, $pageStart, $pageLimit, $sortField, $sortType, $search_name, $search_created_by) {
        $retarray = array();
        if (!empty($company_id)) {
            $this->db->select("l.id,l.name,l.created_on,CONCAT(u.first_name,' ',u.last_name)as created_by,COUNT(lb.book_id)as no_of_books");
            $this->db->from("my_lists l");
            $this->db->join("my_lists_books lb", "l.id=lb.list_id", "LEFT");
            $this->db->join("users u", "u.id=l.created_by");
            if (!empty($search_name)) {
                $this->db->where("(LOWER(l.name) LIKE '%$search_name%')");
            }

            if (!empty($search_created_by)) {
                $this->db->where("(LOWER(CONCAT_WS(' ',u.first_name,u.last_name)) LIKE '%$search_created_by%')");
            }

            $this->db->where("l.company_id",$company_id);
            $this->db->group_by('l.id');
            $this->db->order_by($sortField, $sortType);
            $this->db->limit($pageLimit, $pageStart);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Count my list
     *
     * @access	public
     * @param	company_id,name_search,created_by_search
     * @return	count of rows
     */
    public function get_my_list_count($company_id, $name_search, $created_by_search) {
        $iTotal = 0;
        $result = array();
        if (!empty($company_id)) {
            $this->db->select("COUNT(l.id) as num_rows");
            $this->db->from("my_lists l");
            $this->db->join("users u", "u.id=l.created_by", "LEFT");
            if (!empty($name_search)) {
                $this->db->where("(LOWER(l.name) LIKE '%$name_search%')");
            }

            if (!empty($search_created_by)) {
                $this->db->where("(LOWER(CONCAT_WS(' ',u.first_name,u.last_name)) LIKE '%$created_by_search%')");
            }
            $this->db->where("l.company_id",$company_id);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $result = $query->row();
                $iTotal = $result->num_rows;
            }
        }
        return $iTotal;
    }

    /**
     * My List Detail
     *
     * @access	public
     * @param	list_id
     * @return	Array
     */
    public function get_my_list_details_by_id($list_id) {
        $retarray = array();
        if (!empty($list_id)) {
            $this->db->select("l.id,l.name,DATE_FORMAT(l.created_on,'%m/%d/%Y') as created_on,u.first_name");
            $this->db->from("my_lists l");
            $this->db->join("my_lists_books lb", "l.id=lb.list_id", "LEFT");
            $this->db->join("users u", "u.id=l.created_by");
            $this->db->where("l.id",$list_id);
            $this->db->group_by('l.id');
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Check list name
     *
     * @access	public
     * @param	list_name,list_id
     * @return	boolean
     */
    public function check_list_name_by_id($list_name, $list_id) {
        $retarray = array();
        if (!empty($list_id) && !empty($list_name)) {
            $this->db->where("id<>", $list_id);
            $this->db->where("LOWER(name)", strtolower($list_name));
            $query = $this->db->get("my_lists");
            if ($query->num_rows() > 0) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }

    /**
     * Update list name
     *
     * @access	public
     * @param	list_data,list_id
     * @return	NA
     */
    public function update_list_name($list_data, $list_id) {
        if (!empty($list_id) && (is_array($list_data) && count($list_data) > 0)) {
            $this->db->where("id", $list_id);
            $this->db->update("my_lists", $list_data);
        }
    }

    /**
     * Book Details of my lists
     *
     * @access	public
     * @param	retailer_id,list_id, pageStart, pageLimit, search_title, search_author, search_publisher
     * @return	Array
     */
    public function get_book_details_by_list_id($retailer_id, $list_id, $pageStart, $pageLimit, $search_title, $search_author, $search_publisher) {
        $retarray = array();
        $bookidarray = array();
        $path = realpath(PUBPATH . '../assets/images/bookcovers');
        if (!empty($list_id)) {
            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select("b.id as book_id,b.title,b.cover_image as image,GROUP_CONCAT(DISTINCT cp.name) as author,b.publication_date,b.imprint,cm.name as publisher");
            $this->db->from("my_lists_books lb");
            $this->db->join("books b", "b.id=lb.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("company cm", "cm.id=b.company_id", "LEFT");
            $this->db->join("book_contributors bc", "bc.role_id=1 AND lb.book_id = bc.book_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)", "LEFT");
            $this->db->join("contributors_people cp", "cp.id=bc.person_id", "LEFT");
            $this->db->from("channels_books as cb", "cb.book_id=b.id AND  (cb.deleted_by < 1 OR cb.deleted_by = 0)");
            $this->db->join("channels as c", "cb.channel_id = c.id AND c.status = 1 AND (c.deleted_by < 1 OR c.deleted_by = 0)");
            $this->db->join("channels_retailers as cr", "c.id = cr.channel_id AND (cr.deleted_by < 1 OR cr.deleted_by = 0)", "LEFT");
            $this->db->join("users as u", "u.id=$retailer_id AND u.status = 1");
            $this->db->join("currency as cu", "cb.currency_id = cu. id");
            $this->db->join("retailer_preference_country as rpc", "rpc.retailer_id =$retailer_id AND cu.country_id = rpc.country_id");
            $this->db->join("country as cou", "rpc.country_id = cou.id AND cu.country_id = cou.id", "LEFT");
            $this->db->join("retailer_preference_language as rpl", "b.language_id = rpl.language_id AND rpl.retailer_id=$retailer_id");
            $this->db->join("retailer_preference_business_models as rpb", "c.business_model_id = rpb.business_model_id AND rpb.retailer_id=$retailer_id");
            $this->db->join("business_models bm", "bm.id = c.business_model_id");
            $this->db->where("lb.list_id",$list_id);
            $this->db->where("((c.retailers_list='All') OR (c.retailers_list='Whitelist' AND cr.retailer_id =$retailer_id) OR (c.retailers_list='Blacklist' AND cr.retailer_id !=$retailer_id))");
            if (!empty($search_title)) {
                $this->db->where("LOWER(b.title) LIKE '%$search_title%'");
            }
            if (!empty($search_author)) {
                $this->db->where("LOWER(cp.name) LIKE '%$search_author%'");
            }

            if (!empty($search_publisher)) {
                $this->db->where("LOWER(cm.name) LIKE '%$search_publisher%'");
            }

            $this->db->order_by("b.id,rpc.country_id", "DESC");
            $this->db->order_by("cu.seq_no,cu.code", "ASC");
            $this->db->group_by("b.id");
            $this->db->limit($pageLimit, $pageStart);
            $query = $this->db->get();

            if ($query->num_rows() > 0) {
                $bookarr = $query->result_array();
                if (is_array($bookarr) && count($bookarr) > 0) {
                    $c = 0;
                    $d = 0;
                    $cnt = 0;
                    foreach ($bookarr as $key => $val) {
                            $retarray[$c]['book_id'] = $bookarr[$key]['book_id'];
                            $retarray[$c]['title'] = strip_slashes($bookarr[$key]['title']);
                            $retarray[$c]['author'] = $bookarr[$key]['author'];
                            $retarray[$c]['image'] = (!empty($bookarr[$key]['image']) && file_exists($path . '/' . $bookarr[$key]['image'])) ? base_url() . 'assets/images/bookcovers/' . $bookarr[$key]['image'] : base_url() . 'assets/images/bookcovers/img-cover.png';
                            $retarray[$c]['price'] = $this->retailer_catalog_model->get_retailer_catalog_price_by_id($bookarr[$key]['book_id'], $retailer_id);
                            $c++;
                    }
                }
            }
        }
        return strip_slashes($retarray);
    }

    /**
     * Count of Book Details
     *
     * @access	public
     * @param	list_id,search_title, search_author, search_imprint, search_publisher
     * @return	count of rows
     */
    public function get_book_details_count($list_id, $search_title, $search_author, $search_publisher) {
        $iTotal = 0;
        $result = array();
        if (!empty($list_id)) {
            $this->db->select("COUNT(gb.id) as num_rows");
            $this->db->from("my_lists_books lb");
            $this->db->join("books b", "b.id=lb.book_id AND (b.deleted_by < 1 OR b.deleted_by = 0)");
            $this->db->join("company c", "c.id=b.company_id", "LEFT");
            $this->db->join("book_contributors bc", "bc.role_id=1 AND lb.book_id = bc.book_id AND (bc.deleted_by < 1 OR bc.deleted_by = 0)", "LEFT");
            $this->db->join("contributors_people cp", "cp.id=bc.person_id", "LEFT");
            $this->db->where("lb.list_id",$list_id);
            if (!empty($search_title)) {
                $this->db->where("LOWER(b.title) LIKE '%$search_title%'");
            }
            if (!empty($search_author)) {
                $this->db->where("LOWER(cp.name) LIKE '%$search_author%'");
            }

            if (!empty($search_publisher)) {
                $this->db->where("LOWER(c.name) LIKE '%$search_publisher%'");
            }
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $result = $query->row();
                $iTotal = $result->num_rows;
            }
        }
        return $iTotal;
    }

    /**
     * list name
     *
     * @access	public
     * @param	group_array
     * @return	Array
     */
    public function get_lists_name($list_array) {
        $retarray = array();
        if (is_array($list_array) && count($list_array) > 0) {
            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select("GROUP_CONCAT(name) as lists_names");
            $this->db->where_in("id", $list_array);
            $query = $this->db->get('my_lists');
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Check My List name
     *
     * @access	public
     * @param	list name,company_id
     * @return	boolean
     */
    public function check_list_name($list_name, $company_id) {
        if (!empty($company_id)) {
            $this->db->where("company_id",$company_id);
            $this->db->where("name",$list_name);
            $query = $this->db->get('my_lists');
            if ($query->num_rows() > 0) {
                return TRUE;
            } else {
                return FALSE;
            }
        }
    }

    /**
     * Insert list
     *
     * @access	public
     * @param	list data
     * @return	list_id
     */
    public function insert_lists($list_data) {
        $list_id = 0;
        if (is_array($list_data) && count($list_data) > 0) {
            $this->db->insert("my_lists", $list_data);
            $list_id = $this->db->insert_id();
        }
        return $list_id;
    }

    /**
     * Insert lists books
     *
     * @access	public
     * @param	list_book_data
     * @return	NA
     */
    public function insert_lists_books($list_book_data) {
        if (is_array($list_book_data) && count($list_book_data) > 0) {
            $this->db->custom_insert_batch("my_lists_books", $list_book_data);
        }
    }

    /**
     * My Lists books
     *
     * @access	public
     * @param	lists_book_array,list_id
     * @return	Array
     */
    public function get_lists_books($lists_book_array, $list_id) {
        $retarray = array();
        if ((is_array($lists_book_array) && count($lists_book_array) > 0) && !empty($list_id)) {
            $this->db->where_in('book_id', $lists_book_array);
            $this->db->where('list_id', $list_id);
            $query = $this->db->get("my_lists_books");
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * My Lists books
     *
     * @access	public
     * @param	lists_book_array,list_id
     * @return	Array
     */
    public function get_my_lists_book_details_by_id($list_id) {
        $retarray = array();
        if (!empty($list_id)) {
            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select("GROUP_CONCAT(mlb.book_id) as book_ids");
            $this->db->from("my_lists ml");
            $this->db->join("my_lists_books mlb","ml.id=mlb.list_id");
            $this->db->where('ml.id', $list_id);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * My List books by list id
     *
     * @access	public
     * @param	list_array
     * @return	Array
     */
    public function get_lists_books_by_lists_id($list_array) {
        $retarray = array();
        if (is_array($list_array) && count($list_array) > 0) {
            $this->db->where_in('list_id', $list_array);
            $query = $this->db->get("my_lists_books");
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Insert my lists book history
     *
     * @access	public
     * @param	list book data
     * @return	NA
     */
    public function insert_history_lists_books($lists_book_data) {
        if (is_array($lists_book_data) && count($lists_book_data) > 0) {
            $this->db->custom_insert_batch("history_my_lists_books", $lists_book_data);
        }
    }

    /**
     * Insert my list history
     *
     * @access	public
     * @param	group data
     * @return	NA
     */
    public function insert_history_lists($lists_data) {
        if (is_array($lists_data) && count($lists_data) > 0) {
            $this->db->insert_batch("history_my_lists", $lists_data);
        }
    }

    /**
     * Delete lists book
     *
     * @access	public
     * @param	lists_book_array
     * @return	NA
     */
    public function delete_lists_books($lists_book_array,$list_id) {
        if (is_array($lists_book_array) && count($lists_book_array) > 0) {
            $this->db->where_in("book_id", $lists_book_array);
            $this->db->where("list_id", $list_id);
            $this->db->delete("my_lists_books");
        }
    }

    /**
     * Delete lists book by lists id
     *
     * @access	public
     * @param	delete_lists_array
     * @return	NA
     */
    public function delete_lists_books_by_lists_id($delete_lists_array) {
        if (is_array($delete_lists_array) && count($delete_lists_array) > 0) {
            $this->db->where_in("list_id", $delete_lists_array);
            $this->db->delete('my_lists_books');
        }
    }

    /**
     * Delete lists
     *
     * @access	public
     * @param	delete_group_array
     * @return	NA
     */
    public function delete_lists_by_id($delete_lists_array) {
        if (is_array($delete_lists_array) && count($delete_lists_array) > 0) {
            $this->db->where_in("id", $delete_lists_array);
            $this->db->delete('my_lists');
        }
    }

}
