<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Company_profile_model extends CI_Model {

    public function __construct() {
        parent::__construct();
    }

    /**
     * Company details
     *
     * @access	public
     * @param	company_id
     * @return	Array
     */
    public function get_company_details_by_id($company_id) {
        $retarray = array();
        if (!empty($company_id)) {
            $this->db->select("name,address,contact_no,contact_person,bank_name,bank_address,routing_number,"
                    . "account_number,dwolla_account_number,logo");
            $this->db->where("id", $company_id);
            $query = $this->db->get("company");
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

    /**
     * Update company details
     *
     * @access	public
     * @param	company_id,company data
     * @return	NA
     */
    public function update_company_data_by_id($company_data, $company_id) {
        if ((is_array($company_data) && count($company_data) > 0) && !empty($company_id)) {
            $this->db->where("id", $company_id);
            $this->db->update("company", $company_data);
        }
    }

    /**
     * Company Users list
     *
     * @access	public
     * @param	company_id,pageStart,pageLimit,sortField,sortType
     * @return	Array
     */
    public function get_users_data_by_company_id($company_id, $pageStart, $pageLimit, $sortField, $sortType) {
        $retarray = array();
        if (!empty($company_id)) {
            $this->db->select("u.id,u.email,u.first_name,u.last_name,u.is_confirm,u.created_on,CONCAT(u2.first_name,' ',u2.last_name) as created_by,u.status");
            $this->db->from('users u');
            $this->db->join('users u2', 'u2.id=u.invited_by AND u.company_id=u2.company_id', 'LEFT');
            $this->db->where('u.company_id', $company_id);
            $this->db->order_by($sortField, $sortType);
            $this->db->limit($pageLimit, $pageStart);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $retarray = $query->result_array();
            }
        }
        return $retarray;
    }

    /**
     * Insert user details
     *
     * @access	public
     * @param	users_data,modulearray,usertype
     * @return	Array
     */
    public function insert_user_details($users_data, $modulearray, $usertype) {
        $user_id = 0;
        $retarray = array();
        if (!empty($usertype) && (is_array($users_data) && count($users_data) > 0)) {
            $this->db->insert_batch('users', $users_data);
            $total_affected_rows = $this->db->affected_rows();
            $first_id = $this->db->insert_id();
            $last_id = ($first_id + $total_affected_rows - 1);

            if (!empty($first_id) && !empty($last_id)) {
                for ($i = $first_id; $i <= $last_id; $i++) {
                    $retarray[] = $i;
                    if (!empty($modulearray)) {
                        $query = 'INSERT users_module_rights (user_id, module_id, created_on, created_by)
                                           SELECT u.id, m.id, now(), u.invited_by
                                           FROM users u ,modules m
                                           WHERE m.id in(' . $modulearray . ') and m.usertype_id=' . $usertype . ' and u.id=' . $i;
                        $this->db->query($query);
                    }
                }
            }
        }
        return $retarray;
    }

    /**
     * Check email
     *
     * @access	public
     * @param	email
     * @return	Array
     */
    public function email_exists($email) {
        $retarray = array();
        if (!empty($email)) {
            $this->db->simple_query('SET SESSION group_concat_max_len=15000');
            $this->db->select('group_concat(email) as email_exist');
            $this->db->where_in('email', $email);
            $query = $this->db->get('users');
            if ($query->num_rows() > 0) {
                $retarray = $query->row();
            }
        }
        return $retarray;
    }

}
