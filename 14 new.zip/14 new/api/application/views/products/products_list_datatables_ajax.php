<html ng-app="1worldapp">
    <head><title>Angular + Codeigniter Combo Pack</title>
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/css/bootstrap-combined.min.css" />
        <link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css" />
    </head>
    <body>
        <h1>Depression - Medicine Lists</h1>
        <?php $attributes = array('novalidate' => '', 'name' => 'products_lists'); ?>   
        <?php echo form_open('',$attributes); ?>
        <?php echo form_close(); ?>
<!--        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">-->
        <!--<div ng-controller="WithAjaxCtrl as showCase">            
            <table datatable dt-options="showCase.dtOptions" dt-columns="showCase.dtColumns"></table>
        </div>-->
		<div ng-controller="ProductListCtrl">
        	<table id="entry-grid" datatable="" dt-options="dtOptions" dt-columns="dtColumns" class="table table-hover"></table> 
    	</div>
    <script src="//code.jquery.com/jquery-1.11.3.min.js"></script>
    <script src="//cdn.datatables.net/1.10.7/js/jquery.dataTables.min.js"></script>
    <script src="http://code.angularjs.org/1.1.5/angular.min.js"></script>   
    <script src="<?=base_url(); ?>assets/js/angular-datatables.min.js"></script>    
    <script type="text/javascript">
  	var baseurl = "<?=base_url(); ?>";
	</script>
    <script type="text/javascript" src="<?= base_url(); ?>assets/js/products_datatables_ajax.js"></script>

</html>
